<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Warehouse_layout extends MY_Controller {

    private $folder_view = "warehouse_layout";
    private $table_dmvt = ' KHO_DMVT';
    private $table_hop = 'KHO_Hop';
    private $table_hop_vt = ' KHO_Hop_VT';
    private $table_gia = 'KHO_Gia';
    private $table_gia_hop = 'KHO_Gia_Hop';
    private $table_gia_vt = 'KHO_Gia_VT';

    public function __construct() {
        parent::__construct();
        $this->load->model('Users_model');
        $this->data['folder_view'] = $this->folder_view;
        $this->data["dmvt_result"]    = $this->Common_model->get_result($this->table_dmvt,array('Is_Delete != ' => 1));
    }

    public function index(){
    	$sql = "SELECT c.*
                FROM (
                    SELECT tbl1.*
                    FROM {$this->table_gia} AS tbl1 
                    ORDER BY tbl1.Hang DESC,tbl1.Cot DESC, tbl1.ID DESC
                ) AS c 
                GROUP BY c.Name";
        $results = $this->Common_model->query_raw($sql);
        $shelves_box = array();
        if(isset($results) && $results != null){
            foreach($results as $key => $item) {
                $hang = $item['Hang'];
                $cot  = $item['Cot'];
                $temp = array();
                for($i = 0; $i < $hang; $i++) { 
                    for($j = 0; $j < $cot; $j++) { 
                        $shelves = $this->Common_model->get_record($this->table_gia,array(
                            'Name' => $item['Name'],
                            'Hang' => $i + 1,
                            'Cot'  => $j + 1
                        ));
                        if($shelves != null){
                            $temp[$i + 1][$j + 1]['current'] = $shelves;

                            $sql = "SELECT tbl2.*,tbl1.SoLuong
                                FROM {$this->table_gia_vt} AS tbl1 
                                INNER JOIN {$this->table_dmvt} AS tbl2 ON tbl2.ID = tbl1.DMVT_ID
                                WHERE tbl1.Gia_ID = '{$shelves['ID']}'
                                ORDER BY tbl1.ID DESC";
                            $temp[$i + 1][$j + 1]['dmvt'] = $this->Common_model->query_raw($sql);


                            $sql = "SELECT tbl1.*,tbl2.Name AS BoxName
                                FROM {$this->table_gia_hop} AS tbl1 
                                INNER JOIN {$this->table_hop} AS tbl2 ON tbl2.ID = tbl1.Hop_ID
                                WHERE tbl1.Gia_ID = '{$shelves['ID']}'
                                ORDER BY tbl1.ID DESC";
                            $boxs = array();    
                            $boxs['current'] = $this->Common_model->query_raw($sql);
                            if(isset($boxs['current']) && $boxs['current'] != null){
                                foreach ($boxs['current'] as $key1 => $item1) {
                                    $sql = "SELECT tbl3.*,tbl1.SoLuong
                                        FROM {$this->table_hop_vt} AS tbl1 
                                        INNER JOIN {$this->table_dmvt} AS tbl3 ON tbl3.ID = tbl1.DMVT_ID
                                        WHERE tbl1.Hop_ID = '{$item1['Hop_ID']}'
                                        ORDER BY tbl1.ID DESC";
                                    $boxs['current'][$key1]['dmvt'] = $this->Common_model->query_raw($sql);
                                }
                            }
                            $temp[$i + 1][$j + 1]['result'] = $boxs;
                        }
                    }
                }

                $shelves_box[] = array(
                    'current' => $item,
                    'boxs'    => $temp
                );
            }
        }

        $sql_box = "SELECT tbl1.*
                    FROM {$this->table_hop} AS tbl1 
                    WHERE tbl1.ID NOT IN (
                        SELECT tbl1.Hop_ID
                        FROM {$this->table_gia_hop} AS tbl1 
                        INNER JOIN {$this->table_hop} AS tbl2 ON tbl2.ID = tbl1.Hop_ID
                        INNER JOIN {$this->table_gia} AS tbl3 ON tbl3.ID = tbl1.Gia_ID
                    )
                    ORDER BY tbl1.ID DESC";
        $boxs = $this->Common_model->query_raw($sql_box);
        if(isset($boxs) && $boxs != null){
            foreach ($boxs as $key => $item) {
                $sql = "SELECT tbl3.*,tbl1.SoLuong
                    FROM {$this->table_hop_vt} AS tbl1 
                    INNER JOIN {$this->table_dmvt} AS tbl3 ON tbl3.ID = tbl1.DMVT_ID
                    WHERE tbl1.Hop_ID = '{$item['ID']}'
                    ORDER BY tbl1.ID DESC";
                $boxs[$key]['dmvt'] = $this->Common_model->query_raw($sql);
            }
        }
        $this->data["boxs"] = $boxs;
        $this->data['results'] = $shelves_box;
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add_shelves($shelves_id = null){
        $record = $this->Common_model->get_record($this->table_gia,array('ID' => $shelves_id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "'Giá đựng này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('SoLuong', 'Số lượng', 'required');
            $this->form_validation->set_rules('DMVT_ID', 'Danh mục vật tư', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $check = $this->Common_model->get_record($this->table_gia_vt,array('Gia_ID' => $shelves_id,'DMVT_ID' => $data_post['DMVT_ID']));
                if($check != null){
	                $data['status'] = "fail";
	                $data['message'] = "Vật tư này đã tồn tại trong giá đựng.";
	                die(json_encode($data));
	            }
                $colums = $this->db->list_fields($this->table_gia_vt);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert["Gia_ID"]  	= $shelves_id;
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table_gia_vt,$data_insert);  
                if($id > 0){
                	$record = $this->Common_model->get_record($this->table_gia_vt,array("ID" => $id));
                	$dmvt = $this->Common_model->get_record($this->table_dmvt,array("ID" => $record['DMVT_ID']));
                    $record['DMVTName'] = @$dmvt['Name'] == null ? '' : $dmvt['Name'];
                    $html = '<li class="item-dmvt" style="display: list-item;">
								<div>
									<span class="action">
										<a href="'.backend_url($this->folder_view."/edit_shelves/".$shelves_id.'/'.$record['DMVT_ID']).'" class="edit is_ajax"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
										<a href="'.backend_url($this->folder_view."/delete_shelves/".$shelves_id.'/'.$record['DMVT_ID']).'" class="remove is_ajax_delete"><i class="fa fa-times" aria-hidden="true"></i></a>
									</span>
									'.$record['DMVTName'].'
						 		</div>
							</li>';

                    $data['responsive'] = $html;
                    $data['action'] = 'add';
                    $data['status'] = 'success';
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
        	die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add_shelves/".$shelves_id);
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form_shelves",$this->data);
    }

    public function edit_shelves($shelves_id = null,$dmvt_id = null){
        $where = array(
            'Gia_ID'  => $shelves_id,
            'DMVT_ID' => $dmvt_id
        );
        $record = $this->Common_model->get_record($this->table_gia_vt,$where);
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Giá đựng - Vật tư này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('SoLuong', 'Số lượng', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table_gia_vt);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $result = $this->Common_model->update($this->table_gia_vt,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                    $data['status'] = 'success';
                    $data['type'] 	= 'edit';
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit_shelves/".$shelves_id.'/'.$dmvt_id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/form_shelves",$this->data);
    }

    public function delete_shelves($shelves_id = null,$dmvt_id = null){
        $where = array(
            'Gia_ID'  => $shelves_id,
            'DMVT_ID' => $dmvt_id
        );
        $record = $this->Common_model->get_record($this->table_gia_vt,$where);
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Giá - Vật tư này không tồn tại.";
            die(json_encode($data));
        }
        $result = $this->Common_model->delete($this->table_gia_vt,$where);
        if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }

    public function add_box($box_id = null){
        $record = $this->Common_model->get_record($this->table_hop,array('ID' => $box_id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Hộp này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('SoLuong', 'Số lượng', 'required');
            $this->form_validation->set_rules('DMVT_ID', 'Danh mục vật tư', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $check = $this->Common_model->get_record($this->table_hop_vt,array('Hop_ID' => $box_id,'DMVT_ID' => $data_post['DMVT_ID']));
                if($check != null){
	                $data['status'] = "fail";
	                $data['message'] = "Vật tư này đã tồn tại trong hộp.";
	                die(json_encode($data));
	            }

                $colums = $this->db->list_fields($this->table_hop_vt);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert["Hop_ID"]  = $box_id;
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table_hop_vt,$data_insert);  
                if($id > 0){
                	$record = $this->Common_model->get_record($this->table_hop_vt,array("ID" => $id));
                	$dmvt = $this->Common_model->get_record($this->table_dmvt,array("ID" => $record['DMVT_ID']));
                    $record['DMVTName'] = @$dmvt['Name'] == null ? '' : $dmvt['Name'];

                    $html = '<li class="item-dmvt" style="display: list-item;">
								<div>
									<span class="action">
										<a href="'.backend_url($this->folder_view."/edit_box/".$box_id.'/'.$record['DMVT_ID']).'" class="edit is_ajax"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
										<a href="'.backend_url($this->folder_view."/delete_box/".$box_id.'/'.$record['DMVT_ID']).'" class="remove is_ajax_delete"><i class="fa fa-times" aria-hidden="true"></i></a>
									</span>
									'.$record['DMVTName'].'
						 		</div>
							</li>';

                    $data['responsive'] = $html;
                    $data['action'] = 'add';
                    $data['status'] = 'success';
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add_box/".$box_id);
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form_box",$this->data);
    }

    public function edit_box($box_id = null,$dmvt_id = null){
        $where = array(
            'Hop_ID'  => $box_id,
            'DMVT_ID' => $dmvt_id
        );
        $record = $this->Common_model->get_record($this->table_hop_vt,$where);
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "'Hộp - Vật tư này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('SoLuong', 'Số lượng', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table_hop_vt);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $result = $this->Common_model->update($this->table_hop_vt,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                	$data['action'] = 'edit';
                    $data['status'] = 'success';
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit_box/".$box_id.'/'.$dmvt_id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/form_box",$this->data);
    }

    public function delete_box($box_id = null,$dmvt_id = null){
        $where = array(
            'Hop_ID'  => $box_id,
            'DMVT_ID' => $dmvt_id
        );
        $record = $this->Common_model->get_record($this->table_hop_vt,$where);
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "'Hộp - Vật tư này không tồn tại.";
            die(json_encode($data));
        }
        $result = $this->Common_model->delete($this->table_hop_vt,$where);
        if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }
}
