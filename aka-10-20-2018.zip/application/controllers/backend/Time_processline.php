<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Time_processline extends MY_Controller {

    private $folder_view = "time_processline";
    private $table = 'm5_timeprocessline';
    private $table_process = 'm5_process';
    private $table_employee = 'M6_Employee';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
    }

    public function index(){
        $where = " WHERE 1=1 ";
        if($this->input->get("keyword") != null){
            $where .= " AND (tbl2.Name Like '%".addslashes($this->input->get("keyword"))."%' OR tbl3.Name Like '%".addslashes($this->input->get("keyword"))."%') ";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl2.Name AS ProcessName,tbl3.Name AS EmployeeName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_process} AS tbl2 ON tbl2.ID = tbl1.Process_ID
                INNER JOIN {$this->table_employee} AS tbl3 ON tbl3.ID = tbl1.Employee_ID
                $where 
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_process}  AS tbl2 ON tbl2.ID = tbl1.Process_ID
            INNER JOIN {$this->table_employee} AS tbl3 ON tbl3.ID = tbl1.Employee_ID
            $where";

        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('Employee_ID', 'Nhân viên', 'required');
            $this->form_validation->set_rules('Process_ID','Quy trình', 'required');
            $this->form_validation->set_rules('TimeProcess','Thời gian xử lý', 'required');
            $this->form_validation->set_rules('DateGetSample','Ngày lấy mẫu', 'required');
            $this->form_validation->set_rules('NumOfSample','Số lượng mẫu', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $ngaylaymau = str_replace('/', '-', $data_post['DateGetSample']);
                $data_insert["DateGetSample"]  = date('Y-m-d H:i:s',strtotime($ngaylaymau));
                $data_insert["NumOfSample"]  =$this->cover_number($data_post['NumOfSample']);
                $data_insert["TimeProcess"]  =$this->cover_number($data_post['TimeProcess']);
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                    $record = $this->get_record($id);
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $record['DateGetSample'] = date($this->date_format,strtotime($record["DateGetSample"]));
                    $record['NumOfSample'] = number_format($record["NumOfSample"]);
                    $record['TimeProcess'] = number_format($record["TimeProcess"]);
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->data['process'] = $this->Common_model->get_result($this->table_process);
        $this->data['employee'] = $this->Common_model->get_result($this->table_employee);
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Thời gian làm việc không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('Employee_ID', 'Nhân viên', 'required');
            $this->form_validation->set_rules('Process_ID','Quy trình', 'required');
            $this->form_validation->set_rules('TimeProcess','Thời gian xử lý', 'required');
            $this->form_validation->set_rules('DateGetSample','Ngày lấy mẫu', 'required');
            $this->form_validation->set_rules('NumOfSample','Số lượng mẫu', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $ngaylaymau = str_replace('/', '-', $data_post['DateGetSample']);
                $data_update["DateGetSample"]  = date('Y-m-d H:i:s',strtotime($ngaylaymau));
                $data_update["NumOfSample"]  =$this->cover_number($data_post['NumOfSample']);
                $data_update["TimeProcess"]  =$this->cover_number($data_post['TimeProcess']);
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                    $record = $this->get_record($id);
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $record['DateGetSample'] = date($this->date_format,strtotime($record["DateGetSample"]));
                    $record['NumOfSample'] = number_format($record["NumOfSample"]);
                    $record['TimeProcess'] = number_format($record["TimeProcess"]);
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->data['process'] = $this->Common_model->get_result($this->table_process);
        $this->data['employee'] = $this->Common_model->get_result($this->table_employee);
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Thời gian làm việc không tồn tại.";
            die(json_encode($data));
        }
        try{
            $result = $this->Common_model->delete($this->table,array("ID" => $id));
            if($result){
                $data['status'] = 'success';
            }
            else{
                $data['status'] = "fail";
                $data['message'] = "Lỗi không thể xóa được.";
            }
        } catch (Exception $e) {
            $data['status'] = "fail";
            $data['message'] = $e->getMessage();
        }
        die(json_encode($data));
    }

    private function get_record($id = 0){
    	$sql = "SELECT tbl1.*,tbl2.Name AS ProcessName,tbl3.Name AS EmployeeName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_process} AS tbl2 ON tbl2.ID = tbl1.Process_ID
                INNER JOIN {$this->table_employee} AS tbl3 ON tbl3.ID = tbl1.Employee_ID
                WHERE tbl1.ID = '{$id}'";
        $record = $this->Common_model->query_raw_row($sql);
        return $record;
    }
}