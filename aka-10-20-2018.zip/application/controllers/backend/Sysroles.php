<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class sysroles extends MY_Controller {
    private $folder_view = "sysroles";
    public function __construct() {
        parent::__construct();
    }

    public function index(){
        $this->data["table_data"] = $this->Common_model->get_result("Aka_Sys_Roles",array('Is_Sys !=' => 1));
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function create(){
        if($this->input->post()){
            $this->form_validation->set_rules('Role_Title', 'Tên hệ thống', 'required');
            $this->form_validation->set_rules('Status', 'Trạng thái', 'required');
            if ($this->form_validation->run() == TRUE){
                $colums = $this->db->list_fields('Aka_Sys_Roles');
                $data_post = $this->input->post();
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $id = $this->Common_model->add("Aka_Sys_Roles",$data_insert);  
                redirect(backend_url("/".$this->folder_view."/edit/" . $id ."?create=success"));
            }else{
                $this->data['post']['status'] = "error";
                $this->data['post']['error'] = validation_errors();
            }
        }
        $this->load->view($this->backend_asset."/".$this->folder_view."/create",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record("Aka_Sys_Roles",array("ID" => $id,'Is_Sys !=' => 1));
        if($record == null){
            redirect(backend_url("/".$this->folder_view."/"));
        }
        if($this->input->post()){
            $this->form_validation->set_rules('Role_Title', 'Tên hệ thống', 'required');
            $this->form_validation->set_rules('Status', 'Trạng thái', 'required');
            if ($this->form_validation->run() == TRUE){
                $colums = $this->db->list_fields('Aka_Sys_Roles');
                $data_post = $this->input->post();
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $this->Common_model->update("Aka_Sys_Roles",$data_update,array("ID" =>$record["ID"]));  
                redirect(backend_url("/".$this->folder_view."/edit/" . $id. "?edit=success"));
            }else{
                $this->data['post']['error'] = validation_errors();
            }
        }
        $this->data['record'] = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/edit",$this->data);
    }

    public function details($id = null){
        $record = $this->Common_model->get_record("Aka_Sys_Roles",array("ID" => $id,'Is_Sys !=' => 1));
        if($record == null){
            redirect(backend_url("/".$this->folder_view."/"));
        }
        if($this->input->post()){
            $modules = $this->input->post("Modules");
            $allow = $this->input->post("Allow");
            $listParentAllow = [];
            $listUpdate = [];
            if(count($modules) == count($allow)){
                foreach ($modules as $key => $value) {
                    $data_cm = array("Module_ID" => $value, "Role_ID" => $id );
                    $check_record = $this->Common_model->get_record("Aka_Sys_Rules",$data_cm);
                    $record = $this->Common_model->get_record("Aka_Sys_Modules",["ID" => $value]);
                    $data_cm["Is_Allow"] = $allow[$key];
                    if( intval($data_cm["Is_Allow"]) == 1 ){
                        $listParentAllow [] = intval($record["Parent_ID"]);
                    }

                    $data_cm["Updated_At"] = date("Y-m-d h:i:sa");
                    if($check_record == null){
                        $id_r = $this->Common_model->add("Aka_Sys_Rules",$data_cm); 
                        if( intval($data_cm["Is_Allow"]) == 1 )
                            $listUpdate [] = $id_r;
                    }else{
                        $this->Common_model->update("Aka_Sys_Rules",$data_cm,array("ID" =>$check_record["ID"])); 
                        if( intval($data_cm["Is_Allow"]) == 1 )
                            $listUpdate [] = $check_record["ID"];
                    }
                }
                
                foreach ( $listParentAllow as $key => $value) {
                    $data_cm = array("Module_ID" => $value, "Role_ID" => $id );
                    $check_record = $this->Common_model->get_record("Aka_Sys_Rules",$data_cm);
                    if($check_record == null){
                        $data_cm["Is_Allow"] = 1;
                        $listUpdate [] = $this->Common_model->add("Aka_Sys_Rules",$data_cm); 
                    }else{
                        $this->Common_model->update("Aka_Sys_Rules",["Is_Allow" => 1],array("ID" =>$check_record["ID"])); 
                        $listUpdate [] = $check_record["ID"];
                    }
                }
                if($listUpdate ){
                    $this->db->where_not_in('ID', $listUpdate);
                    $this->db->where('Role_ID',$id);
                    $this->db->update("Aka_Sys_Rules",["Is_Allow" => 0]);
                }
            }
            die(json_encode(array('status' => 'success')));
        }
        $this->load->model("Sys_rules_model");
        $in_onlySp = ['0'];
        //if($this->user_info['Is_Lock'] == 1) $in_onlySp[] = '1';
        $record_md = $this->Sys_rules_model->get_data_role_by($id,$in_onlySp);
        $this->data["Role_ID"] = $id;
        $this->data["html_modules"] = $this->render_html_modules($record_md);
        $this->load->view($this->backend_asset."/".$this->folder_view."/details",$this->data);
    }

    public function delete($id = 0){
        $this->Common_model->delete("Aka_Sys_Roles",array("ID" => $id,'Is_Sys !=' => 1));
        redirect(backend_url("/".$this->folder_view."?delete=success"));
    }
    private $index = 1;
    private $html_modules = "";
    private function get_html_modules($data = null,$root = 0,$level = '', $table = true , $activer = -1){
        $termsList = array();
        $new_listdata = array();
        if ($root != 0)
        {
            $level .= '&mdash; &mdash;';
        }
        if ($data != null) { 
            foreach ($data AS $key => $item )
            {
                if ($item['Parent_ID'] == $root)
                {
                    $termsList[] = ($item);
                }
                else
                {
                    $new_listdata[] = ($item);
                }
            }
        }
        if ($termsList != null)
        {
            foreach ($termsList AS $key => $item_2 )
            {
                $active = '';
                if ($activer == $item_2['ID'])
                {
                    $active = 'checked';
                }
                $this->html_modules .= '<tr><td>'.($this->index++).'</td><td>'.$level .'  '.$item_2['Module_Name'].'</td><td>'.$item_2['Module_Url'].'</td><td> <label data-parent="'.$root.'" data-id="'.$item_2['ID'].'">';
                $this->html_modules .=  ($item_2['Is_Allow'] == "1") ? '<input name = "Rules[]" type="checkbox" value = "1" class="js-switch" checked /><input type = "hidden" name = "Allow[]" value="1">' : '<input name="Rules[]" type="checkbox" value = "0" class="js-switch"/><input type = "hidden" name = "Allow[]" value="0">';
                $this->html_modules .= '<input type = "hidden" name = "Modules[]" value="'.$item_2['ID'].'"></label></td></tr>';
                $this->get_html_modules($new_listdata, $item_2['ID'], $level, $table, $activer);
            }
        }
        return $this->html_modules;
    }

    private function render_html_modules($data = null) {
    	$termsList = array();
    	$new_listdata = array();
    	if ($data != null) {
    		foreach ($data as $key => $value) {
    			if ($value['Parent_ID'] == 0) {
    				$count = 0;
    				foreach ($data as $k => $v) {
    					if ($value['ID'] == $v['Parent_ID']) {
    						$count++;
    					}
    				}
    				$value['count'] = $count;
    				$termsList[] = ($value);
    			} else {
    				$new_listdata[] = ($value);
    			}
    		}
    	}
    	$html = '';
    	foreach ($termsList as $key => $value) {
    		$html .= '<tr>';
    		$html .= '<td rowspan="'.$value['count'].'">'.($this->index++).'</td>';
    		$html .= '<td rowspan="'.$value['count'].'">'.$value['Module_Name'].'</td>';
    		foreach ($new_listdata as $k => $v) {
    			if ($value['ID'] == $v['Parent_ID']) {
    				$html .= '<td>'.$v['Module_Name'].'</td>';
    				//$html .= '<td>'.$v['Module_Url'].'</td>';
    				$html .= '<td><label data-parent="'.$value['ID'].'" data-id="'.$v['ID'].'">';
    				$html .= ($v['Is_Allow'] == "1") ? '<input name = "Rules[]" type="checkbox" value = "1" class="js-switch" checked /><input type = "hidden" class="allow" name = "Allow[]" value="1">' : '<input name="Rules[]" type="checkbox" value = "0" class="js-switch"/><input type = "hidden" class="allow" name = "Allow[]" value="0">';
    				$html .= '<input type = "hidden" name = "Modules[]" value="'.$v['ID'].'"></label></td></tr>';
    			}
    		}
    	}
    	$this->html_modules = $html;
    	return $this->html_modules;
    }

    public function active($id){
        $this->Common_model->update("Aka_Sys_Roles",
            array(
                "Status" => 1
            ),
            array(
                "ID"    => $id
            )
        );
        redirect(backend_url("/".$this->folder_view."/?update=success"));
    }

    public function unactive($id){
        $record = $this->Common_model->get_record("Aka_Sys_Roles",array(
                "ID"    => $id
            )
        );
        $status = 0;
        if($record  != null){
            $status = ($record["Status"] == 1) ? 2 : 1;
        }
        $this->Common_model->update("Aka_Sys_Roles",
            array(
                "Status" => $status
            ),
            array(
                "ID"    => $id
            )
        );
        redirect(backend_url("/".$this->folder_view."/?update=success"));
    }
}
