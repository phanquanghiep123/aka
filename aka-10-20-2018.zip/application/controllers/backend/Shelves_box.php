<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Shelves_box extends MY_Controller {

    private $folder_view = "shelves_box";
    private $table = 'KHO_Gia_Hop';
    private $table_box = 'KHO_Hop';
    private $table_shelves = 'KHO_Gia';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
        $this->data["box_result"]    = $this->Common_model->get_result($this->table_box);
        $this->data["shelves_result"]    = $this->Common_model->get_result($this->table_shelves);
        $this->data['header'] = array('Giá đựng - Hàng - Cột','Hộp','Hàng','Cột');
    }

    public function index(){
        $sql = "SELECT c.*
                FROM (
                    SELECT tbl1.*
                    FROM {$this->table_shelves} AS tbl1 
                    ORDER BY tbl1.Hang DESC,tbl1.Cot DESC, tbl1.ID DESC
                ) AS c 
                GROUP BY c.Name";
        $results = $this->Common_model->query_raw($sql);
        $shelves_box = array();
        if(isset($results) && $results != null){
            foreach($results as $key => $item) {
                $hang = $item['Hang'];
                $cot  = $item['Cot'];
                $temp = array();
                for($i = 0; $i < $hang; $i++) { 
                    for($j = 0; $j < $cot; $j++) { 
                        $shelves = $this->Common_model->get_record($this->table_shelves,array(
                            'Name' => $item['Name'],
                            'Hang' => $i + 1,
                            'Cot'  => $j + 1
                        ));
                        if($shelves != null){
                            $sql = "SELECT tbl1.*,tbl2.Name AS BoxName
                                FROM {$this->table} AS tbl1 
                                INNER JOIN {$this->table_box} AS tbl2 ON tbl2.ID = tbl1.Hop_ID
                                WHERE tbl1.Gia_ID = '{$shelves['ID']}'
                                ORDER BY tbl1.ID DESC";
                            $temp[$i + 1][$j + 1]['current'] = $shelves;
                            $temp[$i + 1][$j + 1]['result'] = $this->Common_model->query_raw($sql);
                        }
                    }
                }

                $shelves_box[] = array(
                    'current' => $item,
                    'boxs'    => $temp
                );
            }
        }

        $sql_box = "SELECT tbl1.*
                    FROM {$this->table_box} AS tbl1 
                    WHERE tbl1.ID NOT IN (
                        SELECT tbl1.Hop_ID
                        FROM {$this->table} AS tbl1 
                        INNER JOIN {$this->table_box} AS tbl2 ON tbl2.ID = tbl1.Hop_ID
                        INNER JOIN {$this->table_shelves} AS tbl3 ON tbl3.ID = tbl1.Gia_ID
                    )
                    ORDER BY tbl1.ID DESC";
        $this->data["boxs"] = $this->Common_model->query_raw($sql_box);
        $this->data['results'] = $shelves_box;
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function index_bk(){
        $where = " WHERE tbl1.Is_Delete != '1' ";
        if($this->input->get("Box") != null){
            $where .= " AND tbl1.Hop_ID = '".$this->input->get("Box")."'";
        }
        if($this->input->get("Gia") != null){
            $where .= " AND tbl1.Gia_ID = '".$this->input->get("Gia")."'";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl3.Name AS GiaName,tbl3.Cot AS GiaCot,tbl3.Hang AS GiaHang,tbl2.Name AS BoxName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_box} AS tbl2 ON tbl2.ID = tbl1.Hop_ID
                INNER JOIN {$this->table_shelves} AS tbl3 ON tbl3.ID = tbl1.Gia_ID
                $where 
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_box} AS tbl2 ON tbl2.ID = tbl1.Hop_ID
            INNER JOIN {$this->table_shelves} AS tbl3 ON tbl3.ID = tbl1.Gia_ID
            $where";


        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        $data = array('status' => 'error');
        if($this->input->post()){
            $this->form_validation->set_rules('Gia_ID', 'Giá đựng', 'required');
            $this->form_validation->set_rules('Hop_ID','Hộp', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $shelves = $this->Common_model->get_record($this->table_shelves,array("ID" => $record['Gia_ID']));
                    $record['GiaName'] = @$shelves['Name'] == null ? '' : $shelves['Name'].'-'.$shelves['Hang'].'-'.$shelves['Cot'];
                    $box = $this->Common_model->get_record($this->table_box,array("ID" => $record['Hop_ID']));
                    $record['BoxName'] = @$box['Name'] == null ? '' : $box['Name'];
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
        }
        die(json_encode($data));
        /*$this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
        */
    }

    public function edit(){
        $data = array('status' => 'error');
        $record = $this->Common_model->get_record($this->table,array("Hop_ID" => $this->input->post('Hop_ID'),'Gia_ID' => $this->input->post('Gia_Old')));
        if($this->input->post()){
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Hộp - Vật tư này không tồn tại.";
                die(json_encode($data));
            }
            $check = $this->Common_model->get_record($this->table,array("Hop_ID" => $this->input->post('Hop_ID'),'Gia_ID' => $this->input->post('Gia_New')));
            if(@$check != null){
                $data['status'] = "fail";
                $data['message'] = "Hộp - Vật tư này đã tồn tại.";
                die(json_encode($data));
            }
            $data_update = array('Gia_ID' => $this->input->post('Gia_New') );
            $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
            if($result){
                /*$record = $this->Common_model->get_record($this->table,array("ID" => $record["ID"]));
                $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                $shelves = $this->Common_model->get_record($this->table_shelves,array("ID" => $record['Gia_ID']));
                $record['GiaName'] = @$shelves['Name'] == null ? '' : $shelves['Name'].'-'.$shelves['Hang'].'-'.$shelves['Cot'];
                $box = $this->Common_model->get_record($this->table_box,array("ID" => $record['Hop_ID']));
                $record['BoxName'] = @$box['Name'] == null ? '' : $box['Name'];*/
                $data['status'] = 'success';
                $data['action'] = 'edit';
                $data['responsive'] = $record;
            }
            else{
                $data['status'] = "fail";
                $data['message'] = "Cập nhật thất bại.";
            }
        }
        die(json_encode($data));
        /*
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);*/
    }

    public function delete(){
        $record = $this->Common_model->get_record($this->table,array("Hop_ID" => $this->input->post('Hop_ID'),'Gia_ID' => $this->input->post('Gia_ID')));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Hộp - Vật tư này không tồn tại.";
            die(json_encode($data));
        }
        $result = $this->Common_model->delete($this->table,array("ID" => $record['ID']));
        if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }

    public function export(){
        set_time_limit(0);
        $this->data['is_export'] = true;
        $sql = "SELECT tbl1.*,tbl3.Name AS GiaName,tbl3.Cot AS GiaCot,tbl3.Hang AS GiaHang,tbl2.Name AS BoxName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_box} AS tbl2 ON tbl2.ID = tbl1.Hop_ID
                INNER JOIN {$this->table_shelves} AS tbl3 ON tbl3.ID = tbl1.Gia_ID 
                WHERE tbl1.Is_Delete = '0' 
                ORDER BY tbl1.ID DESC";
        $results = $this->Common_model->query_raw($sql);
        $title = 'Giá đựng - Hộp';
        $header = array('Giá đựng - Hàng - Cột','Hộp','Hàng','Cột');
        $data = array();
        if(isset($results) && $results != null){
            foreach ($results as $key => $item) {
                $data[] = array(
                    $item['GiaName'].'-'.$item['GiaHang'].'-'.$item['GiaCot'],
                    $item['BoxName'],
                    $item['Hang'],
                    $item['Cot']
                );
            }
        }
        export_excel($title,$header,$data);
    }

    public function import(){
        $data = array('status' => 'error');
        if (isset($_FILES["excel"]['name']) && $_FILES["excel"]['name'] != null){
            $mimes = array('xls','xlsx');
            $ext = pathinfo($_FILES['excel']['name'], PATHINFO_EXTENSION);
            if(!in_array($ext,$mimes)){
                $data['message'] = 'Vui lòng chọn excel file.';
                $data['status']  = 'fail';
                die(json_encode($data));
            }

            $upload_path = FCPATH . "/uploads/excel";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, TRUE);
            }
            $config = array();
            $config['upload_path'] = $upload_path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($this->upload->do_upload('excel')){
                $upload_data = $this->upload->data();
                $path_file = $upload_data['full_path'];
                $data_excel = get_data_excel($path_file);
                foreach ($data_excel[0] as $key => $item) {
                    if($item != trim(@$this->data['header'][$key])){
                        $data['message'] = 'Excel file không đúng định dạng.';
                        $data['status']  = 'fail';
                        die(json_encode($data));
                    }
                }
                $data_insert = array();
                foreach ($data_excel as $key => $item) {
                    if($key > 0){
                        $data_shelves = explode('-',@$item[0]);
                        $shelves = $this->Common_model->get_record($this->table_shelves,array(
                            'Name' => @$data_shelves[0],
                            'Hang' => @$data_shelves[1],
                            'Cot' => @$data_shelves[2]
                        ));
                        $box = $this->Common_model->get_record($this->table_box,array('Name' => trim($item[1])));
                        if($box != null && $shelves != null){
                            $data_insert[] = array(
                                'Gia_ID' => $shelves['ID'],
                                'Hop_ID' => $box['ID'],
                                'Hang' => $item[2],
                                'Cot' => $item[3],
                                'Created_At' => date('Y-m-d H:i:s')
                            );
                        }
                    }
                }
                if(count($data_insert) > 0){
                    $this->Common_model->insert_batch_data($this->table,$data_insert);
                }
                $data['status']  = 'success';
                $data['message'] = "Nhập dữ liệu thành công";
                die(json_encode($data));
            }
            else{
                $data['message'] = $this->upload->display_errors();
                $data['status']  = 'fail';
                die(json_encode($data));
            }
        }
        else{
            $data['message'] = 'Vui lòng chọn file muốn nhập.';
            $data['status']  = 'fail';
            die(json_encode($data));
        }
        die(json_encode($data));
    }
}