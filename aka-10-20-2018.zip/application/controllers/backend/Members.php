<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Members extends MY_Controller {

    private $folder_view = "members";
    private $table = 'Aka_Sys_Users';
    private $table_employee = 'M6_Employee';
    private $table_employee_department = 'M6_Employee_Department';
    private $table_department = 'M6_Department';

    public function __construct() {
        parent::__construct();
        $this->load->model('Users_model');
        $this->data['folder_view'] = $this->folder_view;
        $this->data["rols"]    = $this->Common_model->get_result("Aka_Sys_Roles");

        $sql = "SELECT tbl1.*,tbl2.NgayLam,tbl2.Name AS DepartmentName
                FROM {$this->table_employee} AS tbl1 
                LEFT JOIN (
                	SELECT tbl4.*,tbl3.Name
                	FROM {$this->table_department} AS tbl3 
                	INNER JOIN {$this->table_employee_department} AS tbl4 ON tbl4.Department_ID = tbl3.ID
                	ORDER BY tbl4.NgayLam DESC
                ) AS tbl2 ON tbl2.Employee_ID = tbl1.ID
                WHERE tbl1.Is_Active = '1'
                GROUP BY tbl1.ID
                ORDER BY tbl1.ID DESC";

        $this->data["employees"] = $this->Common_model->query_raw($sql);
    }

    public function update_value(){
        /*$results = $this->Common_model->get_result("excel-1");
        foreach ($results as $key => $item) {
            $arr = array(
                'Name'   => trim($item['ho_ten']),
                'Work'   => trim($item['cong_viec']),
                'Gender' => (trim($item['gioi_tinh']) == "Nữ" ? 0 : 1),
                'User_Name'     => 'NV'.$item['stt'],
                'User_Email'    => 'NV'.$item['stt'].'@gmail.com',
                'User_Pwd'      => '',
                'Status'        => 1,
                'Created_At'    => date('Y-m-d H:i:s'),
                'Updated_At'    => date('Y-m-d H:i:s'),
                'Birthday'      => date('Y-m-d',strtotime($item['ngay_sinh'])),
                'Birthplace'    => trim($item['noi_sinh']) == null ? '' : $item['noi_sinh'],
                'Address'       => trim($item['dia_chi']) == null ? '' : $item['dia_chi'],
                'CMND'          => trim($item['cmnd']) == null ? '' : $item['cmnd'],
                'Date_Of_Issue' => $item['ngay_cap'] == null ? '' : $item['ngay_cap'],
                'Issued_By'     => $item['noi_cap']== null ? '' : $item['noi_cap'],
                'Receive'       => $item['tiep_nhan'] == null ? '' : $item['tiep_nhan'],
                'Time_Out_Word' => trim($item['thoi_gian_thoi_viec']) == null ? '' : $item['thoi_gian_thoi_viec'],
                'Educational'   => trim($item['trinh_do_van_hoa']),
                'Phone'         => trim($item['so_dien_thoai']),
                'Department_ID' => '',
            );  

            $position = trim($item['bo_phan']);
            if($position != null){
                $record = $this->Common_model->get_record('Aka_Position',array("Name" => $position));
                if($record != null){
                    $arr['Position_ID'] = $record['ID'];
                }
                else{
                    $data_insert = array(
                        'Name' => $position,
                        'Status' => 1,
                        'Created_At' => date('Y-m-d H:i:s')
                    );
                    $id = $this->Common_model->add('Aka_Position',$data_insert);  
                    if($id > 0){
                        $arr['Position_ID'] = $id;
                    }
                }
            }

            $department = trim($item['chuc_danh']);
            if($department != null){
                $record = $this->Common_model->get_record('Aka_Department',array("Name" => $department));
                if($record != null){
                    $arr['Department_ID'] = $record['ID'];
                }
                else{
                    $data_insert = array(
                        'Name' => $department,
                        'Status' => 1,
                        'Created_At' => date('Y-m-d H:i:s')
                    );
                    $id = $this->Common_model->add('Aka_Department',$data_insert);  
                    if($id > 0){
                        $arr['Department_ID'] = $id;
                    }
                }
            }


            if(trim($item['ho_ten']) != null && trim($item['stt']) != null){
                $id = $this->Common_model->add($this->table,$arr);
            }
        }*/
    }

    public function index(){
    	$where = array();
        $where["tbl1.Is_Sys != "] = "1";
        if($this->input->get("keyword") != null){
            $where["tbl1.Name Like"] = "%".$this->input->get("keyword")."%";
        }
        $per_page = $this->per_page;
        $count_table = $this->Users_model->count($where);
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0 ;    
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = $count_table;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
    	$this->data["results"] = $this->Users_model->get($where,$offset,$per_page);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('User_Name', 'Tên đăng nhập', 'required');
            $this->form_validation->set_rules('User_Pwd', 'Mật khẩu', 'required');
            $this->form_validation->set_rules('Role_ID', 'Quyền', 'required');
            $this->form_validation->set_rules('Employee_ID', 'Nhân viên', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                if($data_post["User_Email"] != null){
                	$record = $this->Common_model->get_record($this->table,array("User_Email" => trim($data_post["User_Email"])));
                	if ($record != null) {
		                $data['status'] = "fail";
		                $data['message'] = "Email này đã tồn tại.";
		                die(json_encode($data));
	                }
                }
                
                $record = $this->Common_model->get_record($this->table,array("User_Name" => trim($data_post["User_Name"])));
                if ($record != null) {
                    $data['status'] = "fail";
                    $data['message'] = "Tên đăng nhập này đã tồn tại.";
                    die(json_encode($data));
                }
                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert['User_Pwd'] = md5(trim($data_post['User_Pwd'])."{:MC:}".$data_post['User_Email']);
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Người dùng này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('User_Name', 'Tên đăng nhập', 'required');
            $this->form_validation->set_rules('Role_ID', 'Quyền', 'required');
            $this->form_validation->set_rules('Employee_ID', 'Nhân viên', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                if($data_post["User_Email"] != null){
	                $check = $this->Common_model->get_record($this->table,array("User_Email" => trim($data_post["User_Email"])));
	                if ($check != null && $check['ID'] != $record['ID']) {
	                    $data['status'] = "fail";
	                    $data['message'] = "Email này đã tồn tại.";
	                    die(json_encode($data));
	                }
	            }

                $check = $this->Common_model->get_record($this->table,array("User_Name" => trim($data_post["User_Name"])));
                if ($check != null && $check['ID'] != $record['ID']) {
                    $data['status'] = "fail";
                    $data['message'] = "Tên đăng nhập này đã tồn tại.";
                    die(json_encode($data));
                }

                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                if($data_post['User_Pwd'] != null){
                    $data_update['User_Pwd'] = md5(trim($data_post['User_Pwd'])."{:MC:}".$data_post['User_Name']);
                }
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Người dùng này không tồn tại.";
            die(json_encode($data));
        }
    	$result = $this->Common_model->delete($this->table,array("ID" => $id));
    	if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }

    public function status($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Người dùng này không tồn tại.";
            die(json_encode($data));
        }
        $data_update = array();
        $data_update['Status'] = ($record['Status'] == 1 ? 0 : 1);
        $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));
        if($result){
            $data['status'] = 'success';
            $data['is_status'] = $data_update['Status']; 
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể cập nhật được.";
        }
        die(json_encode($data));
    }
}