<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Holidays  extends MY_Controller {

    private $folder_view = "holidays";
    private $table = 'm6_holidays';
    private $table_type = 'M2_LoaiHinh';
    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
        $this->data['header'] = array('Tên phòng ban','Mô tả');
    }

    public function index(){
        $year = date("Y");
        if($this->input->get('year') >= date('Y')){
            $year = $this->input->get('year');
        }
        $this->data["result"] = $this->Common_model->get_result($this->table,["year(HolidayDate)" => $year]);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        $data = array('status' => 'error');
        if($this->input->post()){
            $this->form_validation->set_rules('Name', 'Tên', 'required');
            $this->form_validation->set_rules('HolidayDate', 'Ngày', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }     
                }
                if($data_insert["ID"] != 0 ){
                    $id = $data_insert["ID"];
                    unset($data_insert["ID"]);
                    $this->Common_model->update($this->table,$data_insert,["ID" => $id]);  
                    $data['action'] = 'update';
                }else{
                    unset($data_insert["ID"]);
                    $id = $this->Common_model->add($this->table,$data_insert);  
                    $data['action'] = 'add';
                }
                if($id > 0){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $data['responsive'] = $record;
                    $data['status'] = "success";
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
        }
        die(json_encode($data));
    }
    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Ngày nghỉ không tồn tại.";
            die(json_encode($data));
        }
    	$result = $this->Common_model->delete($this->table,array("ID" => $id));
    	if($result){
            $data['status'] = 'success';
            $data['responsive'] = $record;
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }
}