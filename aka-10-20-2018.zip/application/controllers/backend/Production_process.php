<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Production_process extends MY_Controller {

    private $folder_view = "production_process";
    private $table = 'M2_DonGiaSX';
    private $table_plu = 'M2_MaHang';
    private $table_type = 'M2_LoaiHinh';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
        $this->data["plu_result"]    = $this->Common_model->get_result($this->table_plu);
        $this->data["type_result"] = $this->Common_model->get_result($this->table_type);
        $this->data['header'] = array('Mã hàng','Loại hình','Vị trí','Số ngày đợi');
    }

    public function index(){
        $where = " WHERE 1=1 ";
        if($this->input->get("Plu") != null){
            $where .= " AND tbl1.MaHang_ID = '".$this->input->get("Plu")."'";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;

        $sql = "SELECT tbl1.*,tbl2.Name AS PluName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_plu} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
                $where 
                GROUP BY  tbl1.MaHang_ID
                ORDER BY tbl1.ID ASC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(*) AS count
                FROM (
                    SELECT tbl1.ID
                    FROM {$this->table} AS tbl1 
                    INNER JOIN {$this->table_plu} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
                    $where
                    GROUP BY tbl1.MaHang_ID
                ) AS c";

        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $results = $this->Common_model->query_raw($sql);
        if(isset($results) && $results != null){
            foreach ($results as $key => $item) {
                $sql = "SELECT tbl1.*,tbl2.Name AS TypeName
                    FROM {$this->table} AS tbl1 
                    INNER JOIN {$this->table_type} AS tbl2 ON tbl2.ID = tbl1.LoaiHinh_ID
                    WHERE tbl1.MaHang_ID = '{$item['MaHang_ID']}'
                    ORDER BY tbl1.Position ASC";
                $results[$key]['type'] = $this->Common_model->query_raw($sql);
            }
        }
        $this->data['results'] = $results;
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add_more(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('MaHang_ID', 'Mã hàng', 'required');
            if ($this->form_validation->run() == TRUE) {
                $check = true;
                $data_post = $this->input->post();
                $record = $this->Common_model->get_record($this->table,array("MaHang_ID" => $data_post['MaHang_ID']));
                if($record != null){
                	$this->message('Quy trình sản xuất cho mã hàng này đã tồn tại.');
                	redirect(backend_url("/".$this->folder_view."/add_more/"));
                }
                if(@$data_post['delay'] != null){
                    $type = @$data_post['type'];
                    $dongia = @$data_post['dongia'];
                    $total_delay = 0;
                    foreach ($data_post['delay'] as $key => $item) {
                        $total_delay += $item;
                    }

                    foreach ($data_post['delay'] as $key => $item) {
                        $record = $this->Common_model->get_record($this->table,array("MaHang_ID" => $data_post['MaHang_ID'],"LoaiHinh_ID" => @$type[$key]));
                        if(@$record == null){
                            $data_insert = array(
                                'MaHang_ID'  => $this->input->post('MaHang_ID'),
                                'LoaiHinh_ID'=> $type[$key],
                                'Position'   => ($key+1),
                                'Delay'      => ($item > 0 ? $item : 0),
                                'Total_Day_Delay' => $total_delay,
                                'DonGia'     =>  $this->cover_number(@$dongia[$key]),
                                'Created_At' => date('Y-m-d H:i:s')
                            );
                            $this->Common_model->add($this->table,$data_insert);
                            $total_delay -= $item;
                            $check = false;
                        }
                    }
                }
                if($check == true){
                    $this->message('Vui lòng nhập đầu đủ dữ liệu.');
                }
                else{
                    $this->message($this->message_add_succes,'success');
                    redirect(backend_url("/".$this->folder_view."/"));
                }
            }else{
                $this->message(validation_errors());
            }
            redirect(backend_url($this->folder_view.'/add_more/'));
        }
        $this->data['title_page'] = 'Cập nhật dữ liệu';
        $this->load->view($this->backend_asset."/".$this->folder_view."/add-more",$this->data);
    }

    public function edit($plu_id = null){
        $record = $this->Common_model->get_record($this->table_plu,array("ID" => $plu_id));
        if($record == null){
            redirect(backend_url("/".$this->folder_view."/"));
            die();
        }
        if($this->input->post()){
            $check = true;
            $data_post = $this->input->post();
            if(@$data_post['delay'] != null){
                $type = @$data_post['type'];
                $dongia = @$data_post['dongia'];
                $total_delay = 0;
                foreach ($data_post['delay'] as $key => $item) {
                    $total_delay += $item;
                }
                $list_id = array();
                foreach ($data_post['delay'] as $key => $item) {
                    $record = $this->Common_model->get_record($this->table,array("ID" => $data_post['production'][@$key]));
                    if(@$record != null){
                        $data_update = array(
                            'Delay'      => ($item > 0 ? $item : 0),
                            'Total_Day_Delay' => $total_delay,
                            'DonGia'     =>  $this->cover_number(@$dongia[$key])
                        );
                        $this->Common_model->update($this->table,$data_update,array("ID" => $data_post['production'][@$key]));
                        $total_delay -= $item;
                        $check = false;
                        $list_id[] = $data_post['production'][@$key];
                    }
                }
            }
            if($check == true){
                $this->message('Vui lòng nhập đầu đủ dữ liệu.');
            }
            else{
                $this->message($this->message_update_succes,'success');
            }
            redirect(backend_url("/".$this->folder_view."/edit/".$plu_id));
        }
        $sql = "SELECT tbl1.*,tbl2.Name AS TypeName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_type} AS tbl2 ON tbl2.ID = tbl1.LoaiHinh_ID
                WHERE tbl1.MaHang_ID = '{$plu_id}'
                ORDER BY tbl1.Position ASC";
        $this->data['results'] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/edit",$this->data);
    }

    public function delete($plu_id = null){
        $record = $this->Common_model->get_record($this->table_plu,array("ID" => $plu_id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Quy trình sản xuất này không tồn tại.";
            die(json_encode($data));
        }
        $result = $this->Common_model->delete($this->table,array("MaHang_ID" => $plu_id));
        if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }

    public function export(){
        set_time_limit(0);
        $this->data['is_export'] = true;
        $sql = "SELECT tbl1.*,tbl2.Name AS PluName,tbl3.Name AS TypeName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_plu} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
                INNER JOIN {$this->table_type} AS tbl3 ON tbl3.ID = tbl1.LoaiHinh_ID
                ORDER BY tbl1.Position ASC";
        $results = $this->Common_model->query_raw($sql);
        $title = 'Quy trình sản xuất';
        $header = array('Mã hàng','Loại hình','Vị trí','Số ngày đợi');
        $data = array();
        if(isset($results) && $results != null){
            foreach ($results as $key => $item) {
                $data[] = array(
                    $item['PluName'],
                    $item['TypeName'],
                    $item['Position'],
                    $item['Delay']
                );
            }
        }
        export_excel($title,$header,$data);
    }

    public function import(){
        $data = array('status' => 'error');
        if (isset($_FILES["excel"]['name']) && $_FILES["excel"]['name'] != null){
            $mimes = array('xls','xlsx');
            $ext = pathinfo($_FILES['excel']['name'], PATHINFO_EXTENSION);
            if(!in_array($ext,$mimes)){
                $data['message'] = 'Vui lòng chọn excel file.';
                $data['status']  = 'fail';
                die(json_encode($data));
            }

            $upload_path = FCPATH . "/uploads/excel";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, TRUE);
            }
            $config = array();
            $config['upload_path'] = $upload_path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($this->upload->do_upload('excel')){
                $upload_data = $this->upload->data();
                $path_file = $upload_data['full_path'];
                $data_excel = get_data_excel($path_file);
                foreach ($data_excel[0] as $key => $item) {
                    if($item != trim(@$this->data['header'][$key])){
                        $data['message'] = 'Excel file không đúng định dạng.';
                        $data['status']  = 'fail';
                        die(json_encode($data));
                    }
                }
                $data_insert = array();
                foreach ($data_excel as $key => $item) {
                    if($key > 0 && @$item[0] != null && @$item[1] != null && @$item[2] != null){
                        $plu = $this->Common_model->get_record($this->table_plu,array('Name' => trim(@$item[0])));
                        $type = $this->Common_model->get_record($this->table_type,array('Name' => @$item[1]));
                        if($type != null && $plu != null && @$item[2] != null && is_numeric(@$item[2]) && @$item[2] >= 0 && @$item[3] != null && is_numeric(@$item[3]) && @$item[3] >= 0){
                            $check = $this->Common_model->get_record($this->table,array("MaHang_ID" => $plu['ID'],"LoaiHinh_ID" => $type['ID']));
                            if(@$check == null){
                                $data_insert[] = array(
                                    'MaHang_ID' => $plu['ID'],
                                    'LoaiHinh_ID' => $type['ID'],
                                    'Position' => @$item[2],
                                    'Delay' => @$item[3],
                                    'Created_At' => date('Y-m-d H:i:s')
                                );
                            }
                        }
                    }
                }
                if(count($data_insert) > 0){
                    $this->Common_model->insert_batch_data($this->table,$data_insert);
                }
                $data['status']  = 'success';
                $data['message'] = "Nhập dữ liệu thành công";
                die(json_encode($data));
            }
            else{
                $data['message'] = $this->upload->display_errors();
                $data['status']  = 'fail';
                die(json_encode($data));
            }
        }
        else{
            $data['message'] = 'Vui lòng chọn file muốn nhập.';
            $data['status']  = 'fail';
            die(json_encode($data));
        }
        die(json_encode($data));
    }
}