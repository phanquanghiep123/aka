<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Output_estimate extends MY_Controller {

    private $folder_view = "output_estimate";
    private $table = 'm5_output_estimate';
    private $table_mahang = 'M2_MaHang';
    private $table_department= 'M6_Department';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
    }

    public function index(){
        $where = " WHERE 1=1 ";
        if($this->input->get("keyword") != null){
            $where .= " AND (tbl2.Name Like '%".addslashes($this->input->get("keyword"))."%' OR tbl3.Name Like '%".addslashes($this->input->get("keyword"))."%')";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl2.Name AS MaHangName,tbl3.Name AS DepartmentName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_mahang} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
                INNER JOIN {$this->table_department} AS tbl3 ON tbl3.ID = tbl1.Department_ID
                $where 
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_mahang} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID 
            INNER JOIN {$this->table_department} AS tbl3 ON tbl3.ID = tbl1.Department_ID
            $where";

        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('Department_ID', 'Phòng ban', 'required');
            $this->form_validation->set_rules('MaHang_ID','Mã hàng', 'required');
            $this->form_validation->set_rules('SoTram','Số trạm', 'required');
            $this->form_validation->set_rules('SoLuong','Số lượng', 'required');
            $this->form_validation->set_rules('Name','Tiêu đề', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert['SoTram'] = $this->cover_number($data_post["SoTram"]);
                $data_insert['SoLuong'] = $this->cover_number($data_post["SoLuong"]);
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                    $record = $this->get_record($id);
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $record['SoTram'] = number_format($record["SoTram"]);
                    $record['SoLuong'] = number_format($record["SoLuong"]);
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->data['mahang'] = $this->Common_model->get_result($this->table_mahang);
        $this->data['department'] = $this->Common_model->get_result($this->table_department);
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Nhóm này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('Department_ID', 'Phòng ban', 'required');
            $this->form_validation->set_rules('MaHang_ID','Mã hàng', 'required');
            $this->form_validation->set_rules('SoTram','Số trạm', 'required');
            $this->form_validation->set_rules('SoLuong','Số lượng', 'required');
            $this->form_validation->set_rules('Name','Tiêu đề', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $data_update['SoTram'] = $this->cover_number($data_post["SoTram"]);
                $data_update['SoLuong'] = $this->cover_number($data_post["SoLuong"]);
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                    $record = $this->get_record($id);
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $record['SoTram'] = number_format($record["SoTram"]);
                    $record['SoLuong'] = number_format($record["SoLuong"]);
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->data['mahang'] = $this->Common_model->get_result($this->table_mahang);
        $this->data['department'] = $this->Common_model->get_result($this->table_department);
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Ước tính này không tồn tại.";
            die(json_encode($data));
        }
        try{
            $result = $this->Common_model->delete($this->table,array("ID" => $id));
            if($result){
                $data['status'] = 'success';
            }
            else{
                $data['status'] = "fail";
                $data['message'] = "Lỗi không thể xóa được.";
            }
        } catch (Exception $e) {
            $data['status'] = "fail";
            $data['message'] = $e->getMessage();
        }

        die(json_encode($data));
    }

    private function get_record($id = null){
        $sql = "SELECT tbl1.*,tbl2.Name AS MaHangName,tbl3.Name AS DepartmentName
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_mahang} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
            INNER JOIN {$this->table_department} AS tbl3 ON tbl3.ID = tbl1.Department_ID
            WHERE tbl1.ID = '{$id}'";
        $record = $this->Common_model->query_raw_row($sql);
        return $record;
    }
}