<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Process extends MY_Controller {

    private $folder_view = "process";
    private $table = 'm5_process';
    private $table_mahang = 'M2_MaHang';
    private $table_group = 'm5_group';
    private $table_machine = 'm5_machine';
    private $table_request = 'm5_request';
    private $table_level = 'm5_employee_level';
    private $table_process_multimedia = 'm5_process_multimedia';
    private $table_media = 'M_Multimedia';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
        $this->data['header'] = array('Mã màu','Mô tả');
    }

    public function index(){
        $where = " WHERE 1=1 ";
        if($this->input->get("keyword") != null){
            $where .= " AND tbl1.Name Like '%".addslashes($this->input->get("keyword"))."%'";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl2.Name AS MaHangName,tbl3.Name AS GroupName,tbl4.FullName AS MachineName,tbl5.Name AS RequestName,tbl6.Name AS LevelName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_mahang}  AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
                INNER JOIN {$this->table_group}   AS tbl3 ON tbl3.ID = tbl1.Group_ID
                INNER JOIN {$this->table_machine} AS tbl4 ON tbl4.ID = tbl1.Machine_ID
                INNER JOIN {$this->table_request} AS tbl5 ON tbl5.ID = tbl1.Request_ID
                INNER JOIN {$this->table_level}   AS tbl6 ON tbl6.ID = tbl1.Employee_Level_ID
                $where 
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_mahang}  AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
            INNER JOIN {$this->table_group}   AS tbl3 ON tbl3.ID = tbl1.Group_ID
            INNER JOIN {$this->table_machine} AS tbl4 ON tbl4.ID = tbl1.Machine_ID
            INNER JOIN {$this->table_request} AS tbl5 ON tbl5.ID = tbl1.Request_ID
            INNER JOIN {$this->table_level}   AS tbl6 ON tbl6.ID = tbl1.Employee_Level_ID
            $where";

        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('Name', 'Tiêu đề', 'required');
            $this->form_validation->set_rules('Machine_ID','Máy', 'required');
            $this->form_validation->set_rules('Employee_Level_ID','Cấp độ', 'required');
            $this->form_validation->set_rules('Group_ID','Nhóm', 'required');
            $this->form_validation->set_rules('Request_ID','Yêu cầu', 'required');
            $this->form_validation->set_rules('MaHang_ID','Mã hàng', 'required');
            $this->form_validation->set_rules('Color','Màu sắc', 'required');
            $this->form_validation->set_rules('DoKho','Độ khó', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                if(@$data_post['Key_Process'] != null){
                	$record = $this->Common_model->get_record($this->table,array("Key_Process" => $data_post['Key_Process']));
                	if(@$record != null){
                		$data['status'] = "fail";
		                $data['message'] = "Key Process này đã tồn tại.";
		                die(json_encode($data));
                	}
                }

                if($this->check_record($data_post['MaHang_ID'],$data_post['Group_ID'],$data_post['Machine_ID'],$data_post['Request_ID'],$data_post['Employee_Level_ID']) != null ){
                	$data['status'] = "fail";
	                $data['message'] = "Quy trình này đã tồn tại.";
	                die(json_encode($data));
                }

                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                if (isset($_FILES["Image"]['name']) && $_FILES["Image"]['name'] != null){
                    $upload_path = FCPATH . "/uploads/group";
                    if (!is_dir($upload_path)) {
                        mkdir($upload_path, 0755, TRUE);
                    }
                    $file = $_FILES["Image"];
                    $allowed_types = "jpg|png";
                    $upload = upload_flie($upload_path, $allowed_types, $file);
                    if($upload["status"] == "success"){
                        $data_insert["Icon"] = "/uploads/group/".$upload["reponse"]["file_name"];
                    }
                }
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){

                	if(@$data_post['Key_Process'] == null){
                		$data_update = array();
		                $data_update['Key_Process'] = $id;
						$this->Common_model->update($this->table,$data_update,array("ID" => $id));
                	}

                	$upload_path = FCPATH . "/uploads/process/".$id;
                    if (!is_dir($upload_path)) {
                        mkdir($upload_path, 0755, TRUE);
                    }
                    if(isset($_FILES["files"]) && $_FILES["files"] != null){
                        $files = $_FILES;
                        for($i=0; $i < count($files['files']['name']); $i++){

                            $_FILES['file']['name'] = $files['files']['name'][$i];
                            $_FILES['file']['type'] = $files['files']['type'][$i];
                            $_FILES['file']['tmp_name'] = $files['files']['tmp_name'][$i];
                            $_FILES['file']['error'] = $files['files']['error'][$i];
                            $_FILES['file']['size'] = $files['files']['size'][$i];


                            $mimes = array('xls','xlsx','gif','png','jpg','pdf','doc','docx');
                            $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
                            if(in_array($ext,$mimes)){
                                $config = array();
                                $config['upload_path'] = $upload_path;
                                $config['allowed_types'] = '*';
                                $config['remove_spaces'] = TRUE;
                                $this->load->library('upload');
                                $this->upload->initialize($config);
                                if($this->upload->do_upload('file')){
                                    $upload_data = $this->upload->data();
                                    $path_file = "/uploads/process/".$id.'/'.$upload_data["file_name"];
                                    $arr = array(
                                        'Name'     => $upload_data['raw_name'],
                                        'URL'      => $path_file,
                                        'FileType' => $upload_data['file_ext'],
                                        'NgayGio'  => date('Y-m-d H:i:s'),
                                        'Employee_ID' => @$this->user_info['Employee_ID']
                                    );
                                    $media_id = $this->Common_model->add($this->table_media,$arr); 
                                    if($media_id > 0){
                                        $arr = array(
                                            'Multimedia_ID'  => $media_id,
                                            'Process_ID' => $id,
                                            'Name' => $upload_data['raw_name'],
                                        );
                                        $this->Common_model->add($this->table_process_multimedia,$arr); 
                                    }
                                }
                            }
                        }
                    }

                    $record = $this->get_record($id);
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->data['mahang'] = $this->Common_model->get_result($this->table_mahang);
        $this->data['group'] = $this->Common_model->get_result($this->table_group);
        $this->data['machine'] = $this->Common_model->get_result($this->table_machine);
        $this->data['request'] = $this->Common_model->get_result($this->table_request);
        $this->data['level'] = $this->Common_model->get_result($this->table_level);
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Quy trình này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('Name', 'Tiêu đề', 'required');
            $this->form_validation->set_rules('Key_Process','Key Process', 'required');
            $this->form_validation->set_rules('Machine_ID','Máy', 'required');
            $this->form_validation->set_rules('Employee_Level_ID','Cấp độ', 'required');
            $this->form_validation->set_rules('Group_ID','Nhóm', 'required');
            $this->form_validation->set_rules('Request_ID','Yêu cầu', 'required');
            $this->form_validation->set_rules('MaHang_ID','Mã hàng', 'required');
            $this->form_validation->set_rules('Color','Màu sắc', 'required');
            $this->form_validation->set_rules('DoKho','Độ khó', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();

                $check = $this->Common_model->get_record($this->table,array("Key_Process" => $data_post['Key_Process']));
            	if(@$check != null && $check['ID'] != $id){
            		$data['status'] = "fail";
	                $data['message'] = "Key Process này đã tồn tại.";
	                die(json_encode($data));
            	}

            	$check = $this->check_record($data_post['MaHang_ID'],$data_post['Group_ID'],$data_post['Machine_ID'],$data_post['Request_ID'],$data_post['Employee_Level_ID']);
            	if(@$check != null && $check['ID'] != $id){
                	$data['status'] = "fail";
	                $data['message'] = "Quy trình này đã tồn tại.";
	                die(json_encode($data));
                }

                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                if (isset($_FILES["Image"]['name']) && $_FILES["Image"]['name'] != null){
                    $upload_path = FCPATH . "/uploads/group";
                    if (!is_dir($upload_path)) {
                        mkdir($upload_path, 0755, TRUE);
                    }
                    $file = $_FILES["Image"];
                    $allowed_types = "jpg|png";
                    $upload = upload_flie($upload_path, $allowed_types, $file);
                    if($upload["status"] == "success"){
                        $data_update["Icon"] = "/uploads/group/".$upload["reponse"]["file_name"];
                    }
                }
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){

                	$upload_path = FCPATH . "/uploads/process/".$id;
                    if (!is_dir($upload_path)) {
                        mkdir($upload_path, 0755, TRUE);
                    }
                    if(isset($_FILES["files"]) && $_FILES["files"] != null){
                        $files = $_FILES;
                        for($i=0; $i < count($files['files']['name']); $i++){

                            $_FILES['file']['name'] = $files['files']['name'][$i];
                            $_FILES['file']['type'] = $files['files']['type'][$i];
                            $_FILES['file']['tmp_name'] = $files['files']['tmp_name'][$i];
                            $_FILES['file']['error'] = $files['files']['error'][$i];
                            $_FILES['file']['size'] = $files['files']['size'][$i];


                            $mimes = array('xls','xlsx','gif','png','jpg','pdf','doc','docx');
                            $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
                            if(in_array($ext,$mimes)){
                                $config = array();
                                $config['upload_path'] = $upload_path;
                                $config['allowed_types'] = '*';
                                $config['remove_spaces'] = TRUE;
                                $this->load->library('upload');
                                $this->upload->initialize($config);
                                if($this->upload->do_upload('file')){
                                    $upload_data = $this->upload->data();
                                    $path_file = "/uploads/process/".$id.'/'.$upload_data["file_name"];
                                    $arr = array(
                                        'Name'     => $upload_data['raw_name'],
                                        'URL'      => $path_file,
                                        'FileType' => $upload_data['file_ext'],
                                        'NgayGio'  => date('Y-m-d H:i:s'),
                                        'Employee_ID' => @$this->user_info['Employee_ID']
                                    );
                                    $media_id = $this->Common_model->add($this->table_media,$arr); 
                                    if($media_id > 0){
                                        $arr = array(
                                            'Multimedia_ID'  => $media_id,
                                            'Process_ID' => $id,
                                            'Name' => $upload_data['raw_name'],
                                        );
                                        $this->Common_model->add($this->table_process_multimedia,$arr); 
                                    }
                                }
                            }
                        }
                    }

                    $record = $this->get_record($id);
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $sql = "SELECT tbl1.*, tbl3.Name, tbl3.URL
            FROM {$this->table_process_multimedia} AS tbl1 
            INNER JOIN {$this->table_media} AS tbl3 ON tbl3.ID = tbl1.Multimedia_ID
            WHERE tbl1.Process_ID = '$id'
            ORDER BY tbl1.ID DESC";
        $this->data['media']  = $this->Common_model->query_raw($sql);
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->data['mahang'] = $this->Common_model->get_result($this->table_mahang);
        $this->data['group'] = $this->Common_model->get_result($this->table_group);
        $this->data['machine'] = $this->Common_model->get_result($this->table_machine);
        $this->data['request'] = $this->Common_model->get_result($this->table_request);
        $this->data['level'] = $this->Common_model->get_result($this->table_level);
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Quy trình này không tồn tại.";
            die(json_encode($data));
        }
        try{
            $sql = "SELECT tbl1.*, tbl3.Name, tbl3.URL
                FROM {$this->table_process_multimedia} AS tbl1 
                INNER JOIN {$this->table_media} AS tbl3 ON tbl3.ID = tbl1.Multimedia_ID
                WHERE tbl1.Process_ID = '$id'
                ORDER BY tbl1.ID DESC";
            $media = $this->Common_model->query_raw($sql);
            if(isset($media) && $media != null){
            	foreach ($media as $key => $item) {
            		$result = $this->Common_model->delete($this->table_process_multimedia,array("ID" => $item['ID']));
    		        if($result){
    		        	$media_item = $this->Common_model->get_record($this->table_media,array("ID" => $item['Multimedia_ID']));
    		            if(isset($media_item['URL']) && $media_item['URL'] != null){
    		                @unlink(FCPATH.$media_item['URL']);
    		            }
    		            $this->Common_model->delete($this->table_media,array("ID" => $item['Multimedia_ID']));
    		        }
            	}
            }


            $result = $this->Common_model->delete($this->table,array("ID" => $id));
            if($result){
                $data['status'] = 'success';
            }
            else{
                $data['status'] = "fail";
                $data['message'] = "Lỗi không thể xóa được.";
            }
        } catch (Exception $e) {
            $data['status'] = "fail";
            $data['message'] = $e->getMessage();
        }
        die(json_encode($data));
    }

    private function get_record($id = 0){
    	$sql = "SELECT tbl1.*,tbl2.Name AS MaHangName,tbl3.Name AS GroupName,tbl4.FullName AS MachineName,tbl5.Name AS RequestName,tbl6.Name AS LevelName
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_mahang}  AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
            INNER JOIN {$this->table_group}   AS tbl3 ON tbl3.ID = tbl1.Group_ID
            INNER JOIN {$this->table_machine} AS tbl4 ON tbl4.ID = tbl1.Machine_ID
            INNER JOIN {$this->table_request} AS tbl5 ON tbl5.ID = tbl1.Request_ID
            INNER JOIN {$this->table_level}   AS tbl6 ON tbl6.ID = tbl1.Employee_Level_ID
            WHERE tbl1.ID = '{$id}'";
        $record = $this->Common_model->query_raw_row($sql);
        return $record;
    }

    private function check_record($MaHang_ID = 0,$Group_ID = 0,$Machine_ID = 0,$Request_ID = 0,$Employee_Level_ID = 0){
    	$sql = "SELECT tbl1.*,tbl2.Name AS MaHangName,tbl3.Name AS GroupName,tbl4.FullName AS MachineName,tbl5.Name AS RequestName,tbl6.Name AS LevelName
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_mahang}  AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
            INNER JOIN {$this->table_group}   AS tbl3 ON tbl3.ID = tbl1.Group_ID
            INNER JOIN {$this->table_machine} AS tbl4 ON tbl4.ID = tbl1.Machine_ID
            INNER JOIN {$this->table_request} AS tbl5 ON tbl5.ID = tbl1.Request_ID
            INNER JOIN {$this->table_level}   AS tbl6 ON tbl6.ID = tbl1.Employee_Level_ID
            WHERE tbl1.MaHang_ID = '{$MaHang_ID}' AND tbl1.Group_ID = '{$Group_ID}' AND tbl1.Machine_ID = '{$Machine_ID}' AND tbl1.Request_ID = '{$Request_ID}' AND tbl1.Employee_Level_ID = '{$Employee_Level_ID}'";
        $record = $this->Common_model->query_raw_row($sql);
        return $record;
    }

    public function remove_media($Process_ID = null,$media_id = null){
    	$record = $this->Common_model->get_record($this->table_process_multimedia,array("ID" => $media_id,'Process_ID' => $Process_ID));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Tập tin này không tồn tại.";
            die(json_encode($data));
        }
        $result = $this->Common_model->delete($this->table_process_multimedia,array("ID" => $media_id));
        if($result){
        	$media = $this->Common_model->get_record($this->table_media,array("ID" => $record['Multimedia_ID']));
            if(isset($media['URL']) && $media['URL'] != null){
                @unlink(FCPATH.$media['URL']);
            }
            $this->Common_model->delete($this->table_media,array("ID" => $record['Multimedia_ID']));
            $data['status'] = 'success';
        }
        die(json_encode($data));
    }

    /*
    public function export(){
        set_time_limit(0);
        $this->data['is_export'] = true;
        $sql = "SELECT tbl1.*,tbl2.Name AS MaHangName
                FROM {$this->table} AS tbl1 
                LEFT JOIN {$this->table_mahang} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
                ORDER BY tbl1.ID DESC";
        $results = $this->Common_model->query_raw($sql);
        $title = 'Nhóm';
        $header = array('Tiêu đề','Mã hàng','Màu sắc','Mô tả');
        $data = array();
        if(isset($results) && $results != null){
            foreach ($results as $key => $item) {
                $data[] = array(
                    $item['MaMau'],
                    $item['MaHangName'],
                    $item['Color'],
                    $item['Description']
                );
            }
        }
        export_excel($title,$header,$data);
    }

    public function import(){
        $data = array('status' => 'error');
        if (isset($_FILES["excel"]['name']) && $_FILES["excel"]['name'] != null){
            $mimes = array('xls','xlsx');
            $ext = pathinfo($_FILES['excel']['name'], PATHINFO_EXTENSION);
            if(!in_array($ext,$mimes)){
                $data['message'] = 'Vui lòng chọn excel file.';
                $data['status']  = 'fail';
                die(json_encode($data));
            }

            $upload_path = FCPATH . "/uploads/excel";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, TRUE);
            }
            $config = array();
            $config['upload_path'] = $upload_path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($this->upload->do_upload('excel')){
                $upload_data = $this->upload->data();
                $path_file = $upload_data['full_path'];
                $data_excel = get_data_excel($path_file);
                foreach ($data_excel[0] as $key => $item) {
                    if($item != trim(@$this->data['header'][$key])){
                        $data['message'] = 'Excel file không đúng định dạng.';
                        $data['status']  = 'fail';
                        die(json_encode($data));
                    }
                }
                $message = '';
                $data_insert = array();
                foreach ($data_excel as $key => $item) {
                    if($key > 0 && @$item[0] != null){
                        $check = $this->Common_model->get_record($this->table,array("MaMau" => trim($item[0])));
                        if($check != null){
                            $message .= 'Mã màu "'.$item[0].'" đã tồn tại. <br>';
                        }
                        else{
                            $data_insert[] = array(
                                'MaMau' => trim(@$item[0]),
                                'Description' => trim(@$item[1]),
                                'Created_At' => date('Y-m-d H:i:s')
                            );
                        }
                    }
                }
                if(count($data_insert) > 0){
                    $this->Common_model->insert_batch_data($this->table,$data_insert);
                }
                $data['status']  = 'success';
                $data['message'] = "Nhập dữ liệu thành công";
                $data['response'] = $message;
                die(json_encode($data));
            }
            else{
                $data['message'] = $this->upload->display_errors();
                $data['status']  = 'fail';
                die(json_encode($data));
            }
        }
        else{
            $data['message'] = 'Vui lòng chọn file muốn nhập.';
            $data['status']  = 'fail';
            die(json_encode($data));
        }
        die(json_encode($data));
    }*/
}