<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Assemblylinetechnique extends MY_Controller {

    private $folder_view = "assemblylinetechnique";
    private $table = 'm5_assemblylinetechnique';
    private $table_department = 'm5_assemblylinedepartment';
    private $table_process = 'm5_process';
    private $table_scenario = 'm5_scenario';
    private $table_output_estimate = 'm5_output_estimate';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
    }

    public function index(){
        $where = " WHERE 1=1 ";
        if($this->input->get("keyword") != null){
            $where .= " AND (tbl2.Name Like '%".addslashes($this->input->get("keyword"))."%' OR tbl3.Name Like '%".addslashes($this->input->get("keyword"))."%') ";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl2.Name AS ProcessName,tbl3.Name AS ScenarioName,tbl3.SoTram
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_process} AS tbl2 ON tbl2.ID = tbl1.Process_ID
                INNER JOIN {$this->table_scenario} AS tbl3 ON tbl3.ID = tbl1.Scenario_ID
                $where
                GROUP BY tbl1.Scenario_ID
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_process}  AS tbl2 ON tbl2.ID = tbl1.Process_ID
            INNER JOIN {$this->table_scenario} AS tbl3 ON tbl3.ID = tbl1.Scenario_ID
            $where";

        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('Scenario_ID', 'Kịch bản', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $scenario = $this->Common_model->get_record($this->table_scenario,array("ID" => $data_post['Scenario_ID']));
            	$total = $scenario['SoLuong'];
            	$listsoluong = @$data_post['soluong'];
            	$process = @$data_post['process'];

            	for ($i = 1; $i <= $scenario['SoTram']; $i++) { 
            		if(@$process[$i] == null){
            			$data['status'] = "fail";
	                    $data['message'] = "Vui lòng chọn quy trình";
	                    die(json_encode($data));
            		}
            	}

            	$soluong = 0;
            	if(isset($listsoluong) && $listsoluong != null){
            		foreach ($listsoluong as $key => $item) {
            			$soluong += $this->cover_number($item);
            		}
            	}
            	if($total != $soluong){
            		$data['status'] = "fail";
                    $data['message'] = "Số lượng nhập và tổng số lượng không khớp nhau";
                    die(json_encode($data));
            	}

            	if(isset($listsoluong) && $listsoluong != null){
            		foreach ($listsoluong as $workstation_id => $item) {
            			$data_insert = array(
            				'Scenario_ID' 	 => $data_post['Scenario_ID'],
            				'Process_ID' 	 => $process[$workstation_id],
            				'SoLuong' 		 => $this->cover_number($item),
            				'WorkStation_ID' => $workstation_id,
            				'Created_At' 	 => date('Y-m-d H:i:s')
            			);
            			$this->Common_model->add($this->table_department,$data_insert);  
            			$this->Common_model->add($this->table,$data_insert);
            		}
            	}
            	$data['status'] = 'success';
            	$data['url'] = backend_url("/".$this->folder_view."/edit/".$data_post['Scenario_ID']);
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->data['process'] = $this->Common_model->get_result($this->table_process);
        $this->data['scenario'] = $this->Common_model->get_result($this->table_scenario);
        $this->load->view($this->backend_asset."/".$this->folder_view."/add",$this->data);
    }

    public function edit($scenario_id = null){
        $result = $this->get_result($scenario_id);
        if($result == null){
            redirect(backend_url("/".$this->folder_view."/"));
            die();
        }
        if($this->input->post()){
            $this->form_validation->set_rules('soluong[]', 'Số lượng', 'required');
            if($this->form_validation->run() == TRUE){
            	$data_post = $this->input->post();
            	$scenario = $this->Common_model->get_record($this->table_scenario,array("ID" => $scenario_id));
            	$total = $scenario['SoLuong'];
            	$listsoluong = @$data_post['soluong'];
                $process = @$data_post['process'];


                foreach ($process as $id => $item) {
                    if($item == null){
                        $this->session->set_flashdata('record',$this->input->post());
                        $this->message('Vui lòng chọn quy trình');
                        redirect(backend_url("/".$this->folder_view."/edit/".$scenario_id));
                    }
                }


            	$soluong = 0;
            	if(isset($listsoluong) && $listsoluong != null){
            		foreach ($listsoluong as $key => $item) {
            			$soluong += $this->cover_number($item);
            		}
            	}
            	if($total != $soluong){
            		$this->session->set_flashdata('record',$this->input->post());
            		$this->message('Số lượng nhập và tổng số lượng không khớp nhau');
            		redirect(backend_url("/".$this->folder_view."/edit/".$scenario_id));
            	}

            	if(isset($listsoluong) && $listsoluong != null){
            		foreach ($listsoluong as $id => $item) {
            			$data_update = array(
                            'SoLuong'    => $this->cover_number($item),
                            'Process_ID' => $process[$id]
                        );
            			$assemblylinetechnique = $this->Common_model->get_record($this->table,array("ID" => $id));
            			if($assemblylinetechnique != null){
            				$this->Common_model->update($this->table,$data_update,array("ID" => $id));
            				$where = array(
            					'Scenario_ID' 	 => $assemblylinetechnique['Scenario_ID'],
            					'WorkStation_ID' => $assemblylinetechnique['WorkStation_ID']
            				);
            				$this->Common_model->update($this->table_department,$data_update,$where);
            			}
            		}
            	}
            	$this->message($this->message_update_succes,'success');
            }else{
            	$this->session->set_flashdata('record',$this->input->post());
                $this->message(validation_errors());
            }
            redirect(backend_url("/".$this->folder_view."/edit/".$scenario_id));
        }
        $this->data['results']  = $result;
        $scenario = $this->Common_model->get_record($this->table_scenario,array("ID" => $scenario_id));
        $output_estimate = $this->Common_model->get_record($this->table_output_estimate,array("ID" => @$scenario['Output_Estimate_ID']));
        $this->data['process'] = $this->Common_model->get_result($this->table_process,array('MaHang_ID' => @$output_estimate['MaHang_ID']));
        $this->load->view($this->backend_asset."/".$this->folder_view."/edit",$this->data);
    }

    public function delete($scenario_id = 0){
        $record = $this->get_record($scenario_id);
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Kịch bản này không tồn tại.";
            die(json_encode($data));
        }
        try{
            $result = $this->Common_model->delete($this->table,array("Scenario_ID" => $scenario_id));
            if($result){
                $result = $this->Common_model->delete($this->table_department,array("Scenario_ID" => $scenario_id));
                $data['status'] = 'success';
            }
            else{
                $data['status'] = "fail";
                $data['message'] = "Lỗi không thể xóa được.";
            }
        } catch (Exception $e) {
            $data['status'] = "fail";
            $data['message'] = $e->getMessage();
        }
        die(json_encode($data));
    }

    public function get_table($scenario_id = 0){
    	$data = array('status' => 'error','id' => $scenario_id);
    	$scenario = $this->Common_model->get_record($this->table_scenario,array("ID" => $scenario_id));
    	if(@$scenario == null){
    		$data['status'] = 'fail';
    		$data['message'] = 'Kịch bản này không tồn tại.';
    		die(json_encode($data));
    	}
    	$record = $this->get_record($scenario_id);
    	if($record != null){
    		$data['status'] = 'fail';
    		$data['message'] = 'Dây chuyền lắp ráp echo kịch bản này đã tồn tại.';
    		die(json_encode($data));
    	}
    	$output_estimate = $this->Common_model->get_record($this->table_output_estimate,array("ID" => @$scenario['Output_Estimate_ID']));
    	$this->data['process'] = $this->Common_model->get_result($this->table_process,array('MaHang_ID' => @$output_estimate['MaHang_ID']));
    	$this->data['scenario'] = $scenario;
    	$data['status'] = 'success';
    	$data['response'] = $this->load->view($this->backend_asset."/".$this->folder_view."/table",$this->data,true);
    	die(json_encode($data));
    }

    private function get_record($scenario_id = 0){
    	$sql = "SELECT tbl1.*,tbl2.Name AS ProcessName,tbl3.Name AS ScenarioName,tbl3.SoTram
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_process} AS tbl2 ON tbl2.ID = tbl1.Process_ID
                INNER JOIN {$this->table_scenario} AS tbl3 ON tbl3.ID = tbl1.Scenario_ID
                WHERE tbl1.Scenario_ID = '{$scenario_id}' 
                GROUP BY tbl1.Scenario_ID";
        $record = $this->Common_model->query_raw_row($sql);
        return $record;
    }

    private function check_record($scenario_id = 0,$process_id = 0){
    	$sql = "SELECT tbl1.*,tbl2.Name AS ProcessName,tbl3.Name AS ScenarioName,tbl3.SoTram
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_process} AS tbl2 ON tbl2.ID = tbl1.Process_ID
                INNER JOIN {$this->table_scenario} AS tbl3 ON tbl3.ID = tbl1.Scenario_ID
                WHERE tbl1.Scenario_ID = '{$scenario_id}' AND tbl1.Process_ID = '{$process_id}' 
                GROUP BY tbl1.Scenario_ID";
        $record = $this->Common_model->query_raw_row($sql);
        return $record;
    }

    private function get_result($scenario_id = 0){
    	$sql = "SELECT tbl1.*,tbl2.Name AS ProcessName,tbl3.Name AS ScenarioName,tbl3.SoTram,tbl3.SoLuong AS ScenarioSoLuong
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_process} AS tbl2 ON tbl2.ID = tbl1.Process_ID
                INNER JOIN {$this->table_scenario} AS tbl3 ON tbl3.ID = tbl1.Scenario_ID
                WHERE tbl1.Scenario_ID = '{$scenario_id}' 
                ORDER BY tbl1.ID ASC";
        $result = $this->Common_model->query_raw($sql);
        return $result;
    }

}