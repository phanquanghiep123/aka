<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Plu extends MY_Controller {

    private $folder_view = "plu";
    private $table = "M2_MaHang";
    private $table_order = "M2_DonHang";
    private $table_media = 'M_Multimedia';
    private $table_plu_media = 'M2_MaHang_Multimedia';
    private $process = 'm5_process';
    private $relationship = "m5_relationship";
    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
        $this->data["order_result"]    = $this->Common_model->get_result($this->table_order);
        $this->data['header'] = array('Mã đơn hàng','Ngày bắt đầu','Ngày kết thúc','Tổng số lượng','Đơn giá');
    }

    public function index(){
       $where = " WHERE 1=1 ";
        if($this->input->get("keyword") != null){
            $where .= " AND tbl1.Name Like '%".addslashes($this->input->get("keyword"))."%'";
        }
        if($this->input->get("Order") != null){
            $where .= " AND tbl1.DonHang_ID = '".$this->input->get("Order")."'";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl2.MaDonHang
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_order} AS tbl2 ON tbl2.ID = tbl1.DonHang_ID
                $where 
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_order} AS tbl2 ON tbl2.ID = tbl1.DonHang_ID 
            $where";
        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('DonHang_ID','Hợp đồng', 'required');
            $this->form_validation->set_rules('StartDate','Ngày bắt đầu', 'required');
            $this->form_validation->set_rules('EndDate','Ngày kết thúc', 'required');
            $this->form_validation->set_rules('TongSoLuong','Số lượng', 'required');
            $this->form_validation->set_rules('DonGiaHD','Đơn giá', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        if($key == 'StartDate' || $key == 'EndDate'){
                            $data_insert[$key] = date('Y-m-d',strtotime($value));
                        }
                        else if($key == 'TongSoLuong' || $key == 'DonGiaHD'){
                            $data_insert[$key] = $this->cover_number($value);
                        }
                        else{
                            $data_insert[$key] = $value;
                        }
                    }              
                }
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){

                	if(isset($_FILES["files"]) && $_FILES["files"] != null){
	                	$upload_path = FCPATH . "/uploads/contract/".$this->user_info['ID'];
	                    if (!is_dir($upload_path)) {
	                        mkdir($upload_path, 0755, TRUE);
	                    }
	                	$files = $_FILES;
	                	for($i=0; $i < count($files['files']['name']); $i++){

	                		$_FILES['file']['name'] = $files['files']['name'][$i];
					        $_FILES['file']['type'] = $files['files']['type'][$i];
					        $_FILES['file']['tmp_name'] = $files['files']['tmp_name'][$i];
					        $_FILES['file']['error'] = $files['files']['error'][$i];
					        $_FILES['file']['size'] = $files['files']['size'][$i];


	                		$mimes = array('xls','xlsx','gif','png','jpg','pdf','doc','docx');
				            $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
				            if(in_array($ext,$mimes)){
				            	$config = array();
					            $config['upload_path'] = $upload_path;
					            $config['allowed_types'] = '*';
					            $config['remove_spaces'] = TRUE;
					            $this->load->library('upload');
					            $this->upload->initialize($config);
					            if($this->upload->do_upload('file')){
					                $upload_data = $this->upload->data();
			                        $path_file = "/uploads/contract/".$this->user_info['ID'].'/'.$upload_data["file_name"];
			                    	$arr = array(
			                    		'Name' 	   => $upload_data['raw_name'],
			                    		'URL'  	   => $path_file,
			                    		'FileType' => $upload_data['file_ext'],
			                    		'NgayGio'  => date('Y-m-d H:i:s'),
			                    		'Employee_ID' => @$this->user_info['Employee_ID']
			                    	);
			                    	$media_id = $this->Common_model->add($this->table_media,$arr);
			                    	if($media_id > 0){
			                    		$arr = array(
				                    		'Multimedia_ID'  => $media_id,
				                    		'MaHang_ID' => $id
				                    	);
				                    	$this->Common_model->add($this->table_plu_media,$arr); 
			                    	}
			                    }
				            }
	                	}
	                }


                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $record['StartDate'] = date($this->date_format,strtotime($record["StartDate"]));
                    $record['EndDate'] = date($this->date_format,strtotime($record["EndDate"]));
                    $record['TongSoLuong'] = $record['TongSoLuong'] != null ? number_format($record['TongSoLuong']) : '0';
                    $record['DonGiaHD'] = ($record['DonGiaHD'] != null ? number_format($record['DonGiaHD']) : '0').' VNĐ';
                    
                    $order = $this->Common_model->get_record($this->table_order,array("ID" => $record['DonHang_ID']));
                    $record['MaDonHang'] = @$order['MaDonHang'] == null ? '' : $order['MaDonHang'];


                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $today = new DateTime(date("Y-m-d H:i:s"));
                    $datetime1 = new DateTime(str_replace('/','-',$record["StartDate"]));
                    $datetime2 = new DateTime(str_replace('/','-',$record["EndDate"]));
                    $interval = $datetime1->diff($datetime2);
                    $total =  (int)$interval->format('%a'); 
                    $interval = $datetime1->diff($today);
                    $totaltoday =  (int)$interval->format('%a');
                    $status = 0;
                    $progress = '0%';
                    if($total != 0){
                        if($total < $totaltoday){
                            $progress = '100%';
                        }else{
                            $progress = round( ($totaltoday/$total) * 100 ) . "%"; 
                        }
                    }else{
                        $class="progress-bar-success";
                        $progress = '100%';
                    }
                    $record ['Progress'] = $progress;
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($this->input->get("order_id")){
            $this->data['record']["DonHang_ID"]  = $this->input->get("order_id");
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Hợp đồng này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('DonHang_ID','Hợp đồng', 'required');
            $this->form_validation->set_rules('StartDate','Ngày bắt đầu', 'required');
            $this->form_validation->set_rules('EndDate','Ngày kết thúc', 'required');
            $this->form_validation->set_rules('TongSoLuong','Số lượng', 'required');
            $this->form_validation->set_rules('DonGiaHD','Đơn giá', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        if($key == 'StartDate' || $key == 'EndDate'){
                            $data_update[$key] = date('Y-m-d',strtotime($value));
                        }
                        else if($key == 'TongSoLuong' || $key == 'DonGiaHD'){
                            $data_update[$key] = $this->cover_number($value);
                        }
                        else{
                            $data_update[$key] = $value;
                        }
                    }              
                }
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                	if(isset($_FILES["files"]) && $_FILES["files"] != null){
	                	$upload_path = FCPATH . "/uploads/contract/".$this->user_info['ID'];
	                    if (!is_dir($upload_path)) {
	                        mkdir($upload_path, 0755, TRUE);
	                    }
	                	$files = $_FILES;
	                	for($i=0; $i < count($files['files']['name']); $i++){

	                		$_FILES['file']['name'] = $files['files']['name'][$i];
					        $_FILES['file']['type'] = $files['files']['type'][$i];
					        $_FILES['file']['tmp_name'] = $files['files']['tmp_name'][$i];
					        $_FILES['file']['error'] = $files['files']['error'][$i];
					        $_FILES['file']['size'] = $files['files']['size'][$i];


	                		$mimes = array('xls','xlsx','gif','png','jpg','pdf','doc','docx');
				            $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
				            if(in_array($ext,$mimes)){
				            	$config = array();
					            $config['upload_path'] = $upload_path;
					            $config['allowed_types'] = '*';
					            $config['remove_spaces'] = TRUE;
					            $this->load->library('upload');
					            $this->upload->initialize($config);
					            if($this->upload->do_upload('file')){
					                $upload_data = $this->upload->data();
			                        $path_file = "/uploads/contract/".$this->user_info['ID'].'/'.$upload_data["file_name"];
			                    	$arr = array(
			                    		'Name' 	   => $upload_data['raw_name'],
			                    		'URL'  	   => $path_file,
			                    		'FileType' => $upload_data['file_ext'],
			                    		'NgayGio'  => date('Y-m-d H:i:s'),
			                    		'Employee_ID' => @$this->user_info['Employee_ID']
			                    	);
			                    	$media_id = $this->Common_model->add($this->table_media,$arr);
			                    	if($media_id > 0){
			                    		$arr = array(
				                    		'Multimedia_ID'  => $media_id,
				                    		'MaHang_ID' => $record["ID"]
				                    	);
				                    	$this->Common_model->add($this->table_plu_media,$arr); 
			                    	}
			                    }
				            }
	                	}
	                }

                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $record['StartDate'] = date($this->date_format,strtotime($record["StartDate"]));
                    $record['EndDate'] = date($this->date_format,strtotime($record["EndDate"]));
                    $record['TongSoLuong'] = $record['TongSoLuong'] != null ? number_format($record['TongSoLuong']) : '0';
                    $record['DonGiaHD'] = ($record['DonGiaHD'] != null ? number_format($record['DonGiaHD']) : '0').' VNĐ';
                    $order = $this->Common_model->get_record($this->table_order,array("ID" => $record['DonHang_ID']));
                    $record['MaDonHang'] = @$order['MaDonHang'] == null ? '' : $order['MaDonHang'];
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $today = new DateTime(date("Y-m-d H:i:s"));
                    $datetime1 = new DateTime(str_replace('/','-',$record["StartDate"]));
                    $datetime2 = new DateTime(str_replace('/','-',$record["EndDate"]));
                    $interval = $datetime1->diff($datetime2);
                    $total =  (int)$interval->format('%a'); 
                    $interval = $datetime1->diff($today);
                    $totaltoday =  (int)$interval->format('%a');
                    $status = 0;
                    $progress = '0%';
                    if($total != 0){
                        if($total < $totaltoday){
                            $progress = '100%';
                        }else{
                            $progress = round( ($totaltoday/$total) * 100 ) . "%"; 
                        }
                    }else{
                        $class="progress-bar-success";
                        $progress = '100%';
                    }
                    $record ['Progress'] = $progress;
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;

        $sql = "SELECT tbl1.*, tbl3.Name, tbl3.URL
                FROM {$this->table_plu_media} AS tbl1 
                INNER JOIN {$this->table_media} AS tbl3 ON tbl3.ID = tbl1.Multimedia_ID
                WHERE tbl1.MaHang_ID = '$id'
                ORDER BY tbl1.ID DESC";
        $this->data['media']  = $this->Common_model->query_raw($sql);
        
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Mã hàng này không tồn tại.";
            die(json_encode($data));
        }

        $check  = $this->Common_model->get_record('M2_DonGiaSX',array("MaHang_ID" => $id));
        if($check != null){
            $data['status'] = "fail";
            $data['message'] = "Mã hàng đã được sử dụng – Không thể xóa.";
            die(json_encode($data));
        }
        $sql = "SELECT tbl1.*, tbl3.Name, tbl3.URL
                FROM {$this->table_plu_media} AS tbl1 
                INNER JOIN {$this->table_media} AS tbl3 ON tbl3.ID = tbl1.Multimedia_ID
                WHERE tbl1.MaHang_ID = '$id'
                ORDER BY tbl1.ID DESC";
        $media  = $this->Common_model->query_raw($sql);
        if(isset($media) && $media != null){
            foreach ($media as $key => $item) {
                $this->Common_model->delete($this->table_plu_media,array("ID" => $item['ID']));
                $this->Common_model->delete($this->table_media,array("ID" => $item['Multimedia_ID']));
                if(isset($item['URL']) && $item['URL'] != null){
                    @unlink(FCPATH.$item['URL']);
                }
            }
        }
        $result = $this->Common_model->delete($this->table,array("ID" => $id));
        if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }

    public function remove_media($plu_id = null,$media_id = null){
        $record = $this->Common_model->get_record($this->table_plu_media,array("ID" => $media_id,'MaHang_ID' => $plu_id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Tập tin này không tồn tại.";
            die(json_encode($data));
        }
        $result = $this->Common_model->delete($this->table_plu_media,array("ID" => $media_id));
        if($result){
        	$media = $this->Common_model->get_record($this->table_media,array("ID" => $record['Multimedia_ID']));
            if(isset($media['URL']) && $media['URL'] != null){
                @unlink(FCPATH.$media['URL']);
            }
            $this->Common_model->delete($this->table_media,array("ID" => $record['Multimedia_ID']));
            $data['status'] = 'success';
        }
        die(json_encode($data));
    }

    public function view($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Hợp đồng này không tồn tại.";
            die(json_encode($data));
        }
        $this->data['record']  = $record;

        $sql = "SELECT tbl1.*, tbl3.Name, tbl3.URL
                FROM {$this->table_plu_media} AS tbl1 
                INNER JOIN {$this->table_media} AS tbl3 ON tbl3.ID = tbl1.Multimedia_ID
                WHERE tbl1.MaHang_ID = '$id'
                ORDER BY tbl1.ID DESC";
        $this->data['media']  = $this->Common_model->query_raw($sql);

        $data['status'] = 'success';
        $data['response'] = $this->load->view($this->backend_asset."/".$this->folder_view."/view",$this->data,true);
        die(json_encode($data));
    }

    public function export(){
        set_time_limit(0);
        $this->data['is_export'] = true;
        $title = 'Mã hàng';
        $header = array('Mã đơn hàng','Ngày bắt đầu','Ngày kết thúc','Tổng số lượng','Đơn giá');
        $data = array();
        $sql = "SELECT tbl1.*,tbl2.MaDonHang
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_order} AS tbl2 ON tbl2.ID = tbl1.DonHang_ID
                ORDER BY tbl1.ID DESC";
        $results = $this->Common_model->query_raw($sql);
        if(isset($results) && $results != null){
            foreach ($results as $key => $item) {
                $data[] = array(
                    $item['MaDonHang'],
                    date($this->date_format,strtotime($item["StartDate"])),
                    date($this->date_format,strtotime($item["EndDate"])),
                    $item['TongSoLuong'],
                    $item['DonGiaHD']
                );
            }
        }
        export_excel($title,$header,$data);
    }

    public function import(){
        $data = array('status' => 'error');
        if (isset($_FILES["excel"]['name']) && $_FILES["excel"]['name'] != null){
            $mimes = array('xls','xlsx');
            $ext = pathinfo($_FILES['excel']['name'], PATHINFO_EXTENSION);
            if(!in_array($ext,$mimes)){
                $data['message'] = 'Vui lòng chọn excel file.';
                $data['status']  = 'fail';
                die(json_encode($data));
            }

            $upload_path = FCPATH . "/uploads/excel";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, TRUE);
            }
            $config = array();
            $config['upload_path'] = $upload_path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($this->upload->do_upload('excel')){
                $upload_data = $this->upload->data();
                $path_file = $upload_data['full_path'];
                $data_excel = get_data_excel($path_file);
                foreach ($data_excel[0] as $key => $item) {
                    if($item != trim(@$this->data['header'][$key])){
                        $data['message'] = 'Excel file không đúng định dạng.';
                        $data['status']  = 'fail';
                        die(json_encode($data));
                    }
                }
                $data_insert = array();
                foreach ($data_excel as $key => $item) {
                    if($key > 0 && trim(@$item[0]) != null && trim(@$item[1]) != null && trim(@$item[2]) != null && trim(@$item[3]) != null && trim(@$item[4]) != null){
                        $order = $this->Common_model->get_record($this->table_order,array("MaDonHang" => trim($item[0])));
                        if($order != null){
                           $data_insert[] = array(
                                'DonHang_ID' => $order['ID'],
                                'StartDate' => date('Y-m-d',strtotime(str_replace('/', '-', @$item[1]))),
                                'EndDate' => date('Y-m-d',strtotime(str_replace('/', '-', @$item[2]))),
                                'TongSoLuong' => trim(@$item[3]),
                                'DonGiaHD' => trim(@$item[4]),
                                'Created_At' => date('Y-m-d H:i:s')
                            );
                        }
                    }
                }
                if(count($data_insert) > 0){
                    $this->Common_model->insert_batch_data($this->table,$data_insert);
                }
                $data['status']  = 'success';
                $data['message'] = "Nhập dữ liệu thành công";
                die(json_encode($data));
            }
            else{
                $data['message'] = $this->upload->display_errors();
                $data['status']  = 'fail';
                die(json_encode($data));
            }
        }
        else{
            $data['message'] = 'Vui lòng chọn file muốn nhập.';
            $data['status']  = 'fail';
            die(json_encode($data));
        }
        die(json_encode($data));
    }
    public function maps (){
        $id = $this->input->post("id");
        $t = $this->Common_model->get_record($this->table,["ID" => $id]);
        if($t){
            $this->db->select("Name as text,ID as key ,concat(X_Scatter,' ',Y_Scatter) AS location, Color as color");
            $this->db->from($this->process);
            $this->db->where(["MaHang_ID" => $t["ID"]]);
            $process = $this->db->get()->result_array();
            $this->db->select("Key_From_ID AS from,Key_To_ID as to");
            $this->db->from($this->relationship);
            $this->db->where(["MaHang_ID" => $t["ID"]]);
            $relationship = $this->db->get()->result_array();
            $this->data["nodeDataArray"] = $process;
            $this->data["linkDataArray"] = $relationship;
        }
        die(json_encode($this->data));
    }
    public function update(){
        if($this->input->post()){
            $id = $this->input->post("id");
            $r = $this->Common_model->get_record($this->table,["ID" => $id]);
            if($r){
                $nodeDataArray = $this->input->post("nodeDataArray");
                $inID = [0];
                if($nodeDataArray){
                    
                    foreach ($nodeDataArray as $key => $value) {
                        $location = explode(" ",$value["location"]);
                        $update = [
                            "Name" => $value["text"],
                            "X_Scatter" => @$location[0],
                            "Y_Scatter" => @$location[1],
                            "Color" => $value["color"],
                        ];
                        $this->Common_model->update($this->process,$update, ["ID" => $value["key"]]);
                        $inID[] = $value["key"];
                    }
                   

                }
                if($inID){
                    $this->db->where_not_in("ID",$inID);
                }
                $this->db->delete($this->process);
                $relationship  = $this->input->post("relationship");
                $inID = [0];
                if($relationship){
                    
                    foreach ($relationship as $key => $value) {
                        $check = $this->Common_model->get_record($this->relationship,[
                            "MaHang_ID" => $r["ID"],
                            "Key_From_ID" => $value["from"],
                            "Key_To_ID" => $value["to"],
                        ]);
                        if(!$check){
                            $inID[] = $this->Common_model->add($this->relationship,[
                                "MaHang_ID" => $r["ID"],
                                "Key_From_ID" => $value["from"],
                                "Key_To_ID" => $value["to"],
                            ]);
                        }else{
                            $inID[] = $check["ID"];
                        }
                    }
                    
                }
                if($inID){
                    $this->db->where_not_in("ID",$inID);
                }

                $this->db->delete($this->relationship);
                $this->data['status'] = 'success';
            }
        }
        die(json_encode($this->data));
    }
}