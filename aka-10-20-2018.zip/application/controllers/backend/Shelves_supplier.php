<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Shelves_supplier extends MY_Controller {

    private $folder_view = "shelves_supplier";
    private $table = 'KHO_DonGia_NCC_VT';
    private $table_dmvt = 'KHO_DMVT';
    private $table_ncc = 'KHO_NCC';
    private $table_dvt = 'KHO_DVT';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
        
        $sql = "SELECT tbl1.*,tbl2.Name AS NameDVT
                FROM {$this->table_dmvt} AS tbl1 
                INNER JOIN {$this->table_dvt} AS tbl2 ON tbl2.ID = tbl1.DVT_ID";
        $this->data["dmvt_result"]    = $this->Common_model->query_raw($sql);
        $this->data["ncc_result"] = $this->Common_model->get_result($this->table_ncc,array('Is_Delete != ' => 1));
        $this->data['header'] = array('Danh mục vật tư','Đơn vị tính','Đơn giá');
    }

    public function index(){
        $where = "  WHERE tbl1.Is_Delete != '1' ";
        if($this->input->get("NCC") != null){
            $where .= " AND tbl1.NCC_ID = '".$this->input->get("NCC")."'";
        }
        if($this->input->get("DMVT") != null){
            $where .= " AND tbl1.DMVT_ID = '".$this->input->get("DMVT")."'";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl3.Name AS NCCName,tbl2.Name AS DMVTName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_dmvt} AS tbl2 ON tbl2.ID = tbl1.DMVT_ID
                INNER JOIN {$this->table_ncc} AS tbl3 ON tbl3.ID = tbl1.NCC_ID
                $where 
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_dmvt} AS tbl2 ON tbl2.ID = tbl1.DMVT_ID
            INNER JOIN {$this->table_ncc} AS tbl3 ON tbl3.ID = tbl1.NCC_ID
            $where";


        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('DonGia', 'Đơn giá', 'required');
            $this->form_validation->set_rules('DMVT_ID', 'Danh mục vật tư', 'required');
            $this->form_validation->set_rules('NCC_ID','Nhà cung cấp', 'required');
            $this->form_validation->set_rules('Date','Ngày tháng', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert["DonGia"]  = $this->cover_number($data_post['DonGia']);
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Date'] = date($this->date_format,strtotime($record["Date"]));
                    $record['DonGia'] = number_format($record["DonGia"]).'VNĐ';
                    $dmvt = $this->Common_model->get_record($this->table_dmvt,array("ID" => $record['DMVT_ID']));
                    $record['DMVTName'] = @$dmvt['Name'] == null ? '' : $dmvt['Name'];
                    $ncc = $this->Common_model->get_record($this->table_ncc,array("ID" => $record['NCC_ID']));
                    $record['NCCName'] = @$ncc['Name'] == null ? '' : $ncc['Name'];
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Đơn giá NCC - Vật tư này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('DonGia', 'Đơn giá', 'required');
            $this->form_validation->set_rules('DMVT_ID', 'Danh mục vật tư', 'required');
            $this->form_validation->set_rules('NCC_ID','Nhà cung cấp', 'required');
            $this->form_validation->set_rules('Date','Ngày tháng', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $data_update["DonGia"]  = $this->cover_number($data_post['DonGia']);
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Date'] = date($this->date_format,strtotime($record["Date"]));
                    $record['DonGia'] = number_format($record["DonGia"]).'VNĐ';
                    $dmvt = $this->Common_model->get_record($this->table_dmvt,array("ID" => $record['DMVT_ID']));
                    $record['DMVTName'] = @$dmvt['Name'] == null ? '' : $dmvt['Name'];
                    $ncc = $this->Common_model->get_record($this->table_ncc,array("ID" => $record['NCC_ID']));
                    $record['NCCName'] = @$ncc['Name'] == null ? '' : $ncc['Name'];
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Đơn giá NCC - Vật tư này không tồn tại.";
            die(json_encode($data));
        }
        $data_update = array();
        $data_update["Is_Delete"]  = 1;
        $result = $this->Common_model->update($this->table,$data_update,array("ID" => $id));
        //$result = $this->Common_model->delete($this->table,array("ID" => $id));
        if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }

    public function export_excel(){
        set_time_limit(0);
        $this->data['is_export'] = true;
        $data_post = $this->input->post();
        $title = 'Báo giá vật tư';
        $dongia = $this->input->post('dongia');
        $header = array('Nhà cung cấp','Ngày báo giá','Danh mục vật tư','Đơn giá');
        $ncc = $this->Common_model->get_record($this->table_ncc,array('ID' => @$data_post['NCC']));
        $data = array();
        if(isset($dongia) && $dongia != null && @$data_post['Date'] != null && @$ncc['Name'] != null){
            foreach ($dongia as $key => $item) {
                if(isset($item) && $item != null){
                    $dmvt = $this->Common_model->get_record($this->table_dmvt,array('ID' => $key));
                    if($dmvt != null){
                        $data[] = array(
                            $ncc['Name'],
                            date('d/m/Y',strtotime($data_post['Date'])),
                            $dmvt['Name'],
                            $this->cover_number($item)
                        );
                    }
                }
            }
        }
        export_excel($title,$header,$data);
    }

    public function export(){
        set_time_limit(0);
        $this->data['is_export'] = true;
        $sql = "SELECT tbl1.*,tbl3.Name AS NCCName,tbl2.Name AS DMVTName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_dmvt} AS tbl2 ON tbl2.ID = tbl1.DMVT_ID
                INNER JOIN {$this->table_ncc} AS tbl3 ON tbl3.ID = tbl1.NCC_ID 
                WHERE tbl1.Is_Delete = '0' 
                ORDER BY tbl1.ID DESC";
        $results = $this->Common_model->query_raw($sql);
        $title = 'Báo giá NCC Vật tư';
        $header = array('Nhà cung cấp','Danh mục vật tư','Đơn giá','Ngày tháng');
        $data = array();
        if(isset($results) && $results != null){
            foreach ($results as $key => $item) {
                $data[] = array(
                    $item['NCCName'],
                    $item['DMVTName'],
                    $item['DonGia'],
                    date($this->date_format,strtotime($item['Date']))
                );
            }
        }
        export_excel($title,$header,$data);
    }

    public function import(){
        $data = array('status' => 'error');
        $this->form_validation->set_rules('NCC','Nhà cung cấp', 'required');
        $this->form_validation->set_rules('Date','Ngày nhập', 'required');
        if ($this->form_validation->run() == TRUE) {
            $data_post = $this->input->post();
            $dongia = $data_post['dongia'];
            $check = true;
            if(isset($dongia) && $dongia != null){
                foreach ($dongia as $key => $item) {
                    if($item != null && $item != ''){
                        $check = false;
                    }
                }
            }

            if($check){
                $data['status'] = "fail";
                $data['message'] = "Vui lòng nhập đơn giá.";
                die(json_encode($data));
            }


            foreach ($dongia as $key => $item) {
                if($item != null && $item != ''){
                    $arr = array(
                        'NCC_ID' => $data_post['NCC'],
                        'Date' => date('Y-m-d H:i:s',strtotime($data_post['Date'])),
                        'DMVT_ID' => $key,
                        'DonGia' => $this->cover_number($item),
                        'Created_At' => date('Y-m-d H:i:s')
                    );
                    $this->Common_model->add($this->table,$arr);
                } 
            }
            
            $data['status'] = 'success';
            $data['message'] = "Dữ liệu đã được nhập thành công.";
        }else{
            $data['status'] = "fail";
            $data['message'] = validation_errors();
        }
        die(json_encode($data));
    }

    public function import_excel(){
        $data = array('status' => 'error');
        if (isset($_FILES["excel"]['name']) && $_FILES["excel"]['name'] != null){
            $mimes = array('xls','xlsx');
            $ext = pathinfo($_FILES['excel']['name'], PATHINFO_EXTENSION);
            if(!in_array($ext,$mimes)){
                $data['message'] = 'Vui lòng chọn excel file.';
                $data['status']  = 'fail';
                die(json_encode($data));
            }

            $upload_path = FCPATH . "/uploads/excel";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, TRUE);
            }
            $config = array();
            $config['upload_path'] = $upload_path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($this->upload->do_upload('excel')){
                $upload_data = $this->upload->data();
                $path_file = $upload_data['full_path'];
                $this->data['header'] = array('Nhà cung cấp','Ngày báo giá','Danh mục vật tư','Đơn giá');
                $data_excel = get_data_excel($path_file);
                foreach ($data_excel[0] as $key => $item) {
                    if($item != trim(@$this->data['header'][$key])){
                        $data['message'] = 'Excel file không đúng định dạng.';
                        $data['status']  = 'fail';
                        die(json_encode($data));
                    }
                }
                $data_insert = array();
                foreach ($data_excel as $key => $item) {
                    if($key > 0){
                        $ncc = $this->Common_model->get_record($this->table_ncc,array('Name' => trim(@$item[0])));
                        $dmvt = $this->Common_model->get_record($this->table_dmvt,array('Name' => trim(@$item[2])));
                        if($ncc != null && $dmvt != null){
                            $data_insert[] = array(
                                'DMVT_ID' => $dmvt['ID'],
                                'NCC_ID' => $ncc['ID'],
                                'DonGia' => intval(@$item[3]),
                                'Date' => date('Y-m-d',strtotime(str_replace('/', '-', @$item[1]))),
                                'Created_At' => date('Y-m-d H:i:s')
                            );
                        }
                    }
                }
                if(count($data_insert) > 0){
                    $this->Common_model->insert_batch_data($this->table,$data_insert);
                }
                $data['status']  = 'success';
                $data['message'] = "Nhập dữ liệu thành công";
                die(json_encode($data));
            }
            else{
                $data['message'] = $this->upload->display_errors();
                $data['status']  = 'fail';
                die(json_encode($data));
            }
        }
        else{
            $data['message'] = 'Vui lòng chọn file muốn nhập.';
            $data['status']  = 'fail';
            die(json_encode($data));
        }
        die(json_encode($data));
    }
}