<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends My_Controller {

    public function __construct() {
        parent::__construct(); 
    }

    public function index() {
        $this->data["main_page"] = "dashboard";
        $this->load->view($this->backend_asset."/dashboard",$this->data);
    }
    
    public function notuser (){
        $this->load->view($this->backend_asset."/notuser",$this->data);
    }

}
