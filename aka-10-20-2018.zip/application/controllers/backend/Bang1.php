<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Bang1 extends MY_Controller {

    private $folder_view = "bang1";
    private $table = 'Bang1';
    private $table_bang2 = 'Bang2';

    public function __construct() {
        parent::__construct();
        $this->load->model('Users_model');
        $this->data['folder_view'] = $this->folder_view;
        $this->data["bang2_result"]    = $this->Common_model->get_result($this->table_bang2);
    }

    public function index(){
        $where = " WHERE 1=1 ";
        if($this->input->get("keyword") != null){
            $where .= " AND tbl1.ten Like '%".$this->input->get("keyword")."%'";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl2.ten AS ten_bang2
                FROM {$this->table} AS tbl1 
                LEFT JOIN {$this->table_bang2} AS tbl2 ON tbl2.ID = tbl1.Bang2_ID
                $where 
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table} AS tbl1 
            LEFT JOIN {$this->table_bang2} AS tbl2 ON tbl2.ID = tbl1.Bang2_ID 
            $where";

        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('ten', 'Tên', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert["ngay"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['ngay'] = date($this->datetime_format,strtotime($record["ngay"]));
                    $record['status'] = $record['status'] == 1 ? 'Hoạt động' : 'Ngưng hoạt động';
                    $bang2 = $this->Common_model->get_record($this->table_bang2,array("ID" => $record['Bang2_ID']));
                    $record['ten_bang2'] = @$bang2['ten'] == null ? '' : $bang2['ten'];
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Item này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('ten', 'Tên', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['ngay'] = date($this->datetime_format,strtotime($record["ngay"]));
                    $record['status'] = $record['status'] == 1 ? 'Hoạt động' : 'Ngưng hoạt động';
                    $bang2 = $this->Common_model->get_record($this->table_bang2,array("ID" => $record['Bang2_ID']));
                    $record['ten_bang2'] = @$bang2['ten'] == null ? '' : $bang2['ten'];
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Item này không tồn tại.";
            die(json_encode($data));
        }
        $result = $this->Common_model->delete($this->table,array("ID" => $id));
        if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }
}