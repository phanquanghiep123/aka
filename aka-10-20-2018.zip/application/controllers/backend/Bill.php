<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Bill extends MY_Controller {

    private $folder_view = "bill";
    private $table = 'KHO_HoaDon';
    private $table_ncc = 'KHO_NCC';
    private $table_media = 'M_Multimedia';
    private $table_bill_media = 'KHO_HoaDon_Multimedia';
    private $table_nhap = 'KHO_Nhap';
    private $table_dmvt = 'KHO_DMVT';

    public function __construct() {
        parent::__construct();
        $this->load->model('Users_model');
        $this->data['folder_view'] = $this->folder_view;
        $this->data["ncc_result"]    = $this->Common_model->get_result($this->table_ncc);
        $this->data['header'] = array('Nhà cung cấp','Mã hóa đơn','Mô tả','VAT','Phí vận chuyển','Tổng tiền','Trạng thái','Ngày tháng');
    }

    public function index(){
        $where = " WHERE tbl1.Is_Delete != '1' ";
        if($this->input->get("keyword") != null){
            $where .= " AND tbl2.Name Like '%".addslashes($this->input->get("keyword"))."%'";
        }
        if($this->input->get("ncc") != null){
            $where .= " AND tbl1.NCC_ID = '".$this->input->get("ncc")."'";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl2.Name AS NameNCC
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_ncc} AS tbl2 ON tbl2.ID = tbl1.NCC_ID
                $where 
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_ncc} AS tbl2 ON tbl2.ID = tbl1.NCC_ID 
            $where";


        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('Ma_Hoa_Don', 'Mã hóa đơn', 'required');
            $this->form_validation->set_rules('NgayThang', 'Ngày tháng', 'required');
            $this->form_validation->set_rules('Status', 'Trạng thái', 'required');
            $this->form_validation->set_rules('TongSoTien', 'Tổng số tiền', 'required');
            $this->form_validation->set_rules('VAT', 'VAT', 'required');
            $this->form_validation->set_rules('PhiVanChuyen', 'Phí vận chuyển', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $record = $this->Common_model->get_record($this->table,array("Ma_Hoa_Don" => $data_post['Ma_Hoa_Don'],'Is_Delete' => '0'));
                if($record != null){
                    $data['status'] = "fail";
                    $data['message'] = "Mã hóa đơn này đã tồn tại.";
                    die(json_encode($data));
                }

                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                	$data_update = array();
                    $first_barcode = 6;
                    $data_update["Barcode"]  = $this->barcode_id($id,$first_barcode);
                    $this->Common_model->update($this->table,$data_update,array("ID" => $id));

                    if(isset($_FILES["files"]) && $_FILES["files"] != null){
	                	$upload_path = FCPATH . "/uploads/bill/".$this->user_info['ID'];
	                    if (!is_dir($upload_path)) {
	                        mkdir($upload_path, 0755, TRUE);
	                    }
	                	$files = $_FILES;
	                	for($i=0; $i < count($files['files']['name']); $i++){

	                		$_FILES['file']['name'] = $files['files']['name'][$i];
					        $_FILES['file']['type'] = $files['files']['type'][$i];
					        $_FILES['file']['tmp_name'] = $files['files']['tmp_name'][$i];
					        $_FILES['file']['error'] = $files['files']['error'][$i];
					        $_FILES['file']['size'] = $files['files']['size'][$i];


	                		$mimes = array('xls','xlsx','gif','png','jpg','pdf','doc','docx');
				            $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
				            if(in_array($ext,$mimes)){
				            	$config = array();
					            $config['upload_path'] = $upload_path;
					            $config['allowed_types'] = '*';
					            $config['remove_spaces'] = TRUE;
					            $this->load->library('upload');
					            $this->upload->initialize($config);
					            if($this->upload->do_upload('file')){
					                $upload_data = $this->upload->data();
			                        $path_file = "/uploads/bill/".$this->user_info['ID'].'/'.$upload_data["file_name"];
			                    	$arr = array(
			                    		'Name' 	   => $upload_data['raw_name'],
			                    		'URL'  	   => $path_file,
			                    		'FileType' => $upload_data['file_ext'],
			                    		'NgayGio'  => date('Y-m-d H:i:s'),
			                    		'Employee_ID' => @$this->user_info['Employee_ID']
			                    	);
			                    	$media_id = $this->Common_model->add($this->table_media,$arr);
			                    	if($media_id > 0){
			                    		$arr = array(
				                    		'Multimedia_ID'  => $media_id,
				                    		'HoaDon_ID' => $id
				                    	);
				                    	$this->Common_model->add($this->table_bill_media,$arr); 
			                    	}
			                    }
				            }
	                	}
	                }


                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['TongSoTien'] = number_format($record["TongSoTien"]).'VNĐ';
                    $record['PhiVanChuyen'] = number_format($record["PhiVanChuyen"]).'VNĐ';
                    $record['NgayThang'] = date($this->date_format,strtotime($record["NgayThang"]));
                    $record['Status'] = $record['Status'] == 1 ? 'Đã thanh toán' : 'Chưa thanh toán';
                    $record['Image'] = @$record["URL_Image"] != null ? '<img src="'.base_url($record["URL_Image"]).'" style="max-height:60px;">' : '';
                    $ncc = $this->Common_model->get_record($this->table_ncc,array("ID" => $record['NCC_ID']));
                    $record['NameNCC'] = @$ncc['Name'] == null ? '' : $ncc['Name'];
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Hóa đơn này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('Ma_Hoa_Don', 'Mã hóa đơn', 'required');
            $this->form_validation->set_rules('NgayThang', 'Ngày tháng', 'required');
            $this->form_validation->set_rules('Status', 'Trạng thái', 'required');
            $this->form_validation->set_rules('TongSoTien', 'Tổng số tiền', 'required');
            $this->form_validation->set_rules('VAT', 'VAT', 'required');
            $this->form_validation->set_rules('PhiVanChuyen', 'Phí vận chuyển', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                
                $check = $this->Common_model->get_record($this->table,array("Ma_Hoa_Don" => $data_post['Ma_Hoa_Don'],'Is_Delete' => '0'));
                if(@$check != null && $record['ID'] != $check['ID']){
                    $data['status'] = "fail";
                    $data['message'] = "Mã hóa đơn này đã tồn tại.";
                    die(json_encode($data));
                }

                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                    
                    if(isset($_FILES["files"]) && $_FILES["files"] != null){
	                	$upload_path = FCPATH . "/uploads/bill/".$this->user_info['ID'];
	                    if (!is_dir($upload_path)) {
	                        mkdir($upload_path, 0755, TRUE);
	                    }
	                	$files = $_FILES;
	                	for($i=0; $i < count($files['files']['name']); $i++){

	                		$_FILES['file']['name'] = $files['files']['name'][$i];
					        $_FILES['file']['type'] = $files['files']['type'][$i];
					        $_FILES['file']['tmp_name'] = $files['files']['tmp_name'][$i];
					        $_FILES['file']['error'] = $files['files']['error'][$i];
					        $_FILES['file']['size'] = $files['files']['size'][$i];


	                		$mimes = array('xls','xlsx','gif','png','jpg','pdf','doc','docx');
				            $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
				            if(in_array($ext,$mimes)){
				            	$config = array();
					            $config['upload_path'] = $upload_path;
					            $config['allowed_types'] = '*';
					            $config['remove_spaces'] = TRUE;
					            $this->load->library('upload');
					            $this->upload->initialize($config);
					            if($this->upload->do_upload('file')){
					                $upload_data = $this->upload->data();
			                        $path_file = "/uploads/bill/".$this->user_info['ID'].'/'.$upload_data["file_name"];
			                    	$arr = array(
			                    		'Name' 	   => $upload_data['raw_name'],
			                    		'URL'  	   => $path_file,
			                    		'FileType' => $upload_data['file_ext'],
			                    		'NgayGio'  => date('Y-m-d H:i:s'),
			                    		'Employee_ID' => @$this->user_info['Employee_ID'],
			                    	);
			                    	$media_id = $this->Common_model->add($this->table_media,$arr); 
			                    	if($media_id > 0){
			                    		$arr = array(
				                    		'Multimedia_ID'  => $media_id,
				                    		'HoaDon_ID' => $id,
				                    	);
				                    	$this->Common_model->add($this->table_bill_media,$arr); 
			                    	}
			                    }
				            }
	                	}
	                }

                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['TongSoTien'] = number_format($record["TongSoTien"]).'VNĐ';
                    $record['PhiVanChuyen'] = number_format($record["PhiVanChuyen"]).'VNĐ';
                    $record['NgayThang'] = date($this->date_format,strtotime($record["NgayThang"]));
                    $record['Status'] = $record['Status'] == 1 ? 'Đã thanh toán' : 'Chưa thanh toán';
                    $record['Image'] = @$record["URL_Image"] != null ? '<img src="'.base_url($record["URL_Image"]).'" style="max-height:60px;">' : '';
                    $ncc = $this->Common_model->get_record($this->table_ncc,array("ID" => $record['NCC_ID']));
                    $record['NameNCC'] = @$ncc['Name'] == null ? '' : $ncc['Name'];
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);

        $sql = "SELECT tbl1.*, tbl3.Name, tbl3.URL
                FROM {$this->table_bill_media} AS tbl1 
                INNER JOIN {$this->table_media} AS tbl3 ON tbl3.ID = tbl1.Multimedia_ID
                WHERE tbl1.HoaDon_ID = '$id'
                ORDER BY tbl1.ID DESC";
        $this->data['media']  = $this->Common_model->query_raw($sql);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Hóa đơn này không tồn tại.";
            die(json_encode($data));
        }
        $data_update = array();
        $data_update["Is_Delete"]  = 1;
        try{
            $result = $this->Common_model->update($this->table,$data_update,array("ID" => $id));
            //$result = $this->Common_model->delete($this->table,array("ID" => $id));
            if($result){
                //if(isset($record['URL_Image']) && $record['URL_Image'] != null){
                    //@unlink(FCPATH.$record['URL_Image']);
                //}
                $data['status'] = 'success';
            }
            else{
                $data['status'] = "fail";
                $data['message'] = "Lỗi không thể xóa được.";
            }
        } catch (Exception $e) {
            $data['status'] = "fail";
            $data['message'] = $e->getMessage();
        }
        die(json_encode($data));
    }

    public function barcode($id = 0){
        $this->data['is_export'] = true;
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($record == null){
            redirect(backend_url("/".$this->folder_view."/"));
        }
        $string = $record['Ma_Hoa_Don'];
        createbarcode($record['Barcode'],$string,true);
        die();
    }

    public function view($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id,'Is_Delete' => '0'));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Hóa đơn này không tồn tại.";
            die(json_encode($data));
        }
        $this->data['record']  = $record;

        $sql = "SELECT tbl1.*, tbl3.Name, tbl3.URL
                FROM {$this->table_bill_media} AS tbl1 
                INNER JOIN {$this->table_media} AS tbl3 ON tbl3.ID = tbl1.Multimedia_ID
                WHERE tbl1.HoaDon_ID = '$id'
                ORDER BY tbl1.ID DESC";
        $this->data['media']  = $this->Common_model->query_raw($sql);



        $sql = "SELECT tbl1.*, tbl3.Name AS DMVTName
                FROM {$this->table_nhap} AS tbl1 
                INNER JOIN {$this->table_dmvt} AS tbl3 ON tbl3.ID = tbl1.DMVT_ID
                WHERE tbl1.HoaDon_ID = '$id'
                ORDER BY tbl1.ID DESC";

        $this->data['info'] = $this->Common_model->query_raw($sql);
        $data['status'] = 'success';
        $data['response'] = $this->load->view($this->backend_asset."/".$this->folder_view."/view",$this->data,true);
        die(json_encode($data));
    }

    public function remove_media($bill_id = null,$media_id = null){
        $record = $this->Common_model->get_record($this->table_bill_media,array("ID" => $media_id,'HoaDon_ID' => $bill_id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Tập tin này không tồn tại.";
            die(json_encode($data));
        }
        $result = $this->Common_model->delete($this->table_bill_media,array("ID" => $media_id));
        if($result){
        	$media = $this->Common_model->get_record($this->table_media,array("ID" => $record['Multimedia_ID']));
            if(isset($media['URL']) && $media['URL'] != null){
                @unlink(FCPATH.$media['URL']);
            }
            $this->Common_model->delete($this->table_media,array("ID" => $record['Multimedia_ID']));
            $data['status'] = 'success';
        }
        die(json_encode($data));
    }

    public function export(){
        set_time_limit(0);
        $this->data['is_export'] = true;
        $sql = "SELECT tbl1.*,tbl2.Name AS NameNCC
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_ncc} AS tbl2 ON tbl2.ID = tbl1.NCC_ID
                WHERE tbl1.Is_Delete = '0'
                ORDER BY tbl1.ID DESC";
        $results = $this->Common_model->query_raw($sql);
        $title = 'Hóa đơn';
        $header = array('Nhà cung cấp','Mã hóa đơn','Mô tả','VAT','Phí vận chuyển','Tổng tiền','Trạng thái','Ngày tháng');
        $data = array();
        if(isset($results) && $results != null){
            foreach ($results as $key => $item) {
                $data[] = array(
                    $item['NameNCC'],
                    $item['Ma_Hoa_Don'],
                    $item['Description'],
                    $item['VAT'],
                    $item['PhiVanChuyen'],
                    $item['TongSoTien'],
                    ($item['Status'] == 1 ? 'Đã thanh toán' : 'Chưa thanh toán'),
                    date($this->date_format,strtotime($item['NgayThang']))
                );
            }
        }
        export_excel($title,$header,$data);
    }

    public function import(){
        $data = array('status' => 'error');
        if (isset($_FILES["excel"]['name']) && $_FILES["excel"]['name'] != null){
            $mimes = array('xls','xlsx');
            $ext = pathinfo($_FILES['excel']['name'], PATHINFO_EXTENSION);
            if(!in_array($ext,$mimes)){
                $data['message'] = 'Vui lòng chọn excel file.';
                $data['status']  = 'fail';
                die(json_encode($data));
            }

            $upload_path = FCPATH . "/uploads/excel";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, TRUE);
            }
            $config = array();
            $config['upload_path'] = $upload_path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
            $this->upload->initialize($config);
            if($this->upload->do_upload('excel')){
                $upload_data = $this->upload->data();
                $path_file = $upload_data['full_path'];
                $data_excel = get_data_excel($path_file);
                foreach ($data_excel[0] as $key => $item) {
                    if($item != trim(@$this->data['header'][$key])){
                        $data['message'] = 'Excel file không đúng định dạng.';
                        $data['status']  = 'fail';
                        die(json_encode($data));
                    }
                }

                foreach ($data_excel as $key => $item) {
                    if($key > 0){
                        $ncc = $this->Common_model->get_record($this->table_ncc,array('Name' => trim(@$item[0])));
                        if($ncc != null && @$item[1] != null){
                            $check = $this->Common_model->get_record($this->table,array("Ma_Hoa_Don" => trim($item[1]),'Is_Delete' => '0'));
                            if($check != null){
                                $message .= 'Mã hóa đơn "'.$item[0].'" đã tồn tại. <br>';
                            }
                            else{
                                $data_insert = array(
                                    'NCC_ID' => $ncc['ID'],
                                    'Ma_Hoa_Don' => @$item[1],
                                    'Description' => (trim(@$item[2]) == null ? '' : trim($item[2])),
                                    'VAT' => @$item[3],
                                    'PhiVanChuyen' => @$item[4],
                                    'TongSoTien' => @$item[5],
                                    'Status' => (trim(@$item[6]) == 'Đã thanh toán' ? 1 : 0),
                                    'NgayThang' => date('Y-m-d',strtotime(@$item[7])),
                                    'Created_At' => date('Y-m-d H:i:s')
                                );

                                $id = $this->Common_model->add($this->table,$data_insert);  
                                if($id > 0){
                                    $data_update = array();
                                    $first_barcode = 6;
                                    $data_update["Barcode"]  = $this->barcode_id($id,$first_barcode);
                                    $this->Common_model->update($this->table,$data_update,array("ID" => $id));
                                }
                            }
                        }
                    }
                }
                $data['status']  = 'success';
                $data['message'] = "Nhập dữ liệu thành công";
                die(json_encode($data));
            }
            else{
                $data['message'] = $this->upload->display_errors();
                $data['status']  = 'fail';
                die(json_encode($data));
            }
        }
        else{
            $data['message'] = 'Vui lòng chọn file muốn nhập.';
            $data['status']  = 'fail';
            die(json_encode($data));
        }
        die(json_encode($data));
    }
}