<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Warehouse_staff extends MY_Controller {

    private $folder_view = "warehouse_staff";
    private $table = 'KHO_Nhap';
    private $table_tra  = 'KHO_Tra';
    private $table_xuat = 'KHO_Xuat';
    private $table_hoadon = 'KHO_HoaDon';
    private $table_dmvt = 'KHO_DMVT';
    private $table_dvt = 'KHO_DVT';
    private $table_KHO_Gia_VT = 'KHO_Gia_VT';
    private $table_KHO_Hop_VT = 'KHO_Hop_VT';
    private $table_gia = 'KHO_Gia';
    private $table_hop = 'KHO_Hop';

    public function __construct() {
        parent::__construct();
        $this->load->model('Users_model');
        $this->data['folder_view'] = $this->folder_view;
        $this->data["dmvt_result"]    = $this->Common_model->get_result($this->table_dmvt,array('Is_Delete != ' => 1));
        $this->data["gia_result"]    = $this->Common_model->get_result($this->table_gia,array('Is_Delete != ' => 1));
        $this->data["hop_result"]    = $this->Common_model->get_result($this->table_hop,array('Is_Delete != ' => 1));
        $this->data['header'] = array('Danh mục vật tư','Số lượng','Loại vị trí','Vị trí','Trạng thái');
    }

    public function index(){
        $where = " WHERE tbl1.Is_Delete != '1' ";
        if($this->input->get("DMVT") != null){
            $where .= " AND tbl1.DMVT_ID = '".$this->input->get("DMVT")."'";
        }
        if($this->input->get("Status") != null && $this->input->get("Status") != 0){
            $where .= " AND tbl1.Status = '".$this->input->get("Status")."'";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl3.Name AS DMVTName,tbl4.Name AS DVTName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_dmvt} AS tbl3 ON tbl3.ID = tbl1.DMVT_ID
                INNER JOIN {$this->table_dvt} AS tbl4 ON tbl4.ID = tbl3.DVT_ID
                $where
                GROUP BY tbl1.ID
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_dmvt} AS tbl3 ON tbl3.ID = tbl1.DMVT_ID
            INNER JOIN {$this->table_dvt} AS tbl4 ON tbl4.ID = tbl3.DVT_ID
            $where";


        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('DMVT_ID','Danh mục vật tư', 'required');
            $this->form_validation->set_rules('SoLuong','Số lượng', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();

                $gia = @$data_post['gia'];
                $hop = @$data_post['hop'];
                $soluong = 0;
                if($gia != null){
                    foreach ($gia  as $key => $item) {
                        if($item != null && $item > 0){
                            $check_gia = $this->Common_model->get_record($this->table_gia,array('ID' => $key,'Is_Delete' => '0'));
                            if($check_gia != null){
                            	$soluong += $item;
                            	$data_post['Position'] = 1;
                            }
                        }
                    }
                }

                if($hop != null){
                    foreach ($hop as $key => $item) {
                        if($item != null && $item > 0){
                            $check_hop = $this->Common_model->get_record($this->table_hop,array('ID' => $key,'Is_Delete' => '0'));
                            if($check_hop != null){
                                $soluong += $item;
                                $data_post['Position'] = 1;
                            }
                        }
                    }
                }
                

                if($soluong != 0 && $soluong != $data_post['SoLuong']){
                    $data['status'] = "fail";
                    $data['message'] = "Số lượng xuất và vị trí không trùng nhau.";
                    die(json_encode($data));
                }

                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert['Employee_NVKho_ID'] = $this->user_info["Employee_ID"];
                $data_insert["Status"]  = 2;
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                    $data_update = array();
                    $data_update["Barcode"]  = $this->barcode_id($id);
                    $this->Common_model->update($this->table,$data_update,array("ID" => $id));


                    if($gia != null){
	                    foreach ($gia  as $key => $item) {
	                        if($item != null && $item > 0){
	                            $check_gia = $this->Common_model->get_record($this->table_gia,array('ID' => $key,'Is_Delete' => '0'));
	                            if($check_gia != null){
	                            	$where = array(
	                            		'DMVT_ID' => $data_post['DMVT_ID'],
	                            		'Gia_ID' => $key,
	                            		'Is_Delete' => '0'
	                            	);
	                            	$check_gia_vt = $this->Common_model->get_record($this->table_KHO_Gia_VT,$where);
		                            if($check_gia_vt == null){
		                                $arr = array(
		                                    'Gia_ID' => $key,
		                                    'DMVT_ID' => $data_post['DMVT_ID'],
		                                    'Hang'   => $check_gia['Hang'],
		                                    'Cot'   => $check_gia['Cot'],
		                                    'SoLuong' => $item,
		                                    'Created_At' => date('Y-m-d H:i:s')
		                                );
		                                $check_id = $this->Common_model->add($this->table_KHO_Gia_VT,$arr);
		                            }
		                            else{
		                            	$arr = array(
		                                    'SoLuong' => ($check_gia_vt['SoLuong'] + $item)
		                                );
		                                $result = $this->Common_model->update($this->table_KHO_Gia_VT,$arr,$where);
		                            }


		                            $arr = array(
                                        'Gia_ID' => $key,
                                        'Nhap_ID' => $id,
                                        'SoLuong' => $item,
                                        'Created_At' => date('Y-m-d H:i:s')
                                    );
                                    $this->Common_model->add('KHO_Nhap_Gia',$arr);
	                            }
	                        }
	                    }
	                }

	                if($hop != null){
	                    foreach ($hop as $key => $item) {
	                        if($item != null && $item > 0){
	                            $check_hop = $this->Common_model->get_record($this->table_hop,array('ID' => $key,'Is_Delete' => '0'));
	                            if($check_hop != null){
	                                $where = array(
	                            		'DMVT_ID' => $data_post['DMVT_ID'],
	                            		'Hop_ID' => $key,
	                            		'Is_Delete' => '0'
	                            	);
	                            	$check_hop_vt = $this->Common_model->get_record($this->table_KHO_Hop_VT,$where);
	                            	if($check_hop_vt == null){
		                                $arr = array(
		                                    'Hop_ID' => $key,
		                                    'DMVT_ID' => $data_post['DMVT_ID'],
		                                    'SoLuong' => $item,
		                                    'Created_At' => date('Y-m-d H:i:s')
		                                );
		                                $check_id = $this->Common_model->add($this->table_KHO_Hop_VT,$arr);
		                            }
		                            else{
		                            	$arr = array(
		                                    'SoLuong' => ($check_hop_vt['SoLuong'] + $item)
		                                );
		                                $result = $this->Common_model->update($this->table_KHO_Hop_VT,$arr,$where);
		                            }


		                            $arr = array(
                                        'Hop_ID' => $key,
                                        'Nhap_ID' => $id,
                                        'SoLuong' => $item,
                                        'Created_At' => date('Y-m-d H:i:s')
                                    );
                                    $this->Common_model->add('KHO_Nhap_Hop',$arr);

	                            }
	                        }
	                    }
	                }

                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $record["Status"] = $this->get_status($record["Status"]);
                    $record["Position"] = $this->get_name_position($record["Position"]);
                    $dmvt = $this->Common_model->get_record($this->table_dmvt,array("ID" => $record['DMVT_ID']));
                    $record['DMVTName'] = @$dmvt['Name'] == null ? '' : $dmvt['Name'];

                    $dvt = $this->Common_model->get_record($this->table_dvt,array("ID" => @$dmvt['DVT_ID']));
                    $record['DVTName'] = @$dvt['Name'] == null ? '' : $dvt['Name'];

                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Lần nhập hàng này không tồn tại.";
                die(json_encode($data));
            }

            if($record['Status'] == 3 && $record['Position'] == 1){
                $data['status'] = "fail";
                $data['message'] = "Nhập hàng này đã hoàn thành. Không thể thay đổi.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('DMVT_ID','Danh mục vật tư', 'required');
            $this->form_validation->set_rules('SoLuong','Số lượng', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();


                if($record['Status'] != 2 && $record['DMVT_ID'] != $data_post['DMVT_ID']){
		            $data['status'] = "fail";
		            $data['message'] = "Danh mục vật tư không trùng khớp.";
		            die(json_encode($data));
		        }


                $gia = @$data_post['gia'];
                $hop = @$data_post['hop'];
                $soluong = 0;
                if($gia != null){
                    foreach ($gia  as $key => $item) {
                        if($item != null && $item > 0){
                        	$check_gia = $this->Common_model->get_record($this->table_gia,array('ID' => $key,'Is_Delete' => '0'));
                            if($check_gia != null){
                            	$soluong += $item;
                            }
                        }
                    }
                }

                if($hop != null){
                    foreach ($hop as $key => $item) {
                        if($item != null && $item > 0){
                            $soluong += $item;
                        }
                    }
                }

                if($soluong != 0 && $soluong != $data_post['SoLuong']){
                    $data['status'] = "fail";
                    $data['message'] = "Số lượng xuất và vị trí không trùng nhau.";
                    die(json_encode($data));
                }

                $result_nhap_gia = $this->Common_model->get_result('KHO_Nhap_Gia',array('Nhap_ID' => $id));
		        $result_nhap_hop = $this->Common_model->get_result('KHO_Nhap_Hop',array('Nhap_ID' => $id));
		        
		        //Xóa đi số lượng cũ
		        if(isset($result_nhap_gia) && $result_nhap_gia != null){
		        	foreach ($result_nhap_gia as $key => $item) {
		        		$where = array(
		            		'DMVT_ID' => $record['DMVT_ID'],
		            		'Gia_ID' => $item['Gia_ID'],
		            		'Is_Delete' => '0'
		            	);
		            	$check_gia_vt = $this->Common_model->get_record($this->table_KHO_Gia_VT,$where);
		        		if($check_gia_vt != null && $check_gia_vt['SoLuong'] > $item['SoLuong']){
		        			$arr = array(
			                    'SoLuong' => ($check_gia_vt['SoLuong'] - $item['SoLuong'])
			                );
			                $result = $this->Common_model->update($this->table_KHO_Gia_VT,$arr,$where);
		        		}
		        	}
		        }

		        if(isset($result_nhap_hop) && $result_nhap_hop != null){
		        	foreach ($result_nhap_hop as $key => $item) {
		        		$where = array(
		            		'DMVT_ID' => $record['DMVT_ID'],
		            		'Hop_ID' => $item['Hop_ID'],
		            		'Is_Delete' => '0'
		            	);
		            	$check_hop_vt = $this->Common_model->get_record($this->table_KHO_Hop_VT,$where);
		        		if($check_hop_vt != null && $check_hop_vt['SoLuong'] > $item['SoLuong']){
		        			$arr = array(
			                    'SoLuong' => ($check_hop_vt['SoLuong'] - $item['SoLuong'])
			                );
			                $result = $this->Common_model->update($this->table_KHO_Hop_VT,$arr,$where);
		        		}
		        	}
		        }

		        $this->Common_model->delete('KHO_Nhap_Gia',array("Nhap_ID" => $id));
		        $this->Common_model->delete('KHO_Nhap_Hop',array("Nhap_ID" => $id));

		        //Cập nhật lại số lượng
		        $soluong = 0;
		        $position = false;
		        if($gia != null){
                    foreach ($gia  as $key => $item) {
                        if($item != null && $item > 0){
                            $check_gia = $this->Common_model->get_record($this->table_gia,array('ID' => $key,'Is_Delete' => '0'));
                            if($check_gia != null){
                            	$where = array(
                            		'DMVT_ID' => $data_post['DMVT_ID'],
                            		'Gia_ID' => $key,
                            		'Is_Delete' => '0'
                            	);
                            	$check_gia_vt = $this->Common_model->get_record($this->table_KHO_Gia_VT,$where);
		        				if(@$check_gia_vt['SoLuong'] != null){
	                            	$arr = array('SoLuong' => ($check_gia_vt['SoLuong'] + $item) );
	                                $result = $this->Common_model->update($this->table_KHO_Gia_VT,$arr,$where);
		                            $position = true;
		                            $soluong += $item;
		                            $arr = array(
	                                    'Gia_ID' => $key,
	                                    'Nhap_ID' => $id,
	                                    'SoLuong' => $item,
	                                    'Created_At' => date('Y-m-d H:i:s')
	                                );
	                                $this->Common_model->add('KHO_Nhap_Gia',$arr);
	                            }
                            }
                        }
                    }
                }

                if($hop != null){
                    foreach ($hop as $key => $item) {
                        if($item != null && $item > 0){
                            $check_hop = $this->Common_model->get_record($this->table_hop,array('ID' => $key,'Is_Delete' => '0'));
                            if($check_hop != null){
                                $where = array(
                            		'DMVT_ID' => $data_post['DMVT_ID'],
                            		'Hop_ID' => $key,
                            		'Is_Delete' => '0'
                            	);
                            	$check_hop_vt = $this->Common_model->get_record($this->table_KHO_Hop_VT,$where);
		        				if(@$check_hop_vt['SoLuong'] != null){
	                            	$position = true;
	                            	$arr = array('SoLuong' => ($check_hop_vt['SoLuong'] + $item));
	                                $result = $this->Common_model->update($this->table_KHO_Hop_VT,$arr,$where);

	                                $soluong += $item;
		                            $arr = array(
	                                    'Hop_ID' => $key,
	                                    'Nhap_ID' => $id,
	                                    'SoLuong' => $item,
	                                    'Created_At' => date('Y-m-d H:i:s')
	                                );
	                                $this->Common_model->add('KHO_Nhap_Hop',$arr);
	                            }
                            }
                        }
                    }
                }

                $data_update = array();
                $data_update["Barcode"]  = $this->barcode_id($id);
                $data_update["SoLuong"]  = $data_post["SoLuong"];
                if($record['Status'] == 1){
                	$data_update["Status"]  = 3;// Đã hoàn thành việc nhập kho
                }

                if($position){
                	$data_update["Position"]  = 1;
                }
                else{
                    $data_update["Position"]  = 0;
                }
                $this->Common_model->update($this->table,$data_update,array("ID" => $id));

                $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                $record["Status"] = $this->get_status($record["Status"]);
                $record["Position"] = $this->get_name_position($record["Position"]);
                $dmvt = $this->Common_model->get_record($this->table_dmvt,array("ID" => $record['DMVT_ID']));
                $record['DMVTName'] = @$dmvt['Name'] == null ? '' : $dmvt['Name'];
                $dvt = $this->Common_model->get_record($this->table_dvt,array("ID" => @$dmvt['DVT_ID']));
                $record['DVTName'] = @$dvt['Name'] == null ? '' : $dvt['Name'];
                $data['status'] = 'success';
                $data['action'] = 'edit';
                $data['responsive'] = $record;
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }

        $dmvt = $this->Common_model->get_record($this->table_dmvt,array("ID" => $record['DMVT_ID'],'Is_Delete' => '0'));
        $this->data['get_postion']['nhap'] = $record;
        $this->data['get_postion']['dmvt'] = $dmvt;
        $this->data['get_postion']['dvt']  = $this->Common_model->get_record('KHO_DVT',array("ID" => $dmvt['DVT_ID'],'Is_Delete' => '0'));


        $sql = "SELECT tbl1.*,tbl2.SoLuong AS SoLuongVT,tbl3.SoLuong AS SoLuongNhap
                FROM {$this->table_gia} AS tbl1
                LEFT JOIN {$this->table_KHO_Gia_VT} AS tbl2 ON tbl2.Gia_ID = tbl1.ID AND tbl2.DMVT_ID = '{$record['DMVT_ID']}' AND tbl2.Is_Delete != '1' 
                LEFT JOIN KHO_Nhap_Gia AS tbl3 ON tbl3.Gia_ID = tbl1.ID AND tbl3.Nhap_ID = '$id'
                ORDER BY tbl2.SoLuong DESC,tbl1.Name ASC";
        $this->data['get_postion']['gia_result'] = $this->Common_model->query_raw($sql);

        $sql = "SELECT tbl1.*,tbl2.SoLuong AS SoLuongVT,tbl3.SoLuong AS SoLuongNhap
                FROM {$this->table_hop} AS tbl1
                LEFT JOIN {$this->table_KHO_Hop_VT} AS tbl2 ON tbl2.Hop_ID = tbl1.ID AND tbl2.DMVT_ID = '{$record['DMVT_ID']}' AND tbl2.Is_Delete != '1' 
                LEFT JOIN KHO_Nhap_Hop AS tbl3 ON tbl3.Hop_ID = tbl1.ID AND tbl3.Nhap_ID = '$id'
                ORDER BY tbl2.SoLuong DESC,tbl1.Name ASC";

        $this->data['get_postion']['hop_result'] = $this->Common_model->query_raw($sql);

        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id,'Status' => '2'));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Nhập hàng này không tồn tại.";
            die(json_encode($data));
        }

        if($record['Status'] != 2){
            $data['status'] = "fail";
            $data['message'] = "Nhập hàng này không thể xóa.";
            die(json_encode($data));
        }

        $data_update = array();
        $data_update["Is_Delete"]  = 1;
        $result = $this->Common_model->update($this->table,$data_update,array("ID" => $id));
        //$result = $this->Common_model->delete($this->table,array("ID" => $id));
        if($result){
        	$result_nhap_gia = $this->Common_model->get_result('KHO_Nhap_Gia',array('Nhap_ID' => $id));
	        $result_nhap_hop = $this->Common_model->get_result('KHO_Nhap_Hop',array('Nhap_ID' => $id));
	        
	        if(isset($result_nhap_gia) && $result_nhap_gia != null){
	        	foreach ($result_nhap_gia as $key => $item) {
	        		$where = array(
	            		'DMVT_ID' => $record['DMVT_ID'],
	            		'Gia_ID' => $item['Gia_ID'],
	            		'Is_Delete' => '0'
	            	);
	            	$check_gia_vt = $this->Common_model->get_record($this->table_KHO_Gia_VT,$where);
	        		if($check_gia_vt != null && $check_gia_vt['SoLuong'] > $item['SoLuong']){
	        			$arr = array(
		                    'SoLuong' => ($check_gia_vt['SoLuong'] - $item['SoLuong'])
		                );
		                $this->Common_model->update($this->table_KHO_Gia_VT,$arr,$where);
		                $this->Common_model->update('KHO_Nhap_Gia',array('Is_Delete' => 1),array('ID' => $item['ID']));
	        		}
	        	}
	        }

	        if(isset($result_nhap_hop) && $result_nhap_hop != null){
	        	foreach ($result_nhap_gia as $key => $item) {
	        		$where = array(
	            		'DMVT_ID' => $record['DMVT_ID'],
	            		'Hop_ID' => $item['Hop_ID'],
	            		'Is_Delete' => '0'
	            	);
	            	$check_hop_vt = $this->Common_model->get_record($this->table_KHO_Hop_VT,$where);
	        		if($check_hop_vt != null && $check_hop_vt['SoLuong'] > $item['SoLuong']){
	        			$arr = array(
		                    'SoLuong' => ($check_hop_vt['SoLuong'] - $item['SoLuong'])
		                );
		                $this->Common_model->update($this->table_KHO_Hop_VT,$arr,$where);
		                $this->Common_model->update('KHO_Nhap_Hop',array('Is_Delete' => 1),array('ID' => $item['ID']));
	        		}
	        	}
	        }
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }

    public function get_position($id = null){
        $record = $this->Common_model->get_record($this->table_dmvt,array("ID" => $id,'Is_Delete' => '0'));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Danh mục vật tự này không tồn tại.";
            die(json_encode($data));
        }
        $nhap_id = $this->input->post('Nhap_ID');
        $this->data['nhap_id'] = $nhap_id;
        $this->data['dmvt_id'] = $id;
        $dvt = $this->Common_model->get_record('KHO_DVT',array("ID" => $record['DVT_ID'],'Is_Delete' => '0'));
        $this->data['nhap'] = $this->Common_model->get_record($this->table,array("ID" => $nhap_id,'Is_Delete' => '0'));
        $this->data['dvt']  = $dvt;
        $this->data['dmvt'] = $record;


        $sql = "SELECT tbl1.*,tbl2.SoLuong AS SoLuongVT,tbl3.SoLuong AS SoLuongNhap
                FROM {$this->table_gia} AS tbl1
                LEFT JOIN {$this->table_KHO_Gia_VT} AS tbl2 ON tbl2.Gia_ID = tbl1.ID AND tbl2.DMVT_ID = '{$id}' AND tbl2.Is_Delete != '1' 
                LEFT JOIN KHO_Nhap_Gia AS tbl3 ON tbl3.Gia_ID = tbl1.ID AND tbl3.Nhap_ID = '$nhap_id'
                ORDER BY tbl2.SoLuong DESC,tbl1.Name ASC";
        $this->data['gia_result'] = $this->Common_model->query_raw($sql);

        $sql = "SELECT tbl1.*,tbl2.SoLuong AS SoLuongVT,tbl3.SoLuong AS SoLuongNhap
                FROM {$this->table_hop} AS tbl1
                LEFT JOIN {$this->table_KHO_Hop_VT} AS tbl2 ON tbl2.Hop_ID = tbl1.ID AND tbl2.DMVT_ID = '{$id}' AND tbl2.Is_Delete != '1' 
                LEFT JOIN KHO_Nhap_Hop AS tbl3 ON tbl3.Hop_ID = tbl1.ID AND tbl3.Nhap_ID = '$nhap_id'
                ORDER BY tbl2.SoLuong DESC,tbl1.Name ASC";

        $this->data['hop_result'] = $this->Common_model->query_raw($sql);


        $date = date('Y-m-d');
        $sql_tonkho = "
            SELECT (IF(tbl3.TotalNhap >= 0,tbl3.TotalNhap,0) - IF(tbl4.TotalXuat >= 0,tbl4.TotalXuat,0) +  IF(tbl5.TotalTra >= 0,tbl5.TotalTra,0)) AS TotalTon
            FROM {$this->table_dmvt} AS tbl1
            LEFT JOIN (
                SELECT SUM(SoLuong) AS TotalNhap,DMVT_ID
                FROM {$this->table}
                WHERE Is_Delete != '1' AND Status = '3' AND DATE_FORMAT(Created_At, '%Y-%m-%d') <= '$date'
                GROUP BY DMVT_ID
            ) AS tbl3 ON tbl1.ID = tbl3.DMVT_ID  

            LEFT JOIN (
                SELECT SUM(SoLuong) AS TotalXuat,DMVT_ID
                FROM {$this->table_xuat}
                WHERE Is_Delete != '1' AND Ngay <= '$date'
                GROUP BY DMVT_ID
            ) AS tbl4 ON tbl1.ID = tbl4.DMVT_ID

            LEFT JOIN (
                SELECT SUM(SoLuong) AS TotalTra,DMVT_ID
                FROM {$this->table_tra}
                WHERE Is_Delete != '1' AND Ngay <= '$date'
                GROUP BY DMVT_ID
            ) AS tbl5 ON tbl1.ID = tbl5.DMVT_ID
        WHERE tbl1.ID = '{$id}'";

        $this->data['tonkho'] = $this->Common_model->query_raw_row($sql_tonkho);
        $data['status'] = 'success';
        $data['response'] = $this->load->view($this->backend_asset."/".$this->folder_view."/get_position",$this->data,true);
        die(json_encode($data));
    }

    public function update_position(){
        $data = array('status' => 'error');
        if($this->input->post()){
            $data_post = $this->input->post();

            $record = $this->Common_model->get_record($this->table,array("ID" => @$data_post['nhap_id']));
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Nhập kho này không tồn tại.";
                die(json_encode($data));
            }

            $record = $this->Common_model->get_record($this->table_dmvt,array("ID" => @$data_post['dmvt_id'],'Is_Delete' => '0'));
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Danh mục vật tự này không tồn tại.";
                die(json_encode($data));
            }

            $nhap_id = $data_post['nhap_id'];
            $dmvt_id = $data_post['dmvt_id'];
            $gia = @$data_post['gia'];
            $hop = @$data_post['hop'];
            $soluong = 0;
            if($gia != null){
                foreach ($gia as $key => $item) {
                    if($item != null && $item > 0){
                        $check_gia = $this->Common_model->get_record($this->table_gia,array('ID' => $key,'Is_Delete' => '0'));
                        if($check_gia != null){
                            $soluong += $this->cover_number($item);
                        }
                    }
                }
            }

            if($hop != null){
                foreach ($hop as $key => $item) {
                    if($item != null && $item > 0){
                        $check_hop = $this->Common_model->get_record($this->table_hop,array('ID' => $key,'Is_Delete' => '0'));
                        if($check_hop != null){
                            $soluong += $this->cover_number($item);
                        }
                    }
                }
            }
            
            if($soluong <= 0){
            	$data['status'] = "fail";
	            $data['message'] = "Vui lòng nhập số lượng cập nhật.";
	            die(json_encode($data));
            }


            $date = date('Y-m-d');
            $sql_nhap = "
                SELECT IF(tbl3.TotalNhap >= 0,tbl3.TotalNhap,0) AS TotalNhap
                FROM {$this->table_dmvt} AS tbl1
                LEFT JOIN (
                    SELECT SUM(SoLuong) AS TotalNhap,DMVT_ID
                    FROM {$this->table}
                    WHERE Is_Delete != '1' AND Status = '3' AND DATE_FORMAT(Created_At, '%Y-%m-%d') <= '$date'
                    GROUP BY DMVT_ID
                ) AS tbl3 ON tbl1.ID = tbl3.DMVT_ID  
                WHERE tbl1.ID = '{$dmvt_id}'";
            $totalnhap = $this->Common_model->query_raw_row($sql_nhap);



            $sql_hop_gia = "
                SELECT (IF(tbl3.TotalNhapGia >= 0,tbl3.TotalNhapGia,0) +  IF(tbl4.TotalNhapHop >= 0,tbl4.TotalNhapHop,0)) AS TotalNhap
                FROM {$this->table} AS tbl1
                LEFT JOIN (
                    SELECT SUM(SoLuong) AS TotalNhapGia,Nhap_ID
                    FROM KHO_Nhap_Gia
                    WHERE Is_Delete != '1' AND DATE_FORMAT(Created_At, '%Y-%m-%d') <= '$date'
                    GROUP BY Nhap_ID
                ) AS tbl3 ON tbl1.ID = tbl3.Nhap_ID  

                LEFT JOIN (
                    SELECT SUM(SoLuong) AS TotalNhapHop,Nhap_ID
                    FROM KHO_Nhap_Hop
                    WHERE Is_Delete != '1' AND DATE_FORMAT(Created_At, '%Y-%m-%d') <= '$date'
                    GROUP BY Nhap_ID
                ) AS tbl4 ON tbl1.ID = tbl4.Nhap_ID
                WHERE tbl1.ID = '{$nhap_id}'";
            $total_gia_hop = $this->Common_model->query_raw_row($sql_hop_gia);

            if(($total_gia_hop['TotalNhap'] + $soluong) > $totalnhap['TotalNhap']){
            	$data['status'] = "fail";
	            $data['message'] = "Số lượng cập nhật vượt quá số lượng thực tế.";
	            die(json_encode($data));
            }

            if($gia != null){
                foreach ($gia  as $key => $item) {
                    if($item != null && $item > 0){
                        $check_gia = $this->Common_model->get_record($this->table_gia,array('ID' => $key,'Is_Delete' => '0'));
                        if($check_gia != null){
                        	$where = array(
                        		'DMVT_ID'   => $dmvt_id,
                        		'Gia_ID'    => $key,
                        		'Is_Delete' => '0'
                        	);
                        	$check_gia_vt = $this->Common_model->get_record($this->table_KHO_Gia_VT,$where);
                            if($check_gia_vt == null){
                                $arr = array(
                                    'Gia_ID'   => $key,
                                    'DMVT_ID'  => $dmvt_id,
                                    'Hang'     => $check_gia['Hang'],
                                    'Cot'      => $check_gia['Cot'],
                                    'SoLuong'  => $item,
                                    'Created_At' => date('Y-m-d H:i:s')
                                );
                                $check_id = $this->Common_model->add($this->table_KHO_Gia_VT,$arr);
                            }
                            else{
                            	$arr = array(
                                    'SoLuong' => ($check_gia_vt['SoLuong'] + $item)
                                );
                                $result = $this->Common_model->update($this->table_KHO_Gia_VT,$arr,$where);
                            }


                            $arr = array(
                                'Gia_ID' => $key,
                                'Nhap_ID' => $nhap_id,
                                'SoLuong' => $item,
                                'Created_At' => date('Y-m-d H:i:s')
                            );
                            $this->Common_model->add('KHO_Nhap_Gia',$arr);
                        }
                    }
                }
            }

            if($hop != null){
                foreach ($hop as $key => $item) {
                    if($item != null && $item > 0){
                        $check_hop = $this->Common_model->get_record($this->table_hop,array('ID' => $key,'Is_Delete' => '0'));
                        if($check_hop != null){
                            $where = array(
                        		'DMVT_ID'   => $dmvt_id,
                        		'Hop_ID'    => $key,
                        		'Is_Delete' => '0'
                        	);
                        	$check_hop_vt = $this->Common_model->get_record($this->table_KHO_Hop_VT,$where);
                        	if($check_hop_vt == null){
                                $arr = array(
                                    'Hop_ID'     => $key,
                                    'DMVT_ID'    => $dmvt_id,
                                    'SoLuong'    => $item,
                                    'Created_At' => date('Y-m-d H:i:s')
                                );
                                $check_id = $this->Common_model->add($this->table_KHO_Hop_VT,$arr);
                            }
                            else{
                            	$arr = array(
                                    'SoLuong' => ($check_hop_vt['SoLuong'] + $item)
                                );
                                $result = $this->Common_model->update($this->table_KHO_Hop_VT,$arr,$where);
                            }


                            $arr = array(
                                'Hop_ID' => $key,
                                'Nhap_ID' => $nhap_id,
                                'SoLuong' => $item,
                                'Created_At' => date('Y-m-d H:i:s')
                            );
                            $this->Common_model->add('KHO_Nhap_Hop',$arr);

                        }
                    }
                }
            }

            $data_update = array();
            $data_update["Position"]  = 1;
            $this->Common_model->update($this->table,$data_update,array("ID" => $nhap_id));
            $data['status'] = 'success';
        }
        die(json_encode($data));
    }

    public function export(){
        set_time_limit(0);
        $this->data['is_export'] = true;
        $sql = "SELECT tbl1.*,tbl3.Name AS DMVTName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_dmvt} AS tbl3 ON tbl3.ID = tbl1.DMVT_ID
                WHERE tbl1.Is_Delete != '1'
                GROUP BY tbl1.ID
                ORDER BY tbl1.ID DESC";
        $results = $this->Common_model->query_raw($sql);
        $title = 'Nhập Kho';
        $header = array('Barcode','Danh mục vật tư','Số lượng','Trạng thái','Ngày tháng');
        $data = array();
        if(isset($results) && $results != null){
            foreach ($results as $key => $item) {
                $data[] = array(
                    $item['Barcode'],
                    $item['DMVTName'],
                    $item['SoLuong'],
                    $this->get_status($item["Status"]),
                    date($this->date_format,strtotime($item["Created_At"]))
                );
            }
        }
        export_excel($title,$header,$data);
    }

    private function get_status($status){
    	if($status == 0){
    		return 'Nội bộ ';
    	}
    	if($status == 1){
    		return 'Đợi xác nhận vật tư';
    	}
    	if($status == 2){
    		return 'Đợi xác nhận đơn giá';
    	}
    	return 'Hoàn thành';
    }

    private function get_name_position($position){
        if($position == 0){
            return 'Chưa cập nhật';
        }
        return 'Hoàn thành';
    }
}
