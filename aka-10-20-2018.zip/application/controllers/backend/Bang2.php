<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Bang2 extends MY_Controller {

    private $folder_view = "bang2";
    private $table = 'Bang2';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
        $sql_get_key = "SELECT
            `column_name`, 
            `referenced_table_schema` AS foreign_db, 
            `referenced_table_name` AS foreign_table, 
            `referenced_column_name`  AS foreign_column 
        FROM `information_schema`.`KEY_COLUMN_USAGE`
        WHERE `constraint_schema` = SCHEMA() AND `table_name` = 'KHO_Gia_Hop' AND `referenced_column_name` IS NOT NULL AND TABLE_SCHEMA = '{$this->db->database}'
        ORDER BY `column_name`";

        $sql_get_columns = "
            SELECT COLUMN_NAME,DATA_TYPE,COLUMN_COMMENT
            FROM information_schema.columns
            WHERE table_name = 'KHO_Gia_Hop' AND TABLE_SCHEMA = '{$this->db->database}' ";
        $colums = $this->Common_model->query_raw($sql_get_key);
        //echo '<pre>';
        //print_r($colums);
        //echo '</pre>';
        //die;
    }

    public function index(){
        $where["1"] = "1";
        if($this->input->get("keyword") != null){
            $where["ten Like"] = "%".$this->input->get("keyword")."%";
        }
        $per_page = $this->per_page;
        $count_table = $this->Common_model->count_table($this->table,$where);
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0 ;    
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = $count_table;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
    	$this->data["results"] = $this->Common_model->get_result($this->table,$where,$offset,$per_page);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('ten', 'Tên', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert["ngay"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['ngay'] = date($this->datetime_format,strtotime($record["ngay"]));
                    $record['status'] = $record['status'] == 1 ? 'Hoạt động' : 'Ngưng hoạt động';
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Item này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('ten', 'Tên', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['ngay'] = date($this->datetime_format,strtotime($record["ngay"]));
                    $record['status'] = $record['status'] == 1 ? 'Hoạt động' : 'Ngưng hoạt động';
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Item này không tồn tại.";
            die(json_encode($data));
        }
    	$result = $this->Common_model->delete($this->table,array("ID" => $id));
    	if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }
}