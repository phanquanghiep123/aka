<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Warehousing extends MY_Controller {

    private $folder_view = "warehousing";
    private $table = 'KHO_Nhap';
    private $table_hoadon = 'KHO_HoaDon';
    private $table_dmvt = 'KHO_DMVT';
    private $table_ncc = 'KHO_NCC';
    private $table_media = 'M_Multimedia';
    private $table_bill_media = 'KHO_HoaDon_Multimedia';

    public function __construct() {
        parent::__construct();
        $this->load->model('Users_model');
        $this->data['folder_view'] = $this->folder_view;
        $this->data["hoadon_result"]    = $this->Common_model->get_result($this->table_hoadon,array('Is_Delete != ' => 1));
        $this->data["dmvt_result"]    = $this->Common_model->get_result($this->table_dmvt,array('Is_Delete != ' => 1));
        $this->data['header'] = array('Danh mục vật tư','Số lượng','Đơn giá');
    }

    public function index(){
        $where = " WHERE tbl1.Is_Delete != '1' ";
        if($this->input->get("bill") != null){
            $where .= " AND tbl1.HoaDon_ID = '".$this->input->get("bill")."'";
        }
        if($this->input->get("DMVT") != null){
            $where .= " AND tbl1.DMVT_ID = '".$this->input->get("DMVT")."'";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl3.Name AS DMVTName,tbl2.Ma_Hoa_Don
                FROM {$this->table} AS tbl1 
                LEFT JOIN {$this->table_hoadon} AS tbl2 ON tbl2.ID = tbl1.HoaDon_ID
                INNER JOIN {$this->table_dmvt} AS tbl3 ON tbl3.ID = tbl1.DMVT_ID
                $where 
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table} AS tbl1 
            LEFT JOIN {$this->table_hoadon} AS tbl2 ON tbl2.ID = tbl1.HoaDon_ID
            INNER JOIN {$this->table_dmvt} AS tbl3 ON tbl3.ID = tbl1.DMVT_ID
            $where";


        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('SoLuong', 'Số lượng', 'required');
            $this->form_validation->set_rules('DonGia', 'Đơn giá', 'required');
            $this->form_validation->set_rules('DMVT_ID', 'Danh mục vật tư', 'required');
            $this->form_validation->set_rules('HoaDon_ID','Hóa đơn', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        if($key == 'SoLuong' || $key == 'DonGia'){
                            $data_insert[$key] = $this->cover_number($value);
                        }
                        else{
                            $data_insert[$key] = $value;
                        }
                    }              
                }
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $data_insert['Status'] = 1;
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['DonGia'] = number_format($record["DonGia"]).' VNĐ';
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $record["Status"] = $this->get_status($record["Status"]);

                    $dmvt = $this->Common_model->get_record($this->table_dmvt,array("ID" => $record['DMVT_ID']));
                    $record['DMVTName'] = @$dmvt['Name'] == null ? '' : $dmvt['Name'];
                    
                    $bill = $this->Common_model->get_record($this->table_hoadon,array("ID" => $record['HoaDon_ID']));
                    $record['Ma_Hoa_Don'] = @$bill['Ma_Hoa_Don'] == null ? '' : $bill['Ma_Hoa_Don'];


                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function add_more($bill_id = null){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('HoaDon_ID','Hóa đơn', 'required');
            $this->form_validation->set_rules('path_file','Excel File', 'required');
            if ($this->form_validation->run() == TRUE) {
                $path_file = $this->input->post('path_file');
                if(!file_exists($path_file)){
                    $data['message'] = 'Excel file không tồn tại.';
                    $data['status']  = 'fail';
                    die(json_encode($data));
                }

                $data_excel = get_data_excel($path_file);
                foreach ($data_excel[0] as $key => $item) {
                    if($item != trim(@$this->data['header'][$key])){
                        $data['message'] = 'Excel file không đúng định dạng.';
                        $data['status']  = 'fail';
                        die(json_encode($data));
                    }
                }
                foreach ($data_excel as $key => $item) {
                    if($key > 0 && @$item[0] != null && @$item[1] != null && @$item[2] != null){
                        $dmvt = $this->Common_model->get_record($this->table_dmvt,array('Name' => trim($item[0])));
                        if(@$dmvt != null){
                            $data_insert = array(
                                'HoaDon_ID' => $this->input->post('HoaDon_ID'),
                                'DMVT_ID' => $dmvt['ID'],
                                'SoLuong' => $item[1],
                                'DonGia'  => $item[2],
                                'Status'  => 1,
                                'Created_At' => date('Y-m-d H:i:s'),
                                'Employee_KeToan_ID' => $this->user_info["Employee_ID"]
                            );
                            $id = $this->Common_model->add($this->table,$data_insert);  
                            if($id > 0){
                                $data_update = array();
                                $data_update["Barcode"]  = $this->barcode_id($id);
                                $this->Common_model->update($this->table,$data_update,array("ID" => $id));
                            }
                        }
                    }
                }
                @unlink($path_file);
                $data['status'] = 'success';
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['bill_id'] = $bill_id;
        $this->data['bill'] = $this->Common_model->get_record($this->table_hoadon,array('ID' => $bill_id));
        $sql = "SELECT tbl1.*, tbl3.Name, tbl3.URL
                FROM {$this->table_bill_media} AS tbl1 
                INNER JOIN {$this->table_media} AS tbl3 ON tbl3.ID = tbl1.Multimedia_ID
                WHERE tbl1.HoaDon_ID = '$bill_id'
                ORDER BY tbl1.ID DESC";
        $this->data['media']  = $this->Common_model->query_raw($sql);
        $this->data['ncc']   = $this->Common_model->get_record($this->table_ncc,array("ID" => @$this->data['bill']['NCC_ID']));
        $this->data['results'] =  $this->Common_model->get_result($this->table_dmvt,array('Is_Delete' => '0'));
        $this->load->view($this->backend_asset."/".$this->folder_view."/add",$this->data);
    }

    public function insert_data(){
        $data = array('status' => 'error');
        if($this->input->post()){
            $this->form_validation->set_rules('HoaDon_ID','Hóa đơn', 'required');
            if ($this->form_validation->run() == TRUE) {
                $soluong = $this->input->post('soluong');
                $dongia = $this->input->post('dongia');
                if(isset($soluong) && $soluong != null){
                    foreach ($soluong as $key => $item) {
                        if(isset($item) && $item != null && isset($dongia[$key]) && $dongia[$key] != null){
                            $dmvt = $this->Common_model->get_record($this->table_dmvt,array('ID' => $key));
                            if($dmvt != null){
                                $data_insert = array(
                                    'HoaDon_ID' => $this->input->post('HoaDon_ID'),
                                    'DMVT_ID' => $dmvt['ID'],
                                    'SoLuong' => $this->cover_number($item),
                                    'DonGia'  => $this->cover_number(@$dongia[$key]),
                                    'Status'  => 1,
                                    'Created_At' => date('Y-m-d H:i:s'),
                                    'Employee_KeToan_ID' => $this->user_info["Employee_ID"]
                                );
                                $id = $this->Common_model->add($this->table,$data_insert);  
                                if($id > 0){
                                    $data_update = array();
                                    $data_update["Barcode"]  = $this->barcode_id($id);
                                    $this->Common_model->update($this->table,$data_update,array("ID" => $id));
                                }
                            }
                        }
                    }
                }
                $data['status'] = 'success';
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
        }
        die(json_encode($data));
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id,'Is_Delete' => 0));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Đợt nhập này không tồn tại.";
                die(json_encode($data));
            }

            if($record['Status'] == 3){
                $data['status'] = "fail";
                $data['message'] = "Đợt nhập không thể chỉnh sửa.";
                die(json_encode($data));
            }

            $this->form_validation->set_rules('SoLuong', 'Số lượng', 'required');
            $this->form_validation->set_rules('DonGia', 'Đơn giá', 'required');
            $this->form_validation->set_rules('DMVT_ID', 'Danh mục vật tư', 'required');
            $this->form_validation->set_rules('HoaDon_ID','Hóa đơn', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                $data_post['SoLuong'] = $this->cover_number($data_post['SoLuong']);
                if($record['Status'] == 2){
                    if($record['SoLuong'] != $data_post['SoLuong']){
                        $data['status'] = "fail";
                        $data['message'] = "Số lượng không đúng.";
                        die(json_encode($data));
                    }
                    if($record['DMVT_ID'] != $data_post['DMVT_ID']){
                        $data['status'] = "fail";
                        $data['message'] = "Danh mục vật tư không đúng.";
                        die(json_encode($data));
                    }
                }

                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $data_update["DonGia"]  = $this->cover_number($data_post['DonGia']);
                if($record['Status'] == 2){
                    $data_update['Status'] = 3;
                }
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['DonGia'] = number_format($record["DonGia"]).' VNĐ';
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $record["Status"] = $this->get_status($record["Status"]);

                    $dmvt = $this->Common_model->get_record($this->table_dmvt,array("ID" => $record['DMVT_ID']));
                    $record['DMVTName'] = @$dmvt['Name'] == null ? '' : $dmvt['Name'];
                    
                    $bill = $this->Common_model->get_record($this->table_hoadon,array("ID" => $record['HoaDon_ID']));
                    $record['Ma_Hoa_Don'] = @$bill['Ma_Hoa_Don'] == null ? '' : $bill['Ma_Hoa_Don'];


                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Đợt nhập này không tồn tại.";
            die(json_encode($data));
        }
        if($record['Status'] != 1){
            $data['status'] = "fail";
            $data['message'] = "Đợt nhập không thể xóa.";
            die(json_encode($data));
        }
        $data_update = array();
        $data_update["Is_Delete"]  = 1;
        $result = $this->Common_model->update($this->table,$data_update,array("ID" => $id));
        //$result = $this->Common_model->delete($this->table,array("ID" => $id));
        if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }

    public function export(){
        set_time_limit(0);
        $this->data['is_export'] = true;
        $sql = "SELECT tbl1.*,tbl3.Name AS DMVTName,tbl2.Ma_Hoa_Don
                FROM {$this->table} AS tbl1 
                LEFT JOIN {$this->table_hoadon} AS tbl2 ON tbl2.ID = tbl1.HoaDon_ID
                INNER JOIN {$this->table_dmvt} AS tbl3 ON tbl3.ID = tbl1.DMVT_ID 
                WHERE tbl1.Is_Delete = '0' 
                ORDER BY tbl1.ID DESC";
        $results = $this->Common_model->query_raw($sql);
        $title = 'Nhập Kho';
        $header = array('Barcode','Hóa đơn','Danh mục vật tư','Số lượng','Đơn giá','Trạng thái','Ngày tháng');
        $data = array();
        if(isset($results) && $results != null){
            foreach ($results as $key => $item) {
                $data[] = array(
                    $item['Barcode'],
                    $item['Ma_Hoa_Don'],
                    $item['DMVTName'],
                    $item['SoLuong'],
                    $item['DonGia'],
                    $this->get_status($item["Status"]),
                    date($this->date_format,strtotime($item["Created_At"]))
                );
            }
        }
        export_excel($title,$header,$data);
    }

    public function export_excel(){
        set_time_limit(0);
        $this->data['is_export'] = true;
        $title = 'Nhập Kho';
        $soluong = $this->input->post('soluong');
        $dongia = $this->input->post('dongia');
        $header = array('Danh mục vật tư','Số lượng','Đơn giá');
        $data = array();
        if(isset($soluong) && $soluong != null){
            foreach ($soluong as $key => $item) {
                if(isset($item) && $item != null){
                    $dmvt = $this->Common_model->get_record($this->table_dmvt,array('ID' => $key));
                    if($dmvt != null){
                        $data[] = array(
                            $dmvt['Name'],
                            $this->cover_number($item),
                            $this->cover_number(@$dongia[$key])
                        );
                    }
                }
            }
        }
        export_excel($title,$header,$data);
    }

    public function get_data_excel(){
        $data = array('status' => 'error');
        if (isset($_FILES["excel"]['name']) && $_FILES["excel"]['name'] != null){
            $mimes = array('xls','xlsx');
            $ext = pathinfo($_FILES['excel']['name'], PATHINFO_EXTENSION);
            if(!in_array($ext,$mimes)){
                $data['message'] = 'Vui lòng chọn excel file.';
                $data['status']  = 'fail';
                die(json_encode($data));
            }

            $upload_path = FCPATH . "/uploads/excel";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, TRUE);
            }
            $config = array();
            $config['upload_path'] = $upload_path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($this->upload->do_upload('excel')){
                $upload_data = $this->upload->data();
                $path_file = $upload_data['full_path'];
                $data_excel = get_data_excel($path_file);
                foreach ($data_excel[0] as $key => $item) {
                    if($item != trim(@$this->data['header'][$key])){
                        $data['message'] = 'Excel file không đúng định dạng.';
                        $data['status']  = 'fail';
                        die(json_encode($data));
                    }
                }
                $data_insert = array();
                $message = '';
                foreach ($data_excel as $key => $item) {
                    if($key > 0 && @$item[0] != null){
                        $dmvt = $this->Common_model->get_record($this->table_dmvt,array('Name' => trim($item[0])));
                        if(@$dmvt == null){
                            $message .= 'Danh mục vật tư "'.trim($item[0]).'" không tồn tại <br/>';
                        }
                        $data_insert[] = array(
                            'dmvt'    => trim($item[0]),
                            'so-luong' => trim($item[1]),
                            'don-gia' => trim($item[2])
                        );
                    }
                }
                $this->data['data_insert'] = $data_insert;
                $this->data['message'] = $message;
                $data['status']    = 'success';
                $data['path_file'] = $path_file;
                $data['response']  = $this->load->view($this->backend_asset."/".$this->folder_view."/data-info-excel",$this->data,true);
                die(json_encode($data));
            }
            else{
                $data['message'] = $this->upload->display_errors();
                $data['status']  = 'fail';
                die(json_encode($data));
            }
        }
        else{
            $data['message'] = 'Vui lòng chọn file muốn nhập.';
            $data['status']  = 'fail';
            die(json_encode($data));
        }
        die(json_encode($data));
    }

    public function get_bill($bill_id = null){
        $data = array('status' => 'error');
        $hoadon  = $this->Common_model->get_record($this->table_hoadon,array('ID' => $bill_id,'Is_Delete != ' => 1));
        if($hoadon == null){
            $data['status'] = "fail";
            $data['message'] = "Hóa đơn này không tồn tại.";
            die(json_encode($data));
        }
        $this->data['hoadon'] = $hoadon;
        $this->data['ncc']   = $this->Common_model->get_record($this->table_ncc,array("ID" => $hoadon['NCC_ID']));
        
        $sql = "SELECT tbl1.*, tbl3.Name, tbl3.URL
                FROM {$this->table_bill_media} AS tbl1 
                INNER JOIN {$this->table_media} AS tbl3 ON tbl3.ID = tbl1.Multimedia_ID
                WHERE tbl1.HoaDon_ID = '$bill_id'
                ORDER BY tbl1.ID DESC";
        $this->data['media']  = $this->Common_model->query_raw($sql);

        $data['status'] = "success";
        $data['response'] = $this->load->view($this->backend_asset."/".$this->folder_view."/bill-info",$this->data,true);
        die(json_encode($data));
    }

    private function get_status($status){
        if($status == 0){
            return 'Nội bộ ';
        }
        if($status == 1){
            return 'Đợi xác nhận';
        }
        if($status == 2){
            return 'Nhập đơn giá';
        }
        return 'Hoàn thành';
    }
}
