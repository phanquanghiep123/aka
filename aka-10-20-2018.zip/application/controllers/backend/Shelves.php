<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Shelves extends MY_Controller {

    private $folder_view = "shelves";
    private $table = 'KHO_Gia';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
        $this->data['header'] = array('Tên giá đựng','Số hàng','Số cột');
    }

    public function index(){

        $where = " WHERE tbl1.Is_Delete != '1' ";
        if($this->input->get("keyword") != null){
            $where .= " AND tbl1.Name LIKE '%".addslashes($this->input->get("keyword"))."%'";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT c.*
                FROM (
                    SELECT tbl1.*
                    FROM {$this->table} AS tbl1 
                    $where 
                    ORDER BY tbl1.Hang DESC,tbl1.Cot DESC, tbl1.ID DESC
                ) AS c 
                GROUP BY c.Name
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(c.ID) AS count
                FROM (
                    SELECT tbl1.ID
                    FROM {$this->table} AS tbl1
                    $where
                    GROUP BY tbl1.Name
                ) AS c";


        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);

        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('Name','Tên giá đựng', 'required');
            $this->form_validation->set_rules('Cot', 'Số Cột', 'required');
            $this->form_validation->set_rules('Hang','Số Hàng', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $this->add_row_col($data_post['Name'],intval($data_post['Hang']),intval($data_post['Cot']));
                $data['status'] = 'success';
                $data['action'] = 'add';
                /*$colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }*/
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Giá đựng này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('Name','Tên giá đựng', 'required');
            $this->form_validation->set_rules('Cot', 'Cột', 'required');
            $this->form_validation->set_rules('Hang','Hàng', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                /*if($this->check($data_post,$id)){
                    $data['status'] = "fail";
                    $data['message'] = "Giá đựng này đã tồn tại.";
                    die(json_encode($data));
                }
                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }*/
                $this->add_row_col($data_post['Name'],intval($data_post['Hang']),intval($data_post['Cot']));
                $data['status'] = 'success';
                $data['action'] = 'edit';
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Giá đựng này không tồn tại.";
            die(json_encode($data));
        }
    	//$result = $this->Common_model->delete($this->table,array("ID" => $id));
    	$data_update = array();
        $data_update["Is_Delete"]  = 1;
        $result = $this->Common_model->update($this->table,$data_update,array("Name" => $record['Name']));
        if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }

    private function check($arr = array(),$id = null){
        $where = array(
            "Name"   => trim($arr['Name']),
            "Hang"    => trim($arr['Hang']),
            "Cot" => trim($arr['Cot'])
        );
        $record = $this->Common_model->get_record($this->table,$where);
        if($record != null){
            //return true;
            if($id == null){
                return true;
            }
            else{
                if($id == $record['ID']){
                    return false;
                }
                else{
                    return true;
                }
            }
        }
        return false;
    }

    private function add_row_col($name = null,$number_row = 0,$number_column = 0){
    	for ($i = 1; $i <= $number_row; $i++) { 
    		for ($j = 1; $j <= $number_column; $j++){ 
    			$where = array(
		            "Name"   => trim($name),
		            "Hang"   => $i,
		            "Cot" 	 => $j
		        );
    			$record = $this->Common_model->get_record($this->table,$where);
    			if($record == null){
    				$data_insert = array(
    					"Name"   => trim($name),
			            "Hang"   => $i,
			            "Cot" 	 => $j,
			            'Created_At' => date('Y-m-d H:i:s')
    				);
    				$this->Common_model->add($this->table,$data_insert);  
    			}
    		}
    	}
    }

    public function export(){
        set_time_limit(0);
        $this->data['is_export'] = true;
        $sql = "SELECT c.*
                FROM (
                    SELECT tbl1.*
                    FROM {$this->table} AS tbl1 
                    WHERE tbl1.Is_Delete = '0'
                    ORDER BY tbl1.Hang DESC,tbl1.Cot DESC, tbl1.ID DESC
                ) AS c 
                GROUP BY c.Name";
        $results = $this->Common_model->query_raw($sql);
        $title = 'Giá – Kệ';
        $header = array('Tên giá đựng','Hàng','Cột');
        $data = array();
        if(isset($results) && $results != null){
            foreach ($results as $key => $item) {
                $data[] = array(
                    $item['Name'],
                    $item['Hang'],
                    $item['Cot']
                );
            }
        }
        export_excel($title,$header,$data);
    }

    public function import(){
        $data = array('status' => 'error');
        if (isset($_FILES["excel"]['name']) && $_FILES["excel"]['name'] != null){
            $mimes = array('xls','xlsx');
            $ext = pathinfo($_FILES['excel']['name'], PATHINFO_EXTENSION);
            if(!in_array($ext,$mimes)){
                $data['message'] = 'Vui lòng chọn excel file.';
                $data['status']  = 'fail';
                die(json_encode($data));
            }

            $upload_path = FCPATH . "/uploads/excel";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, TRUE);
            }
            $config = array();
            $config['upload_path'] = $upload_path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($this->upload->do_upload('excel')){
                $upload_data = $this->upload->data();
                $path_file = $upload_data['full_path'];
                $data_excel = get_data_excel($path_file);
                foreach ($data_excel[0] as $key => $item) {
                    if($item != trim(@$this->data['header'][$key])){
                        $data['message'] = 'Excel file không đúng định dạng.';
                        $data['status']  = 'fail';
                        die(json_encode($data));
                    }
                }
                $data_insert = array();
                foreach ($data_excel as $key => $item) {
                    if($key > 0 && @$item[0] != null && intval(@$item[1]) > 0 && intval(@$item[2]) > 0){
                        /*$data_insert[] = array(
                            'Name' => $item[0],
                            'Cot' => $item[1],
                            'Hang' => $item[2],
                            'Created_At' => date('Y-m-d H:i:s')
                        );*/
                        $this->add_row_col($item[0],intval($item[1]),intval($item[2]));
                    }
                }
                $data['status']  = 'success';
                $data['message'] = "Nhập dữ liệu thành công";
                die(json_encode($data));
            }
            else{
                $data['message'] = $this->upload->display_errors();
                $data['status']  = 'fail';
                die(json_encode($data));
            }
        }
        else{
            $data['message'] = 'Vui lòng chọn file muốn nhập.';
            $data['status']  = 'fail';
            die(json_encode($data));
        }
        die(json_encode($data));
    }
}