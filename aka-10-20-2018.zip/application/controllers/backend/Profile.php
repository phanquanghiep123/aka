<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends MY_Controller {

    private $folder_view = "profile"; 
    private $_table = 'Aka_Sys_Users';

    public function __construct() {
        parent::__construct();
    }

    public function index(){
        $id = $this->user_info["ID"];
    	$record = $this->Common_model->get_record($this->_table,array("ID" => $id));
    	if($record == null){
    		redirect(backend_url());
        }
        if($this->input->post()){
            $this->form_validation->set_rules('User_Pwd', 'Mật khẩu', 'min_length[6]');
            if ($this->form_validation->run() == TRUE){
                $colums = $this->db->list_fields($this->_table);
                $data_post = $this->input->post();
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $data_update["Update_At"] = date("Y-m-d h:i:sa");
                if($data_update["User_Pwd"] != null && $data_update["User_Pwd"] != ""){
                	$data_update["User_Pwd"] = md5(trim($data_update["User_Pwd"])."{:MC:}".trim($record["User_Email"]));
                }
                if (isset($_FILES["User_Avatar"])){
                    $upload_path = FCPATH . "/uploads/backend";
                    if (!is_dir($upload_path)) {
                        mkdir($upload_path, 0755, TRUE);
                    }
                    $upload_path = FCPATH . "/uploads/backend/member";
                    if (!is_dir($upload_path)) {
                        mkdir($upload_path, 0755, TRUE);
                    }
                    $upload_path = $upload_path . "/" . $this->user_info["ID"];
                    if (!is_dir($upload_path)) {
                        mkdir($upload_path, 0755, TRUE);
                    }
                    $file = $_FILES["User_Avatar"];
                    $allowed_types = "jpg|png";
                    $upload = upload_flie($upload_path, $allowed_types, $file);
                    if($upload["status"] == "success"){
                    	$data_update["User_Avatar"] = "/uploads/backend/member/".$this->user_info["ID"]."/".$upload["reponse"]["file_name"];
                    }
                	else{
                		$data_update["User_Avatar"] = $record["User_Avatar"];
                    }
                }else{
                	$data_update["User_Avatar"] = $record["User_Avatar"];
                }
                $this->Common_model->update($this->_table,$data_update,array("ID" =>$record["ID"]));  
                $this->message($this->message_update_succes,'success');
            }else{
                $this->data['post']['status'] = "error";
                $this->data['post']['error'] = validation_errors();
            }
            redirect(backend_url("/".$this->folder_view."/"));
        }
        $this->data["role"] = $this->Common_model->get_result("Aka_Sys_Roles");
    	$this->data['record'] = $record;
    	$this->load->view($this->backend_asset."/".$this->folder_view."/edit",$this->data);
    }

    public function delete($id){
        $userID = $this->user_info["ID"];
        $check = $this->Common_model->delete("Aka_Sys_Company_Employee",array("Company_ID" => $id ,"User_ID" => $userID));
        if($check){
            $this->message($this->message_delete_succes,'success');
        }
        redirect(backend_url("/".$this->folder_view."/"));
    }
}
