<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Passing extends MY_Controller {

    private $folder_view = "passing";
    private $table = 'Luminous_Passing';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
    }

    public function index(){
        $where["1"] = "1";
        if($this->input->get("keyword") != null){
            $where["Name Like"] = "%".$this->input->get("keyword")."%";
        }
        $per_page = $this->per_page;
        $count_table = $this->Common_model->count_table($this->table,$where);
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0 ;    
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = $count_table;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->get_result($this->table,$where,$offset,$per_page,array('ID' => "DESC"));
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }
    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('Name', 'Tên chuyên', 'required');
            $this->form_validation->set_rules('Plan', 'Kế hoạch', 'required');
            $this->form_validation->set_rules('Status', 'Trạng thái', 'required');
            $this->form_validation->set_rules('ChuyenID','Chuyền ID','required|is_unique['.$this->table.'.ChuyenID]');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Status'] = $record["Status"] == 1 ? 'Hoạt động' : 'Ngưng hoạt động';
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }
    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Quản lí chuyền này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('Plan', 'Kế hoạch', 'required');
            $this->form_validation->set_rules('Status', 'Trạng thái', 'required');
            $this->form_validation->set_rules('ChuyenID', 'Chuyền ID', 'required|edit_unique[Luminous_Passing.ChuyenID.ID.'.$id.']');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Status'] = $record["Status"] == 1 ? 'Hoạt động' : 'Ngưng hoạt động';
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }
    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Quản lí chuyền này không tồn tại.";
            die(json_encode($data));
        }
        $result = $this->Common_model->delete($this->table,array("ID" => $id));
        if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }
    public function status($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Quản lí chuyền này không tồn tại.";
            die(json_encode($data));
        }
        $data_update = array();
        $data_update['Status'] = ($record['Status'] == 1 ? 0 : 1);
        $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));
        if($result){
            $data['status'] = 'success';
            $data['is_status'] = $data_update['Status']; 
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể cập nhật được.";
        }
        die(json_encode($data));
    }

    public function export(){
        set_time_limit(0);
        $this->data['is_export'] = true;
        $results = $this->Common_model->get_result($this->table,array('Is_Delete' => '0'),null,null,array('Name' => "ASC"));
        $title = 'Đơn vị tính';
        $header = array('Đơn vị tính','Mô tả','Trạng thái');
        $data = array();
        if(isset($results) && $results != null){
            foreach ($results as $key => $item) {
                $data[] = array(
                    $item['Name'],
                    $item['Description'],
                    $item["Status"] == 1 ? 'Hoạt động' : 'Ngưng hoạt động'
                );
            }
        }
        export_excel($title,$header,$data);
    }

    public function import(){
        $data = array('status' => 'error');
        if (isset($_FILES["excel"]['name']) && $_FILES["excel"]['name'] != null){
            $mimes = array('xls','xlsx');
            $ext = pathinfo($_FILES['excel']['name'], PATHINFO_EXTENSION);
            if(!in_array($ext,$mimes)){
                $data['message'] = 'Vui lòng chọn excel file.';
                $data['status']  = 'fail';
                die(json_encode($data));
            }

            $upload_path = FCPATH . "/uploads/excel";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, TRUE);
            }
            $config = array();
            $config['upload_path'] = $upload_path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($this->upload->do_upload('excel')){
                $upload_data = $this->upload->data();
                $path_file = $upload_data['full_path'];
                $data_excel = get_data_excel($path_file);
                foreach ($data_excel[0] as $key => $item) {
                    if($item != trim(@$this->data['header'][$key])){
                        $data['message'] = 'Excel file không đúng định dạng.';
                        $data['status']  = 'fail';
                        $data['test'] = $data_excel[0];
                        die(json_encode($data));
                    }
                }
                $message = '';
                $data_insert = array();
                foreach ($data_excel as $key => $item) {
                    if($key > 0 && @$item[0] != null){
                        $check = $this->Common_model->get_record($this->table,array("Name" => trim($item[0]),'Is_Delete' => '0'));
                        if($check != null){
                            $message .= 'Đơn vị tính "'.$item[0].'" đã tồn tại. <br>';
                        }
                        else{
                            $data_insert[] = array(
                                'Name' => trim(@$item[0]),
                                'Description' => trim(@$item[1]),
                                'Status' => 1,
                                'Created_At' => date('Y-m-d H:i:s')
                            );
                        }
                    }
                }
                if(count($data_insert) > 0){
                    $this->Common_model->insert_batch_data($this->table,$data_insert);
                }
                $data['status']  = 'success';
                $data['message'] = "Nhập dữ liệu thành công";
                $data['response'] = $message;
                die(json_encode($data));
            }
            else{
                $data['message'] = $this->upload->display_errors();
                $data['status']  = 'fail';
                die(json_encode($data));
            }
        }
        else{
            $data['message'] = 'Vui lòng chọn file muốn nhập.';
            $data['status']  = 'fail';
            die(json_encode($data));
        }
        die(json_encode($data));
    }
    public function counters (){
        $this->table = "Luminous_Counter";
        $this->load->model("Counters_model");
        $where["1"] = "1";
        if($this->input->get("keyword") != null){
            $where["tbl2.Name Like"] = "%".$this->input->get("keyword")."%";
        }
        $per_page = $this->per_page;
        $count_table = $this->Counters_model->count_table($this->table,$where);
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0 ;    
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = $count_table;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Counters_model->get_result($this->table,$where,$offset,$per_page,array('ID' => "DESC"));
        $this->data["add_url"] = backend_url ($this->folder_view."/add_counter");
        $this->load->view($this->backend_asset."/".$this->folder_view."/counters",$this->data);
    }
    public function add_counter(){
        
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('Passing_ID', 'Chuyên', 'required');
            $this->form_validation->set_rules('Type', 'Trạng thái', 'required');
            $this->form_validation->set_rules('Status', 'Trạng thái', 'required');
            $this->form_validation->set_rules('Counter_ID','Bộ đếm ID','required|is_unique[Luminous_Counter.Counter_ID]');
            if ($this->form_validation->run() == TRUE) {
                if($this->input->post("Type") <= 2){
                   $c =  $this->Common_model->get_record("Luminous_Counter",["Passing_ID" => $this->input->post("Passing_ID"),"Type" => $this->input->post("Type") ]);
                    if($c != null){
                        $lable  = $this->input->post("Type") == 1 ? "Thoát chuyền" :"Hoàn thành";
                        $data['message'] = "<p>Loại máy `".$lable."` đã có ở chuyền này xin vui lòng chọn loại máy khác</p>";
                        $data['status'] = "fail";
                        die(json_encode($data));
                    }
                }
                $data_post = $this->input->post();
                $colums = $this->db->list_fields("Luminous_Counter");
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }
                }
                $id = $this->Common_model->add("Luminous_Counter",$data_insert);  
                if($id > 0){
                    $this->load->model("Counters_model");
                    $record = $this->Counters_model->get_record("Luminous_Counter",array("tbl1.ID" => $id)); 
                    if($record["Type"] == '1') $record["Type"] = "Hoàn thành";
                    if($record["Type"] == '2') $record["Type"] = "Thoát chuyền";
                    if($record["Type"] == '3') $record["Type"] = "Cụm";
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add_counter");
        $this->data['type'] = 'add';
        $this->data["passings"] = $this->Common_model->get_result("Luminous_Passing");
        $this->load->view($this->backend_asset."/".$this->folder_view."/formcounter",$this->data);
    }
    public function edit_counter($id = null){
        $this->table = "Luminous_Counter";
        $this->load->model("Counters_model");
        $record = $this->Counters_model->get_record($this->table,array("tbl1.ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Quản lí chuyền này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('Passing_ID', 'Chuyên', 'required');
            $this->form_validation->set_rules('Type', 'Trạng thái', 'required');
            $this->form_validation->set_rules('Status', 'Trạng thái', 'required');
            $this->form_validation->set_rules('Counter_ID','Bộ đếm ID','required|edit_unique[Luminous_Counter.Counter_ID.ID.'.$id.']');
            if($this->form_validation->run() == TRUE){
                if($this->input->post("Type") <= 2){
                    $c =  $this->Common_model->get_record("Luminous_Counter",
                    [
                        "Passing_ID" => $this->input->post("Passing_ID"),
                        "Type" => $this->input->post("Type") ,
                        "ID != "   => $id
                    ]
                    );
                     if($c != null){
                        $lable  = $this->input->post("Type") == 2 ? "Thoát chuyền" :"Hoàn thành";
                        $data['message'] = "<p>Loại máy `".$lable."` đã có ở chuyền này xin vui lòng chọn loại máy khác</p>";
                        $data['status'] = "fail";
                        die(json_encode($data));
                     }
                 }
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                    $record = $this->Counters_model->get_record($this->table,array("tbl1.ID" => $id));
                    if($record["Type"] == 1) $record["Type"] = "Hoàn thành";
                    if($record["Type"] == 2) $record["Type"] = "Thoát chuyền";
                    if($record["Type"] == 3) $record["Type"] = "Cụm";
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit_counter/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->data["passings"] = $this->Common_model->get_result("Luminous_Passing");
        $this->load->view($this->backend_asset."/".$this->folder_view."/formcounter",$this->data);
    }
    public function delete_counter($id = 0){
        $this->table = "Luminous_Counter";
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Quản lí chuyền này không tồn tại.";
            die(json_encode($data));
        }
        $result = $this->Common_model->delete($this->table,array("ID" => $id));
        if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }
    public function status_counter($id = 0){
        $this->table = "Luminous_Counter";
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Quản lí chuyền này không tồn tại.";
            die(json_encode($data));
        }
        $data_update = array();
        $data_update['Status'] = ($record['Status'] == 1 ? 0 : 1);
        $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));
        if($result){
            $data['status'] = 'success';
            $data['is_status'] = $data_update['Status']; 
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể cập nhật được.";
        }
        die(json_encode($data));
    }
}