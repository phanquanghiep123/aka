<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Import_excel extends MY_Controller {

    private $folder_view = "import_excel";

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
    }

    public function index($table = null){
        //$table = 'KHO_DMVT';
        $base_64 = $table . str_repeat('=', strlen($table) % 4);
		$table = base64_decode($base_64);
        if ($table == null || !$this->db->table_exists($table)){
            redirect(backend_url());
        }
        if($this->input->post()){
            if (isset($_FILES["excel"]['name']) && $_FILES["excel"]['name'] != null){
                $mimes = array('application/vnd.ms-excel','text/xls','text/xlsx');
                if(!in_array($_FILES["excel"]["type"],$mimes)){
                    $this->message('Vui lòng chọn excel file.');
                    redirect(backend_url('/import_excel/index/'.$table));
                }

                $upload_path = FCPATH . "/uploads/excel";
                if (!is_dir($upload_path)) {
                    mkdir($upload_path, 0755, TRUE);
                }
                $config = array();
                $config['upload_path'] = $upload_path;
                $config['allowed_types'] = '*';
                $config['remove_spaces'] = TRUE;
                $this->load->library('upload');
                $this->upload->initialize($config);
                if ($this->upload->do_upload('excel')){
                    $upload_data = $this->upload->data();
                    $this->data["path_file"] = $upload_data['full_path'];
                    $this->data['header'] = get_data_excel($this->data["path_file"],true);
                    $this->data['table'] = $table;
                    $sql_get_columns = "
                        SELECT COLUMN_NAME,DATA_TYPE,COLUMN_COMMENT
                        FROM information_schema.columns
                        WHERE table_name = '{$table}' AND TABLE_SCHEMA = '{$this->db->database}' AND COLUMN_NAME != 'Created_At' AND COLUMN_NAME != 'ID' AND COLUMN_NAME != 'Status' ";
                    $this->data['colums'] = $this->Common_model->query_raw($sql_get_columns);
                    $this->load->view($this->backend_asset."/".$this->folder_view."/import",$this->data);
                }
                else{
                    $this->message($this->upload->display_errors());
                    redirect(backend_url('/import_excel/index/'.$table));
                }
            }
            else{
                $this->message('Vui lòng chọn file muốn nhập.');
                redirect(backend_url('/import_excel/index/'.$table));
            }
        }
        else{
            $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
        }
    }

    public function import(){
    	set_time_limit(0);
        $data = array('status' => 'error');
        $table = $this->input->post('table');
        $path_file = $this->input->post('path_file');
        $fields = $this->input->post('field');
        $check = false;
        foreach ($fields as $key => $item) {
            if($item != '' && $item != null){
                $check = true;
            }
        }
        if(!$check || $fields == null){
            $data['status'] = 'fail';
            $data['message'] = 'Vui lòng chọn trường dữ liệu.';
            die(json_encode($data));
        }
        if(!($path_file != null && file_exists($path_file))){
            $data['status'] = 'fail';
            $data['message'] = 'Không tìm thấy Excel file.';
            die(json_encode($data));
        }
        if($table == null || !$this->db->table_exists($table)){
            $data['status'] = 'fail';
            $data['message'] = 'Bảng dữ liệu này không tồn tại';
            die(json_encode($data));
        }

        $data_excel = get_data_excel($path_file);
        if(@$data_excel != null && count($data_excel) > 0){
            $sql_get_columns = "
                SELECT COLUMN_NAME,DATA_TYPE,COLUMN_COMMENT
                FROM information_schema.columns
                WHERE table_name = '{$table}' AND TABLE_SCHEMA = '{$this->db->database}' AND COLUMN_NAME != 'Created_At' AND COLUMN_NAME != 'ID' AND COLUMN_NAME != 'Status' AND COLUMN_NAME != 'Is_Delete' ";
            $colums = $this->Common_model->query_raw($sql_get_columns);

            $sql_get_key = "SELECT
                `column_name`, 
                `referenced_table_schema` AS foreign_db, 
                `referenced_table_name` AS foreign_table, 
                `referenced_column_name`  AS foreign_column 
            FROM `information_schema`.`KEY_COLUMN_USAGE`
            WHERE `constraint_schema` = SCHEMA() AND `table_name` = '{$table}' AND `referenced_column_name` IS NOT NULL AND TABLE_SCHEMA = '{$this->db->database}'
            ORDER BY `column_name`";
            $colums_key = $this->Common_model->query_raw($sql_get_key);
            $data_insert = array();
            foreach ($data_excel as $key => $item) {
                if($key > 0){
                    $temp = array();
                    $check_foreignkey = true;
                    foreach ($fields as $key1 => $field) {
                        if($field != null && $field != '' && $this->db->field_exists($field,$table)){
                            if($this->check_foreignkey_field($colums_key,$field)){
                                $value_foreignkey = $this->get_val_foreignkey_field($colums_key,$field,$item[$key1]);
                                if($value_foreignkey == 0){
                                    $check_foreignkey = false;
                                }
                                else{
                                    $temp[$field] = $value_foreignkey;
                                }
                            }
                            else{
                                $type_field = $this->get_type_field($colums,$field);
                                if($type_field == 'datetime'){
                                    $temp[$field] = date('Y-m-d H:i:s',strtotime($item[$key1]));
                                }
                                else if($type_field == 'date'){
                                    $temp[$field] = date('Y-m-d',strtotime($item[$key1]));
                                }
                                else if($type_field == 'tinyint' || $type_field == 'bigint'){
                                    $temp[$field] = intval($item[$key1]);
                                }
                                else{
                                    $temp[$field] = $item[$key1];
                                }
                            }
                        }
                    }
                    if(count($temp) > 0 && $check_foreignkey){
                    	if($this->db->field_exists('Created_At',$table)){
                    		$temp['Created_At'] = date('Y-m-d H:i:s');
                    	}
                        $data_insert[] = $temp;
                    }
                }
            }
            if(count($data_insert) > 0){
            	$this->Common_model->insert_batch_data($table,$data_insert);
            }

            $data['insert'] = $data_insert;
            $data['status'] = 'success';
            $data['response'] = $colums_key;
        }
        die(json_encode($data));
    }

    private function get_type_field($colums = array(),$field = null){
        foreach ($colums as $key => $item) {
            if($item['COLUMN_NAME'] == $field){
                return $item['DATA_TYPE'];
            }
        }
        return false;
    }

    private function check_foreignkey_field($colums_key = array(),$field = null){
        if(isset($colums_key) && $colums_key != null){
        	foreach($colums_key as $key => $item) {
	            if($item['column_name'] == $field){
	                return true;
	            }
	        }
        }
        return false;
    }    

    private function get_val_foreignkey_field($colums_key = array(),$field = null,$name = null){
        foreach ($colums_key as $key => $item) {
            if($item['column_name'] == $field){
                $foreign_table = $item['foreign_table'];
                if($foreign_table != null && $this->db->table_exists($foreign_table)){
                    $record = $this->Common_model->get_record($foreign_table,array("Name" => trim($name)));
                    if(@$record['ID'] != null && $record['ID'] > 0){
                        return $record['ID'];
                    }
                }
            }
        }
        return 0;
    }

    private function check_foreignkey_table($table = null){
    	if($this->db->table_exists($table)){
    		$sql_get_key = "SELECT
                `column_name`, 
                `referenced_table_schema` AS foreign_db, 
                `referenced_table_name` AS foreign_table, 
                `referenced_column_name`  AS foreign_column 
            FROM `information_schema`.`KEY_COLUMN_USAGE`
            WHERE `constraint_schema` = SCHEMA() AND `table_name` = '{$table}' AND `referenced_column_name` IS NOT NULL AND TABLE_SCHEMA = '{$this->db->database}'
            ORDER BY `column_name`";
            $colums_key = $this->Common_model->query_raw($sql_get_key);
            if(isset($colums_key) && $colums_key != null){
            	return true;
            }
    	}
    	return false;
    }
}