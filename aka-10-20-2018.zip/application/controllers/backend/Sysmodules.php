<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Sysmodules extends MY_Controller {
    private $html_modules = '';
    private $folder_view = "sysmodules";
    public function __construct() {
        parent::__construct();
    }
    public function index(){
        if($this->input->post()){
            $od = $this->input->post("Order");
            $md = $this->input->post("IDModel");
            foreach ($md as $key => $value) {
                $data_update = array("Order" => $od[$key]);
                $this->Common_model->update("Aka_Sys_Modules",$data_update , array("ID" => $value));
            }
            redirect(backend_url("/".$this->folder_view."?edit=success"));
        }
    	//$table_data = $this->Common_model->get_result('Aka_Sys_Modules',null,null,null,array("Order" => "ASC"));
        $in_onlySp = ['0'];
        if($this->user_info['Is_Lock'] == 1) $in_onlySp = ['0','1'];
        $this->db->select("*");
        $this->db->from("Aka_Sys_Modules");
        $this->db->where_in("Only_Sp",$in_onlySp);
        $this->db->order_by("Order","ASC");
        $table_data = $this->db->get()->result_array();
    	$this->data['html_modules'] = $this->get_html_modules($table_data);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function create(){
        if($this->input->post()){
            $this->form_validation->set_rules('Module_Name', 'Tên hệ thống', 'required');
            $this->form_validation->set_rules('Module_Key', 'Mã định danh hệ thống', 'required');
            $this->form_validation->set_rules('Module_Url', 'Đường dẫn', 'required');
            $this->form_validation->set_rules('Status', 'Trạng thái', 'required');
            if ($this->form_validation->run() == TRUE){
                $colums = $this->db->list_fields('Aka_Sys_Modules');
                $data_post = $this->input->post();
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert["Is_Sys"] = $this->user_info['Is_Sys'];
                $id = $this->Common_model->add("Aka_Sys_Modules",$data_insert);  
                redirect(backend_url("/".$this->folder_view."/edit/" . $id ."?create=success"));
            }else{
            	$this->data['post']['status'] = "error";
                $this->data['post']['error'] = validation_errors();
            }
        }
        $table_data = $this->Common_model->get_result('Aka_Sys_Modules',null,null,null,array("Order" => "ASC"));
        $this->data['option_modules'] = $this->get_html_modules($table_data,0,'',false,0);
    	$this->load->view($this->backend_asset."/".$this->folder_view."/create",$this->data);
    }

    public function edit($id = null){
    	$record = $this->Common_model->get_record("Aka_Sys_Modules",array("ID" => $id));
    	if($record == null){
    		redirect(backend_url("/".$this->folder_view."/"));
        }
        if($this->input->post()){
            $this->form_validation->set_rules('Module_Name', 'Tên hệ thống', 'required');
            $this->form_validation->set_rules('Module_Key', 'Mã định danh hệ thống', 'required');
            $this->form_validation->set_rules('Module_Url', 'Đường dẫn', 'required');
            $this->form_validation->set_rules('Status', 'Trạng thái', 'required');
            if ($this->form_validation->run() == TRUE){
                $colums = $this->db->list_fields('Aka_Sys_Modules');
                $data_post = $this->input->post();
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $this->Common_model->update("Aka_Sys_Modules",$data_update,array("ID" =>$record["ID"]));  
                redirect(backend_url("/".$this->folder_view."/edit/" . $id. "?edit=success"));
            }else{
                $this->data['post']['error'] = validation_errors();
            }
        }
    	$this->data['record'] = $record;
    	$table_data = $this->Common_model->get_result('Aka_Sys_Modules',array("ID !=" => $record["ID"]),null,null,array("Order" => "ASC"));
        $this->data['option_modules'] = $this->get_html_modules($table_data,0,'',false,@$record["Parent_ID"]);
    	$this->load->view($this->backend_asset."/".$this->folder_view."/edit",$this->data);
    }

    public function delete($id = 0){
    	$this->Common_model->delete("Aka_Sys_Modules",array("ID" => $id));
    	redirect(backend_url("/".$this->folder_view."?delete=success"));
    }
    
    private $index = 1;
    private function get_html_modules($data = null,$root = 0,$level = '', $table = true , $activer = -1){
        $termsList = array();
        $new_listdata = array();
        if ($root != 0)
        {
            $level .= '&mdash; &mdash;';
        }
        if ($data != null) { 
            foreach ($data AS $key => $item )
            {
                if ($item['Parent_ID'] == $root)
                {
                    $termsList[] = ($item);
                }
                else
                {
                    $new_listdata[] = ($item);
                }
            }
        }
        if ($termsList != null)
        {
            foreach ($termsList AS $key => $item_2 )
            {
                $active = '';
                if ($activer == $item_2['ID'])
                {
                    $active = 'selected';
                }
                if ($table == false)
                {
                    $this->html_modules .= '<option value="' . $item_2['ID'] . '" '. $active . '>' . $level . '  ' . $item_2['Module_Name'] . '</option>';
                   
                }
                else
                {
                    $this->html_modules .= '<tr>';
                    $this->html_modules .= '<td>'.($this->index++).'</td>';
                    $this->html_modules .= '<td>' . $level . '  ' . $item_2['Module_Name'] . '</td>';
                    $this->html_modules .= '<td>' . $item_2['Module_Url'] . '</td>';
                    $this->html_modules .= '<td><input type="number" name = "Order[]" value ="'. $item_2['Order'] .'"><input type="hidden" name = "IDModel[]" value ="'. $item_2['ID'] . '"> </td>';
                    if($item_2["Status"] == "1")
                    	$this->html_modules .='<td>Hoạt động</td>';
                    else
                    	$this->html_modules .='<td>Ngừng hoạt động </td>';
                    $this->html_modules .= '<td><a href = "'.backend_url('sysmodules/edit/'. $item_2['ID']).'" title = "Chỉnh sửa" style = "margin-right:5px;"> <i class="fa fa-edit" aria-hidden="true"></i> </a> | <a title="Xóa" href = "'.backend_url('sysmodules/delete/'. $item_2['ID']).'" onclick="return confirm(\'Bạn thật sự muốn xóa?\');"> <i class="fa fa-trash-o" aria-hidden="true"></i> </a> </td>';
                    $this->html_modules .= '</tr>';
                }
                $this->get_html_modules($new_listdata, $item_2['ID'], $level, $table, $activer);
            }
        }
        return $this->html_modules;
    }
}
