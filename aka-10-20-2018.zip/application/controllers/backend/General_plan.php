<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class General_plan extends MY_Controller {

    private $folder_view = "general_plan";
    private $table = 'M3_KeHoachChung';
    private $table_plu = 'M2_MaHang';
    private $table_loaihinh = 'M2_LoaiHinh';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
        $this->data['loaihinh'] = $this->Common_model->get_result($this->table_loaihinh);
        $this->data['plus'] = $this->Common_model->get_result($this->table_plu);
    }

    public function index($date = null){
        if($date != null){
            $date = date('Y-m-d',$date);
            $last_date = date('Y-m-d',strtotime("+7 day",strtotime($date)));
        }
        else{
            $date = date('Y-m-d');
            $last_date = date('Y-m-d',strtotime("+7 day"));
        }
        if($this->input->post()){
            $data_post = $this->input->post();
            $soluong = @$data_post['soluong'];
            $date_post    = @$data_post['date'];
            if(isset($soluong) && $soluong != null && $this->input->post('loaihinh') != null){
                foreach ($soluong as $key => $item) {
                    foreach ($item as $key1 => $item2) {
                        if(@$item2 != null && @$date_post[$key][$key1] != null){
                            $check = $this->Common_model->get_record($this->table,array('MaHang' => $key,'LoaiHinh' => $this->input->post('loaihinh'),'Ngay' => $date_post[$key][$key1]));
                            if($check != null){
                                $arr = array(
                                    'SoLuong' => $this->cover_number($item2)
                                );
                                $this->Common_model->update($this->table,$arr,array('MaHang' => $key,'Ngay' => $date_post[$key][$key1]));
                            }
                            else{
                                $arr = array(
                                    'MaHang' => $key,
                                    'Ngay'  => $date_post[$key][$key1],
                                    'LoaiHinh' => $this->input->post('loaihinh'),
                                    'SoLuong' => $this->cover_number($item2)
                                );
                                $this->Common_model->add($this->table,$arr);
                            }
                        }
                    }
                }
            }
            $this->message($this->message_update_succes,'success');
            redirect(backend_url($this->folder_view.'/index/'.strtotime($date).'?loaihinh='.$this->input->post('loaihinh')));
        }
        $sql = "SELECT tbl1.*
                FROM {$this->table_plu} AS tbl1
                ORDER BY tbl1.ID DESC";
        $results = $this->Common_model->query_raw($sql);
        if(isset($results) && $results != null){
            foreach($results as $key => $item){
                $where = array(
                    'MaHang' => $item['ID'],
                    //'Date >='    => $date,
                    //'Date <'    => $last_date
                );
                $results[$key]['kehoachchung'] = $this->Common_model->get_result($this->table,$where,null,null,array('Ngay' => 'ASC'));
                $sql = "SELECT SUM(SoLuong) AS Total FROM {$this->table} WHERE MaHang = '{$item['ID']}'";
                $results[$key]['total'] = $this->Common_model->query_raw_row($sql);
            }
        }
        $numberDays = 7;
        $this->data['numberDays'] = $numberDays;
        $this->data['current_date'] = $date;
        $this->data['results'] = $results;
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function load_table($date = null){
        if($date != null){
            $date = date('Y-m-d',$date);
            $last_date = date('Y-m-d',strtotime("+7 day",strtotime($date)));
        }
        else{
            $date = date('Y-m-d');
            $last_date = date('Y-m-d',strtotime("+7 day"));
        }
        $sql = "SELECT tbl1.*
                FROM {$this->table_plu} AS tbl1
                ORDER BY tbl1.ID DESC";
        $results = $this->Common_model->query_raw($sql);
        if(isset($results) && $results != null){
            foreach($results as $key => $item){
                $where = array(
                    'MaHang'  => $item['ID'],
                    'LoaiHinh' => $this->input->post('loaihinh'),
                    //'Date >='    => $date,
                    //'Date <'    => $last_date
                );
                $results[$key]['kehoachchung'] = $this->Common_model->get_result($this->table,$where,null,null,array('Ngay' => 'ASC'));
                $sql = "SELECT SUM(SoLuong) AS Total FROM {$this->table} WHERE MaHang = '{$item['ID']}' AND LoaiHinh = '{$this->input->post('loaihinh')}'";
                $results[$key]['total'] = $this->Common_model->query_raw_row($sql);
            }
        }
        $numberDays = 7;
        $this->data['numberDays'] = $numberDays;
        $this->data['current_date'] = $date;
        $this->data['results'] = $results;
        $this->load->view($this->backend_asset."/".$this->folder_view."/table",$this->data);
    }
}