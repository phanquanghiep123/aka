<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Absent_schedule extends MY_Controller {

    private $_folder_view = "absent_schedule";
    private $_table = 'm6_absent_schedule';
    private $_time_slot = 'm6_time_slot';
    private $_department = 'M6_Department';
    private $_attendance = "m6_attendance";
    private $_working_schedule = 'm6_working_schedule';
    private $_employee = 'M6_Employee';
    private $_holiday = 'm6_holidays';
    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->_folder_view;
        $this->load->model("Attendance_model");
        $this->load->model("Attendance_schedule_model");
        $this->data['header'] = array('Tên phòng ban','Mô tả');
    }

    public function index(){
        $this->data["get"] = $this->input->get();
        $where = [];
        $year = date("Y");
        $month = date("m");
        $name = "";
        if($this->input->get("Year")){
            $year  = $this->input->get("Year");   
        }
        if($this->input->get("Year")){
            $month  = $this->input->get("Month"); 
        }
        if($this->input->get("Year")){
            $name  = $this->input->get("Name"); 
        }
        $where["year(tbl2.AbsentDate)"] = $year;
        $where["month(tbl2.AbsentDate)"] = $month;
        $this->data["get"]['Year'] = $year;
        $this->data["get"]['Month'] = $month;
        $this->data["get"]['Name'] = $name;
        $Employee_ID = ($this->user_info["Employee_ID"]);
        $Employees = $Departments = null;
        if($this->user_info["Is_Sys"] == 1){
            $Departments = $this->Common_model->get_result($this->_department);
        }else{
            $Employee = $this->Common_model->get_record($this->_employee,["ID" => $Employee_ID]);
            $Department_ID = $Employe["Department_ID"];
            $Departments = $this->Common_model->get_result($this->_department,["ID" => $Department_ID]);
        }
        if($Departments != null){
            $FDepartments = $Departments[0];
            $FDepartments_ID = ($this->input->get("Department_ID")) ?  $this->input->get("Department_ID") : $FDepartments["ID"];
            $Employees = $this->Attendance_schedule_model->listData($FDepartments_ID,$where,$name);
        }    
        $where = [];
        $where["year(HolidayDate)"] = $year;
        $where["month(HolidayDate)"] = $month;
        $holidays = $this->Common_model->get_result($this->_holiday,$where);
        $this->data["Departments"] = $Departments;
        $this->data["Employees"]   = $Employees;
        $this->data["holidays"]    = $holidays;
        $this->load->view($this->backend_asset."/".$this->_folder_view."/index",$this->data);
    }
    public function view(){
        $data = array('status' => 'error');
        if($this->input->post()){
            $member = $this->input->post("member");
            $date = $this->input->post("date");
            $department = $this->input->post("department");  
            $m = $this->Common_model->get_record($this->_employee,["ID" => $member]);
            $d = $this->Common_model->get_record($this->_department,["ID" => $department]);
            $data['responsive']["time_slots"] = null;
            $data['responsive']["time_slots_member"] = null;
            $data['responsive']["member"] = null;
            if($m && $d){
                $data['responsive']["member"] = $m;
                $data['responsive']["time_slots_member"] = $time_slots_member = $this->Attendance_schedule_model->by_user($m["ID"], $d["ID"],$date);
                $not_IDs = [];
                foreach ($time_slots_member as $key => $value) {
                    $not_IDs[] =  $value["Time_Slot_ID"];
                }
                $ws = $this->Common_model->get_result($this->_working_schedule,["Department_ID" => $d["ID"],"Is_Active" => 1]);
                if($ws){
                    $slot_IDs = [];
                    foreach ($ws as $key => $value) {
                        $slot_IDs[] = $value["Time_Slot_Working_ID"];
                    }
                    if($slot_IDs != null){
                        $ts = $this->Attendance_model->working_schedule($slot_IDs,$not_IDs);
                        $data['responsive']["time_slots"] = $ts;
                    }
                } 
            }           
            $data['status'] = "success";
        }
        die(json_encode($data));
    }
    public function edit(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $id = $this->input->post("id");
            $record = $this->Common_model->get_record($this->_table,["ID" => $id]);
            if($record){
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->_table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums) && $key != "ID"){
                        $data_update[$key] = $value;
                    }              
                }
                $result = $this->Common_model->update($this->_table,$data_update,array("ID" =>$record["ID"])); 
                $m = $this->Common_model->get_record($this->_employee,["ID" => $record["Employee_ID"]]);
                $data['responsive'] = json_encode($this->Attendance_schedule_model->by_user($m["ID"], $m["Department_ID"],$record["AbsentDate"]));
                $data['status'] = "success";     
            } 
        }else{
            $id = $this->input->get("id");
            $data['status'] = "success"; 
            $data['responsive'] = $this->Common_model->get_record($this->_table,array("ID" =>$id)); 
        }
        die(json_encode($data));
    }
    public function update(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $listAdd = $this->input->post("listAdd");
            $listDelete = $this->input->post("listDelete");
            $CurentDay = $this->input->post("CurentDay");
            $memberID = $this->input->post("memberID");
            $m = $this->Common_model->get_record($this->_employee,["ID" => $memberID]);
            if($m){
                if(is_array($listDelete)){
                    foreach ($listDelete as $key => $value) {
                        $this->Common_model->delete($this->_table ,["Employee_ID" => $memberID,"Time_Slot_ID" => $value,"AbsentDate" => $CurentDay]);
                        $check_attendance = $this->Common_model->get_record($this->_attendance ,["Employee_ID" => $memberID,"Time_Slot_ID" => $value, "WorkingDate" => $CurentDay]);
                        if($check_attendance ){
                            $this->Common_model->update($this->_attendance,["Absent_Schedule_ID" => null],["ID" => $check_attendance["ID"]]);
                        }
                    }
                }
                 if(is_array($listAdd)){
                    foreach ($listAdd as $key => $value) {
                        $c = $this->Common_model->get_record($this->_table ,["Employee_ID" => $memberID,"Time_Slot_ID" => $value, "AbsentDate" => $CurentDay]);
                        if($c == null){
                            $data["ID"] =  $this->Common_model->add($this->_table ,["Employee_ID" => $memberID,"Time_Slot_ID" => $value,"Sort" => $key, "AbsentDate" => $CurentDay]);
                            if($data["ID"]){
                                $check_attendance = $this->Common_model->get_record($this->_attendance ,["Employee_ID" => $memberID,"Time_Slot_ID" => $value, "WorkingDate" => $CurentDay]);
                                if($check_attendance ){
                                    $this->Common_model->update($this->_attendance,["Absent_Schedule_ID" => $data["ID"],"Is_Absent" => 1],["ID" => $check_attendance["ID"]]);
                                }
                            }
                        }  else{
                            $this->Common_model->update($this->_table ,["Sort" => $key],["Employee_ID" => $memberID,"Time_Slot_ID" => $value]);
                        }             
                    }
                }
                $data['responsive'] = json_encode($this->Attendance_schedule_model->by_user($m["ID"], $m["Department_ID"],$CurentDay));
                $data['status'] = 'success';
            }
        }
        die(json_encode($data));
    }

    
}