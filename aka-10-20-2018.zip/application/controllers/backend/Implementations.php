<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Implementations extends MY_Controller {
    private $folder_view = "implementations";
    private $table = "M3_KeHoach_ThucHien";
    private $model = "Implementations_model";
    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
        $this->load->model($this->model);
        $this->model = $this->{$this->model};
    }

    public function index(){       
        $this->data["title_page"] = "Kế hoạch thực hiện";
        $this->data["table_data"] = $this->model->get_all();
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }
    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('Chuyen_ID', 'Tên chuyền', 'required');
            $this->form_validation->set_rules('ChiTietMaHangID', 'Tên đơn hàng', 'required');
            $this->form_validation->set_rules('SoLuongThucHien', 'Số lượng thực hiện', 'required');
            $this->form_validation->set_rules('SoLuongKeHoach', 'Số lượng kế hoạch', 'required');
            if ($this->form_validation->run() == TRUE){
                $colums = $this->db->list_fields($this->table);
                $data_post = $this->input->post();
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                    $record = $this->model->get_edit($id);
                    $data['responsive'] = $record;
                    $data['status'] = "success";
                    $data['action'] = 'add';
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data["departments"] = $this->Common_model->get_result("M6_Department");
        $this->data["action"]      = backend_url("/".$this->folder_view."/add/");
        $this->data["goods"]       = $this->model->get_order();
        $this->load->view($this->backend_asset."/".$this->folder_view."/create",$this->data);
    }

    public function delete($id = 0){
    	$this->Common_model->delete($this->table,array("ID" => $id));
    	redirect(backend_url("/".$this->folder_view."?delete=success"));
    }

    public function edit($id = null){
    	$record = $this->Common_model->get_record($this->table,array("ID" => $id));
    	if($record == null){
    		redirect(backend_url("/".$this->folder_view."/"));
        }
        if($this->input->post()){
            $this->form_validation->set_rules('Chuyen_ID', 'Tên chuyền', 'required');
            $this->form_validation->set_rules('ChiTietMaHangID', 'Tên đơn hàng', 'required');
            $this->form_validation->set_rules('SoLuongThucHien', 'Số lượng thực hiện', 'required');
            $this->form_validation->set_rules('SoLuongKeHoach', 'Số lượng kế hoạch', 'required');
            if ($this->form_validation->run() == TRUE){
                $colums = $this->db->list_fields($this->table);
                $data_post = $this->input->post();
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));  
                $record = $this->model->get_edit($record["ID"]);
                $data['responsive'] = $record;
                $data['status'] = "success";
                $data['action'] = 'edit';
            }else{
                $data['status'] = "fail";
                $data['message'] = "Thêm mới thất bại. Vui lòng kiểm tra thông tin đầu vào";
            }
            die(json_encode($data));
        }
        $this->data["departments"] = $this->Common_model->get_result("M6_Department");
        $this->data["action"]      = backend_url("/".$this->folder_view."/edit/");
        $this->data["goods"]       = $this->model->get_order();
        $this->data["post"]        = $this->model->get_edit($id);
    	$this->load->view($this->backend_asset."/".$this->folder_view."/edit",$this->data);
    }
}
