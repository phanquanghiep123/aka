<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Plu_detail extends MY_Controller {

    private $folder_view = "plu_detail";
    private $table = 'M2_ChiTietMaHang';
    private $table_plu = 'M2_MaHang';
    private $table_size = 'M2_Size';
    private $table_color = 'M2_Color';
    private $table_sizegroup = 'M2_SizeGroup';
    private $table_kehoachsx = 'M2_KeHoachSX';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;

        $sql = "SELECT tbl2.*,tbl3.Name AS GroupName
                FROM {$this->table_size} AS tbl2 
                INNER JOIN {$this->table_sizegroup} AS tbl3 ON tbl3.ID = tbl2.SizeGroup_ID
                ORDER BY tbl2.ID DESC";
        $this->data["size_result"] = $this->Common_model->query_raw($sql);
        $this->data["plu_result"]    = $this->Common_model->get_result($this->table_plu);
        $this->data["size_group_result"] = $this->Common_model->get_result($this->table_sizegroup);
        
        $where = '';
        if($this->input->post('color')){
            $where = " AND ID IN (".$this->input->post('color').")";
        }
        $sql = "SELECT *
                FROM {$this->table_color}
                WHERE 1=1 $where
                ORDER BY ID DESC";

        $this->data["color_result"] = $this->Common_model->query_raw($sql);
        $this->data['header'] = array('Mã hàng','Kích thước','Màu sắc','Số lượng','Ngày bắt đầu','Ngày kết thúc');
    }

    public function index(){
        $where = " WHERE 1=1 ";
        if($this->input->get("Plu") != null){
            $where .= " AND tbl1.MaHang_ID = '".$this->input->get("Plu")."'";
        }
        if($this->input->get("Size") != null){
            $where .= " AND tbl1.Size_ID = '".$this->input->get("Size")."'";
        }
        if($this->input->get("Color") != null){
            $where .= " AND tbl1.Color_ID = '".$this->input->get("Color")."'";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl2.Name AS PluName,tbl3.Name AS SizeName,tbl4.MaMau,tbl5.SoLuongSum
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_plu} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
                INNER JOIN {$this->table_size} AS tbl3 ON tbl3.ID = tbl1.Size_ID
                INNER JOIN {$this->table_color} AS tbl4 ON tbl4.ID = tbl1.Color_ID
                LEFT JOIN (
                    SELECT SUM(tbl1.SoLuong) AS SoLuongSum,tbl2.ID
                    FROM {$this->table} AS tbl1 
                    INNER JOIN {$this->table_plu} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
                    GROUP BY tbl2.ID
                ) AS tbl5 ON tbl5.ID = tbl1.MaHang_ID
                $where 
                GROUP BY tbl2.ID
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM (
            	SELECT tbl2.ID
	            FROM {$this->table} AS tbl1 
	            INNER JOIN {$this->table_plu} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
	            INNER JOIN {$this->table_size} AS tbl3 ON tbl3.ID = tbl1.Size_ID
	            INNER JOIN {$this->table_color} AS tbl4 ON tbl4.ID = tbl1.Color_ID
	            $where
	            GROUP BY tbl2.ID
	        ) AS tbl1";

        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('MaHang_ID', 'Mã hàng', 'required');
            $this->form_validation->set_rules('Size_ID', 'Kích thước', 'required');
            $this->form_validation->set_rules('Color_ID', 'Màu sắc', 'required');
            $this->form_validation->set_rules('SoLuong', 'Số lượng', 'required');
            $this->form_validation->set_rules('StartDate', 'Ngày bắt đầu', 'required');
            $this->form_validation->set_rules('EndDate', 'Ngày kết thúc', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        if($key == 'StartDate' || $key == 'EndDate'){
                            $data_insert[$key] = date('Y-m-d',strtotime($value));
                        }
                        else if( $key == 'SoLuong'){
                            $data_insert[$key] = $this->cover_number($value);
                        }
                        else{
                            $data_insert[$key] = $value;
                        }
                    }              
                }
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $record['StartDate'] = date($this->date_format,strtotime($record["StartDate"]));
                    $record['EndDate'] = date($this->date_format,strtotime($record["EndDate"]));
                    $record['SoLuong'] = $record['SoLuong'] != null ? number_format($record['SoLuong']) : '0';
                    
                    $plug = $this->Common_model->get_record($this->table_plu,array("ID" => $record['MaHang_ID']));
                    $record['PluName'] = @$plug['Name'] == null ? '' : $plug['Name'];
                    
                    $size = $this->Common_model->get_record($this->table_size,array("ID" => $record['Size_ID']));
                    $record['SizeName'] = @$size['Name'] == null ? '' : $size['Name'];

                    $color = $this->Common_model->get_record($this->table_color,array("ID" => $record['Color_ID']));
                    $record['MaMau'] = @$color['MaMau'] == null ? '' : $color['MaMau'];
                    
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function add_more(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('MaHang_ID', 'Mã hàng', 'required');
            if ($this->form_validation->run() == TRUE) {
               	$check = true;
                $data_post = $this->input->post();
                if(isset($data_post['soluong']) && $data_post['soluong'] != null){
                	$date_start = @$data_post['StartDate'];
                	$date_end = @$data_post['EndDate'];
                	foreach ($data_post['soluong'] as $color_id => $item) { //
                		foreach ($item as $size_id => $item1) {
                			if(isset($item1) && $item1 != null 
                				&& isset($date_start[$color_id][$size_id]) && $date_start[$color_id][$size_id] != null 
                				&& isset($date_end[$color_id][$size_id]) && $date_end[$color_id][$size_id] != null){
                				$data_insert = array(
                					'MaHang_ID' => $this->input->post('MaHang_ID'),
                					'Size_ID'	=> $size_id,
                					'Color_ID'	=> $color_id,
                					'SoLuong' 	=> $this->cover_number($item1),
                					'StartDate'	=> date('Y-m-d',strtotime($date_start[$color_id][$size_id])),
                					'EndDate'	=> date('Y-m-d',strtotime($date_end[$color_id][$size_id])),
                					'Created_At'=> date('Y-m-d H:i:s')
                				);
                				$this->Common_model->add($this->table,$data_insert); 
                				$check = false;
                			}
                		}
                	}
                }
                if($check == true){
                	$this->message('Vui lòng nhập đầu đủ dữ liệu.');
                }
                else{
                	$this->message($this->message_add_succes,'success');
                	redirect(backend_url("/".$this->folder_view."/"));
                }
            }else{
                $this->message(validation_errors());
            }
            redirect(backend_url($this->folder_view.'/add_more/'));
        }
        $this->load->view($this->backend_asset."/".$this->folder_view."/add-more",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Chi tiết mã hàng này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('MaHang_ID', 'Mã hàng', 'required');
            $this->form_validation->set_rules('Size_ID', 'Kích thước', 'required');
            $this->form_validation->set_rules('Color_ID', 'Màu sắc', 'required');
            $this->form_validation->set_rules('SoLuong', 'Số lượng', 'required');
            $this->form_validation->set_rules('StartDate', 'Ngày bắt đầu', 'required');
            $this->form_validation->set_rules('EndDate', 'Ngày kết thúc', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        if($key == 'StartDate' || $key == 'EndDate'){
                            $data_update[$key] = date('Y-m-d',strtotime($value));
                        }
                        else if( $key == 'SoLuong'){
                            $data_update[$key] = $this->cover_number($value);
                        }
                        else{
                            $data_update[$key] = $value;
                        }
                    }              
                }
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $record['StartDate'] = date($this->date_format,strtotime($record["StartDate"]));
                    $record['EndDate'] = date($this->date_format,strtotime($record["EndDate"]));
                    $record['SoLuong'] = $record['SoLuong'] != null ? number_format($record['SoLuong']) : '0';
                    
                    $plug = $this->Common_model->get_record($this->table_plu,array("ID" => $record['MaHang_ID']));
                    $record['PluName'] = @$plug['Name'] == null ? '' : $plug['Name'];
                    
                    $size = $this->Common_model->get_record($this->table_size,array("ID" => $record['Size_ID']));
                    $record['SizeName'] = @$size['Name'] == null ? '' : $size['Name'];

                    $color = $this->Common_model->get_record($this->table_color,array("ID" => $record['Color_ID']));
                    $record['MaMau'] = @$color['MaMau'] == null ? '' : $color['MaMau'];
                    

                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function edit_more($id = null){

    	$sql = "SELECT tbl1.*,tbl2.Name AS PluName,tbl3.Name AS SizeName,tbl4.MaMau
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_plu} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
                INNER JOIN {$this->table_size} AS tbl3 ON tbl3.ID = tbl1.Size_ID
                INNER JOIN {$this->table_color} AS tbl4 ON tbl4.ID = tbl1.Color_ID
                WHERE tbl1.MaHang_ID = '{$id}'
                ORDER BY tbl1.ID DESC";
        $record = $this->Common_model->query_raw_row($sql);
        if($record == null){
            redirect(backend_url($this->folder_view));
            die();
        }
        if($this->input->post()){
            $check = true;
            $data_post = $this->input->post();
            if(isset($data_post['soluong']) && $data_post['soluong'] != null){
                $date_start = @$data_post['StartDate'];
                $date_end = @$data_post['EndDate'];
                $this->Common_model->delete($this->table,array("MaHang_ID" => $id));
                foreach ($data_post['soluong'] as $color_id => $item) { //
                    foreach ($item as $size_id => $item1) {
                        if(isset($item1) && $item1 != null 
                            && isset($date_start[$color_id][$size_id]) && $date_start[$color_id][$size_id] != null 
                            && isset($date_end[$color_id][$size_id]) && $date_end[$color_id][$size_id] != null){
                                $data_insert = array(
                                    'MaHang_ID' => $id,
                                    'Size_ID'   => $size_id,
                                    'Color_ID'  => $color_id,
                                    'SoLuong'   => $this->cover_number($item1),
                                    'StartDate' => date('Y-m-d',strtotime($date_start[$color_id][$size_id])),
                                    'EndDate'   => date('Y-m-d',strtotime($date_end[$color_id][$size_id])),
                                    'Created_At'=> date('Y-m-d H:i:s')
                                );
                                $this->Common_model->add($this->table,$data_insert);
                                $check = false;
                        }
                    }
                }
            }
            if($check == true){
                $this->message('Vui lòng nhập đầu đủ dữ liệu.');
            }
            else{
                $this->message($this->message_add_succes,'success');
            }
            redirect(backend_url("/".$this->folder_view."/edit_more/".$id));
        }
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $sql = "SELECT tbl4.*
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_color} AS tbl4 ON tbl4.ID = tbl1.Color_ID
            WHERE tbl1.MaHang_ID = '{$id}'
            GROUP BY tbl4.ID
        	ORDER BY tbl4.ID DESC";
        $this->data['color_result'] = $this->Common_model->query_raw($sql);

        $sql = "SELECT tbl3.*
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_size} AS tbl3 ON tbl3.ID = tbl1.Size_ID
            WHERE tbl1.MaHang_ID = '{$id}'
            GROUP BY tbl3.ID
        	ORDER BY tbl3.ID DESC";
        $this->data['size_result'] = $this->Common_model->query_raw($sql);
        $this->data['action'] = 'edit';
        $this->load->view($this->backend_asset."/".$this->folder_view."/edit-more",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table_plu,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Mã hàng này không tồn tại.";
            die(json_encode($data));
        }
        /*$check  = $this->Common_model->get_record('M2_DonGiaSX',array("MaHang_ID" => $id));
        if($check != null){
            $data['status'] = "fail";
            $data['message'] = "Đơn giá sản xuất này được sử dụng – Không thể xóa.";
            die(json_encode($data));
        }*/
        $result = $this->Common_model->delete($this->table,array("MaHang_ID" => $id));
        if($result){
            //$this->Common_model->delete($this->table_kehoachsx,array("ChiTiet_ID" => $id));
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }

    public function view($id = null){
        $sql = "SELECT tbl1.*,tbl2.Name AS PluName,tbl3.Name AS SizeName,tbl4.MaMau
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_plu} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
                INNER JOIN {$this->table_size} AS tbl3 ON tbl3.ID = tbl1.Size_ID
                INNER JOIN {$this->table_color} AS tbl4 ON tbl4.ID = tbl1.Color_ID
                WHERE tbl1.ID = '$id'";
        $record = $this->Common_model->query_raw_row($sql);
        if(@$record == null){
            redirect(backend_url($this->folder_view));
            die();
        }

        $startTimeStamp = strtotime($record['StartDate']);
        $endTimeStamp = strtotime($record['EndDate']);
        $timeDiff = abs($endTimeStamp - $startTimeStamp);
        $numberDays = ($timeDiff/86400);  // 86400 seconds in one day
        // and you might want to convert to integer
        $numberDays = intval($numberDays);
        $this->data['numberDays'] = $numberDays;
        if($this->input->post()){
            $check = true;
            $data_post = $this->input->post();
            for($i = 0; $i <= $numberDays; $i++){
                $date = date('Y-m-d',strtotime("+".$i." day", strtotime($record['StartDate'])));
                if($date <= date('Y-m-d') && @$data_post['soluong'][$i] != null){
                    $check = false;
                }
            }
            if($check == true){
                $this->message('Vui lòng nhập đầu đủ dữ liệu.');
            }
            else{
                for($i = 0; $i <= $numberDays; $i++){
                    $date = date('Y-m-d',strtotime("+".$i." day", strtotime($record['StartDate'])));
                    if($date <= date('Y-m-d')){
                        $check = $this->Common_model->get_record($this->table_kehoachsx,array('ChiTiet_ID' => $id,'Date' => $date));
                        if($check != null){
                            $arr = array(
                                'SoLuong' => $this->cover_number($data_post['soluong'][$i])
                            );
                            $this->Common_model->update($this->table_kehoachsx,$arr,array('ChiTiet_ID' => $id,'Date' => $date));
                        }
                        else{
                            $arr = array(
                                'ChiTiet_ID' => $id,
                                'Date'  => $date,
                                'SoLuong' => $this->cover_number($data_post['soluong'][$i]),
                                'Created_At' => date('Y-m-d H:i:s')
                            );
                            $this->Common_model->add($this->table_kehoachsx,$arr);
                        }
                    }
                }
                $this->message($this->message_add_succes,'success');
            }
            redirect(backend_url($this->folder_view.'/view/'.$id));
        }
        $this->data['kehoachsx'] = $this->Common_model->get_result($this->table_kehoachsx,array('ChiTiet_ID' => $id),null,null,array('Date' => 'ASC'));
        $this->data['record'] = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/view",$this->data);
    }

    public function export(){
        set_time_limit(0);
        $this->data['is_export'] = true;
        $sql = "SELECT tbl1.*,tbl2.Name AS PluName,tbl3.Name AS SizeName,tbl4.MaMau
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_plu} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
                INNER JOIN {$this->table_size} AS tbl3 ON tbl3.ID = tbl1.Size_ID
                INNER JOIN {$this->table_color} AS tbl4 ON tbl4.ID = tbl1.Color_ID
                ORDER BY tbl1.ID DESC";
        $results = $this->Common_model->query_raw($sql);
        $title = 'Chi tiết mã hàng';
        $header = array('Mã hàng','Kích thước','Màu sắc','Số lượng','Ngày bắt đầu','Ngày kết thúc');
        $data = array();
        if(isset($results) && $results != null){
            foreach ($results as $key => $item) {
                $data[] = array(
                    $item['PluName'],
                    $item['SizeName'],
                    $item['MaMau'],
                    $item['SoLuong'],
                    date($this->date_format,strtotime($item["StartDate"])),
                    date($this->date_format,strtotime($item["EndDate"]))
                );
            }
        }
        export_excel($title,$header,$data);
    }

    public function import(){
        $data = array('status' => 'error');
        if (isset($_FILES["excel"]['name']) && $_FILES["excel"]['name'] != null){
            $mimes = array('xls','xlsx');
            $ext = pathinfo($_FILES['excel']['name'], PATHINFO_EXTENSION);
            if(!in_array($ext,$mimes)){
                $data['message'] = 'Vui lòng chọn excel file.';
                $data['status']  = 'fail';
                die(json_encode($data));
            }

            $upload_path = FCPATH . "/uploads/excel";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, TRUE);
            }
            $config = array();
            $config['upload_path'] = $upload_path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($this->upload->do_upload('excel')){
                $upload_data = $this->upload->data();
                $path_file = $upload_data['full_path'];
                $data_excel = get_data_excel($path_file);
                foreach ($data_excel[0] as $key => $item) {
                    if($item != trim(@$this->data['header'][$key])){
                        $data['message'] = 'Excel file không đúng định dạng.';
                        $data['status']  = 'fail';
                        die(json_encode($data));
                    }
                }
                $data_insert = array();
                foreach ($data_excel as $key => $item) {
                    if($key > 0 && @$item[0] != null && @$item[1] != null && @$item[2] != null && @$item[3] != null && @$item[4] != null && @$item[5] != null){
                        $plu = $this->Common_model->get_record($this->table_plu,array('Name' => trim(@$item[0])));
                        $size = $this->Common_model->get_record($this->table_size,array('Name' => @$item[1]));
                        $color = $this->Common_model->get_record($this->table_color,array('MaMau' => @$item[2]));
                        if($plu != null && $size != null && $color != null){
                            $data_insert[] = array(
                                'MaHang_ID' => $plu['ID'],
                                'Size_ID' => $size['ID'],
                                'Color_ID' => $color['ID'],
                                'SoLuong' => trim(@$item[3]),
                                'StartDate' => date('Y-m-d',strtotime(str_replace('/', '-', @$item[4]))),
                                'EndDate' => date('Y-m-d',strtotime(str_replace('/', '-', @$item[5]))),
                                'Created_At' => date('Y-m-d H:i:s')
                            );
                        }
                    }
                }
                if(count($data_insert) > 0){
                    $this->Common_model->insert_batch_data($this->table,$data_insert);
                }
                $data['status']  = 'success';
                $data['message'] = "Nhập dữ liệu thành công";
                die(json_encode($data));
            }
            else{
                $data['message'] = $this->upload->display_errors();
                $data['status']  = 'fail';
                die(json_encode($data));
            }
        }
        else{
            $data['message'] = 'Vui lòng chọn file muốn nhập.';
            $data['status']  = 'fail';
            die(json_encode($data));
        }
        die(json_encode($data));
    }

    public function load_table($group_id = null){
        $sql = "SELECT tbl2.*,tbl3.Name AS GroupName
                FROM {$this->table_size} AS tbl2 
                INNER JOIN {$this->table_sizegroup} AS tbl3 ON tbl3.ID = tbl2.SizeGroup_ID
                WHERE tbl2.SizeGroup_ID = '{$group_id}'
                ORDER BY tbl2.ID DESC";
        $this->data["size_result"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/table",$this->data);
    }
}