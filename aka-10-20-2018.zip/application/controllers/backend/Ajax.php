<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {

    public $data      = null;
    public $is_login  = false;
    public $user_info = null;
    public function __construct() {
        parent::__construct();
        if ($this->session->userdata('admin_info')) {
            $this->is_login  = true;
            $this->user_info = $this->session->userdata('admin_info');
        }
        $this->data["admin_info"] = $this->user_info;
        $this->data["is_login"]   = $this->is_login;
        if(!$this->data["is_login"]) die("error") ;
        if(!$this->input->is_ajax_request()) die("error");
    }

    public function materialmanagement(){
        $curentpage = $this->input->post("currentpage");
        $numberitem = $this->input->post("numberitem");
        $table      = $this->input->post("table");
        $data = array("total" => 0, "result" => array() ,"post" => $this->input->post());
        if(is_numeric($curentpage) && is_numeric($numberitem )){
            $where = [];
            $offset = $curentpage * $numberitem;
            $this->load->model("Metarial_model");
            if($table == "Aka_Metarial"){
                $data["total"]  = $this->Metarial_model->countgetall($where);
                $data["result"] = $this->Metarial_model->getall($offset,$numberitem,$where);
            }else if($table == "Aka_Warehousing"){
                $where["tbl1.InOut"] = $this->input->post("InOut");
                $data["total"]       = $this->Metarial_model->countwarehousing($where);
                $data["result"]      = $this->Metarial_model->warehousing($offset,$numberitem,$where);
            }
            else if ($table == "Inventorymanagement"){
                if($this->input->post("timepicker_start") != null){
                    $where ["timepicker_start"] =  $this->input->post("timepicker_start");
                }
                if($this->input->post("timepicker_end") != null){
                    $where ["timepicker_end"] =  $this->input->post("timepicker_end");
                }
                if($this->input->post("member_id") != null){
                    $where ["member_id"] =  $this->input->post("member_id");
                }
                $data["total"]       = $this->Metarial_model->CountInventorymanagement($where);
                $data["result"]      = $this->Metarial_model->Inventorymanagement($offset,$numberitem,$where);
            }        
        }
        die(json_encode($data));
    }

    public function getdata(){
        $data    = ["status" => "error","mesenger" => null,"reponse" => [] ];
        $table   = $this->input->post("table");
        $keyword = $this->input->post("keyword");
        $value   = ($this->input->post("value") != null) ? $this->input->post("value") : "ID";
        $lable   = ($this->input->post("lable") != null) ? $this->input->post("lable") : "Name";
        if($table == "Material_Type"){
            $arraytype = [
                ["ID" => 1,"Name" => "dùng thường xuyên"],
                ["ID" => 2,"Name" => "thỉnh thoản dùng"],
                ["ID" => 3,"Name" => "dùng một lần"]
            ];
            foreach ($arraytype as $key => $value) {
                if (strpos($value["Name"], $keyword) !== false) {
                    $data ["reponse"] [] = $value;
                }
            }
            $data ["status"] = "success";
        }else{
            $this->db->select($table.".".$value." AS ID, ".$table.".".$lable." AS Name");
            $this->db->from($table);
            $this->db->like($lable,$keyword);
            if($table == "Aka_Sys_Users"){
                $this->db->join("Aka_Sys_Company_Employee","Aka_Sys_Company_Employee.User_ID = Aka_Sys_Users.ID");
                $this->db->where("Aka_Sys_Company_Employee.Company_ID",$this->user_info["Company_ID"]);
            }else{
                $this->db->where($table.".Company_ID",$this->user_info["Company_ID"]);
            }
            $this->db->limit(10);
            $query = $this->db->get()->result_array();
            $data ["reponse"] = $query;
            $data ["status"] = "success";
        }
        die(json_encode($data));
    }

    public function Update_ata(){
        $data   = ["status" => "error","mesenger" => null , "post" => $this->input->post()];
        $value  = $this->input->post("value");
        $table  = $this->input->post("table");
        $id     = $this->input->post("id");
        $column = $this->input->post("column"); 
        try {
            $record = $this->Common_model->get_record($table,["ID" => $id,"Company_ID" => $this->user_info["Company_ID"]]);
            if($record != null){
                if($column == "Qty" && $record["InOut"] == "1"){
                    $Material_ID = $record["Material_ID"];
                    $Material = $this->Common_model->get_record("Aka_Metarial",["ID" => $Material_ID]);
                    if($Material != null){
                        $this->db->select("sum(Qty) AS Qtyin");
                        $this->db->from("Aka_Warehousing");
                        $this->db->where("InOut",0);
                        $this->db->where("Material_ID",$Material_ID);
                        $Qtyin = $this->db->get()->row_array();
                        $this->db->select("sum(Qty) AS Qtyout");
                        $this->db->from("Aka_Warehousing");
                        $this->db->where("InOut",1);
                        $this->db->where("ID != ",$id);
                        $this->db->where("Material_ID",$Material_ID);
                        $Qtyout = $this->db->get()->row_array();
                        $Qtyin  = (@$Qtyin["Qtyin"] == null || @$Qtyin["Qtyin"] == "NULL") ? 0 : $Qtyin["Qtyin"] ;
                        $Qtyout = (@$Qtyout["Qtyout"] == null || @$Qtyout["Qtyout"] == "NULL") ? 0 : $Qtyout["Qtyout"] ;
                        $Qty_Minimum = (@$Material["Qty_Minimum"] == null || @$Qtyin["Qty_Minimum"] == "NULL" ) ? 0 : $Material["Qty_Minimum"];
                        $total     = intval($Qtyout)  + intval($value);
                        $totalrest = intval($Qtyin) - $total;
                        if($totalrest < $Qty_Minimum){
                            $data ["mesenger"][] ="Vật liệu không đủ để xuất kho!";
                            die(json_encode($data));
                        }else{
                        	$Warning_Amplitude = ($Material["Warning_Amplitude"] == null || @$Qtyin["Warning_Amplitude"] == "NULL") ? 0 : $Material["Warning_Amplitude"];
                            if($totalrest < $Warning_Amplitude){
                                $data ["mesenger"][] ="Vật liệu không còn nhiều!";
                            }
                        }
                    }
                }
                $update = $this->Common_model->update($table,[$column => $value],["ID" => $id]);
                if($update){
                    $data ["status"] = "success"; 
                    $data["mesenger"][] = "Cập nhật thành công!";
                }
            }else{
                $data["mesenger"][] = "Hàng này không tồn tại!";
            }  
        } catch (Exception $e) {
            $data["mesenger"][] = "Có lỗi xãy ra vui lòng kiểm tra dữ liệu đầu vào!";
        }
        $this->output->enable_profiler(TRUE);
        die(json_encode($data));
    }

    public function delete(){
        $data   = ["status" => "error","mesenger" => null ,"reponse" => null];
        $value  = $this->input->post("ids");
        $table  = $this->input->post("table");
        try {
            $this->db->where_in("ID",$value);
            $this->db->delete($table);
            $data ["status"] = "success";
            $data ["mesenger"] = "Xóa thành công!";
        } catch (Exception $e) {
            $data ["status"] = "error";
            $data ["mesenger"] = "Có lỗi xãy ra vui lòng thử lại";
        }
        die(json_encode($data));
    }

    public function addcolumn(){
        $data   = ["status" => "error","mesenger" => null];
        $table  = $this->input->post("table");
        $data["post"] = $this->input->post();
        try {
            $colums = $this->db->list_fields($table);
            $data_post = $this->input->post();
            $data_insert = array();
            $InOut = $this->input->post("InOut");
            if($InOut == "1" && $table == "Aka_Warehousing"){
            	$Material_ID = $this->input->post("Material_ID");
                $Material = $this->Common_model->get_record("Aka_Metarial",["ID" => $Material_ID]);
            	if($Material != null){
            		$Qty = $this->input->post("Qty");
	            	$this->db->select("sum(Qty) AS Qtyin");
	                $this->db->from("Aka_Warehousing");
	                $this->db->where("InOut",0);
	                $this->db->where("Material_ID",$Material_ID);
	                $Qtyin = $this->db->get()->row_array();
	                $this->db->select("sum(Qty) AS Qtyout");
	                $this->db->from("Aka_Warehousing");
	                $this->db->where("InOut",1);
	                $this->db->where("Material_ID",$Material_ID);
	                $Qtyout = $this->db->get()->row_array();
                    $Qtyin  = (@$Qtyin["Qtyin"] == null || @$Qtyin["Qtyin"] == "NULL") ? 0 : $Qtyin["Qtyin"] ;
                    $Qtyout = (@$Qtyout["Qtyout"] == null || @$Qtyout["Qtyout"] == "NULL") ? 0 : $Qtyout["Qtyout"] ;
                    $Qty_Minimum = (@$Material["Qty_Minimum"] == null || @$Qtyin["Qty_Minimum"] == "NULL" ) ? 0 : $Material["Qty_Minimum"];
                    $total     = intval($Qtyout)  + intval($Qty);
                    $totalrest = intval($Qtyin) - $total;
                    if($totalrest < $Qty_Minimum){
                        $data ["mesenger"][] ="Vật liệu không đủ để xuất kho!";
                        $data ["column_error"][] = "Qty";
                        die(json_encode($data));
                    }else{
                        $Warning_Amplitude = ($Material["Warning_Amplitude"] == null || @$Qtyin["Warning_Amplitude"] == "NULL") ? 0 : $Material["Warning_Amplitude"];
                        if($totalrest < $Warning_Amplitude){
                            $data ["mesenger"][] ="Vật liệu không còn nhiều!";
                        }
                    }
           		}
            }
            foreach ($data_post as $key => $value) {
                if(in_array($key, $colums)){
                    $data_insert[$key] = $value;
                }            
            }
            unset( $data_insert["ID"]);
            if(in_array("Member_ID", $colums)){
                $data_insert["Member_ID"] =$this->user_info["ID"];
            }
            if( in_array("Company_ID", $colums) ){
                $data_insert["Company_ID"] = $this->user_info["Company_ID"];
            }
            $id = $this->Common_model->add($table,$data_insert);
            if($id){
                $data["status"]   = "success";
                $data["mesenger"][] = "Thêm mới thành công!";
                $data["reponse"]  = $id;
            }else{
                $data["mesenger"][] = "Có lỗi xãy ra vui lòng kiểm tra dữ liệu đầu vào!";
            }
        } catch (Exception $e) {
        	$data["mesenger"][] = "Có lỗi xãy ra vui lòng kiểm tra dữ liệu đầu vào!";
        }
        die(json_encode($data));
    }

    public function get_company(){
        $data   = ["status" => "error","mesenger" => null];
        $keyword = $this->input->post("keyword");
        $type    = $this->input->post("type");
        $this->db->select("Aka_Sys_Company.*");
        $this->db->from("Aka_Sys_Company");
        $this->db->where("Aka_Sys_Company.ID not in (Select Company_ID From Aka_Sys_Company_Employee where User_ID = ".$this->user_info["ID"].")");
        $this->db->where("Aka_Sys_Company.User_ID != ",$this->user_info["ID"]);
        $this->db->where("Aka_Sys_Company.Status","1");
        $this->db->group_start();
        $this->db->like("CompanyName",$keyword);
        $this->db->or_like("Company_Code",$keyword);
        $this->db->group_end();
        $this->db->group_by("Aka_Sys_Company.ID");
        $query = null;
        try {
            $query = $this->db->get();
        } catch ( Exception $e) {
            
        }
        if($query != null){
            $data["reponse"] = $query->result_array();
            $data["status"]  = "success";
        }
        die(json_encode($data));
    }

    public function signupcompany(){
        $data      = ["status" => "error","mesenger" => null];
        $Companies = ($this->input->post("CompanyName"));
        $token = md5(uniqid());
        $item = array(
            "Company_ID" => $Companies,
            "User_ID" => $this->user_info["ID"],
        );
        $check = $this->Common_model->get_record("Aka_Sys_Company_Employee",$item);
        $company = $this->Common_model->get_record("Aka_Sys_Company",["ID" => $Companies]);
        if($check == null && $company != null) {
            $item = array(
                "Company_ID" => $Companies,
                "User_ID" => $this->user_info["ID"], 
                "Token" => $token,
                "Verify" => "0"
            );
            $this->Common_model->add("Aka_Sys_Company_Employee",$item);
            $mail_subject = "Đăng kí nhân viên của công ty ".$company["CompanyName"]."";
            $mail_content = "<div>";
            $mail_content .= "<h2>Xin chào ".$this->user_info["User_Name"]."!<h2><br><br>";
            $mail_content .= "<p>Bạn vừa sử dụng tài khoản của mình đăng kí làm thành viên của công ty '".$company["CompanyName"]."'<p><br>";
            $mail_content .= "<p>Vui lòng xác thực điều này bằng cách click vào xác thực <a href='".backend_url("verify/singup_company_success/".$token)."'>Xác Thực</a> <p><br>";
            $mail_content .= "<p>Để hủy vui lòng click vào hủy  <a href='".backend_url("verify/singup_company_error/".$token)."'>Hủy</a><p><br>";
            $mail_content .= "</div>";
            sendmail($this->user_info["User_Email"], $mail_subject, $mail_content);
            $data["status"]  = "success";
        } 
        $data["post"] = $this->input->post();
        die(json_encode($data));
    }

    public function enterdata(){
        $data    = ["status" => "error","mesenger" => null];
        $keyword = $this->input->post("code");
        $table   = $this->input->post("table");
        $column  = $this->input->post("column");
        $where["Company_ID"] = $this->user_info["Company_ID"];
        $where["ID"] = $keyword;
        $record  = $this->Common_model->get_record($table,$where);
        if($record ){
            $data["status"]  = "success";
            $data["reponse"] = $record;
        }else{
            $data["mesenger"] = "Mã này không đúng";
        }
        $data["post"] = $this->input->post();
        die(json_encode($data));
    }

    public function addproduct_step1(){
        $data = ["status" => "error","mesenger" => null,"reponse" => null];
        $this->form_validation->set_rules('Name', 'Tên sản phẩm', 'required');
        $this->form_validation->set_rules('Status', 'Trạng thái', 'required');
        $this->form_validation->set_rules('Code', 'Mã sản phẩm', 'required');
        $check_code = $this->check_code($this->input->post("Code"),$this->input->post("ID"));
        if ($this->form_validation->run() == TRUE && $check_code) {
            $colums = $this->db->list_fields('Aka_Goods');
            $data_post = $this->input->post();
            $data_insert = array();
            foreach ($data_post as $key => $value) {
                if($value && $key != "ID") {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    } 
                }                           
            }
            if (isset($_FILES["Thumb"])){
                $upload_path = FCPATH . "/uploads/backend";
                if (!is_dir($upload_path)) {
                    mkdir($upload_path, 0755, TRUE);
                }
                $upload_path = FCPATH . "/uploads/backend/member";
                if (!is_dir($upload_path)) {
                    mkdir($upload_path, 0755, TRUE);
                }
                $upload_path = $upload_path . "/" . $this->user_info["ID"];
                if (!is_dir($upload_path)) {
                    mkdir($upload_path, 0755, TRUE);
                }
                $file = $_FILES["Thumb"];
                $allowed_types = "jpg|png";
                $upload = upload_flie($upload_path, $allowed_types, $file);
                if($upload["status"] == "success")
                    $data_insert["Thumb"] = "/uploads/backend/member/".$this->user_info["ID"]."/".$upload["reponse"]["file_name"];
                else
                    $data_insert["Thumb"] = "";
            }else{
                $data_insert["Thumb"] = "";
            }
            if($this->input->post("ID") == null || $this->input->post("ID") == 0){
                $data_insert["Company_ID"] = $this->user_info["Company_ID"];
                $data_insert["Member_By"]  = $this->user_info["ID"];
                $id = $this->Common_model->add("Aka_Goods",$data_insert); 
                $data["mesenger"] = "<p>Tạo mới sản phẩm bước 1 thành công chuyển sang bước 2</p>";
            }else{
                $id = $this->input->post("ID");
                $this->Common_model->update("Aka_Goods",$data_insert,["ID" => $id ,"Company_ID" => $this->user_info["Company_ID"]]); 
                $data["mesenger"] = "<p>Cập nhật sản phẩm bước 1 thành công chuyển sang bước 2</p>";
            }
            $data["status"]  = "success";
            $data["reponse"] = $id;
        }else{
            $data['mesenger'] = validation_errors();
            if($check_code == FALSE){
                $data['mesenger'] .='<p>Mã sản phẩm này đã tồn tại</p>';
            }
        }
        $data["post"] = $this->input->post();
        echo (json_encode($data));
    }
    
    public function get_info_step2(){
        $data = ["status" => "error","mesenger" => null,"reponse" => null];
        $company_id = $this->user_info["Company_ID"];
        $id = $this->input->post("ID");
        if($id == null) $id = 0;
        $this->db->select("tbl1.*,tbl2.ID AS check_size");
        $this->db->from("Aka_Size AS tbl1");
        $this->db->join("Aka_Goods_Size_Materials AS tbl2","tbl2.Size_ID = tbl1.ID AND tbl2.Goods_ID = ".$id."","LEFT");
        $this->db->where("tbl1.Company_ID" , $company_id);
        $this->db->group_by("tbl1.ID");
        $sizes = $this->db->get()->result_array();

        $this->db->select("tbl1.*,tbl2.ID AS check_metarial");
        $this->db->from("Aka_Materials AS tbl1");
        $this->db->join("Aka_Goods_Size_Materials AS tbl2","tbl2.Materials_ID = tbl1.ID AND tbl2.Goods_ID = ".$id."","LEFT");
        $this->db->where("tbl1.Company_ID" , $company_id);
        $this->db->group_by("tbl1.ID");    
        $metarial = $this->db->get()->result_array();
        $data  = ["status" => "success","reponse" => ["sizes" => $sizes ,"metarial" => $metarial] ,"mesenger" => "Lấy thông tin sản phẩm thành công vui lòng lựa chọn các thông tin bên dưới"];
        die(json_encode($data));
    }
    public function get_info_step3 (){
        $data = ["status" => "error","mesenger" => null,"reponse" => null];
        $company_id = $this->user_info["Company_ID"];
        $id = $this->input->post("ID");
        $result = $this->Common_model->get_result("Aka_Goods_Size_Materials",["Goods_ID" => $id]);
        $data  = ["status" => "success","reponse" => $result];
        die(json_encode($data));
    }
    private function check_code($code,$id = null)
    { 
        $where = ["Company_ID" => $this->user_info["Company_ID"],"Code" => $code ];
        if($id != null){
            $where["ID !="] = $id;
        }
        $return_value = $this->Common_model->get_record("Aka_Goods",$where);
        if ($return_value != null)
        {
            return FALSE;
        }
        else
        {
            return TRUE;
        }
    }
    public function addandedit(){
        $data = ["status" => "error","mesenger" => null,"reponse" => null ,"post" => $this->input->post()];
        try {
            $id = $this->input->post("ID") != null ? $this->input->post("ID") : 0;
            $table = $this->input->post("Table");
            $colums = $this->db->list_fields($table);
            $data_post = $this->input->post();
            $data_insert = array();
            foreach ($data_post as $key => $value) {
                if( !is_null($value) && $key != "ID" ) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    } 
                }                           
            }
            if($table == "Aka_Metarial"){           
                if( trim(@$data_insert["Barcode"]) == "" || @$data_insert["Barcode"] == ""){
                    $Aka_Metarial = $this->Common_model->get_result("Aka_Metarial");
                    $data_insert["Barcode"] = $this->check_barcode($Aka_Metarial);
                }
                $this->load->library('barcode128');
                $img = $this->barcode128->createbarcode($data_insert["Barcode"],1);
                ob_start();
                imagepng($img);
                $output_img =   ob_get_clean();
                $name   = 'barcode128-'. $data_insert["Barcode"] .'.png';
                $folder = '/uploads/backend/member/' . $this->user_info["ID"] .'/';
                $file   = $folder.$name; 
                $path   = FCPATH . "/".$file;
                $upload_path = FCPATH . "/uploads/backend";
                if (!is_dir($upload_path)) {
                    mkdir($upload_path, 0755, TRUE);
                }
                $upload_path = FCPATH . "/uploads/backend/member";
                if (!is_dir($upload_path)) {
                    mkdir($upload_path, 0755, TRUE);
                }
                $upload_path = $upload_path . "/" . $this->user_info["ID"];
                if (!is_dir($upload_path)) {
                    mkdir($upload_path, 0755, TRUE);
                }
                try {
                    $fp = fopen( $path, 'wb' );
                    fwrite($fp,$output_img);
                    fclose($fp);  

                    $data_insert["Image_Barcode"] = $file; 
                } catch (Exception $e) {

                }
            }
            if($table == "Aka_Warehousing" && @$data_insert["InOut"] == 1){
                $Material_ID = $data_insert["Material_ID"];
                $Material = $this->Common_model->get_record("Aka_Metarial",["ID" => $Material_ID]);
                if($Material != null){
                    $Qty = $data_insert["Qty"];;
                    $this->db->select("sum(Qty) AS Qtyin");
                    $this->db->from("Aka_Warehousing");
                    $this->db->where("InOut",0);
                    $this->db->where("Material_ID",$Material_ID);
                    $Qtyin = $this->db->get()->row_array();
                    $this->db->select("sum(Qty) AS Qtyout");
                    $this->db->from("Aka_Warehousing");
                    $this->db->where("InOut",1);
                    $this->db->where("Material_ID",$Material_ID);
                    $Qtyout = $this->db->get()->row_array();
                    $Qtyin  = (@$Qtyin["Qtyin"] == null || @$Qtyin["Qtyin"] == "NULL") ? 0 : $Qtyin["Qtyin"] ;
                    $Qtyout = (@$Qtyout["Qtyout"] == null || @$Qtyout["Qtyout"] == "NULL") ? 0 : $Qtyout["Qtyout"] ;
                    $Qty_Minimum = (@$Material["Qty_Minimum"] == null || @$Qtyin["Qty_Minimum"] == "NULL" ) ? 0 : $Material["Qty_Minimum"];
                    $total     = intval($Qtyout)  + intval($Qty);
                    $totalrest = intval($Qtyin) - $total;
                    if($totalrest < $Qty_Minimum){
                        $data ["mesenger"] ="Vật liệu không đủ để xuất kho!";
                        die(json_encode($data));
                    }else{
                        $Warning_Amplitude = ($Material["Warning_Amplitude"] == null || @$Qtyin["Warning_Amplitude"] == "NULL") ? 0 : $Material["Warning_Amplitude"];
                        if($totalrest < $Warning_Amplitude){
                            $data ["mesenger"] ="Vật liệu không còn nhiều!";
                        }
                    }
                }
            }
            if(in_array("Member_ID", $colums)){
                $data_insert["Member_ID"] = $this->user_info["ID"];
            }
            $check_data = $this->Common_model->get_record($table,["ID"=>$id]);
            if($check_data == null){
                $data["ID"] = $this->Common_model->add($table,$data_insert);
                $data["reponse"] = "insert";
                $data ["mesenger"] = "Thêm mới thành công!";
            }else{
                $this->Common_model->update($table,$data_insert,["ID" => $id]);
                $data["reponse"] = "update";
                $data["ID"] = $check_data["ID"];
                $data ["mesenger"] = "Cập nhật thành công!";
            }
            $data["status"] = "success";
            
        } catch (Exception $e) {
            die($e);
        }
        die(json_encode($data));
       
    }
    public function getdataedit(){
        $data = ["status" => "error","mesenger" => null,"reponse" => null,"post" => $this->input->post()];
        try {
            $id     = $this->input->post("ID");
            $table  = $this->input->post("Table");
            $record = $this->Common_model->get_record($table,[ "ID" => $id ] );
            if( $record == null ) die( json_encode($data) );
            $data["status"] = "success";
            $data["reponse"] = $record;
        } catch (Exception $e) {
            die($e);
        }
        die(json_encode($data));
    }
    public function get_info_material(){
        $data = ["status" => "error","mesenger" => null,"reponse" => null,"post" => $this->input->post()];
        $id = $this->input->post("id");
        $this->db->select('sum(Qty) AS SumQty');
        $this->db->from('Aka_Warehousing');
        $this->db->where(["Material_ID" => $id,"InOut" => 0]);
        $in = $this->db->get()->row_array();
        $this->db->select('sum(Qty) AS SumQty');
        $this->db->from('Aka_Warehousing');
        $this->db->where(["Material_ID" => $id,"InOut" => 1]);
        $out = $this->db->get()->row_array();
        $inventory = $in["SumQty"] - $out["SumQty"];
        $data = ["status" => "success","mesenger" => null,"reponse" => $inventory ,"post" => $this->input->post()];
        die(json_encode($data));
    }
    function generatorBarcode(){
        $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < 10; $i++) {
            $randomString .= substr($characters,rand(0, $charactersLength),1);
        }
        return "aka".$randomString;
    }
    function check_barcode($datarg = null){
        $barcode = $this->generatorBarcode();
        $i = true;
        foreach ($datarg as $key => $value) {
            if($barcode == $value["Barcode"]){
                $i = false;
                break;
            }
        }
        if($i == false) $this->check_barcode($datarg);
        return $barcode;
    }
}
