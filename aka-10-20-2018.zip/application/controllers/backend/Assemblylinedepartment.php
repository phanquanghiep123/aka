<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Assemblylinedepartment extends MY_Controller {

    private $folder_view = "assemblylinedepartment";
    private $table = 'm5_assemblylinedepartment';
    private $table_technique = 'm5_assemblylinetechnique';
    private $table_process = 'm5_process';
    private $table_scenario = 'm5_scenario';
    private $table_employee = 'M6_Employee';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
    }

    public function index(){
        $where = " WHERE 1=1 ";
        if($this->input->get("keyword") != null){
            $where .= " AND (tbl2.Name Like '%".addslashes($this->input->get("keyword"))."%' OR tbl3.Name Like '%".addslashes($this->input->get("keyword"))."%') ";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl2.Name AS ProcessName,tbl3.Name AS ScenarioName,tbl3.SoTram
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_process} AS tbl2 ON tbl2.ID = tbl1.Process_ID
                INNER JOIN {$this->table_scenario} AS tbl3 ON tbl3.ID = tbl1.Scenario_ID
                $where
                GROUP BY tbl1.Scenario_ID
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_process}  AS tbl2 ON tbl2.ID = tbl1.Process_ID
            INNER JOIN {$this->table_scenario} AS tbl3 ON tbl3.ID = tbl1.Scenario_ID
            $where";

        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function edit($scenario_id = null){
        $result = $this->get_result($scenario_id);
        if($result == null){
            redirect(backend_url("/".$this->folder_view."/"));
            die();
        }
        if($this->input->post()){
            //$this->form_validation->set_rules('employee', 'Nhân viên', 'required');
            if($this->input->post('employee') != null){
            	$data_post = $this->input->post();
            	$employees = @$data_post['employee'];

            	if(isset($employees) && $employees != null){
            		foreach ($employees as $id => $employee_id) {
            			$data_update = array('Employee_ID' => ($employee_id != null ? $employee_id : 0));
            			$this->Common_model->update($this->table,$data_update,array("ID" => $id));
            		}
            	}
            	$this->message($this->message_update_succes,'success');
            }else{
            	$this->session->set_flashdata('record',$this->input->post());
                $this->message('Vui lòng chọn nhân viên');
            }
            redirect(backend_url("/".$this->folder_view."/edit/".$scenario_id));
        }
        $this->data['results']  = $result;
        $this->data['employee'] = $this->Common_model->get_result($this->table_employee,array('Is_Active' => 1));
        $this->load->view($this->backend_asset."/".$this->folder_view."/edit",$this->data);
    }

    private function get_result($scenario_id = 0){
    	$sql = "SELECT tbl1.*,tbl2.Name AS ProcessName,tbl3.Name AS ScenarioName,tbl3.SoTram,tbl3.SoLuong AS ScenarioSoLuong
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_process} AS tbl2 ON tbl2.ID = tbl1.Process_ID
                INNER JOIN {$this->table_scenario} AS tbl3 ON tbl3.ID = tbl1.Scenario_ID
                WHERE tbl1.Scenario_ID = '{$scenario_id}' 
                ORDER BY tbl1.ID ASC";
        $result = $this->Common_model->query_raw($sql);
        return $result;
    }
}