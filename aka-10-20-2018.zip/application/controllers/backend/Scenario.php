<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Scenario extends MY_Controller {

    private $folder_view = "scenario";
    private $table = 'm5_scenario';
    private $process = 'm5_process';
    private $table_output_estimate = 'm5_output_estimate';
    private $table_assemblylinetechnique =  'm5_assemblylinetechnique';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
    }

    public function index(){
        $where = " WHERE 1=1 ";
        if($this->input->get("keyword") != null){
            $where .= " AND tbl1.Name Like '%".addslashes($this->input->get("keyword"))."%'";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl2.Name AS EstimateName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_output_estimate} AS tbl2 ON tbl2.ID = tbl1.Output_Estimate_ID
                $where 
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_output_estimate} AS tbl2 ON tbl2.ID = tbl1.Output_Estimate_ID 
            $where";

        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        //get all process;
        $this->data["process"] = $this->Common_model->get_result($this->process);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('Output_Estimate_ID', 'Ước tính', 'required');
            $this->form_validation->set_rules('Name','Tiêu đề', 'required');
            $this->form_validation->set_rules('SoTram','Số trạm', 'required');
            $this->form_validation->set_rules('SoLuong','Số lượng', 'required');
            $this->form_validation->set_rules('ScenarioDate','Thời gian của kịch bản', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert['SoTram'] = $this->cover_number($data_post["SoTram"]);
                $data_insert['SoLuong'] = $this->cover_number($data_post["SoLuong"]);
                $scenarioDate = str_replace('/', '-', $data_post['ScenarioDate']);
                $data_insert['ScenarioDate'] = date('Y-m-d',strtotime($scenarioDate));
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                    $record = $this->get_record($id);
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $record['ScenarioDate'] = date($this->date_format,strtotime($record["ScenarioDate"]));
                    $record['SoTram'] = number_format($record["SoTram"]);
                    $record['SoLuong'] = number_format($record["SoLuong"]);
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->data['estimate'] = $this->Common_model->get_result($this->table_output_estimate);
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Kịch bản này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('Output_Estimate_ID', 'Ước tính', 'required');
            $this->form_validation->set_rules('Name','Tiêu đề', 'required');
            $this->form_validation->set_rules('SoTram','Số trạm', 'required');
            $this->form_validation->set_rules('SoLuong','Số lượng', 'required');
            $this->form_validation->set_rules('ScenarioDate','Thời gian của kịch bản', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $data_update['SoTram'] = $this->cover_number($data_post["SoTram"]);
                $data_update['SoLuong'] = $this->cover_number($data_post["SoLuong"]);
                $scenarioDate = str_replace('/', '-', $data_post['ScenarioDate']);
                $data_update['ScenarioDate'] = date('Y-m-d',strtotime($scenarioDate));
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                    $record = $this->get_record($id);
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $record['ScenarioDate'] = date($this->date_format,strtotime($record["ScenarioDate"]));
                    $record['SoTram'] = number_format($record["SoTram"]);
                    $record['SoLuong'] = number_format($record["SoLuong"]);
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->data['estimate'] = $this->Common_model->get_result($this->table_output_estimate);
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Kịch bản này không tồn tại.";
            die(json_encode($data));
        }
        try{
            $result = $this->Common_model->delete($this->table,array("ID" => $id));
            if($result){
                $data['status'] = 'success';
            }
            else{
                $data['status'] = "fail";
                $data['message'] = "Lỗi không thể xóa được.";
            }
        } catch (Exception $e) {
            $data['status'] = "fail";
            $data['message'] = $e->getMessage();
        }

        die(json_encode($data));
    }

    private function get_record($id = null){
        $sql = "SELECT tbl1.*,tbl2.Name AS EstimateName
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_output_estimate} AS tbl2 ON tbl2.ID = tbl1.Output_Estimate_ID
            WHERE tbl1.ID = '{$id}'";
        $record = $this->Common_model->query_raw_row($sql);
        return $record;
    }
    public function get (){
    	if($this->input->post()){
    	 	$id = $this->input->post("id");
    	 	$r = $this->Common_model->get_record($this->table,["ID" => $id]);
    	 	if($r){
    	 		$NotIN = [];
    	 		$assemblylinetechniques = $this->Common_model->get_result($this->table_assemblylinetechnique,["Scenario_ID" => $r["ID"]]);
    	 		if($assemblylinetechniques){
    	 			foreach ($assemblylinetechniques as $key => $value) {
    	 				$NotIN[] = $value["Process_ID"];
    	 			}
    	 		}
    	 		$this->data["notIN"] = $NotIN;
    	 		$this->data["process"] = $this->Common_model->get_result($this->process);
    	 	}
    	}
    	die(json_encode($this->data));
    }
    public function update(){
    	if($this->input->post()){
    	 	 var_dump($this->input->post());
    	}
    }
}