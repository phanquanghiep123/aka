<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Scripts extends MY_Controller {
    private $folder_view = "scripts";
    private $table = "M2_KichBan";
    private $table_order      = "M2_UocTinhDG";
    private $table_production = "M2_UocTinhDGSX";
    private $model = "Scripts_model";
    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
        $this->load->model($this->model);
        $this->model = $this->{$this->model};
        $this->data['header'] = array(
            'Tên kịch bản',
            'Chi phí chưa lương',
            'Chi phí có lương',
            'Số CN SX',
            'Số ngày/năm SX',
            'Số liệu (Năm/tháng)',
            'Para1',
            'Para2',
            'Para3',
            'Para4',
            'Para5',
            'Hành động'
        );
    }
    public function index(){
        $where["1"] = "1";
        $where['Is_Delete != '] = "1";
        if($this->input->get("keyword") != null){
            $where["Name Like"] = "%".$this->input->get("keyword")."%";
        }
        $per_page = $this->per_page;
        $count_table = $this->Common_model->count_table($this->table,$where);
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0 ;    
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = $count_table;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->get_result($this->table,$where,$offset,$per_page,array('ID' => "DESC"));
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }
    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('Name','Tên kịch bản', 'required');
            $this->form_validation->set_rules('ChiPhiChuaLuong','Chi phí chưa lương', 'required');
            $this->form_validation->set_rules('ChiPhiCoLuong','Chi phí có lương', 'required');
            $this->form_validation->set_rules('SoCNTrucTiepSX','Số CN trực tiếp SX', 'required');
            $this->form_validation->set_rules('SoNgaySX_Nam','Số ngày/năm SX', 'required');
            $this->form_validation->set_rules('SoLieuTheoNam_Thang','Số liệu theo (Năm/tháng)', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id){
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                    $detail = $this->input->post("detail");
                    $index = count( $detail["Name"] );
                    $data_inserts = [];
                    for ($i=0; $i < $index; $i++) { 
                        $data_inserts[] = [
                            "Name"       => $detail["Name"][$i],
                            "SoTien"     => $detail["SoTien"][$i],
                            "Position"   => $i,
                            "KichBan_ID" => $id
                        ];
                    }
                    $this->Common_model->insert_batch_data("M2_KichBan_ChiTiet",$data_inserts);
                    $details = $this->Common_model->get_result("M2_KichBan_ChiTiet",["KichBan_ID" => $id,"Is_Delete" => 0]);
                    $data_update = [
                        "Para1" => $this->Para1($details),
                        "Para2" => $this->Para2($details),
                        "Para3" => $this->Para3($details),
                        "Para4" => $this->Para4($details),
                        "Para5" => $this->Para5($details)
                    ];
                    $this->Common_model->update($this->table, $data_update,array("ID" => $id));
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }
    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Kịch bản này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('Name','Tên kịch bản', 'required');
            $this->form_validation->set_rules('ChiPhiChuaLuong','Chi phí chưa lương', 'required');
            $this->form_validation->set_rules('ChiPhiCoLuong','Chi phí có lương', 'required');
            $this->form_validation->set_rules('SoCNTrucTiepSX','Số CN trực tiếp SX', 'required');
            $this->form_validation->set_rules('SoNgaySX_Nam','Số ngày/năm SX', 'required');
            $this->form_validation->set_rules('SoLieuTheoNam_Thang','Số liệu theo (Năm/tháng)', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $this->Common_model->update($this->table, $data_update,array("ID" => $id));
                if($id){
                    $detail = $this->input->post("detail");
                    $index = count( $detail["Name"] );
                    $data_inserts = [];
                    $data_id      = [];
                    for ($i=0; $i < $index; $i++) { 
                        if(@$detail["Name"][$i] != null){
                            if(@$detail["ID"][$i] == 0){
                                $data_inserts = [
                                    "Name"       => @$detail["Name"][$i],
                                    "SoTien"     => @$detail["SoTien"][$i],
                                    "Position"   => $i,
                                    "KichBan_ID" => @$id
                                ];
                                $data_id[] = $this->Common_model->add("M2_KichBan_ChiTiet",$data_inserts);
                            }else{
                                $data_id[] = $detail["ID"][$i];
                                $this->Common_model->update("M2_KichBan_ChiTiet",
                                    [
                                        "Name"       => $detail["Name"][$i],
                                        "SoTien"     => $detail["SoTien"][$i],
                                        "Position"   => $i,
                                    ],array("ID" => $detail["ID"][$i])
                                );
                            }
                        }
                    }
                    if($data_id){
                        $this->db->where("KichBan_ID",$id);
                        $this->db->where_not_in("ID",$data_id);
                        $this->db->update("M2_KichBan_ChiTiet",["Is_Delete" => 1]);
                    }
                    $details = $this->Common_model->get_result("M2_KichBan_ChiTiet",["KichBan_ID" => $id,"Is_Delete" => 0],null,null,array('Position' => "ASC"));
                    $data_update = [
                        "Para1" => $this->Para1($details),
                        "Para2" => $this->Para2($details),
                        "Para3" => $this->Para3($details),
                        "Para4" => $this->Para4($details),
                        "Para5" => $this->Para5($details)
                    ];
                    $this->Common_model->update($this->table, $data_update,array("ID" => $id));
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->data["details"] = $this->Common_model->get_result("M2_KichBan_ChiTiet",["KichBan_ID" => $id,"Is_Delete" => 0],null,null,array('Position' => "ASC"));
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }
    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Kịch bản này không tồn tại.";
            die(json_encode($data));
        }
        $data_update = array();
        $data_update["Is_Delete"]  = 1;
        $result = $this->Common_model->update($this->table,$data_update,array("ID" => $id));
        if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }
    public function view($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Kịch bản không tồn tại.";
            die(json_encode($data));
        }
        $this->data['record']  = $record;
        $this->data["details"] = $this->Common_model->get_result("M2_KichBan_ChiTiet",["KichBan_ID" => $id,"Is_Delete" => 0]);
        $data['status'] = 'success';
        $data['response'] = $this->load->view($this->backend_asset."/".$this->folder_view."/view",$this->data,true);
        die(json_encode($data));
    }
    private function Para1 ($array){
        $return = 0;
        foreach ($array as $key => $value) {
            $return += $value["SoTien"];
        }
        return $return;
    }
    private function Para2 ($array){
        $return = 0;
        foreach ($array as $key => $value) {
            $return += $value["SoTien"];
        }
        return $return;
    }
    private function Para3 ($array){
        $return = 0;
        foreach ($array as $key => $value) {
            $return += $value["SoTien"];
        }
        return $return;
    }
    private function Para4 ($array){
        $return = 0;
        foreach ($array as $key => $value) {
            $return += $value["SoTien"];
        }
        return $return;
    }
    private function Para5 ($array){
        $return = 0;
        foreach ($array as $key => $value) {
            $return += $value["SoTien"];
        }
        return $return;
    }
    public function orders (){
        $this->data['header'] = array(
            'Tên Ước tinh đơn hàng',
            'Tên kịch bản',
            'Para1',
            'Para2',
            'Para3',
            'Para4',
            'Para5',
            'Hành động'
        );
        $where["1"] = "1";
        $where['tbl1.Is_Delete != '] = "1";
        if($this->input->get("keyword") != null){
            $where["tbl1.Name Like"] = "%".$this->input->get("keyword")."%";
        }
        $per_page = $this->per_page;
        $count_table = $this->model->get_orders_count($where);
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0 ;    
        $config['base_url'] = backend_url("/".$this->folder_view.'/orders/'.$this->request);
        $config['total_rows'] = $count_table;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->model->get_orders($where,$offset,$per_page,array('ID' => "DESC"));
        $this->load->view($this->backend_asset."/".$this->folder_view."/orders",$this->data);
    }
    public function order_add (){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('Name','Tên ước tính', 'required');
            $this->form_validation->set_rules('KichBan_ID','Kịch bản', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table_order);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $id = $this->Common_model->add($this->table_order,$data_insert);  
                if($id){
                    $detail = $this->input->post("detail");
                    $index = count( $detail["SoCN"] );
                    $data_inserts = [];
                    for ($i=0; $i < $index; $i++) { 
                        $data_inserts[] = [
                            "SoCN"       => $detail["SoCN"][$i],
                            "SoChuyen"   => $detail["SoChuyen"][$i],
                            "SanLuong"   => $detail["SanLuong"][$i],
                            "Position"   => $i,
                            "UocTinh_ID" => $id
                        ];
                    }
                    $this->Common_model->insert_batch_data("M2_UocTinh_ChiTiet",$data_inserts);
                    $details = $this->Common_model->get_result("M2_UocTinh_ChiTiet",["UocTinh_ID " => $id,"Is_Delete" => 0]);
                    $data_update = [
                        "Para1" => $this->order_Para1($details),
                        "Para2" => $this->order_Para2($details),
                        "Para3" => $this->order_Para3($details),
                        "Para4" => $this->order_Para4($details),
                        "Para5" => $this->order_Para5($details)
                    ];
                    $this->Common_model->update($this->table_order, $data_update,array("ID" => $id));
                    $record = $this->model->get_order($id);
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['scripts']    = $this->Common_model->get_result($this->table,array('Is_Delete' => 0));
        $this->data['action']     = backend_url("/".$this->folder_view."/order_add");
        $this->data['type']       = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/order_add",$this->data);
    }
    public function order_edit($id = null){
        $record = $this->model->get_order($id);
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Thông tin ước tính này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('Name','Tên ước tính', 'required');
            $this->form_validation->set_rules('KichBan_ID','Kịch bản', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                $colums = $this->db->list_fields($this->table_order);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $this->Common_model->update($this->table_order, $data_update,array("ID" => $id));
                if($id){
                    $detail = $this->input->post("detail");
                    $index = count( $detail["SoCN"] );
                    $data_inserts = [];
                    $data_id      = [];
                    for ($i=0; $i < $index; $i++) { 
                        if(@$detail["SoCN"][$i] != null){
                            if(@$detail["ID"][$i] == 0){
                                $data_inserts = [
		                            "SoCN"       => $detail["SoCN"][$i],
		                            "SoChuyen"   => $detail["SoChuyen"][$i],
		                            "SanLuong"   => $detail["SanLuong"][$i],
		                            "Position"   => $i,
		                            "UocTinh_ID" => $id
		                        ];
                                $data_id[] = $this->Common_model->add("M2_UocTinh_ChiTiet",$data_inserts);
                            }else{
                                $data_id[] = $detail["ID"][$i];
                                $this->Common_model->update("M2_UocTinh_ChiTiet",
                                    [
                                        "SoCN"       => $detail["SoCN"][$i],
			                            "SoChuyen"   => $detail["SoChuyen"][$i],
			                            "SanLuong"   => $detail["SanLuong"][$i],
			                            "Position"   => $i,
                                    ],array("ID" => $detail["ID"][$i])
                                );
                            }
                        }
                    }
                    if($data_id){
                        $this->db->where("UocTinh_ID",$id);
                        $this->db->where_not_in("ID",$data_id);
                        $this->db->update("M2_UocTinh_ChiTiet",["Is_Delete" => 1]);
                    }
                    $details = $this->Common_model->get_result("M2_UocTinh_ChiTiet",["UocTinh_ID" => $id,"Is_Delete" => 0],null,null,array('Position' => "ASC"));
                    $data_update = [
                        "Para1" => $this->order_Para1($details),
                        "Para2" => $this->order_Para2($details),
                        "Para3" => $this->order_Para3($details),
                        "Para4" => $this->order_Para4($details),
                        "Para5" => $this->order_Para5($details)
                    ];
                    $this->Common_model->update($this->table_order, $data_update,array("ID" => $id));
                    $record = $this->model->get_order( $id );
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['scripts']    = $this->Common_model->get_result($this->table,array('Is_Delete' => 0));
        $this->data['action']     = backend_url("/".$this->folder_view."/order_edit/".$id);
        $this->data['type']       = 'edit';
        $this->data['record']     = $record;
        $this->data["details"]    = $this->Common_model->get_result("M2_UocTinh_ChiTiet",["UocTinh_ID" => $id,"Is_Delete" => 0],null,null,array('Position' => "ASC"));
        $this->load->view($this->backend_asset."/".$this->folder_view."/order_add",$this->data);
    }
    public function order_view($id = null){
        $record = $this->model->get_order($id);
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Ước tính không tồn tại.";
            die(json_encode($data));
        }
        $this->data['record']  = $record;
        $this->data['scripts']    = $this->Common_model->get_result($this->table,array('Is_Delete' => 0));
        $this->data['action']     = backend_url("/".$this->folder_view."/order_edit/".$id);
        $this->data['record']     = $record;
        $this->data["details"]    = $this->Common_model->get_result("M2_UocTinh_ChiTiet",["UocTinh_ID" => $id,"Is_Delete" => 0],null,null,array('Position' => "ASC"));
        $data['status']           = 'success';
        $data['response'] = $this->load->view($this->backend_asset."/".$this->folder_view."/order_view",$this->data,true);
        die(json_encode($data));
    }
    public function order_delete($id = 0){
        $record = $this->Common_model->get_record($this->table_order,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Kịch bản này không tồn tại.";
            die(json_encode($data));
        }
        $data_update = array();
        $data_update["Is_Delete"]  = 1;
        $result = $this->Common_model->update($this->table_order,$data_update,array("ID" => $id));
        if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }
    private function order_Para1 ($array){
        $return = 0;
        foreach ($array as $key => $value) {
            $return += $value["SanLuong"];
        }
        return $return;
    }
    private function order_Para2 ($array){
        $return = 0;
        foreach ($array as $key => $value) {
            $return += $value["SanLuong"];
        }
        return $return;
    }
    private function order_Para3 ($array){
        $return = 0;
        foreach ($array as $key => $value) {
            $return += $value["SanLuong"];
        }
        return $return;
    }
    private function order_Para4 ($array){
        $return = 0;
        foreach ($array as $key => $value) {
            $return += $value["SanLuong"];
        }
        return $return;
    }
    private function order_Para5 ($array){
        $return = 0;
        foreach ($array as $key => $value) {
            $return += $value["SanLuong"];
        }
        return $return;
    }
    public function productions (){
	    $this->data['header'] = array(
	        'Tên Ước tinh đơn hàng',
	        'Tên kịch bản',
	        'Para1',
	        'Para2',
	        'Para3',
	        'Para4',
	        'Para5',
	        'Hành động'
	    );
	    $where["1"] = "1";
	    $where['tbl1.Is_Delete != '] = "1";
	    if($this->input->get("keyword") != null){
	        $where["tbl1.Name Like"] = "%".$this->input->get("keyword")."%";
	    }
	    $per_page = $this->per_page;
	    $count_table = $this->model->get_productions_count($where);
	    $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0 ;    
	    $config['base_url'] = backend_url("/".$this->folder_view.'/productions/'.$this->request);
	    $config['total_rows'] = $count_table;
	    $config['per_page'] = $per_page;
	    $config['page_query_string'] = TRUE;
	    $config['segment'] = 2;
	    $this->load->library('pagination');
	    $this->pagination->initialize($this->get_config_paging($config));
	    $this->data["results"] = $this->model->get_productions($where,$offset,$per_page,array('ID' => "DESC"));
	    $this->load->view($this->backend_asset."/".$this->folder_view."/productions",$this->data);
	}
	public function production_add (){
	    if($this->input->post()){
	        $data = array('status' => 'error');
	        $this->form_validation->set_rules('Name','Tên ước tính', 'required');
	        $this->form_validation->set_rules('KichBan_ID','Kịch bản', 'required');
	        if ($this->form_validation->run() == TRUE) {
	            $data_post = $this->input->post();
	            $colums = $this->db->list_fields($this->table_production);
	            $data_insert = array();
	            foreach ($data_post as $key => $value) {
	                if(in_array($key, $colums)){
	                    $data_insert[$key] = $value;
	                }              
	            }
	            $id = $this->Common_model->add($this->table_production,$data_insert);  
	            if($id){
	                $detail = $this->input->post("detail");
	                $index = count( $detail["SoCN"] );
	                $data_inserts = [];
	                for ($i=0; $i < $index; $i++) { 
	                    $data_inserts[] = [
	                        "SoCN"       => $detail["SoCN"][$i],
	                        "SoChuyen"   => $detail["SoChuyen"][$i],
	                        "SanLuong"   => $detail["SanLuong"][$i],
	                        "Position"   => $i,
	                        "UocTinh_ID" => $id
	                    ];
	                }
	                $this->Common_model->insert_batch_data("M2_UocTinh_ChiTietSX",$data_inserts);
	                $details = $this->Common_model->get_result("M2_UocTinh_ChiTietSX",["UocTinh_ID " => $id,"Is_Delete" => 0]);
	                $data_update = [
	                    "Para1" => $this->production_Para1($details),
	                    "Para2" => $this->production_Para2($details),
	                    "Para3" => $this->production_Para3($details),
	                    "Para4" => $this->production_Para4($details),
	                    "Para5" => $this->production_Para5($details)
	                ];
	                $this->Common_model->update($this->table_production, $data_update,array("ID" => $id));
	                $record = $this->model->get_production($id);
	                $data['status'] = 'success';
	                $data['action'] = 'add';
	                $data['responsive'] = $record;
	            }
	            else{
	                $data['status'] = "fail";
	                $data['message'] = "Thêm mới thất bại.";
	            }
	        }else{
	            $data['status'] = "fail";
	            $data['message'] = validation_errors();
	        }
	        die(json_encode($data));
	    }
	    $this->data['scripts']    = $this->Common_model->get_result($this->table,array('Is_Delete' => 0));
	    $this->data['action']     = backend_url("/".$this->folder_view."/production_add");
	    $this->data['type']       = 'add';
	    $this->load->view($this->backend_asset."/".$this->folder_view."/production_add",$this->data);
	}
	public function production_edit($id = null){
	    $record = $this->model->get_production($id);
	    if($this->input->post()){
	        $data = array('status' => 'error');
	        if($record == null){
	            $data['status'] = "fail";
	            $data['message'] = "Thông tin ước tính này không tồn tại.";
	            die(json_encode($data));
	        }
	        $this->form_validation->set_rules('Name','Tên ước tính', 'required');
	        $this->form_validation->set_rules('KichBan_ID','Kịch bản', 'required');
	        if($this->form_validation->run() == TRUE){
	            $data_post = $this->input->post();
	            $colums = $this->db->list_fields($this->table_production);
	            $data_update = array();
	            foreach ($data_post as $key => $value) {
	                if(in_array($key, $colums)){
	                    $data_update[$key] = $value;
	                }              
	            }
	            $this->Common_model->update($this->table_production, $data_update,array("ID" => $id));
	            if($id){
	                $detail = $this->input->post("detail");
	                $index = count( $detail["SoCN"] );
	                $data_inserts = [];
	                $data_id      = [];
	                for ($i=0; $i < $index; $i++) { 
	                    if(@$detail["SoCN"][$i] != null){
	                        if(@$detail["ID"][$i] == 0){
	                            $data_inserts = [
		                            "SoCN"       => $detail["SoCN"][$i],
		                            "SoChuyen"   => $detail["SoChuyen"][$i],
		                            "SanLuong"   => $detail["SanLuong"][$i],
		                            "Position"   => $i,
		                            "UocTinh_ID" => $id
		                        ];
	                            $data_id[] = $this->Common_model->add("M2_UocTinh_ChiTietSX",$data_inserts);
	                        }else{
	                            $data_id[] = $detail["ID"][$i];
	                            $this->Common_model->update("M2_UocTinh_ChiTietSX",
	                                [
	                                    "SoCN"       => $detail["SoCN"][$i],
			                            "SoChuyen"   => $detail["SoChuyen"][$i],
			                            "SanLuong"   => $detail["SanLuong"][$i],
			                            "Position"   => $i,
	                                ],array("ID" => $detail["ID"][$i])
	                            );
	                        }
	                    }
	                }
	                if($data_id){
	                    $this->db->where("UocTinh_ID",$id);
	                    $this->db->where_not_in("ID",$data_id);
	                    $this->db->update("M2_UocTinh_ChiTietSX",["Is_Delete" => 1]);
	                }
	                $details = $this->Common_model->get_result("M2_UocTinh_ChiTietSX",["UocTinh_ID" => $id,"Is_Delete" => 0],null,null,array('Position' => "ASC"));
	                $data_update = [
	                    "Para1" => $this->production_Para1($details),
	                    "Para2" => $this->production_Para2($details),
	                    "Para3" => $this->production_Para3($details),
	                    "Para4" => $this->production_Para4($details),
	                    "Para5" => $this->production_Para5($details)
	                ];
	                $this->Common_model->update($this->table_production, $data_update,array("ID" => $id));
	                $record = $this->model->get_production( $id );
	                $data['status'] = 'success';
	                $data['action'] = 'edit';
	                $data['responsive'] = $record;
	            }
	        }else{
	            $data['status'] = "fail";
	            $data['message'] = validation_errors();
	        }
	        die(json_encode($data));
	    }
	    $this->data['scripts']    = $this->Common_model->get_result($this->table,array('Is_Delete' => 0));
	    $this->data['action']     = backend_url("/".$this->folder_view."/production_edit/".$id);
	    $this->data['type']       = 'edit';
	    $this->data['record']     = $record;
	    $this->data["details"]    = $this->Common_model->get_result("M2_UocTinh_ChiTietSX",["UocTinh_ID" => $id,"Is_Delete" => 0],null,null,array('Position' => "ASC"));
	    $this->load->view($this->backend_asset."/".$this->folder_view."/production_add",$this->data);
	}
	public function production_view($id = null){
        $record = $this->model->get_production($id);
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Ước tính không tồn tại.";
            die(json_encode($data));
        }
        $this->data['record']  = $record;
        $this->data['scripts']    = $this->Common_model->get_result($this->table,array('Is_Delete' => 0));
        $this->data['action']     = backend_url("/".$this->folder_view."/production_view/".$id);
        $this->data['record']     = $record;
        $this->data["details"]    = $this->Common_model->get_result("M2_UocTinh_ChiTietSX",["UocTinh_ID" => $id,"Is_Delete" => 0],null,null,array('Position' => "ASC"));
        $data['status']           = 'success';
        $data['response'] = $this->load->view($this->backend_asset."/".$this->folder_view."/production_view",$this->data,true);
        die(json_encode($data));
    }
    public function production_delete($id = 0){
        $record = $this->Common_model->get_record($this->table_production,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Kịch bản này không tồn tại.";
            die(json_encode($data));
        }
        $data_update = array();
        $data_update["Is_Delete"]  = 1;
        $result = $this->Common_model->update($this->table_production,$data_update,array("ID" => $id));
        if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }
	private function production_Para1 ($array){
	    $return = 0;
	    foreach ($array as $key => $value) {
	        $return += $value["SanLuong"];
	    }
	    return $return;
	}
	private function production_Para2 ($array){
	    $return = 0;
	    foreach ($array as $key => $value) {
	        $return += $value["SanLuong"];
	    }
	    return $return;
	}
	private function production_Para3 ($array){
	    $return = 0;
	    foreach ($array as $key => $value) {
	        $return += $value["SanLuong"];
	    }
	    return $return;
	}
	private function production_Para4 ($array){
	    $return = 0;
	    foreach ($array as $key => $value) {
	        $return += $value["SanLuong"];
	    }
	    return $return;
	}
	private function production_Para5 ($array){
	    $return = 0;
	    foreach ($array as $key => $value) {
	        $return += $value["SanLuong"];
	    }
	    return $return;
	}
}