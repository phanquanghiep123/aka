<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Bang2_submit extends MY_Controller {
    private $folder_view = "bang2_submit";
    private $table = 'Bang2';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
    }
    
    public function index(){
        $where["1"] = "1";
        if($this->input->get("keyword") != null){
            $where["ten Like"] = "%".$this->input->get("keyword")."%";
        }
        $per_page = $this->per_page;
        $count_table = $this->Common_model->count_table($this->table,$where);
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0 ;    
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = $count_table;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->get_result($this->table,$where,$offset,$per_page);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }
    
    public function add() {
        if ($this->input->post()) {
            $this->form_validation->set_rules('ten', 'Tên', 'required');
            if ($this->form_validation->run() == TRUE) {
                $colums = $this->db->list_fields($this->table);
                $data_post = $this->input->post();
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }
                }
                $data_insert['ngay'] = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                $this->message($this->message_add_succes,'success');
                redirect(backend_url($this->folder_view.'/edit/'.$id));
            }else{
                $this->session->set_flashdata('record',$this->input->post());
                $this->message(validation_errors());
                redirect(backend_url($this->folder_view.'/create/'));
            }
        }
        $this->load->view($this->backend_asset."/".$this->folder_view."/edit",$this->data);
    }
    
    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($record == null){
            redirect(backend_url($this->folder_view));
        }
        if($this->input->post()){
            $this->form_validation->set_rules('ten', 'Tên', 'required');
            if ($this->form_validation->run() == TRUE){
                $colums = $this->db->list_fields($this->table);
                $data_post = $this->input->post();
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }
                }
                $this->message($this->message_update_succes,'success');
                $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));
            }else{
                $this->message(validation_errors());
            }
            redirect(backend_url($this->folder_view.'/edit/'.$id));
        }
        $this->data['record'] = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/edit",$this->data);
    }

    public function delete($id = null){
        $this->Common_model->delete($this->table,array("ID" => $id));
        $this->message($this->message_delete_succes,'success');
        redirect(backend_url($this->folder_view));
    }
}
