<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Production_plan extends MY_Controller {

    private $folder_view = "production_plan";
    private $table = 'M2_ChiTietMaHang';
    private $table_plu = 'M2_MaHang';
    private $table_size = 'M2_Size';
    private $table_color = 'M2_Color';
    private $table_sizegroup = 'M2_SizeGroup';
    private $table_kehoachsx = 'M2_KeHoachSX';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
    }

    public function index($date = null){
        if($date != null){
            $date = date('Y-m-d',$date);
            $last_date = date('Y-m-d',strtotime("+7 day",strtotime($date)));
        }
        else{
            $date = date('Y-m-d');
            $last_date = date('Y-m-d',strtotime("+7 day"));
        }
        if($this->input->post()){
            $data_post = $this->input->post();
            $soluong = @$data_post['soluong'];
            $date_post    = @$data_post['date'];
            if(isset($soluong) && $soluong != null){
                foreach ($soluong as $key => $item) {
                    foreach ($item as $key1 => $item2) {
                        if(@$item2 != null && @$date_post[$key][$key1] != null){
                            $check = $this->Common_model->get_record($this->table_kehoachsx,array('ChiTiet_ID' => $key,'Date' => $date_post[$key][$key1]));
                            if($check != null){
                                $arr = array(
                                    'SoLuong' => $this->cover_number($item2)
                                );
                                $this->Common_model->update($this->table_kehoachsx,$arr,array('ChiTiet_ID' => $key,'Date' => $date_post[$key][$key1]));
                            }
                            else{
                                $arr = array(
                                    'ChiTiet_ID' => $key,
                                    'Date'  => $date_post[$key][$key1],
                                    'SoLuong' => $this->cover_number($item2),
                                    'Created_At' => date('Y-m-d H:i:s')
                                );
                                $this->Common_model->add($this->table_kehoachsx,$arr);
                            }
                        }
                    }
                }
            }
            $this->message($this->message_update_succes,'success');
            redirect(backend_url($this->folder_view.'/index/'.strtotime($date)));
        }
        $sql = "SELECT tbl1.*,tbl2.Name AS PluName,tbl3.Name AS SizeName,tbl4.MaMau
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_plu} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
                INNER JOIN {$this->table_size} AS tbl3 ON tbl3.ID = tbl1.Size_ID
                INNER JOIN {$this->table_color} AS tbl4 ON tbl4.ID = tbl1.Color_ID
                /*WHERE tbl1.EndDate >= '$date'*/
                ORDER BY tbl1.StartDate ASC";
        $results = $this->Common_model->query_raw($sql);
        if(isset($results) && $results != null){
            foreach($results as $key => $item){
                $where = array(
                    'ChiTiet_ID' => $item['ID'],
                    //'Date >='    => $date,
                    //'Date <'    => $last_date
                );
                $results[$key]['kehoachsx'] = $this->Common_model->get_result($this->table_kehoachsx,$where,null,null,array('Date' => 'ASC'));
                $sql = "SELECT SUM(SoLuong) AS Total FROM {$this->table_kehoachsx} WHERE ChiTiet_ID = '{$item['ID']}'";
                $results[$key]['total'] = $this->Common_model->query_raw_row($sql);
            }
        }
        $numberDays = 7;
        $this->data['numberDays'] = $numberDays;
        $this->data['current_date'] = $date;
        $this->data['results'] = $results;
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }
}