<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Price_production extends MY_Controller {

    private $folder_view = "price_production";
    private $table = 'M2_DonGiaSX';
    private $table_plu = 'M2_MaHang';
    private $table_type = 'M2_LoaiHinh';
    private $table_qtsx = 'M2_QuyTrinhSX';

    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
        $this->data["plu_result"]    = $this->Common_model->get_result($this->table_plu);
        $this->data["type_result"] = $this->Common_model->get_result($this->table_type);
        $this->data['header'] = array('Mã hàng','Loại hình','Đơn giá');
    }

    public function index(){
        $where = " WHERE 1=1 ";
        if($this->input->get("Plu") != null){
            $where .= " AND tbl1.MaHang_ID = '".$this->input->get("Plu")."'";
        }
        if($this->input->get("Type") != null){
            $where .= " AND tbl1.LoaiHinh_ID = '".$this->input->get("Type")."'";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl2.Name AS PluName,tbl3.Name AS TypeName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_plu} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
                INNER JOIN {$this->table_type} AS tbl3 ON tbl3.ID = tbl1.LoaiHinh_ID
                $where 
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_plu} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
            INNER JOIN {$this->table_type} AS tbl3 ON tbl3.ID = tbl1.LoaiHinh_ID
            $where";


        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('MaHang_ID', 'Mã hàng', 'required');
            $this->form_validation->set_rules('LoaiHinh_ID', 'Loại hình', 'required');
            $this->form_validation->set_rules('DonGia', 'Đơn giá', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();

                $record = $this->Common_model->get_record($this->table,array("MaHang_ID" => $data_post['MaHang_ID'],"LoaiHinh_ID" => $data_post['LoaiHinh_ID']));
                if($record != null){
                    $data['status'] = "fail";
                    $data['message'] = "Loại hình cho mã hàng này đã tồn tại.";
                    die(json_encode($data));
                }


                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert["DonGia"]  = $this->cover_number($data_post["DonGia"]);
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $record['DonGia'] = ($record['DonGia'] != null ? number_format($record['DonGia']) : '0').' VNĐ';
                    
                    $plug = $this->Common_model->get_record($this->table_plu,array("ID" => $record['MaHang_ID']));
                    $record['PluName'] = @$plug['Name'] == null ? '' : $plug['Name'];
                    
                    $type = $this->Common_model->get_record($this->table_type,array("ID" => $record['LoaiHinh_ID']));
                    $record['TypeName'] = @$type['Name'] == null ? '' : $type['Name'];
                    
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data["type_result"] = null;
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function add_more(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('MaHang_ID', 'Mã hàng', 'required');
            if ($this->form_validation->run() == TRUE) {
                $check = true;
                $data_post = $this->input->post();
                if(@$data_post['dongia'] != null){
                    foreach ($data_post['dongia'] as $key => $item) {
                        $record = $this->Common_model->get_record($this->table,array("MaHang_ID" => $data_post['MaHang_ID'],"LoaiHinh_ID" => $key));
                        if(@$record == null && $item != null){
                            $data_insert = array(
                                'MaHang_ID'  => $this->input->post('MaHang_ID'),
                                'LoaiHinh_ID'=> $key,
                                'DonGia'     => $this->cover_number($item),
                                'Created_At' => date('Y-m-d H:i:s')
                            );
                            $this->Common_model->add($this->table,$data_insert); 
                            $check = false;
                        }
                    }
                }
                if($check == true){
                    $this->message('Vui lòng nhập đầu đủ dữ liệu.');
                }
                else{
                    $this->message($this->message_add_succes,'success');
                    redirect(backend_url("/".$this->folder_view."/"));
                }
            }else{
                $this->message(validation_errors());
            }
            redirect(backend_url($this->folder_view.'/add_more/'));
        }
        $this->load->view($this->backend_asset."/".$this->folder_view."/add-more",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Đơn giá sản xuất này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('MaHang_ID', 'Mã hàng', 'required');
            $this->form_validation->set_rules('LoaiHinh_ID', 'Loại hình', 'required');
            $this->form_validation->set_rules('DonGia', 'Đơn giá', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();
                $check = $this->Common_model->get_record($this->table,array("MaHang_ID" => $data_post['MaHang_ID'],"LoaiHinh_ID" => $data_post['LoaiHinh_ID']));
                if($check != null && $check['ID'] != $record['ID']){
                    $data['status'] = "fail";
                    $data['message'] = "Loại hình cho mã hàng này đã tồn tại.";
                    die(json_encode($data));
                }

                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                $data_update["DonGia"]  = $this->cover_number($data_post["DonGia"]);
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){
                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Created_At'] = date($this->datetime_format,strtotime($record["Created_At"]));
                    $record['DonGia'] = ($record['DonGia'] != null ? number_format($record['DonGia']) : '0').' VNĐ';
                    
                    $plug = $this->Common_model->get_record($this->table_plu,array("ID" => $record['MaHang_ID']));
                    $record['PluName'] = @$plug['Name'] == null ? '' : $plug['Name'];
                    
                    $type = $this->Common_model->get_record($this->table_type,array("ID" => $record['LoaiHinh_ID']));
                    $record['TypeName'] = @$type['Name'] == null ? '' : $type['Name'];
                    

                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }
        $sql = "SELECT tbl1.*,tbl3.Name AS TypeName,tbl3.ID AS TypeID
                FROM {$this->table_qtsx} AS tbl1 
                INNER JOIN {$this->table_type} AS tbl3 ON tbl3.ID = tbl1.LoaiHinh_ID
                WHERE tbl1.MaHang_ID = '{$record['MaHang_ID']}'
                ORDER BY tbl1.Position ASC";
        $this->data["type_result"] = $this->Common_model->query_raw($sql);
        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Đơn giá sản xuất này không tồn tại.";
            die(json_encode($data));
        }
        /*$check  = $this->Common_model->get_record('M2_DonGiaSX',array("MaHang_ID" => $id));
        if($check != null){
            $data['status'] = "fail";
            $data['message'] = "Đơn giá sản xuất này được sử dụng – Không thể xóa.";
            die(json_encode($data));
        }*/
        $result = $this->Common_model->delete($this->table,array("ID" => $id));
        if($result){
            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }

    public function export(){
        set_time_limit(0);
        $this->data['is_export'] = true;
        $sql = "SELECT tbl1.*,tbl2.Name AS PluName,tbl3.Name AS TypeName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_plu} AS tbl2 ON tbl2.ID = tbl1.MaHang_ID
                INNER JOIN {$this->table_type} AS tbl3 ON tbl3.ID = tbl1.LoaiHinh_ID
                ORDER BY tbl1.ID DESC";
        $results = $this->Common_model->query_raw($sql);
        $title = 'Đơn giá sản xuất';
        $header = array('Mã hàng','Loại hình','Đơn giá');
        $data = array();
        if(isset($results) && $results != null){
            foreach ($results as $key => $item) {
                $data[] = array(
                    $item['PluName'],
                    $item['TypeName'],
                    $item['DonGia']
                );
            }
        }
        export_excel($title,$header,$data);
    }

    public function import(){
        $data = array('status' => 'error');
        if (isset($_FILES["excel"]['name']) && $_FILES["excel"]['name'] != null){
            $mimes = array('xls','xlsx');
            $ext = pathinfo($_FILES['excel']['name'], PATHINFO_EXTENSION);
            if(!in_array($ext,$mimes)){
                $data['message'] = 'Vui lòng chọn excel file.';
                $data['status']  = 'fail';
                die(json_encode($data));
            }

            $upload_path = FCPATH . "/uploads/excel";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, TRUE);
            }
            $config = array();
            $config['upload_path'] = $upload_path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($this->upload->do_upload('excel')){
                $upload_data = $this->upload->data();
                $path_file = $upload_data['full_path'];
                $data_excel = get_data_excel($path_file);
                foreach ($data_excel[0] as $key => $item) {
                    if($item != trim(@$this->data['header'][$key])){
                        $data['message'] = 'Excel file không đúng định dạng.';
                        $data['status']  = 'fail';
                        die(json_encode($data));
                    }
                }
                $data_insert = array();
                foreach ($data_excel as $key => $item) {
                    if($key > 0 && @$item[0] != null && @$item[1] != null && @$item[2] != null){
                        $plu = $this->Common_model->get_record($this->table_plu,array('Name' => trim(@$item[0])));
                        $type = $this->Common_model->get_record($this->table_type,array('Name' => @$item[1]));
                        if($type != null && $plu != null){
                            $data_insert[] = array(
                                'MaHang_ID' => $plu['ID'],
                                'LoaiHinh_ID' => $type['ID'],
                                'DonGia' => @$item[2],
                                'Created_At' => date('Y-m-d H:i:s')
                            );
                        }
                    }
                }
                if(count($data_insert) > 0){
                    $this->Common_model->insert_batch_data($this->table,$data_insert);
                }
                $data['status']  = 'success';
                $data['message'] = "Nhập dữ liệu thành công";
                die(json_encode($data));
            }
            else{
                $data['message'] = $this->upload->display_errors();
                $data['status']  = 'fail';
                die(json_encode($data));
            }
        }
        else{
            $data['message'] = 'Vui lòng chọn file muốn nhập.';
            $data['status']  = 'fail';
            die(json_encode($data));
        }
        die(json_encode($data));
    }

    public function get_type($order_id = null){
    	$data = array('status' => 'error');
    	$sql = "SELECT tbl1.*,tbl3.Name AS TypeName,tbl3.ID AS TypeID
                FROM {$this->table_qtsx} AS tbl1 
                INNER JOIN {$this->table_type} AS tbl3 ON tbl3.ID = tbl1.LoaiHinh_ID
                WHERE tbl1.MaHang_ID = '{$order_id}'
                ORDER BY tbl1.Position ASC";
        $results = $this->Common_model->query_raw($sql);
        $option = '';
        if(isset($results) && $results != null){
        	foreach ($results as $key => $item) {
        		$option .= '<option value="'.$item['TypeID'].'">'.$item['TypeName'].'</option>';
        	}
        }
        $data['status'] = 'success';
        $data['response'] = $option;
        die(json_encode($data));
    }

    public function load_table($order_id = null){
        $sql = "SELECT tbl1.*,tbl3.Name AS TypeName,tbl3.ID AS TypeID
                FROM {$this->table_qtsx} AS tbl1 
                INNER JOIN {$this->table_type} AS tbl3 ON tbl3.ID = tbl1.LoaiHinh_ID
                WHERE tbl1.MaHang_ID = '{$order_id}'
                ORDER BY tbl1.Position ASC";
        $this->data["type_result"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/table",$this->data);
    }
}