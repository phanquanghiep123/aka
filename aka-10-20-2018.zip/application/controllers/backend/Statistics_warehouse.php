<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Statistics_warehouse extends MY_Controller {

    private $folder_view = "statistics_warehouse";
    private $table_tra  = 'KHO_Tra';
    private $table_xuat = 'KHO_Xuat';
    private $table_nhap = 'KHO_Nhap';
    private $table_dmvt = 'KHO_DMVT';
    private $table_dvt  = 'KHO_DVT';


    public function __construct() {
        parent::__construct();
        $this->data['folder_view'] = $this->folder_view;
    }

    public function index(){
        $start_date = date('Y-m-d');
        $end_date   = date('Y-m-d');

        $where = " WHERE 1=1 ";
        if($this->input->get("keyword") != null){
            $where .= " AND tbl1.Name LIKE '%".addslashes($this->input->get("keyword"))."%'";
        }
        if($this->input->get("daterange") != null){
        	$daterange = explode('-', $this->input->get("daterange"));
        	if(isset($daterange) && $daterange != null && count($daterange) == 2){
        		$start_date = date('Y-m-d',strtotime(trim($daterange[0])));
        		$end_date   = date('Y-m-d',strtotime(trim($daterange[1])));
            }
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $date = date('Y-m-d');
        $sql_tonkho = "
            SELECT tbl1.ID,(IF(tbl3.TotalNhap >= 0,tbl3.TotalNhap,0) - IF(tbl4.TotalXuat >= 0,tbl4.TotalXuat,0) +  IF(tbl5.TotalTra >= 0,tbl5.TotalTra,0)) AS TotalTon
            FROM {$this->table_dmvt} AS tbl1
            LEFT JOIN (
                SELECT SUM(SoLuong) AS TotalNhap,DMVT_ID
                FROM {$this->table_nhap}
                WHERE Is_Delete != '1' AND Status = '3' AND DATE_FORMAT(Created_At, '%Y-%m-%d') <= '$date'
                GROUP BY DMVT_ID
            ) AS tbl3 ON tbl1.ID = tbl3.DMVT_ID  

            LEFT JOIN (
                SELECT SUM(SoLuong) AS TotalXuat,DMVT_ID
                FROM {$this->table_xuat}
                WHERE Is_Delete != '1' AND Ngay <= '$date'
                GROUP BY DMVT_ID
            ) AS tbl4 ON tbl1.ID = tbl4.DMVT_ID

            LEFT JOIN (
                SELECT SUM(SoLuong) AS TotalTra,DMVT_ID
                FROM {$this->table_tra}
                WHERE Is_Delete != '1' AND Ngay <= '$date'
                GROUP BY DMVT_ID
            ) AS tbl5 ON tbl1.ID = tbl5.DMVT_ID";


        if($start_date == $end_date && $end_date == date('Y-m-d')){
            $sql = "SELECT tbl1.*,tbl2.Name AS DVTName,tbl3.TotalNhap,tbl4.TotalXuat,tbl5.TotalTon
                FROM {$this->table_dmvt} AS tbl1
                INNER JOIN {$this->table_dvt} AS tbl2 ON tbl2.ID = tbl1.DVT_ID
                LEFT JOIN (
                    SELECT SUM(SoLuong) AS TotalNhap,DMVT_ID
                    FROM {$this->table_nhap}
                    WHERE Is_Delete != '1' AND Status = '3' AND DATE_FORMAT(Created_At, '%Y-%m-%d') <= '$end_date'
                    GROUP BY DMVT_ID
                ) AS tbl3 ON tbl1.ID = tbl3.DMVT_ID  

                LEFT JOIN (
                    SELECT SUM(SoLuong) AS TotalXuat,DMVT_ID
                    FROM {$this->table_xuat}
                    WHERE Is_Delete != '1' AND Ngay <= '$end_date'
                    GROUP BY DMVT_ID
                ) AS tbl4 ON tbl1.ID = tbl4.DMVT_ID

                LEFT JOIN (
                    $sql_tonkho
                ) AS tbl5 ON tbl1.ID = tbl5.ID
                $where
                ORDER BY tbl3.TotalNhap DESC,tbl4.TotalXuat DESC,tbl1.ID DESC
                LIMIT $offset,$per_page";
        }
        else{
            $sql = "SELECT tbl1.*,tbl2.Name AS DVTName,tbl3.TotalNhap,tbl4.TotalXuat,tbl5.TotalTon
                FROM {$this->table_dmvt} AS tbl1
                INNER JOIN {$this->table_dvt} AS tbl2 ON tbl2.ID = tbl1.DVT_ID
                LEFT JOIN (
                    SELECT SUM(SoLuong) AS TotalNhap,DMVT_ID
                    FROM {$this->table_nhap}
                    WHERE Is_Delete != '1' AND Status = '3' AND DATE_FORMAT(Created_At, '%Y-%m-%d') >= '$start_date' AND DATE_FORMAT(Created_At, '%Y-%m-%d') <= '$end_date'
                    GROUP BY DMVT_ID
                ) AS tbl3 ON tbl1.ID = tbl3.DMVT_ID

                LEFT JOIN (
                    SELECT SUM(SoLuong) AS TotalXuat,DMVT_ID
                    FROM {$this->table_xuat}
                    WHERE Is_Delete != '1' AND DATE_FORMAT(Ngay, '%Y-%m-%d') >= '$start_date' AND DATE_FORMAT(Ngay, '%Y-%m-%d') <= '$end_date'
                    GROUP BY DMVT_ID
                ) AS tbl4 ON tbl1.ID = tbl4.DMVT_ID

                LEFT JOIN (
                    $sql_tonkho
                ) AS tbl5 ON tbl1.ID = tbl5.ID

                $where
                ORDER BY tbl3.TotalNhap DESC,tbl4.TotalXuat DESC,tbl1.ID DESC
                LIMIT $offset,$per_page";
        }

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table_dmvt} AS tbl1 
            INNER JOIN {$this->table_dvt} AS tbl2 ON tbl2.ID = tbl1.DVT_ID 
            $where";
        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }
}