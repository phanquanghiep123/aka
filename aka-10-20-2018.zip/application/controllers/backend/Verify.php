<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Verify extends CI_Controller {
    public $data      = null;
    public $is_login  = false;
    public $user_info = null;
    
    public function __construct() {
        parent::__construct();
        if ($this->session->userdata('admin_info')) {
            $this->is_login  = true;
            $this->user_info = $this->session->userdata('admin_info');
        }
        $this->data["admin_info"] = $this->user_info;
        $this->data["is_login"]   = $this->is_login;
    }
    public function index(){
        if($this->data["is_login"] ){
            redirect(backend_url("/"));
        }
        else{
            redirect(backend_url("/acounts/login"));
        }
    }
    public function company_success($code){
        $record = $this->Common_model->get_record("Aka_Sys_Company",["Token" => $code]);
        if($record == null )  redirect(base_url("backend/acounts/login"));
        $this->Common_model->update("Aka_Sys_Company",["Verify" => "1","Token" => md5(uniqid())],["ID" => $record ["ID"]]);
        if($this->data["is_login"] ){
            redirect(backend_url("/"));
        }
        else{
            redirect(backend_url("/acounts/login"));
        }
    }

    public function company_error($code){
        $record = $this->Common_model->get_record("Aka_Sys_Company",["Token" => $code]);
        if($record == null )  redirect(backend_url("/acounts/login"));
        $this->Common_model->update("Aka_Sys_Company",["Verify" => "2","Token" => md5(uniqid())],["ID" => $record ["ID"]]);
        if($this->data["is_login"] ){
            redirect(backend_url("backend"));
        }
        else{
            redirect(backend_url("acounts/login"));
        }
    }

     public function singup_company_success($code){
        $record = $this->Common_model->get_record("Aka_Sys_Company_Employee",["Token" => $code]);
        if($record == null )  {
            redirect(backend_url("/acounts/login"));
        }
        $this->Common_model->update("Aka_Sys_Company_Employee",["Verify" => "1","Token" => md5(uniqid())],["ID" => $record ["ID"]]);
        if($this->data["is_login"] ){
            redirect(backend_url("/"));
        }
        else{
            redirect(backend_url("acounts/login"));
        }
    }

    public function singup_company_error($code){
        $record = $this->Common_model->get_record("Aka_Sys_Company_Employee",["Token" => $code]);
        if($record == null )  {
            redirect(backend_url("acounts/login"));
        }
        $this->Common_model->update("Aka_Sys_Company_Employee",["Verify" => "2","Token" => md5(uniqid())],["ID" => $record ["ID"]]);
        if($this->data["is_login"] ){
            redirect(backend_url("/"));
        }
        else{
            redirect(backend_url("acounts/login"));
        }
    }
}
