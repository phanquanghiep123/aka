<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Return_materials extends MY_Controller {

    private $folder_view = "return_materials";
    private $table = 'KHO_Tra';
    private $table_employees = 'M6_Employee';
    private $table_dmvt = 'KHO_DMVT';
    private $table_KHO_Gia_VT = 'KHO_Gia_VT';
    private $table_KHO_Hop_VT = 'KHO_Hop_VT';
    private $table_gia = 'KHO_Gia';
    private $table_hop = 'KHO_Hop';

    public function __construct() {
        parent::__construct();
        $this->load->model('Users_model');
        $this->data['folder_view'] = $this->folder_view;
        $this->data["employees_result"]    = $this->Common_model->get_result($this->table_employees);
        $this->data["dmvt_result"]    = $this->Common_model->get_result($this->table_dmvt,array('Is_Delete != ' => 1));
        $this->data['header'] = array('Người Trả','Danh mục vật tư','Số lượng','Ngày tháng');
    }

    public function index(){
        $where = " WHERE tbl1.Is_Delete != '1' ";
        if($this->input->get("Employees") != null){
            $where .= " AND tbl1.Employees_ID = '".$this->input->get("Employees")."'";
        }
        if($this->input->get("DMVT") != null){
            $where .= " AND tbl1.DMVT_ID = '".$this->input->get("DMVT")."'";
        }
        $per_page = $this->per_page;
        $offset = ($this->input->get("offset") != "") ? $this->input->get("offset") : 0;
        $sql = "SELECT tbl1.*,tbl3.Name AS DMVTName,tbl2.Name AS EmployeesName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_employees} AS tbl2 ON tbl2.ID = tbl1.Employee_CongNhan_ID
                INNER JOIN {$this->table_dmvt} AS tbl3 ON tbl3.ID = tbl1.DMVT_ID
                $where 
                ORDER BY tbl1.ID DESC
                LIMIT $offset,$per_page";

        $sql_count = "SELECT count(tbl1.ID) AS count
            FROM {$this->table} AS tbl1 
            INNER JOIN {$this->table_employees} AS tbl2 ON tbl2.ID = tbl1.Employee_CongNhan_ID
            INNER JOIN {$this->table_dmvt} AS tbl3 ON tbl3.ID = tbl1.DMVT_ID
            $where";


        $count = $this->Common_model->query_raw_row($sql_count);
        $config['base_url'] = backend_url("/".$this->folder_view.'/'.$this->request);
        $config['total_rows'] = @$count['count'] != null ? $count['count'] : 0;
        $config['per_page'] = $per_page;
        $config['page_query_string'] = TRUE;
        $config['segment'] = 2;
        $this->load->library('pagination');
        $this->pagination->initialize($this->get_config_paging($config));
        $this->data["results"] = $this->Common_model->query_raw($sql);
        $this->load->view($this->backend_asset."/".$this->folder_view."/index",$this->data);
    }

    public function add(){
        if($this->input->post()){
            $data = array('status' => 'error');
            $this->form_validation->set_rules('Ngay', 'Ngày', 'required');
            $this->form_validation->set_rules('DMVT_ID', 'Danh mục vật tư', 'required');
            $this->form_validation->set_rules('Employee_CongNhan_ID','Công nhân', 'required');
            $this->form_validation->set_rules('SoLuong', 'Số lượng', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_post = $this->input->post();

                $gia = @$data_post['gia'];
                $hop = @$data_post['hop'];
                $soluong = 0;
                if($gia != null){
                    foreach ($gia  as $key => $item) {
                        if($item != null && $item > 0){
                            $check_gia = $this->Common_model->get_record($this->table_gia,array('ID' => $key,'Is_Delete' => '0'));
                            if($check_gia != null){
	                            $data_post['Position'] = 1;
                                $soluong += $item;
                            }
                        }
                    }
                }

                if($hop != null){
                    foreach ($hop as $key => $item) {
                        if($item != null && $item > 0){
                            $check_hop = $this->Common_model->get_record($this->table_hop,array('ID' => $key,'Is_Delete' => '0'));
                            if($check_hop != null){
                                $data_post['Position'] = 1;
	                            $soluong += $item;
                            }
                        }
                    }
                }

                if($soluong != 0 && $soluong != $data_post['SoLuong']){
                    $data['status'] = "fail";
                    $data['message'] = "Số lượng trả và vị trí không trùng nhau.";
                    die(json_encode($data));
                }

                

                $colums = $this->db->list_fields($this->table);
                $data_insert = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_insert[$key] = $value;
                    }              
                }
                $data_insert['SoLuong'] = $data_post['SoLuong'];
                $data_insert['Employee_NVKho_ID'] = $this->user_info["Employee_ID"];
                $data_insert["Created_At"]  = date('Y-m-d H:i:s');
                $id = $this->Common_model->add($this->table,$data_insert);  
                if($id > 0){
                	if($gia != null){
                        foreach ($gia  AS $key => $item) {
                            if($item != null && $item > 0){
                                $check_gia = $this->Common_model->get_record($this->table_gia,array('ID' => $key,'Is_Delete' => '0'));
                                if($check_gia != null){
                                    
                                    $where = array(
                                        'DMVT_ID' => $data_post['DMVT_ID'],
                                        'Gia_ID' => $key,
                                        'Is_Delete' => '0'
                                    );
                                    $check_gia_vt = $this->Common_model->get_record($this->table_KHO_Gia_VT,$where);
                                    $arr = array(
                                        'SoLuong' => (@$check_gia_vt['SoLuong'] + $item)
                                    );
                                    $this->Common_model->update($this->table_KHO_Gia_VT,$arr,$where);

                                    $arr = array(
                                        'Gia_ID' => $key,
                                        'Tra_ID' => $id,
                                        'SoLuong' => $item,
                                        'Created_At' => date('Y-m-d H:i:s')
                                    );
                                    $this->Common_model->add('KHO_Tra_Gia',$arr);
                                }
                            }
                        }
                    }

                    if($hop != null){
                        foreach($hop AS $key => $item) {
                            if($item != null && $item > 0){
                                $check_hop = $this->Common_model->get_record($this->table_hop,array('ID' => $key,'Is_Delete' => '0'));
                                if($check_hop != null){
                                    
                                    $where = array(
                                        'DMVT_ID' => $data_post['DMVT_ID'],
                                        'Hop_ID' => $key,
                                        'Is_Delete' => '0'
                                    );
                                    $check_hop_vt = $this->Common_model->get_record($this->table_KHO_Hop_VT,$where);
                                    $arr = array(
                                        'SoLuong' => (@$check_hop_vt['SoLuong'] + $item)
                                    );
                                    $this->Common_model->update($this->table_KHO_Hop_VT,$arr,$where);

                                    $arr = array(
                                        'Hop_ID' => $key,
                                        'Tra_ID' => $id,
                                        'SoLuong' => $item,
                                        'Created_At' => date('Y-m-d H:i:s')
                                    );
                                    $this->Common_model->add('KHO_Tra_Hop',$arr);
                                }
                            }
                        }
                    }

                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Ngay'] = date($this->date_format,strtotime($record["Ngay"]));
                    $record['Position'] = ($record["Position"] == 1 ? 'Đã cập nhật' : 'Chưa cập nhật');
                    $dmvt = $this->Common_model->get_record($this->table_dmvt,array("ID" => $record['DMVT_ID']));
                    $record['DMVTName'] = @$dmvt['Name'] == null ? '' : $dmvt['Name'];
                    $employees = $this->Common_model->get_record($this->table_employees,array("ID" => $record['Employee_CongNhan_ID']));
                    $record['EmployeesName'] = @$employees['Name'] == null ? '' : $employees['Name'];
                    $data['status'] = 'success';
                    $data['action'] = 'add';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Thêm mới thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        $this->data['action'] = backend_url("/".$this->folder_view."/add");
        $this->data['type'] = 'add';
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function edit($id = null){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        if($this->input->post()){
            $data = array('status' => 'error');
            if($record == null){
                $data['status'] = "fail";
                $data['message'] = "Xuất hàng này không tồn tại.";
                die(json_encode($data));
            }
            $this->form_validation->set_rules('Ngay', 'Ngày', 'required');
            $this->form_validation->set_rules('DMVT_ID', 'Danh mục vật tư', 'required');
            $this->form_validation->set_rules('Employee_CongNhan_ID','Công nhân', 'required');
            if($this->form_validation->run() == TRUE){
                $data_post = $this->input->post();

                $gia = @$data_post['gia'];
                $hop = @$data_post['hop'];
                $soluong = 0;
                $position = false;
                if($gia != null){
                    foreach ($gia  as $key => $item) {
                        if($item != null && $item > 0){
                            $check_gia = $this->Common_model->get_record($this->table_gia,array('ID' => $key,'Is_Delete' => '0'));
                            if($check_gia != null){
                                $position = true;
                                $soluong += $item;
                            }
                        }
                    }
                }

                if($hop != null){
                    foreach ($hop as $key => $item) {
                        if($item != null && $item > 0){
                        	$check_hop = $this->Common_model->get_record($this->table_hop,array('ID' => $key,'Is_Delete' => '0'));
                            if($check_hop != null){
                                $position = true;
                            	$soluong += $item;
                            }
                        }
                    }
                }

                if($soluong != 0 && $soluong != $data_post['SoLuong']){
                    $data['status'] = "fail";
                    $data['message'] = "Số lượng trả và vị trí không trùng nhau.";
                    die(json_encode($data));
                }

                $result_xuat_gia = $this->Common_model->get_result('KHO_Xuat_Gia',array('Xuat_ID' => $id));
                $result_xuat_hop = $this->Common_model->get_result('KHO_Xuat_Hop',array('Xuat_ID' => $id));
                
                if(isset($result_xuat_gia) && $result_xuat_gia != null){
                    foreach ($result_xuat_gia as $key => $item) {
                        $where = array(
                            'DMVT_ID' => $record['DMVT_ID'],
                            'Gia_ID' => $item['Gia_ID'],
                            'Is_Delete' => '0'
                        );
                        $check_gia_vt = $this->Common_model->get_record($this->table_KHO_Gia_VT,$where);
                        if($check_gia_vt != null){
                            $arr = array(
                                'SoLuong' => ($check_gia_vt['SoLuong'] - $item['SoLuong'])
                            );
                            $this->Common_model->update($this->table_KHO_Gia_VT,$arr,$where);
                        }
                    }
                }

                if(isset($result_xuat_hop) && $result_xuat_hop != null){
                    foreach ($result_xuat_hop as $key => $item) {
                        $where = array(
                            'DMVT_ID' => $record['DMVT_ID'],
                            'Hop_ID' => $item['Hop_ID'],
                            'Is_Delete' => '0'
                        );
                        $check_hop_vt = $this->Common_model->get_record($this->table_KHO_Hop_VT,$where);
                        if($check_hop_vt != null){
                            $arr = array(
                                'SoLuong' => ($check_hop_vt['SoLuong'] - $item['SoLuong'])
                            );
                            $this->Common_model->update($this->table_KHO_Hop_VT,$arr,$where);
                        }
                    }
                }


                $colums = $this->db->list_fields($this->table);
                $data_update = array();
                foreach ($data_post as $key => $value) {
                    if(in_array($key, $colums)){
                        $data_update[$key] = $value;
                    }              
                }
                if($position){
                    $data_update["Position"]  = 1;
                }
                else{
                    $data_update["Position"]  = 0;
                }
                $result = $this->Common_model->update($this->table,$data_update,array("ID" =>$record["ID"]));                                
                if($result){

                	$this->Common_model->delete('KHO_Tra_Gia',array("Tra_ID" => $id));
                	$this->Common_model->delete('KHO_Tra_Hop',array("Tra_ID" => $id));

                	if($gia != null){
                        foreach ($gia  AS $key => $item) {
                            if($item != null && $item > 0){
                                $check_gia = $this->Common_model->get_record($this->table_gia,array('ID' => $key,'Is_Delete' => '0'));
                                if($check_gia != null){
                                    
                                    $where = array(
                                        'DMVT_ID' => $data_post['DMVT_ID'],
                                        'Gia_ID' => $key,
                                        'Is_Delete' => '0'
                                    );
                                    $check_gia_vt = $this->Common_model->get_record($this->table_KHO_Gia_VT,$where);
                                    $arr = array(
                                        'SoLuong' => (@$check_gia_vt['SoLuong'] + $item)
                                    );
                                    $this->Common_model->update($this->table_KHO_Gia_VT,$arr,$where);

                                    $arr = array(
                                        'Gia_ID' => $key,
                                        'Tra_ID' => $id,
                                        'SoLuong' => $item,
                                        'Created_At' => date('Y-m-d H:i:s')
                                    );
                                    $this->Common_model->add('KHO_Tra_Gia',$arr);
                                }
                            }
                        }
                    }

                    if($hop != null){
                        foreach($hop AS $key => $item) {
                            if($item != null && $item > 0){
                                $check_hop = $this->Common_model->get_record($this->table_hop,array('ID' => $key,'Is_Delete' => '0'));
                                if($check_hop != null){
                                    
                                    $where = array(
                                        'DMVT_ID' => $data_post['DMVT_ID'],
                                        'Hop_ID' => $key,
                                        'Is_Delete' => '0'
                                    );
                                    $check_hop_vt = $this->Common_model->get_record($this->table_KHO_Hop_VT,$where);
                                    $arr = array(
                                        'SoLuong' => (@$check_hop_vt['SoLuong'] + $item)
                                    );
                                    $this->Common_model->update($this->table_KHO_Hop_VT,$arr,$where);

                                    $arr = array(
                                        'Hop_ID' => $key,
                                        'Tra_ID' => $id,
                                        'SoLuong' => $item,
                                        'Created_At' => date('Y-m-d H:i:s')
                                    );
                                    $this->Common_model->add('KHO_Tra_Hop',$arr);
                                }
                            }
                        }
                    }


                    $record = $this->Common_model->get_record($this->table,array("ID" => $id));
                    $record['Ngay'] = date($this->date_format,strtotime($record["Ngay"]));
                    $record['Position'] = ($record["Position"] == 1 ? 'Đã cập nhật' : 'Chưa cập nhật');
                    $dmvt = $this->Common_model->get_record($this->table_dmvt,array("ID" => $record['DMVT_ID']));
                    $record['DMVTName'] = @$dmvt['Name'] == null ? '' : $dmvt['Name'];
                    $employees = $this->Common_model->get_record($this->table_employees,array("ID" => $record['Employee_CongNhan_ID']));
                    $record['EmployeesName'] = @$employees['Name'] == null ? '' : $employees['Name'];
                    $data['status'] = 'success';
                    $data['action'] = 'edit';
                    $data['responsive'] = $record;
                }
                else{
                    $data['status'] = "fail";
                    $data['message'] = "Cập nhật thất bại.";
                }
            }else{
                $data['status'] = "fail";
                $data['message'] = validation_errors();
            }
            die(json_encode($data));
        }
        if($record == null){
            die('-1');
        }

        $this->data['get_postion']['dmvt'] = $this->Common_model->get_record($this->table_dmvt,array("ID" => $record['DMVT_ID'],'Is_Delete' => '0'));
        $this->data['get_postion']['dvt']  = $this->Common_model->get_record('KHO_DVT',array("ID" => @$this->data['get_postion']['dmvt']['DVT_ID'],'Is_Delete' => '0'));


        $sql = "SELECT tbl1.*,tbl2.SoLuong AS SoLuongVT,tbl3.SoLuong AS SoLuongTra
                FROM {$this->table_gia} AS tbl1
                LEFT JOIN {$this->table_KHO_Gia_VT} AS tbl2 ON tbl2.Gia_ID = tbl1.ID AND tbl2.DMVT_ID = '{$record['DMVT_ID']}' AND tbl2.Is_Delete != '1' 
                LEFT JOIN KHO_Tra_Gia AS tbl3 ON tbl3.Gia_ID = tbl1.ID AND tbl3.Tra_ID = '$id'
                ORDER BY tbl2.SoLuong DESC,tbl1.Name ASC";
        $this->data['get_postion']['gia_result'] = $this->Common_model->query_raw($sql);

        $sql = "SELECT tbl1.*,tbl2.SoLuong AS SoLuongVT,tbl3.SoLuong AS SoLuongTra
                FROM {$this->table_hop} AS tbl1
                LEFT JOIN {$this->table_KHO_Hop_VT} AS tbl2 ON tbl2.Hop_ID = tbl1.ID AND tbl2.DMVT_ID = '{$record['DMVT_ID']}' AND tbl2.Is_Delete != '1' 
                LEFT JOIN KHO_Tra_Hop AS tbl3 ON tbl3.Hop_ID = tbl1.ID AND tbl3.Tra_ID = '$id'
                ORDER BY tbl2.SoLuong DESC,tbl1.Name ASC";
        $this->data['get_postion']['hop_result'] = $this->Common_model->query_raw($sql);

        $this->data['action'] = backend_url("/".$this->folder_view."/edit/".$id);
        $this->data['type'] = 'edit';
        $this->data['record']  = $record;
        $this->load->view($this->backend_asset."/".$this->folder_view."/form",$this->data);
    }

    public function delete($id = 0){
        $record = $this->Common_model->get_record($this->table,array("ID" => $id));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Xuất hàng này không tồn tại.";
            die(json_encode($data));
        }
        $data_update = array();
        $data_update["Is_Delete"]  = 1;
        $result = $this->Common_model->update($this->table,$data_update,array("ID" => $id));
        //$result = $this->Common_model->delete($this->table,array("ID" => $id));
        if($result){

            $result_xuat_gia = $this->Common_model->get_result('KHO_Tra_Gia',array('Tra_ID' => $id));
            $result_xuat_hop = $this->Common_model->get_result('KHO_Tra_Hop',array('Tra_ID' => $id));
            
            if(isset($result_xuat_gia) && $result_xuat_gia != null){
                foreach ($result_xuat_gia as $key => $item) {
                    $where = array(
                        'DMVT_ID' => $record['DMVT_ID'],
                        'Gia_ID' => $item['Gia_ID'],
                        'Is_Delete' => '0'
                    );
                    $check_gia_vt = $this->Common_model->get_record($this->table_KHO_Gia_VT,$where);
                    if($check_gia_vt != null){
                        $arr = array(
                            'SoLuong' => ($check_gia_vt['SoLuong'] - $item['SoLuong'])
                        );
                        $this->Common_model->update($this->table_KHO_Gia_VT,$arr,$where);
                        $this->Common_model->update('KHO_Tra_Gia',array('Is_Delete' => 1),array("ID" => $item['ID']));
                    }
                }
            }

            if(isset($result_xuat_hop) && $result_xuat_hop != null){
                foreach ($result_xuat_hop as $key => $item) {
                    $where = array(
                        'DMVT_ID' => $record['DMVT_ID'],
                        'Hop_ID' => $item['Hop_ID'],
                        'Is_Delete' => '0'
                    );
                    $check_hop_vt = $this->Common_model->get_record($this->table_KHO_Hop_VT,$where);
                    if($check_hop_vt != null){
                        $arr = array(
                            'SoLuong' => ($check_hop_vt['SoLuong'] - $item['SoLuong'])
                        );
                        $this->Common_model->update($this->table_KHO_Hop_VT,$arr,$where);
                        $this->Common_model->update('KHO_Tra_Hop',array('Is_Delete' => 1),array("ID" => $item['ID']));
                    }
                }
            }

            $data['status'] = 'success';
        }
        else{
            $data['status'] = "fail";
            $data['message'] = "Lỗi không thể xóa được.";
        }
        die(json_encode($data));
    }

    public function export(){
        set_time_limit(0);
        $this->data['is_export'] = true;
        $sql = "SELECT tbl1.*,tbl3.Name AS DMVTName,tbl2.Name AS EmployeesName
                FROM {$this->table} AS tbl1 
                INNER JOIN {$this->table_employees} AS tbl2 ON tbl2.ID = tbl1.Employee_NVKho_ID
                INNER JOIN {$this->table_dmvt} AS tbl3 ON tbl3.ID = tbl1.DMVT_ID
                WHERE tbl1.Is_Delete = '0' 
                ORDER BY tbl1.ID DESC";
        $results = $this->Common_model->query_raw($sql);
        $title = 'Xuất kho';
        $header = array('Người Xuất','Danh mục vật tư','Số lượng','Ngày tháng');
        $data = array();
        if(isset($results) && $results != null){
            foreach ($results as $key => $item) {
                $data[] = array(
                    $item['EmployeesName'],
                    $item['DMVTName'],
                    $item['SoLuong'],
                    date($this->date_format,strtotime($item['Ngay']))
                );
            }
        }
        export_excel($title,$header,$data);
    }

    public function get_position($id = null){
        $record = $this->Common_model->get_record($this->table_dmvt,array("ID" => $id,'Is_Delete' => '0'));
        $data = array('status' => 'error');
        if($record == null){
            $data['status'] = "fail";
            $data['message'] = "Danh mục vật tự này không tồn tại.";
            die(json_encode($data));
        }
        $tra_id = $this->input->post('Tra_ID');
        $dvt = $this->Common_model->get_record('KHO_DVT',array("ID" => $record['DVT_ID'],'Is_Delete' => '0'));
        $this->data['dvt']  = $dvt;
        $this->data['dmvt'] = $record;


        $sql = "SELECT tbl1.*,tbl2.SoLuong AS SoLuongVT,tbl3.SoLuong AS SoLuongTra
                FROM {$this->table_gia} AS tbl1
                LEFT JOIN {$this->table_KHO_Gia_VT} AS tbl2 ON tbl2.Gia_ID = tbl1.ID AND tbl2.DMVT_ID = '{$id}' AND tbl2.Is_Delete != '1' 
                LEFT JOIN KHO_Tra_Gia AS tbl3 ON tbl3.Gia_ID = tbl1.ID AND tbl3.Tra_ID = '$tra_id'
                ORDER BY tbl2.SoLuong DESC,tbl1.Name ASC";
        $this->data['gia_result'] = $this->Common_model->query_raw($sql);

        $sql = "SELECT tbl1.*,tbl2.SoLuong AS SoLuongVT,tbl3.SoLuong AS SoLuongTra
                FROM {$this->table_hop} AS tbl1
                LEFT JOIN {$this->table_KHO_Hop_VT} AS tbl2 ON tbl2.Hop_ID = tbl1.ID AND tbl2.DMVT_ID = '{$id}' AND tbl2.Is_Delete != '1' 
                LEFT JOIN KHO_Tra_Hop AS tbl3 ON tbl3.Hop_ID = tbl1.ID AND tbl3.Tra_ID = '$tra_id'
                ORDER BY tbl2.SoLuong DESC,tbl1.Name ASC";
        $this->data['hop_result'] = $this->Common_model->query_raw($sql);

        $data['status'] = 'success';
        $data['response'] = $this->load->view($this->backend_asset."/".$this->folder_view."/get_position",$this->data,true);
        die(json_encode($data));
    }
}