<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Inventorymanagement_model extends CI_Model {
	private $_table = "Aka_Metarial";
    function __construct() {
        parent::__construct();
    }
    public function getall($offset = 0,$limit = 20,$where = null){
    	$this->db->select("*");
    	$this->db->from($this->_table. " AS tbl1");
    	if($where != null){
    		$this->db->where($where);
    	}
    	$this->db->limit($limit,$offset);
    	$query = $this->db->get()->result_array();
    	return $query;
    }
    public function countgetall ($where){
    	$this->db->select("*");
    	$this->db->from($this->_table. " AS tbl1");
    	if($where != null){
    		$this->db->where($where);
    	}
    	$query = $this->db->get();
    	return $query->num_rows();
    }
}
