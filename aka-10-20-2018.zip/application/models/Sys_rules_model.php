<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Sys_rules_model extends CI_Model {
	private $_table = "Aka_Sys_Rules";
    function __construct() {
        parent::__construct();
    }
    function get_data_role($id,$type = "0"){
    	$this->db->select("tbl1.*,tbl2.Is_Allow");
    	$this->db->from( "Aka_Sys_Modules  AS tbl1");
    	$this->db->join($this->_table." AS tbl2","tbl2.Module_ID = tbl1.ID AND tbl2.Role_ID = ".$id."","LEFT");
        $this->db->where("tbl1.Is_Sys",$type);
        $this->db->order_by("tbl1.Order","ASC");
        $query = $this->db->get();
        return $query->result_array();
    }
    function get_data_role_company($id,$type = "0"){
        $this->db->select("tbl1.*,tbl2.Is_Allow");
        $this->db->from( "Aka_Sys_Modules  AS tbl1");
        $this->db->join("Aka_Module AS tbl2","tbl2.Module_ID = tbl1.ID AND tbl2.Company_ID = ".$id."","LEFT");
        $this->db->where("tbl1.Is_Sys",$type);
        $this->db->where("tbl1.Common","0");
        $this->db->order_by("tbl1.Order","ASC");
        $query = $this->db->get();
        return $query->result_array();
    }
    function get_data_role_by($id,$onlysp = ['0','1']){
        $this->db->select("tbl1.*,tbl2.Is_Allow");
        $this->db->from( "Aka_Sys_Modules  AS tbl1");
        $this->db->join($this->_table." AS tbl2","tbl2.Module_ID = tbl1.ID AND tbl2.Role_ID = ".$id."","LEFT");
        //$this->db->where_in("tbl1.Only_Sp",$onlysp);
        $this->db->order_by("tbl1.Order","ASC");
        $query = $this->db->get();
        return $query->result_array();
    }

}
