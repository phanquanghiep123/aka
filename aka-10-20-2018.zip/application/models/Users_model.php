<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Users_model extends CI_Model {

	private $_table = "Aka_Sys_Users";

    function __construct() {
        parent::__construct();
    }

    public function get($where = null,$offset = null, $limit = null){
    	$this->db->select("tbl1.*,tbl5.Name,tbl2.Role_Title");
    	$this->db->from($this->_table . " AS tbl1");
        $this->db->join("M6_Employee AS tbl5","tbl5.ID = tbl1.Employee_ID","LEFT");
    	$this->db->join("Aka_Sys_Roles AS tbl2","tbl2.ID = tbl1.Role_ID","LEFT");
    	if ($where != null) {
            $this->db->where($where);
        }
        $this->db->order_by("tbl1.ID","DESC");
        if ($limit != null) { 
            $this->db->limit($limit, $offset);
        }
    	$query = $this->db->get();
        return $query->result_array();
    }

    public function count($where = null){
        $this->db->select("tbl1.*,tbl2.Role_Title");
        $this->db->from($this->_table . " AS tbl1");
        $this->db->join("Aka_Sys_Roles AS tbl2","tbl2.ID = tbl1.Role_ID","LEFT");
        if ($where != null) {
            $this->db->where($where);
        }
        $query = $this->db->get();
        return $query->num_rows();
    }
}
