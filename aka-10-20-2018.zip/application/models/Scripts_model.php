<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');
class Scripts_model extends CI_Model {
  private $_table = "M2_KichBan";
  function __construct() {
      parent::__construct();
  }
  function get_all(){
     $this->db->select("tbl1.*");
     $this->db->from($this->_table ." AS tbl1") ;
     $result = $this->db->get()->result_array();
     return $result;
  }
  function get_edit($id){
  	 $this->db->select("tbl1.*");
     $this->db->from($this->_table ." AS tbl1") ;
     $result = $this->db->get()->row_array();
     return $result;
  }
  function get_orders ($where = null, $offset = null, $limit = null, $order = null){
    $this->db->select("tbl1.*,tbl2.Name AS KichBan");
    $this->db->from("M2_UocTinhDG AS tbl1") ;
    $this->db->join($this->_table . " AS tbl2","tbl2.ID = tbl1.KichBan_ID");
    if ($where != null) {
      $this->db->where($where);
    }
    if ($limit != null) { 
      $this->db->limit($limit, $offset);
    }
    if ($order != null && is_array($order)) {
      foreach ($order as $key => $item) {
        if (isset($item) && !is_array($item)) {
          $this->db->order_by($key, $item);
        }
      }
    }
    $result = $this->db->get()->result_array();
    return $result;
  }
  function get_order ($id){
    $this->db->select("tbl1.*,tbl2.Name AS KichBan");
    $this->db->from("M2_UocTinhDG AS tbl1") ;
    $this->db->join($this->_table . " AS tbl2","tbl2.ID = tbl1.KichBan_ID");
    $this->db->where("tbl1.ID",$id);
    $result = $this->db->get()->row_array();
    return $result;
  }
  function get_orders_count ($where = null){
    $this->db->select("tbl1.*,tbl2.Name AS KichBan");
    $this->db->from("M2_UocTinhDG" ." AS tbl1") ;
    $this->db->join($this->_table . " AS tbl2","tbl2.ID = tbl1.KichBan_ID");
    if ($where != null) {
      $this->db->where($where);
    }
    $result = $this->db->get()->num_rows();
    return $result;
  }

  function get_productions ($where = null, $offset = null, $limit = null, $order_by = null){
    $this->db->select("tbl1.*,tbl2.Name AS KichBan");
    $this->db->from("M2_UocTinhDGSX AS tbl1") ;
    $this->db->join($this->_table . " AS tbl2","tbl2.ID = tbl1.KichBan_ID");
    if ($where != null) {
      $this->db->where($where);
    }
    if ($limit != null) { 
      $this->db->limit($limit, $offset);
    }
    if ($order_by != null && is_array($order_by)) {
      foreach ($order_by as $key => $item) {
        if (isset($item) && !is_array($item)) {
          $this->db->order_by($key, $item);
        }
      }
    }
    $result = $this->db->get()->result_array();
    return $result;
  }
  function get_production ($id){
    $this->db->select("tbl1.*,tbl2.Name AS KichBan");
    $this->db->from("M2_UocTinhDGSX AS tbl1") ;
    $this->db->join($this->_table . " AS tbl2","tbl2.ID = tbl1.KichBan_ID");
    $this->db->where("tbl1.ID",$id);
    $result = $this->db->get()->row_array();
    return $result;
  }
  function get_productions_count ($where = null){
    $this->db->select("tbl1.*,tbl2.Name AS KichBan");
    $this->db->from("M2_UocTinhDGSX" ." AS tbl1") ;
    $this->db->join($this->_table . " AS tbl2","tbl2.ID = tbl1.KichBan_ID");
    if ($where != null) {
      $this->db->where($where);
    }
    $result = $this->db->get()->num_rows();
    return $result;
  }
}
