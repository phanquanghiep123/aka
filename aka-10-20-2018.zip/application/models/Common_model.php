<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Common_model extends CI_Model {

    public $_CAT_PRODUCT = 9;
    public $_CAT_PROJECT = 192;
    public $_CAT_AREA = 215;
    public $_CAT_STYLE = 3;
    public $_CAT_COMPLIANCE = 263;

    function __construct() {
        parent::__construct();
    }

    function add($table, $data) {
        $this->db->trans_start();
        $this->db->set($data);
        $this->db->insert($table, $data);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        if($insert_id > 0){
            $user_info = $this->session->userdata('admin_info');
            $user_id = $user_info['ID'];
            $arr = array(
                'Table'     => $table,
                'Action'    => 'add',
                'Member_ID' => $user_id,
                'Table_ID'  => $insert_id,
                'Created_At'=> date('Y-m-d H:i:s')
            );
            $this->add_tracking($arr);
        }
        return $insert_id;
    }

    function delete($table, $where) {
        $return = false;
        $this->db->trans_start();
        $return = $this->db->delete($table, $where);
        $this->db->trans_complete();
        if($return && @$where['ID'] != null){
            $user_info = $this->session->userdata('admin_info');
            $user_id = $user_info['ID'];
            $arr = array(
                'Table'     => $table,
                'Action'    => 'delete',
                'Member_ID' => $user_id,
                'Table_ID'  => $where['ID'],
                'Created_At'=> date('Y-m-d H:i:s')
            );
            $this->add_tracking($arr);
        }
        return $return;
    }

    function update($table, $data, $where) {
        $return = false;
        $this->db->trans_start();
        $this->db->where($where);
        $return = $this->db->update($table, $data);
        $this->db->trans_complete();
        if($return && @$where['ID'] != null){
            $user_info = $this->session->userdata('admin_info');
            $user_id = $user_info['ID'];
            $action  = @$data['Is_Delete'] == 1 ? 'delete' : 'update';
            $arr = array(
                'Table'     => $table,
                'Action'    => $action,
                'Member_ID' => $user_id,
                'Table_ID'  => $where['ID'],
                'Created_At'=> date('Y-m-d H:i:s')
            );
            $this->add_tracking($arr);
        }
        return $return;
    }

    function add_tracking($data) {
        $this->db->trans_start();
        $this->db->set($data);
        $this->db->insert('Aka_Tracking', $data);
        $this->db->trans_complete();
    }

    function get_record($table, $where = "", $order = null) {
        $this->db->select('*');
        $this->db->from($table);
        if ($where != "") {
            $this->db->where($where);
        }
        if ($order != null && is_array($order)) {
            foreach ($order as $key => $item) {
                if (isset($item) && !is_array($item)) {
                    $this->db->order_by($key, $item);
                }
            }
        }
        return $this->db->get()->row_array();
    }

    function get_result($table, $where = null, $offset = null, $limit = null, $order = null) {
        $this->db->select('*');
        $this->db->from($table);
        if ($where != null) {
            $this->db->where($where);
        }

        if ($limit != null) { 
            $this->db->limit($limit, $offset);
        }
        if ($order != null && is_array($order)) {
            foreach ($order as $key => $item) {
                if (isset($item) && !is_array($item)) {
                    $this->db->order_by($key, $item);
                }
            }
        }
        return $this->db->get()->result_array();
    }

    function get_result_distinct($member_id, $type, $data,$columdate = "Created_At_profile") {
        $this->db->distinct();
        $this->db->from("common_view AS cv");
        if($type != "profile"){
            if($type == "blog"){
                $this->db->join("article AS a","a.id = cv.reference_id");
            }
            if($type == "photo"){
                $this->db->join("photos AS a","a.photo_id = cv.reference_id");
            }
        }
        
        $this->db->where(array("cv.member_owner" => $member_id, "cv.type_object" => $type, "cv.".$columdate." >=" => $data, "cv.member_id !=" => $member_id,"cv.member_id !="=> 0 ,"cv.type_share_view" => "view"));
       // $this->db->group_by(array("member_id", "ip"));
        return $this->db->get()->num_rows();
    }
    
    function get_result_in($table, $column, $in = array()) {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where_in($column, $in);
        return $this->db->get()->result_array();
    }
    function get_result_not_in($table, $column, $in = array()) {
        $this->db->select('*');
        $this->db->from($table);
        if($in)
         $this->db->where_not_in($column, $in);
        return $this->db->get()->result_array();
    }
    function insert_batch_data($table, $data) {
        $this->db->trans_start();
        $this->db->insert_batch($table, $data);
        $insert_id[] = $this->db->insert_id();
        $this->db->trans_complete();
        return $insert_id;
    }

    function count_table($table, $filter = array()) {
        $this->db->select('*');
        $this->db->from($table);
        if (count($filter)) {
            $this->db->where($filter);
        }
        $query = $this->db->get();
        return $query->num_rows();
    }

    function get_sort($group_id, $pid) {
        $filter = array("group_id" => $group_id, "pid" => $pid);
        $this->db->select('sort_id');
        $this->db->from("menu");
        $this->db->where($filter);
        $this->db->order_by("sort_id", "DESC");
        return $this->db->get()->row_array();
    }

    function get_search_category() {
        $all_category = $this->get_result("categories", array(
            "type" => "system"
        ));
        return $this->recursive_category($all_category, 0);
    }

    function query_raw($sql) {
        return $this->db->query($sql)->result_array();
    }

    function query_raw_row($sql) {
        return $this->db->query($sql)->row_array();
    }

    function query($sql) {
        $this->db->query($sql);
    }

    function slug($table, $colum, $like) {
        $this->db->select($colum);
        $this->db->from($table);
        $this->db->like($colum, $like);
        return $this->db->get()->result_array();
    }

    function get_use_rol($rol_id,$sys = 0 ,$type_member = 0){
        $this->db->select("sm.Icon,sm.Order,sm.ID,sm.Module_Name,sm.Module_Url,sm.Module_Class,sm.Module_Key,sm.Parent_ID");
        $this->db->from("Aka_Sys_Modules". " AS sm");
        $this->db->join("Aka_Sys_Rules AS r","r.Module_ID = sm.ID AND r.Role_ID = ".$rol_id."","LEFT");
        $this->db->where("r.Is_Allow","1");
        $this->db->where("sm.Only_Sp","0");
        $this->db->order_by("sm.Order","ASC");
        $query = $this->db->get();
        return $query->result_array();
    }
    function get_use_bycompany_rol($rol_id,$companyID = 0){
        $this->db->select("sm.Icon,sm.Order,sm.ID,sm.Module_Name,sm.Module_Url,sm.Module_Class,sm.Module_Key,sm.Parent_ID");
        $this->db->from("Aka_Sys_Modules". " AS sm");
        $this->db->join("Aka_Sys_Rules AS r","r.Module_ID = sm.ID AND r.Role_ID = ".$rol_id."");
        $this->db->join("Aka_Sys_Roles as asr","asr.ID = r.Role_ID");
        $this->db->join("Aka_Module AS cpm","cpm.Module_ID = sm.ID");
        $this->db->where("r.Allow","1");
        $this->db->where("cpm.Allow","1");
        $this->db->where("sm.Is_Sys",0);
        $this->db->where("sm.Common","0");
        $this->db->where("cpm.Company_ID",$companyID );
        $this->db->order_by("sm.Order","ASC");
        $this->db->group_by("sm.ID");
        $query = $this->db->get();
        return $query->result_array();
    }
    
}
