<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Counters_model extends CI_Model {
	private $_table = "Luminous_Counter";
    function __construct() {
        parent::__construct();
    }
    function get_result($table, $where = null, $offset = null, $limit = null, $order = null) {
        $this->db->select('tbl1.*,tbl2.Name AS Chuyenname,tbl2.ChuyenID,tbl2.Time_Display,tbl2.Notify_Content,tbl2.Plan,tbl2.Commodity_Code,tbl2.Is_Main');
        $this->db->from($table . " AS tbl1");
        $this->db->join("Luminous_Passing AS tbl2","tbl1.Passing_ID = tbl2.ID",'left');
        if ($where != null) {
            $this->db->where($where);
        }

        if ($limit != null) { 
            $this->db->limit($limit, $offset);
        }
        if ($order != null && is_array($order)) {
            foreach ($order as $key => $item) {
                if (isset($item) && !is_array($item)) {
                    $this->db->order_by($key, $item);
                }
            }
        }
        return $this->db->get()->result_array();
    }
    function count_table($table, $filter = array()) {
        $this->db->select('tbl1.ID');
        $this->db->from($table . " AS tbl1");
        $this->db->join("Luminous_Passing AS tbl2","tbl1.Passing_ID = tbl2.ID","LEFT");
        if (count($filter)) {
            $this->db->where($filter);
        }
        $query = $this->db->get();
        return $query->num_rows();
    }
    function get_record($table, $where = "", $order = null) {
        $this->db->select('tbl1.*,tbl2.Name AS Chuyenname,tbl2.ChuyenID,tbl2.Time_Display,tbl2.Notify_Content,tbl2.Plan,tbl2.Commodity_Code,tbl2.Is_Main');
        $this->db->from($table . " AS tbl1");
        $this->db->join("Luminous_Passing AS tbl2","tbl1.Passing_ID = tbl2.ID","LEFT");
        if ($where != "") {
            $this->db->where($where);
        }
        if ($order != null && is_array($order)) {
            foreach ($order as $key => $item) {
                if (isset($item) && !is_array($item)) {
                    $this->db->order_by($key, $item);
                }
            }
        }
        return $this->db->get()->row_array();
    }
}
