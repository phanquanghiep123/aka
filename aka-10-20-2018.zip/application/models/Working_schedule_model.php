<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Working_schedule_model extends CI_Model {
    private $_table      = "m6_working_schedule AS tbl1";
    private $_employee   = "M6_Employee";
    private $_time_slot  = "m6_time_slot AS tbl4";
    private $_working_slot  = "m6_working_slot AS tbl3";
    private $_department =  "M6_Department AS tbl2";
    function __construct() {
        parent::__construct();
    }
    function listTable($where = null,$offset = 0,$limit = 30,$order = null){
        $this->db->select("tbl2.*,GROUP_CONCAT(CONCAT(tbl1.Time_Slot_Working_ID, '-' ,tbl1.Is_Active)) AS Slot_Working_IDs");
        $this->db->from($this->_department);
        $this->db->join($this->_table ,"tbl1.Department_ID = tbl2.ID","LEFT");
        if($where) $this->db->where($where);
        if ($limit != null) { 
            $this->db->limit($limit, $offset);
        }
        if ($order != null && is_array($order)) {
            foreach ($order as $key => $item) {
                if (isset($item) && !is_array($item)) {
                    $this->db->order_by($key, $item);
                }
            }
        }
        $this->db->group_by(["tbl2.ID"]);
        $query = $this->db->get();
        return $query->result_array();
    } 
    function getAdd (){

    }
   

}
