<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');
class Implementations_model extends CI_Model {
  private $_table = "M3_KeHoach_ThucHien";
  function __construct() {
      parent::__construct();
  }
  function get_all(){
     $this->db->select("tbl1.*,tbl4.Name AS TenHang, tbl6.Name AS TenSize,tbl7.MaMau AS TenMau ,tbl2.Name AS TenChuyen");
     $this->db->from($this->_table ." AS tbl1") ;
     $this->db->join("M6_Department AS tbl2","tbl1.Chuyen_ID = tbl2.ID");
     $this->db->join("M2_ChiTietMaHang AS tbl3","tbl3.ID = tbl1.ChiTietMaHangID");
     $this->db->join("M2_MaHang AS tbl4","tbl4.ID = tbl3.MaHang_ID");
     $this->db->join("M2_DonHang AS tbl5","tbl5.ID = tbl4.DonHang_ID");
     $this->db->join("M2_Size AS tbl6","tbl6.ID = tbl3.Size_ID","LEFT");
     $this->db->join("M2_Color AS tbl7","tbl7.ID = tbl3.Color_ID","LEFT");
     $this->db->group_by("tbl1.ID");
     $result = $this->db->get()->result_array();
     return $result;
  }
  function get_edit($id){
  	 $this->db->select("tbl1.*,tbl4.Name AS TenMahang ,tbl2.Name AS TenChuyen");
     $this->db->from($this->_table ." AS tbl1") ;
     $this->db->join("M6_Department AS tbl2","tbl1.Chuyen_ID = tbl2.ID");
     $this->db->join("M2_ChiTietMaHang AS tbl3","tbl3.ID = tbl1.ChiTietMaHangID");
     $this->db->join("M2_MaHang AS tbl4","tbl4.ID = tbl3.MaHang_ID ");
     $this->db->join("M2_DonHang AS tbl5","tbl5.ID = tbl4.DonHang_ID");
     $this->db->where(["tbl1.ID" => $id]);
     $this->db->group_by("tbl1.ID");
     $result = $this->db->get()->row_array();
     return $result;
  }
  function get_order(){
     $this->db->select("tbl1.*,tbl2.Name AS TenMahang");
     $this->db->from("M2_ChiTietMaHang AS tbl1") ;
     $this->db->join("M2_MaHang AS tbl2","tbl2.ID = tbl1.MaHang_ID");
     $this->db->join("M2_DonHang AS tbl3","tbl3.ID = tbl2.DonHang_ID");
     $this->db->group_by("tbl2.ID");
     $result = $this->db->get()->result_array();
     return $result;
  }
}
