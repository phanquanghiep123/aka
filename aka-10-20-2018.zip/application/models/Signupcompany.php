<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Signupcompany extends MY_Controller {
    public function __construct() {
        parent::__construct();
    }
    public function index(){
        if($this->input->post()){
            $Companies = ($this->input->post("CompanyName"));
            $lisCompany = explode(",", @$Companies[0]);
            if(is_array($lisCompany)){
                $id = $this->user_info["ID"];
                foreach ($lisCompany as $key => $value) {
                    $item = array(
                        "Company_ID" => $value,
                        "User_ID" => $id 
                    );
                    $check = $this->Common_model->get_record("Aka_Sys_Company_Employee",$item);
                    if($check == null){
                        $this->Common_model->add("Aka_Sys_Company_Employee",$item);
                    } 
                }
            }

        }
        $this->load->view("backend/includes/header",$this->data);
        $this->load->view("backend/signupcompany/index",$this->data);
        $this->load->view("backend/includes/footer",$this->data);
    }
    public function details(){
        if($this->input->is_ajax_request()){
            $slug = $this->input->post("slug");
            if($slug){
                $this->db->select("ID AS id,CompanyName AS title");
                $this->db->from("Aka_Sys_Company");
                $this->db->like("CompanyName",$slug);
                $query = $this->db->get();
                die(json_encode($query->result_array()));
            }
        }
    }
    public function create(){
        $this->load->model("Companies_model");
        $result_array = $this->Companies_model->get_all_by_tag($this->user_info["ID"]);
        die(json_encode($result_array));
    }
}
