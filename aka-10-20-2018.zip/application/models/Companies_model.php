<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Companies_model extends CI_Model {
	private $_table = "Aka_Sys_Company";
    function __construct() {
        parent::__construct();
    }
    function get_all($where){
    	$this->db->select("tbl1.*,tbl2.User_Name");
    	$this->db->from( $this->_table. " AS tbl1");
    	$this->db->join("Aka_Sys_Users AS tbl2","tbl2.ID = tbl1.User_ID");
        $this->db->order_by("tbl1.ID","DESC");
        $this->db->where($where);
        $query = $this->db->get();
        return $query->result_array();
    }
    function get_all_by_tag($ID){
        $this->db->select("tbl1.ID as value,tbl1.CompanyName as text, tbl1.Created_At as continent");
        $this->db->from( $this->_table. " AS tbl1");
        $this->db->group_by("tbl1.ID");
        $query = $this->db->get();
        return $query->result_array();
    }

    //Co van de o day?
    function get_all_by_user($id){
        $this->db->select("tbl1.*,tbl2.Status,tbl2.Role_ID,tbl3.User_Name");
        $this->db->from( $this->_table. " AS tbl1");
        $this->db->join("Aka_Sys_Company_Employee AS tbl2","tbl2.Company_ID = tbl1.ID");
        $this->db->join("Aka_Sys_Users AS tbl3","tbl3.ID = tbl1.User_ID");
        $this->db->where("tbl2.User_ID",$id);
        $this->db->where("tbl1.User_ID != ",$id);
        $query = $this->db->get();
        return $query->result_array();
    }
    function get_all_by_user_active($id){
        $this->db->select("tbl1.*,tbl3.Role_Title,tbl2.Role_ID");
        $this->db->from( $this->_table. " AS tbl1");
        $this->db->join("Aka_Sys_Company_Employee AS tbl2","tbl2.Company_ID = tbl1.ID","LEFT");
        $this->db->join("Aka_Sys_Roles AS tbl3","tbl3.ID = tbl2.Role_ID AND tbl3.Company_ID = tbl2.Company_ID","LEFT");
        $this->db->where("tbl2.User_ID",$id);
        $this->db->where("tbl2.Status",1);
        $this->db->where("tbl1.Status",1);
        $this->db->group_by("tbl1.ID");
        $query = $this->db->get();
        return $query->result_array();
    }
    function get_model_onwer($companyID){
        $this->db->select("tbl1.*");
        $this->db->from("Aka_Sys_Modules AS tbl1");
        $this->db->join("Aka_Module AS tbl2","tbl1.ID = tbl2.Module_ID");
        $this->db->where(["tbl2.Company_ID" => $companyID , "tbl2.Status" => 1 ,"Allow" => 1]);
        $this->db->where("tbl1.Common","0");
        $this->db->order_by("tbl1.Order","ASC");
        $query = $this->db->get();
        return $query->result_array();
    }
    function get_all_member_by_company(){
        $this->db->select("tbl1.*,tbl1.Status AS StatusCp");
        $this->db->from("Aka_Sys_Users AS tbl1");
        $this->db->where("tbl1.Status >" , 0 );
        $this->db->order_by("tbl1.ID","DESC");
        $query = $this->db->get();
        return $query->result_array();
    }
    function get_all_membernew_by_company($companyID){
        $this->db->select("tbl1.*,tbl2.Status AS StatusCp");
        $this->db->from("Aka_Sys_Users AS tbl1");
        $this->db->join("Aka_Sys_Company_Employee AS tbl2","tbl1.ID = tbl2.User_ID");
        $this->db->where("tbl2.Company_ID",$companyID);
        $this->db->where("tbl2.Status" ,0);
        $this->db->where("tbl2.Verify" ,"1");
        $this->db->order_by("tbl1.ID","DESC");
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_all_Size_Materials_for_product($product_id){
        $this->db->select("tbl1.*,tbl3.Name AS Materials_Name");
        $this->db->from("Aka_Goods_Size_Materials AS tbl1");
        $this->db->join("Aka_Materials AS tbl3","tbl3.ID = tbl1.Materials_ID");
        $this->db->where("tbl1.Goods_ID",$product_id);
        $this->db->order_by("tbl1.ID","DESC");
        $this->db->group_by(["tbl1.Goods_ID","tbl1.Materials_ID"]);
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_size_by_product($material_id,$product_id){
        $this->db->select("tbl1.*,tbl2.Name AS Size_Name");
        $this->db->from("Aka_Goods_Size_Materials AS tbl1");
        $this->db->join("Aka_Size AS tbl2","tbl2.ID = tbl1.Size_ID");
        $this->db->where("tbl1.Materials_ID",$material_id);
        $this->db->where("tbl1.Goods_ID",$product_id);
        $query = $this->db->get();
        return $query->result_array();
    }
    
}
