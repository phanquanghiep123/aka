<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Metarial_model extends CI_Model {
	private $_table = "Aka_Metarial";
    function __construct() {
        parent::__construct();
    }
    public function getall($offset = 0,$limit = 20,$where = null){
    	$this->db->select("tbl1.ID,tbl1.Name,tbl1.Description,tbl1.Material_Type,tbl1.Qty_Minimum,tbl1.Warning_Amplitude,tbl1.Messenger_Warning,tbl1.Unit_Price,tbl1.Created_At,tbl1.Company_ID,tbl2.Name AS Unit");
    	$this->db->from($this->_table. " AS tbl1");
        $this->db->join("Aka_Unit AS tbl2","tbl2.ID = tbl1.Unit_ID","LEFT");
    	if($where != null){
    		$this->db->where($where);
    	}
    	$this->db->limit($limit,$offset);
        $this->db->order_by("tbl1.ID","DESC");
        $this->db->group_by("tbl1.ID");
    	$query = $this->db->get()->result_array();
    	return $query;
    }
    public function countgetall ($where){
    	$this->db->select("tbl1.ID");
    	$this->db->from($this->_table. " AS tbl1");
    	if($where != null){
    		$this->db->where($where);
    	}
    	$query = $this->db->get();
    	return $query->num_rows();
    }
    public function warehousing($offset = 0,$limit = 20,$where = null){
        $this->db->select("tbl1.*,tbl3.Name,tbl2.User_Name,tbl4.Name AS Member_Depot_Name,tbl5.Name AS Member_Supplier");
        $this->db->from("Aka_Warehousing AS tbl1");
        $this->db->join("Aka_Sys_Users AS tbl2","tbl2.ID = tbl1.Member_ID","LEFT");
        $this->db->join("Aka_Metarial AS tbl3","tbl3.ID = tbl1.Material_ID");
        $this->db->join("Aka_Members_Warehouse AS tbl4","tbl4.ID = tbl1.Member_ID_Depot","LEFT");
        $this->db->join("Aka_Member_Supplier AS tbl5","tbl5.ID = tbl1.Member_ID_Depot","LEFT");
        
        if($where != null){
            $this->db->where($where);
        }
        $this->db->group_by("tbl1.ID");
        $this->db->limit($limit,$offset);
        $this->db->order_by("tbl1.ID","DESC");
        $query = $this->db->get()->result_array();
        return $query;
    }
    public function countwarehousing ($where){
        $this->db->select("tbl1.ID");
        $this->db->from("Aka_Warehousing AS tbl1");
        $this->db->join("Aka_Sys_Users AS tbl2","tbl2.ID = tbl1.Member_ID");
        $this->db->join("Aka_Metarial AS tbl3","tbl3.ID = tbl1.Material_ID","LEFT");
        if($where != null){
            $this->db->where($where);
        }
        $query = $this->db->get();
        return $query->num_rows();
    }
    public function Inventorymanagement($offset = 0,$limit = 20,$where = null){
        $wherestring = "";
        $wherestring_2 = "";
        if(isset($where["timepicker_start"])){
            $wherestring .= " AND tbl2.Created_At >='".$where["timepicker_start"]."'";
            $wherestring_2 .= " AND tbl3.Created_At >='".$where["timepicker_start"]."'";
            unset($where["timepicker_start"]);
        }
        if(isset($where["timepicker_end"])){
            $wherestring .= " AND tbl2.Created_At <='".$where["timepicker_end"]."'";
            $wherestring_2 .= " AND tbl3.Created_At <='".$where["timepicker_end"]."'";
            unset($where["timepicker_end"]);
        }
        if(isset($where["member_id"])){
            $wherestring .= " AND tbl2.Member_ID ='".$where["member_id"]."'";
            $wherestring_2 .= " AND tbl3.Member_ID ='".$where["member_id"]."'";
            unset($where["member_id"]);
        }
        $this->db->select("tbl2.Name AS Unit ,tbl1.*,(SELECT sum(Qty) From Aka_Warehousing AS tbl2 WHERE tbl2.Material_ID = tbl1.ID AND tbl2.InOut = 0 ".$wherestring.") AS QtyIn ,
        (SELECT sum(Qty) From Aka_Warehousing AS tbl3 WHERE tbl3.Material_ID = tbl1.ID AND tbl3.InOut = 1 ".$wherestring_2.") AS QtyOut");
        $this->db->from("Aka_Metarial AS tbl1");
        $this->db->join("Aka_Unit AS tbl2","tbl2.ID = tbl1.Unit_ID");
        if($where != null){
            $this->db->where($where);
        }
        $this->db->group_by("tbl1.ID");
        $this->db->limit($limit,$offset);
        $this->db->order_by("tbl1.ID","DESC");
        $query = $this->db->get()->result_array();

        return $query;
    }
    public function CountInventorymanagement($where){
        $this->db->select("tbl1.ID");
        $this->db->from("Aka_Warehousing AS tbl1");
        $this->db->join("Aka_Metarial AS tbl2","tbl2.id = tbl1.Material_ID");

        if(isset($where["timepicker_start"])){
            $where["tbl1.Created_At >="] = $where["timepicker_start"];
            unset($where["timepicker_start"]);
        }
        if(isset($where["timepicker_end"])){
            $where["tbl1.Created_At <="] = $where["timepicker_end"];
            unset($where["timepicker_end"]);
        }
        if(isset($where["member_id"])){
            $where["tbl1.Member_ID"] = $where["member_id"];
            unset($where["member_id"]);
        }
        if($where != null){
            $this->db->where($where);
        }
        $query = $this->db->get();
        return $query->num_rows();
    }
    public function materials( $where = null){
    	$this->db->select("tbl1.*,tbl1.ID AS ID_Code");
    	$this->db->from($this->_table. " AS tbl1");
    	if($where != null){
    		$this->db->where($where);
    	}
        $this->db->order_by("tbl1.ID","DESC");
    	$query = $this->db->get()->result_array();
    	return $query;
    }
    public function enterunitmaterials( $where = null){
        $this->db->select("tbl1.*,tbl1.ID AS ID_Code");
        $this->db->from($this->_table. " AS tbl1");
        if($where != null){
            $this->db->where($where);
        }
        $this->db->order_by("tbl1.ID","DESC");
        $query = $this->db->get()->result_array();
        return $query;
    }
    
    public function depotin($where = null){
        $this->db->select("tbl1.*,tbl3.ID AS ID_Code,tbl3.Barcode,tbl3.Name,tbl2.User_Name AS Member,tbl4.User_Name AS Member_Depot");
        $this->db->from("Aka_Warehousing AS tbl1");
        $this->db->join("Aka_Sys_Users AS tbl2","tbl2.ID = tbl1.Member_ID");
        $this->db->join("Aka_Metarial AS tbl3","tbl3.ID = tbl1.Material_ID");
        $this->db->join("Aka_Sys_Users AS tbl4","tbl4.ID = tbl1.Member_ID_Depot","LEFT");
        if($where != null){
            $this->db->where($where);
        }
        $this->db->where("InOut",0);
        $this->db->order_by("tbl1.ID","DESC");
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function depotout($where = null){
        $this->db->select("tbl1.*,tbl3.ID AS ID_Code,tbl3.Name,tbl3.Barcode,tbl2.User_Name AS Member,tbl4.Name AS Member_Depot");
        $this->db->from("Aka_Warehousing AS tbl1");
        $this->db->join("Aka_Sys_Users AS tbl2","tbl2.ID = tbl1.Member_ID");
        $this->db->join("Aka_Metarial AS tbl3","tbl3.ID = tbl1.Material_ID");
        $this->db->join("Aka_Members_Warehouse AS tbl4","tbl4.ID = tbl1.Member_ID_Depot","LEFT");
        if($where != null){
            $this->db->where($where);
        }
        $this->db->where("InOut",1);
        $this->db->order_by("tbl1.ID","DESC");
        $query = $this->db->get()->result_array();
        return $query;
    }

    public function depot($where = null){
        $wherestring = "";
        $wherestring_2 = "";
        $company_id = @$where["tbl1.Company_ID"];
        if($company_id != null){
            $wherestring .= " AND tbl1.Company_ID >='".$company_id ."'";
            $wherestring_2 .= " AND tbl3.Company_ID >='".$company_id."'";
        }
        if(isset($where["timepicker_start"])){
            $wherestring .= " AND tbl2.Created_At >='".$where["timepicker_start"]."'";
            $wherestring_2 .= " AND tbl3.Created_At >='".$where["timepicker_start"]."'";
            unset($where["timepicker_start"]);
        }
        if(isset($where["timepicker_end"])){
            $wherestring .= " AND tbl2.Created_At <='".$where["timepicker_end"]."'";
            $wherestring_2 .= " AND tbl3.Created_At <='".$where["timepicker_end"]."'";
            unset($where["timepicker_end"]);
        }
        if(isset($where["member_id"])){
            $wherestring .= " AND tbl2.Member_ID ='".$where["member_id"]."'";
            $wherestring_2 .= " AND tbl3.Member_ID ='".$where["member_id"]."'";
            unset($where["member_id"]);
        }
        $this->db->select("tbl1.*,tbl1.ID AS ID_Code,(SELECT sum(Qty) From Aka_Warehousing AS tbl2 WHERE tbl2.Material_ID = tbl1.ID AND tbl2.InOut = 0 ".$wherestring.") AS Number_In ,
        (SELECT sum(Qty) From Aka_Warehousing AS tbl3 WHERE tbl3.Material_ID = tbl1.ID AND tbl3.InOut = 1 ". $wherestring_2.") AS Number_Out");
        $this->db->from("Aka_Metarial AS tbl1");
        if($where != null){
            $this->db->where($where);
        }
        $this->db->group_by("tbl1.ID");
        $this->db->order_by("tbl1.ID","DESC");
        $query = $this->db->get()->result_array();
        return $query;
    }
}
