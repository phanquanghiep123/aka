<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Attendance_model extends CI_Model {
    private $_table = "m6_attendance";
    private $_employee  = "M6_Employee";
    private $_time_slot  = "m6_time_slot";
    function __construct() {
        parent::__construct();
    }
    function listData($Department_ID,$where,$name = null){
        $this->db->select("tbl1.ID,tbl1.Name,tbl2.WorkingDate,tbl1.Department_ID,tbl2.Time_Slot_ID,tbl3.name AS Time_Slot_Name,tbl3.symbol,tbl2.Is_Absent");
        $this->db->from($this->_employee ." AS tbl1");
        $and = "";
        if($where){
            foreach ($where as $key => $value) {
                $and[] = $key . "=" . $value;
            }
        }
        $stringAND = implode(" AND ", $and);
        if($stringAND) $stringAND = " AND " . $stringAND;
        $this->db->join($this->_table ." AS tbl2","tbl2.Employee_ID = tbl1.ID ".$stringAND."" , "LEFT");
        $this->db->join($this->_time_slot ." AS tbl3","tbl2.Time_Slot_ID = tbl3.ID" , "LEFT");
        if(trim($name))
        $this->db->like("tbl1.Name",$name);
        $this->db->where("tbl1.Department_ID",$Department_ID);
       // $this->db->group_by("tbl2.ID");
        $query = $this->db->get();
        return $query->result_array();
    }
    function row($id,$type = "0"){
         
    }
    function by_user($id,$Department_ID,$date){
        $this->db->select("tbl2.*,tbl3.symbol,tbl3.name AS Time_Slot_Name,tbl2.Is_Absent");
        $this->db->from($this->_employee ." AS tbl1");
        $this->db->join($this->_table ." AS tbl2","tbl2.Employee_ID = tbl1.ID" , "LEFT");
        $this->db->join($this->_time_slot ." AS tbl3","tbl2.Time_Slot_ID = tbl3.ID" , "LEFT");
        $this->db->where(
            [
                "tbl1.Department_ID" => $Department_ID,
                "tbl1.ID"   => $id,
                "tbl2.WorkingDate"   => $date
            ]
        );
        $query = $this->db->get();
        return $query->result_array();
    }
    function working_schedule ($inIDs = null ,$notInID = null){
        $this->db->select('*,m6_time_slot.Name AS Time_Slot_Name');
        $this->db->from($this->_time_slot);
        if($inIDs)
            $this->db->where_in("working_slot_ID", $inIDs);
        if($notInID)
            $this->db->where_not_in("ID", $notInID);
        return $this->db->get()->result_array();
    }

}
