<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-12">
						<h2><?php echo @$title_page; ?> </h2>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
				    <form action="" method="post">
				    	<div class="row">
				    		<div class="col-sm-3">
								<div class="form-group"> 
									<select class="form-control" name="MaHang_ID" required="required">
										<option value="">Chọn Mã hàng *</option>
										<?php if(isset($plu_result) && $plu_result != null): ?>
											<?php foreach ($plu_result as $key => $item): ?>
												<option <?php echo $item['ID'] == @$record['MaHang_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
											<?php endforeach; ?>
										<?php endif; ?>
									</select>
								</div>
							</div>
							<div class="col-sm-3"></div>
							<div class="col-sm-6">
								<div class="text-right">
									<a href="<?php echo backend_url($folder_view);?>" class="btn btn-default">Hủy bỏ</a>
									<button type="submit" class="btn btn-primary">Lưu dữ liệu</button>
								</div>
							</div>
				    	</div>
				    	<div class="table-responsive table-add-more">
				    		<table class="table table-striped jambo_table bulk_action not-datatable">
								<thead>
									<tr class="headings">
										<th>#</th>
										<th>Loại hình</th>
										<th>Đơn giá</th>
									</tr>
								</thead>
							</table>
				    	</div>
				    </form>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change','select[name="MaHang_ID"]',function(){
			var val = $(this).val();
			var url = '<?php echo backend_url($folder_view."/load_table/"); ?>' + val;
            $.ajax({
                type: 'POST',
                dataType:'html',
                url: url,
                data:{},
                success: function(html) {
                	$('.table-add-more').html(html);
                }
            });
			return false;
		});
	});
</script>
<style type="text/css">
	.calendar-table table tr th {color: #000;}
	.border-error{border:1px solid #ff0000 !important;}
</style>