<table class="table table-striped jambo_table bulk_action not-datatable">
	<thead>
		<tr class="headings">
			<th>#</th>
			<th>Loại hình</th>
			<th>Đơn giá</th>
		</tr>
	</thead>
	<tbody>
	    <?php if(isset($type_result) && $type_result != null): ?>
	        <?php foreach ($type_result as $key => $item): ?>
	    		<tr style="background-color: #fff;">
					<td><?php echo ($key+1); ?></td>
					<td><?php echo $item['TypeName']; ?></td>
					<td>
						<div class="form-group" style="max-width: 300px;">
							<input type="text" class="form-control format-number" placeholder="Đơn giá" name="dongia[<?php echo $item['TypeID']; ?>]">
						</div>
					</td>
				</tr>
		    <?php endforeach; ?>
	    <?php endif; ?>
	</tbody>
</table>