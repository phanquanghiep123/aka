<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="form-group"> 
		<label class="control-label">Chuyền ID <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["ChuyenID"]; ?>" name="ChuyenID" type="text" placeholder="Vui lòng nhập chuyền ID là duy nhất" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Tên chuyền <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" placeholder="Vui lòng nhập Tiêu đề" required="required">
	</div>
	<div class="form-group" style="display:none"> 
		<label class="control-label">Thời gian hiển thị</label>
		<input class="form-control" value="<?php echo @$record["Time_Display"]; ?>" name="Time_Display" type="number" min="0"  placeholder="Vui lòng nhập Thời gian hiển thị">
	</div>
	<div class="form-group"> 
		<label class="control-label">Thông báo</label>
		<textarea class="form-control" name="Notify_Content" placeholder="Vui lòng nhập Nội dung hiển thị" rows="5"><?php echo @$record["Notify_Content"]; ?></textarea>
	</div>
	<div class="form-group"> 
		<label class="control-label">Kế hoạch <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Plan"]; ?>" placeholder="Vui lòng nhập Kế hoạch" name="Plan" type="number" min="0" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Mã hàng hóa</label>
		<input class="form-control" value="<?php echo @$record["Commodity_Code"]; ?>"  placeholder="Vui lòng nhập Code" name="Commodity_Code" type="text">
	</div>
<!-- Them moi 2 cot
 -->	
 <div class="form-group"> 
		<label class="control-label">Tổng đơn hàng</label>
		<input class="form-control" value="<?php echo @$record["TongDonHang"]; ?>"  placeholder="Vui lòng nhập Code" name="TongDonHang" type="text">
	</div>
		<div class="form-group"> 
		<label class="control-label">Lũy kế</label>
		<input class="form-control" value="<?php echo @$record["LuyKe"]; ?>"  placeholder="Vui lòng nhập Code" name="LuyKe" type="text">
	</div>
			<div class="form-group"> 
		<label class="control-label">Khách hàng</label>
		<input class="form-control" value="<?php echo @$record["KhachHang"]; ?>"  placeholder="Vui lòng nhập Code" name="KhachHang" type="text">
	</div>
<!-- Them moi 2 cot
 -->

	<div class="form-group"> 
		<label class="control-label">Trạng thái <span class="required">*</span></label>
		<select class="form-control" name="Status">
			<option value="1">Hoạt động</option>
			<option value="0" <?php echo @$record["Status"] != null && @$record["Status"] == 0 ? 'selected' : ''; ?>>Ngưng hoạt động</option>
		</select>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>