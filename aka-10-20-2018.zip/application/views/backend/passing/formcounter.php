<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="form-group"> 
		<label class="control-label">Chuyền <span class="required">*</span></label>
		<select class="form-control" name="Passing_ID">
			<?php if(@$passings):?>
			<?php foreach ($passings as $key => $value) {
				echo '<option value="'.$value["ID"].'">'.$value["Name"].'</option>';
			}?>
			<?php endif;?>
		</select>
	</div>
	<div class="form-group"> 
		<label class="control-label">Counter ID <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Counter_ID"]; ?>" name="Counter_ID" type="text" placeholder="Vui lòng nhập Bộ đếm ID là duy nhất" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Trạng thái <span class="required">*</span></label>
		<select class="form-control" name="Type">
		<?php
			if(@$record["Type"]=='2'){?>
				<option value="1" >Hoàn thành</option>
				<option value="2" selected>Thoát chuyền</option>
				<option value="3">Cụm</option>
		<?php 
			}else if(@$record["Type"]=='1'){ ?>
				<option value="1" selected>Hoàn thành</option>
				<option value="2">Thoát chuyền</option>
				<option value="3">Cụm</option>
		<?php	
			}else { ?>
			<option value="1" >Hoàn thành</option>
				<option value="2">Thoát chuyền</option>
				<option value="3" selected>Cụm</option>
		<?php 	}
		?>
		</select>
	</div>
	<div class="form-group" style="display:none;"> 
		<label class="control-label">Trạng thái<span class="required">*</span></label>
		<select class="form-control" name="Status">
			<option value="1">Hoạt động</option>
		</select>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>