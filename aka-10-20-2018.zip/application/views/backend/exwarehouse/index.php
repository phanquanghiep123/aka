<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="box-common-edit-add relative" style="display: none;">
			<a class="collapse-link-custom" href="#" style="color: #ff0000;"><i class="fa fa-times" aria-hidden="true"></i></a>
			<div class="form-slider" style="max-width: 600px;margin:0 auto;"></div>
		</div>
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-6">
						<h2>
							<?php echo @$title_page; ?> 
							<a class="btn btn-success create-item is_ajax" href="<?php echo backend_url($folder_view."/add");?>"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Thêm mới</a>
							<a class="btn btn-success" href="<?php echo backend_url($folder_view."/export");?>"><i class="fa fa-download" aria-hidden="true"></i> Xuất Excel</a>
						</h2>
					</div>
					<div class="col-sm-6">
						<form method="" method="get">
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<select class="form-control" name="Employees">
											<option value="">Công nhân</option>
											<?php if(isset($employees_result) && $employees_result != null): ?>
												<?php foreach ($employees_result as $key => $item): ?>
													<option <?php echo $item['ID'] == $this->input->get('Employees') ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
												<?php endforeach; ?>
											<?php endif; ?>
										</select>
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<select class="form-control" name="DMVT">
											<option value="">Danh mục vật tư</option>
											<?php if(isset($dmvt_result) && $dmvt_result != null): ?>
												<?php foreach ($dmvt_result as $key => $item): ?>
													<option <?php echo $item['ID'] ==  $this->input->get('DMVT') ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
												<?php endforeach; ?>
											<?php endif; ?>
										</select>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="form-group">
										<button type="submit" class="btn btn-primary">Tìm kiếm</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
					<table class="table table-striped jambo_table bulk_action">
						<thead>
							<tr class="headings">
								<th>Stt </th>
								<th>Công nhân</th>
								<th>Danh mục vật tư</th>
								<th>Số lượng</th>
								<th>Ngày</th>
								<th>Hành động</th>
							</tr>
						</thead>
						<tbody>
						    <?php if(isset($results) && $results != null): ?>
						        <?php foreach ($results as $key => $value): ?>
						    		<tr data-id="<?php echo $value['ID']; ?>">
										<td data-column="Stt"><?php echo $key+1;?></td>
										<td data-column="EmployeesName"><?php echo $value["EmployeesName"]; ?></td>
										<td data-column="DMVTName"><?php echo $value["DMVTName"]; ?></td>
										<td data-column="SoLuong"><?php echo $value["SoLuong"]; ?></td>
										<td data-column="Ngay"><?php echo date($date_format,strtotime($value["Ngay"])); ?></td>
										<td data-column="Action">
											<a class="is_ajax" title="Chỉnh sửa" href="<?php echo backend_url($folder_view."/edit/".$value["ID"])?>"><i class="fa fa-edit" aria-hidden="true"></i></a>
											<?php if($admin_info['Employee_ID'] == 0 || $value['Employee_NVKho_ID'] == $admin_info['Employee_ID']): ?>
												 | <a class="is_ajax_delete" title="Xóa" href="<?php echo backend_url($folder_view.'/delete/'.$value["ID"])?>"><i class="fa fa-trash" aria-hidden="true"></i></a> 
											<?php endif; ?>
										</td>
									</tr>
							    <?php endforeach; ?>
						    <?php endif; ?>
						</tbody>
					</table>
				</div>
				<?php if(isset($this->pagination)): ?>
					<div class="row">
						<div class="col-sm-12 text-center">
							<?php echo @$this->pagination->create_links();?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('click','a.is_ajax',function(){
			$(".box-common-edit-add .message").hide();
			var url = $(this).attr('href');
            $.ajax({
                type: 'POST',
                dataType:'html',
                url: url,
                data:{},
                success: function(html) {
                	if(html != -1){
                    	$(".box-common-edit-add .form-slider").html(html);
                    	$(".box-common-edit-add").slideDown();
                    	$("body,html").animate({scrollTop:0}, 'slow');
                    	$(".box-common-edit-add .form_datetime").each(function(){
							$(this).datetimepicker({
						        format: 'Y/m/d',
						        timepicker: false,
						        autoclose: true,
						        todayBtn: true
						    });
						});
                	}
                    else{
                    	alert('Xuất hàng này không tồn tại.');
                    }
                }
            });
			return false;
		});

		$(document).on('click','a.is_ajax_delete',function(){
			if(confirm('Bạn thật sự muốn xóa?')){
				var current = $(this);
				var url = $(this).attr('href');
	            $.ajax({
	                type: 'POST',
	                dataType:'json',
	                url: url,
	                data:{},
	                success: function(data) {
	                	if(data['status'] == 'success'){
	                		current.parents('tr').remove();
	                		$('tr td[data-column="Stt"]').each(function(i){
	                    		$(this).html(i+1);
	                    	});
	                	}
	                }
	            });
            }
			return false;
		});

		$(document).on('submit','.box-common-edit-add form',function(){
			var current = $(this);
			$(".box-common-edit-add .message").hide();
			var options = {
                dataType:'json',
                success: function(data){
                    if(data['status'] == 'success'){
                    	var fields = ["EmployeesName","DMVTName","SoLuong","Ngay"];
                        if(data['action'] == 'add'){
                        	var html = '<tr data-id="' + data['responsive']['ID'] + '">';
                        		html += '	<td data-column="Stt"></td>';
                        		fields.forEach(function(element) {
								  	html += '<td data-column="' + element + '">' + data['responsive'][element] + '</td>';
								});
                        		html += '	<td data-column="Action">';
                        		html += '		<a class="is_ajax" href="<?php echo backend_url($folder_view."/edit/"); ?>' + data['responsive']['ID'] + '"><i class="fa fa-edit" aria-hidden="true"></i></a> | ';
								html += '		<a class="is_ajax_delete" href="<?php echo backend_url($folder_view.'/delete/'); ?>' + data['responsive']['ID'] + '"><i class="fa fa-trash" aria-hidden="true"></i></a>';
                        		html += '	</td>';
                        		html += '</tr>';
                        	$('.x_content table').prepend(html);

                        	$('tr td[data-column="Stt"]').each(function(i){
                        		$(this).html(i+1);
                        	});
                        }
                        else{
                        	fields.forEach(function(element) {
							  	$('tr[data-id="' + data['responsive']['ID'] + '"] td[data-column="' + element + '"]').html(data['responsive'][element]);
							});
                        }
                        $(".box-common-edit-add").slideUp();
                    }
                    else if(data['status'] == 'fail'){
                    	$(".box-common-edit-add .alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.ajaxSubmit(options);
			return false;
		});

		$(document).on('change', '.form-slider select[name="DMVT_ID"]', function() {
			var barcode = $(this).find(":selected").attr('data-barcode');
			if (typeof barcode !== typeof undefined && barcode !== false) {
			    $('.form-slider .barcode-mdvt').val(barcode);
			}
			else{
				$('.form-slider .barcode-mdvt').val('');
			}
		});

		$(window).load(function(){
			$('a.create-item').trigger('click');
		});

		$(document).on('change', '.form-slider .barcode-mdvt', function() {
			var barcode = $(this).val().toString();
			var val = '';
			$('.form-slider select[name="DMVT_ID"] option').each(function(){
			    var data_barcode = $(this).attr('data-barcode');
				if (typeof data_barcode !== typeof undefined && data_barcode !== false && barcode == data_barcode) {
					val = $(this).attr('value');
				}
			});
			$('.form-slider select[name="DMVT_ID"]').val(val).trigger("change");
		});

		$(document).on('change', '.form-slider select[name="Employee_CongNhan_ID"]', function() {
			var barcode = $(this).find(":selected").attr('data-barcode');
			if (typeof barcode !== typeof undefined && barcode !== false) {
			    $('.form-slider .barcode-employee').val(barcode);
			}
			else{
				$('.form-slider .barcode-employee').val('');
			}
		});

		$(document).on('change', '.form-slider .barcode-employee', function() {
			var barcode = $(this).val().toString();
			var val = '';
			$('.form-slider select[name="Employee_CongNhan_ID"] option').each(function(){
			    var data_barcode = $(this).attr('data-barcode');
				if (typeof data_barcode !== typeof undefined && data_barcode !== false && barcode == data_barcode) {
					val = $(this).attr('value');
				}
			});
			$('.form-slider select[name="Employee_CongNhan_ID"]').val(val).trigger("change");
		});

		$('.collapse-link-custom').click(function(){
			$(".box-common-edit-add").slideUp();
			return false;
		});
	});
</script>