<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Ngày tháng <span class="required">*</span></label>
				<input class="form-control form_datetime" value="<?php echo @$record["Ngay"] != null ? date('Y/m/d',strtotime(@$record["Ngay"])) : ''; ?>" name="Ngay" type="text" required="required">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Số lượng <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["SoLuong"]; ?>" name="SoLuong" type="number" min="0" required="required">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Danh mục vật tư <span class="required">*</span></label>
				<select class="form-control" name="DMVT_ID" required="required">
					<option value="">Chọn</option>
					<?php if(isset($dmvt_result) && $dmvt_result != null): ?>
						<?php foreach ($dmvt_result as $key => $item): ?>
							<option <?php echo $item['ID'] == @$record['DMVT_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Người xuất <span class="required">*</span></label>
				<select class="form-control" name="Employees_ID" required="required">
					<option value="">Chọn</option>
					<?php if(isset($employees_result) && $employees_result != null): ?>
						<?php foreach ($employees_result as $key => $item): ?>
							<option <?php echo $item['ID'] == @$record['Employees_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
		</div>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>