<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-5">
						<h2><?php echo @$title_page; ?> </h2>
					</div>
					<div class="col-sm-7">
						<form method="" method="get">
							<div class="row">
								<div class="col-sm-3">
									<div class="form-group">
										<input type="text" class="form-control" placeholder="Tên vật tư" name="keyword" value="<?php echo $this->input->get('keyword'); ?>">
									</div>
								</div>
								<div class="col-sm-3">
									<div class="form-group"> 
										<input class="form-control" placeholder="Khoảng thời gian"  name="daterange" value="<?php echo $this->input->get('daterange'); ?>" type="text">
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<select class="form-control" name="type">
											<option value="1">Tính theo đơn giá nhập kho trung bình</option>
											<option value="2" <?php echo $this->input->get('type') == 2 ? 'selected' : ''; ?>>Tính theo đơn giá mới nhất</option>
											<option value="3" <?php echo $this->input->get('type') == 3 ? 'selected' : ''; ?>>Tính theo đơn giá nhập kho thực tế</option>
										</select>
									</div>
								</div>
								<div class="col-sm-2">
									<div class="form-group">
										<button type="submit" class="btn btn-primary">Tìm kiếm</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="x_content">
			    <?php $this->load->view($backend_asset."/includes/message");?>
		    	<div class="table-responsive" style="overflow-x: auto !important;min-height: auto;">
			    	<table class="table table-striped jambo_table bulk_action not-datatable">
						<thead>
							<tr class="headings">
								<th>#</th>
								<th>Barcode</th>
								<th>Tên vật tư</th>
								<th>Đơn vị tính</th>
								<th>Đơn giá</th>
								<th>Tồn kho</th>
								<th>Số lượng nhập</th>
								<th>Thành tiền</th>
								<th>Số lượng xuất</th>
								<th>Thành tiền</th>
							</tr>
						</thead>
						<tbody>
							<?php if(isset($results) && $results != null): ?>
								<?php foreach ($results as $key => $item): ?>
									<tr>
										<td><?php echo $key+1; ?></td>
										<td><?php echo $item['Barcode']; ?></th>
										<td><?php echo $item['Name']; ?></th>
										<td><?php echo $item['DVTName']; ?></th>
										<td><?php echo number_format($item['AVG_Price']); ?> VNĐ</th>
										<td><?php echo @$item['TotalTon'] != null ? number_format($item['TotalTon']) : '0'; ?></th>
										<td><?php echo @$item['TotalNhap'] != null ? number_format($item['TotalNhap']) : '0'; ?></th>
										<td><?php echo @$item['TotalNhap'] != null ? number_format($item['TotalNhap']*$item['AVG_Price']) : '0'; ?> VNĐ</th>	
										<td><?php echo @$item['TotalXuat'] != null ? number_format($item['TotalXuat']) : '0'; ?></td>
										<td><?php echo @$item['TotalXuat'] != null ? number_format($item['TotalXuat']*$item['AVG_Price']) : '0'; ?> VNĐ</th>
									</tr>
								<?php endforeach; ?>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
				<?php if(isset($this->pagination)): ?>
					<div class="row">
						<div class="col-sm-12 text-center">
							<?php echo @$this->pagination->create_links();?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$('input[name="daterange"]').daterangepicker({
            opens: 'left',
            locale: {
                format: 'YYYY/MM/DD'
            }
        });
	});
</script>