<table class="table table-striped jambo_table bulk_action not-datatable">
	<thead>
		<tr class="headings">
			<th>#</th>
			<th style="min-width: 150px;">Mã hàng</th>
			<th style="min-width: 100px;">Số lượng</th>
			<th style="min-width: 100px;">SL đã lên kế hoạch</th>
			<?php for($i = 0; $i < $numberDays; $i++): ?>
				<th class="text-center" style="min-width:80px;"><?php echo date('d/m',strtotime("+".$i." day", strtotime($current_date))); ?></th>
			<?php endfor; ?>
		</tr>
	</thead>
	<tbody>
		<?php if(isset($results) && $results != null): ?>
			<?php foreach ($results as $key => $item): ?>
				<tr>
					<td><?php echo $key+1; ?></td>
					<td><?php echo $item['Name']; ?></th>
					<td><?php echo @$item["TongSoLuong"]; ?></td>
					<td><?php echo @$item['total']['Total'] != null ? $item['total']['Total'] : '0'; ?></td>
					<?php for($i = 0; $i < $numberDays; $i++): ?>
						<?php $next_date = date('Y-m-d',strtotime("+".$i." day", strtotime($current_date))); ?>
						<?php
							$sl = '';
							if(isset($item['kehoachchung']) && $item['kehoachchung'] != null){
								foreach ($item['kehoachchung'] as $key1 => $item1) {
									if($next_date == date('Y-m-d',strtotime($item1['Ngay']))){
										$sl = $item1['SoLuong'];
										break;
									}
								}
							}
						?>
						<?php if($next_date >= date('Y-m-d',strtotime($item["StartDate"])) && $next_date <= date('Y-m-d',strtotime($item["EndDate"])) ): ?>
							<td>
								<input type="text" class="format-number form-control"  value="<?php echo $sl; ?>" placeholder="SL" name="soluong[<?php echo $item['ID']; ?>][]" style="background-color: #FFEB3C;">
								<input type="hidden" value="<?php echo $next_date; ?>"  name="date[<?php echo $item['ID']; ?>][]">
							</td>
						<?php else: ?>
							<td>
								<input type="text" class="format-number form-control"  value="<?php echo $sl; ?>" placeholder="SL" name="soluong[<?php echo $item['ID']; ?>][]">
								<input type="hidden" value="<?php echo $next_date; ?>"  name="date[<?php echo $item['ID']; ?>][]">
							</td>
						<?php endif; ?>
					<?php endfor; ?>
				</tr>
			<?php endforeach; ?>
		<?php endif; ?>
	</tbody>
</table>