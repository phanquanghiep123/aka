<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-12">
						<h2><?php echo @$title_page; ?> </h2>
					</div>
				</div>
			</div>
			<div class="x_content">
			    <?php $this->load->view($backend_asset."/includes/message");?>
			    <form action="<?php echo backend_url($folder_view.'/index/'.strtotime($current_date)); ?>" method="post">
			    	<div class="row">
			    		<div class="col-xs-6 col-sm-3">
			    			<select class="form-control" name="loaihinh" required>
			    				<option value="">Loại hình</option>
			    				<?php if(isset($loaihinh) && $loaihinh != null): ?>
			    					<?php foreach ($loaihinh as $key => $item): ?>
			    						<option value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
			    					<?php endforeach; ?>
			    				<?php endif; ?>
			    			</select>
			    		</div>
			    		<div class="col-xs-6 col-sm-9">
			    			<div class="text-right">
					    		<button type="submit" class="btn btn-primary">Lưu dữ liệu</button>
					    	</div>
			    		</div>
			    	</div>
			    	<div class="table-responsive table-add-more" style="overflow-x: auto !important;min-height: auto;margin-top: 20px;">
				    	
					</div>
			    </form>
			    <div style="height: 15px;"></div>
			    <div class="row">
			    	<div class="col-xs-6">
			    		<p><a href="<?php echo backend_url($folder_view.'/index/'.strtotime("-7 day",strtotime($current_date))); ?>"><i class="fa fa-angle-double-left" aria-hidden="true"></i> Sau</a></p>
			    	</div>
			    	<div class="col-xs-6">
			    		<p class="text-right"><a href="<?php echo backend_url($folder_view.'/index/'.strtotime("+7 day",strtotime($current_date))); ?>">Trước <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></p>
			    	</div>
			    </div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change','select[name="loaihinh"]',function(){
			var val = $('select[name="loaihinh"]').val();
			load_table(val);
		});

		function load_table(val){
			if(val != null && val != ''){
				var url = '<?php echo backend_url($folder_view."/load_table/".strtotime($current_date)); ?>';
	            $.ajax({
	                type: 'POST',
	                dataType:'html',
	                url: url,
	                data:{'loaihinh':val},
	                success: function(html) {
	                	$('.table-add-more').html(html);
	                }
	            });
			}
			else{
				$('.table-add-more').html('');
			}
			return false;
		}

		<?php if($this->input->get('loaihinh')): ?>
			load_table('<?php echo $this->input->get('loaihinh'); ?>');
		<?php endif; ?>
	});
</script>
<style type="text/css">
	.calendar-table table tr th {color: #000;}
	.border-error{border:1px solid #ff0000 !important;}
</style>