<div class="main-page <?php echo @$main_page;?>">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<h2>Quản Lý Chức Năng Hệ Thống <a class="btn btn-success create-item" href="<?php echo backend_url("sysmodules/create");?>"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Thêm mới</a></h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
				<form method="post">
					<div class="table-responsive">
					    <?php $this->load->view("backend/includes/messenger");?>
						<table class="table table-striped jambo_table bulk_action">
							<thead>
								<tr class="headings">
									<th class="column-title">Stt </th>
									<th class="column-title">Tên hệ thống </th>
									<th class="column-title">Đường dẫn </th>
									<th class="column-title">Vị trí </th>
									<th class="column-title">Trạng thái </th>
									<th class="column-title no-link last"><span class="nobr">Hành động</span> </th>
								</tr>
							</thead>
							<tbody>
							   <?php echo (isset($html_modules)) ? $html_modules : "";?>
							</tbody>
						</table>
					</div>
					<div class="text-right"><button id="send" type="submit" class="btn btn-success">Cập nhật vị trí</button></div>
				</form>
			</div>
		</div>
	</div>
</div>