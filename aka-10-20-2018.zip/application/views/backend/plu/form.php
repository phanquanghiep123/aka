<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tên mã hàng <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["Name"] ; ?>" name="Name" type="text" required="required">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Đơn hàng <span class="required">*</span></label>
				<select class="form-control" name="DonHang_ID" required="">
					<option value="">Chọn</option>
					<?php if(isset($order_result) && $order_result != null): ?>
						<?php foreach ($order_result as $key => $item): ?>
							<option data-start-date="<?php echo @$item["StartDate"] != null ? date('Y/m/d',strtotime($item["StartDate"])) : ''; ?>" data-end-date="<?php echo @$item["EndDate"] != null ? date('Y/m/d',strtotime($item["EndDate"])) : ''; ?>" <?php echo $item['ID'] == @$record["DonHang_ID"] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['MaDonHang']; ?></option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
		</div>
	</div>
	<div class="row">
		<!--<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Ngày bắt đầu <span class="required">*</span></label>
				<input class="form-control form_datetime startdate" value="<?php echo @$record["StartDate"] != null ? date('Y/m/d',strtotime($record["StartDate"])) : ''; ?>" name="StartDate" type="text" required="required">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Ngày kết thúc <span class="required">*</span></label>
				<input class="form-control form_datetime enddate" value="<?php echo @$record["EndDate"] != null ? date('Y/m/d',strtotime($record["EndDate"])) : ''; ?>" name="EndDate" type="text" required="required">
			</div>
		</div>-->
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Ngày bắt đầu - ngày kết thúc <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["StartDate"] != null ? date('Y/m/d',strtotime($record["StartDate"])).' - ' : ''; ?> <?php echo @$record["EndDate"] != null ? date('Y/m/d',strtotime($record["EndDate"])) : ''; ?>" name="daterange" type="text" required="required">
				<input class="form-control" value="<?php echo @$record["StartDate"] != null ? date('Y/m/d',strtotime($record["StartDate"])) : ''; ?>" name="StartDate" type="hidden">
				<input class="form-control" value="<?php echo @$record["EndDate"] != null ? date('Y/m/d',strtotime($record["EndDate"])) : ''; ?>" name="EndDate" type="hidden">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Số lượng <span class="required">*</span></label>
				<input class="form-control format-number" value="<?php echo @$record["TongSoLuong"]; ?>" name="TongSoLuong" type="text" required="required">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">Đơn giá <span class="required">*</span></label>
				<input class="form-control format-number" value="<?php echo @$record["DonGiaHD"]; ?>" name="DonGiaHD" type="text" required="required">
			</div>
		</div>
	</div>
	<div class="form-group"> 
		<label class="control-label">File đính kèm</label>
		<input name="files[]" multiple type="file" accept="application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,image/*,application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
		<div style="height: 15px;"></div>
		<ul>
			<?php if(@$media != null && @$record["ID"] != null): ?>
				<?php foreach ($media as $key => $item): ?>
					<li>
						<a href="<?php echo base_url($item['URL']); ?>" target="_blank"><?php echo $item['Name'].@$item['FileType']; ?></a>
						<a href="<?php echo backend_url($folder_view."/remove_media/".$record["ID"] ."/".$item['ID']); ?>" class="remove-media" data-id="<?php echo $item['ID']; ?>" style="color: #ff0000;margin-left: 10px;"><i class="fa fa-times" aria-hidden="true"></i></a>
					</li>
				<?php endforeach; ?>
			<?php endif; ?>
		</ul>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change', 'select[name="DonHang_ID"]', function() {
			var start_date = $(this).find(":selected").attr('data-start-date');
			var end_date = $(this).find(":selected").attr('data-end-date');
			if (typeof start_date !== typeof undefined && start_date !== false && typeof end_date !== typeof undefined && end_date !== false) {
			    $(this).parents('form').find('input[name="daterange"]').val(start_date + ' - ' + end_date);
			    $(this).parents('form').find('input[name="StartDate"]').val(start_date);
			    $(this).parents('form').find('input[name="EndDate"]').val(end_date);
			}
			else{
				$(this).parents('form').find('input[name="daterange"]').val('');
				$(this).parents('form').find('input[name="StartDate"]').val('');
				$(this).parents('form').find('input[name="EndDate"]').val('');
			}
		});
	});
</script>