<div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tên mã hàng </label>
				<input class="form-control" value="<?php echo @$record["Name"] ; ?>" name="Name" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Đơn hàng</label>
				<select class="form-control" name="HopDong_ID" disabled="">
					<option value="">Chọn</option>
					<?php if(isset($order_result) && $order_result != null): ?>
						<?php foreach ($order_result as $key => $item): ?>
							<option <?php echo $item['ID'] == @$record["DonHang_ID"] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['MaDonHang']; ?></option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Ngày bắt đầu</label>
				<input class="form-control form_datetime startdate" value="<?php echo @$record["StartDate"] != null ? date('Y/m/d',strtotime($record["StartDate"])) : ''; ?>" name="StartDate" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Ngày kết thúc</label>
				<input class="form-control form_datetime enddate" value="<?php echo @$record["EndDate"] != null ? date('Y/m/d',strtotime($record["EndDate"])) : ''; ?>" name="EndDate" type="text" readonly>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Số lượng</label>
				<input class="form-control format-number" value="<?php echo @$record["TongSoLuong"]; ?>" name="TongSoLuong" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Đơn giá</label>
				<input class="form-control format-number" value="<?php echo @$record["DonGiaHD"]; ?>" name="DonGiaHD" type="text" readonly>
			</div>
		</div>
	</div>
	<?php
		$today = new DateTime(date("Y-m-d H:i:s"));
		$datetime1 = new DateTime($record["StartDate"]);
		$datetime2 = new DateTime($record["EndDate"]);
		$interval = $datetime1->diff($datetime2);
		$total =  (int)$interval->format('%a'); 
		$interval = $datetime1->diff($today);
		$totaltoday =  (int)$interval->format('%a');
		$status = 0;
		if($total != 0){
			if($total < $totaltoday){
				$class="progress-bar-success";
				$status = '100%';
			}else{
				$class="progress-bar-info";
				$status = round( ($totaltoday/$total) * 100 ) . "%"; 
			}
		}else{
			$class="progress-bar-success";
			$status = '100%';
		}
	?>
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">Tiến độ</label>
				<div class="progress">
					<div class="progress-bar <?php echo $class;?>" role="progressbar" aria-valuenow="40"
					aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $status;?>">
						<?php echo $status?> Complete (success)
					</div>
				</div>
			</div>
		</div>
	</div>
	<label class="control-label">File đính kèm</label>
	<ul>
		<?php if(@$media != null && @$record["ID"] != null): ?>
			<?php foreach ($media as $key => $item): ?>
				<li>
					<a href="<?php echo base_url($item['URL']); ?>" target="_blank"><?php echo $item['Name'].@$item['FileType']; ?></a>
				</li>
			<?php endforeach; ?>
		<?php endif; ?>
	</ul>
</div>