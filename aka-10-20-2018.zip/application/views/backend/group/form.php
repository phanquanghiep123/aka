<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="form-group"> 
		<label class="control-label">Tiêu đề <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required">
	</div>
	<div class="form-group">
		<label class="control-label">Mã hàng <span class="required">*</span></label>
		<select class="form-control required" name="MaHang_ID">
			<option value="">Chọn mã hàng</option>
			<?php if(isset($mahang) && $mahang != null): ?>
				<?php foreach ($mahang as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" <?php echo @$record["MaHang_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group"> 
		<label class="control-label">Mô tả</label>
		<textarea class="form-control" rows="5" name="Description" maxlength="255"><?php echo @$record["Description"]; ?></textarea>
	</div>
	<div class="form-group" style="position: relative;"> 
		<label class="control-label">Màu sắc</label>
		<input class="form-control color-picker" value="<?php echo @$record["Color"]; ?>" name="Color" type="text">
		<div style="position: absolute;top: 28px;right: 0;height: 33px;width: 33px;background-color: <?php echo @$record["Color"]; ?>" class="color-reference"></div>
	</div>
	<div class="form-group"> 
		<label class="control-label">Hình ảnh</label>
		<input name="Image" type="file"  accept="image/*">
		<div style="height: 5px;"></div>
		<?php echo @$record["ColorURL"] != null ? '<img style="height:30px;" src="'.base_url($record["ColorURL"]).'">' : ''; ?>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>