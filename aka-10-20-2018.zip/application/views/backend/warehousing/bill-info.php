<h3>Thông tin hóa đơn</h3>
<div class="table-responsive" style="min-height: auto;">
	<table class="table">
		<tr>
			<td>Nhà cung cấp:</td>
			<td><?php echo @$ncc['Name']; ?></td>
		</tr>
		<tr>
			<td>VAT:</td>
			<td><?php echo number_format(@$hoadon['VAT']); ?> VNĐ</td>
		</tr>
		<tr>
			<td>Phí vận chuyển:</td>
			<td><?php echo number_format(@$hoadon['PhiVanChuyen']); ?> VNĐ</td>
		</tr>
		<tr>
			<td>Tổng tiền:</td>
			<td><?php echo number_format(@$hoadon['TongSoTien']); ?> VNĐ</td>
		</tr>
		<?php if(@$hoadon['Description'] != null): ?>
			<tr>
				<td>Mô tả:</td>
				<td><?php echo $hoadon['Description']; ?></td>
			</tr>
		<?php endif; ?>
		<?php if(@$media != null): ?>
			<tr>
				<td>Tập tin đính kèm:</td>
				<td>
					<ul>
						<?php foreach ($media as $key => $item): ?>
							<li><a href="<?php echo base_url($item['URL']); ?>" target="_blank"><?php echo $item['Name'].@$item['FileType']; ?></a></li>
						<?php endforeach; ?>
					</ul>
				</td>
			</tr>
		<?php endif; ?>
	</table>
</div>