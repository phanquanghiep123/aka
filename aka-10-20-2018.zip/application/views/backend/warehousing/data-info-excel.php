<hr>
<?php if(isset($message) && $message != null): ?>
	<div class="message alert alert-danger"><?php echo $message; ?></div>
<?php endif; ?>
<div class="table-responsive" style="min-height: auto;">
	<table class="table table-striped jambo_table">
		<thead>
			<tr>
				<th>STT</th>
				<?php foreach ($header as $key => $item): ?>
					<th>
						<p data-toggle="tooltip" data-placement="top" title="<?php echo $item; ?>"><?php echo $item; ?></p>
					</th>
				<?php endforeach; ?>
			</tr>
		</thead>
		<tbody>
			<?php if(isset($data_insert) && $data_insert != null): ?>
				<?php foreach ($data_insert as $key => $item): ?>
					<tr>
						<td><?php echo ($key+1); ?></td>
						<td><?php echo @$item['dmvt']; ?></td>
						<td><?php echo @$item['so-luong']; ?></td>
						<td><?php echo @$item['don-gia']; ?></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
		</tbody>
	</table>
</div>
<?php if(isset($data_insert) && $data_insert != null): ?>
	<p class="text-center"><button type="submit" class="btn btn-primary">Lưu dữ liệu</button></p>
<?php endif; ?>