<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-12">
						<h2><?php echo @$title_page; ?> </h2>
					</div>
				</div>
			</div>
			<div class="x_content">
				<form action="" method="post" class="form-add-bill">
					<div class="row">
						<div class="col-sm-12">
							<div class="message alert alert-success" style="display: none;"></div>
	                		<div class="message alert alert-danger" style="display: none;"></div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-6">
							<div class="form-group">
								<label>Chọn hóa đơn</label>
								<select class="form-control" name="HoaDon_ID">
									<option value="">Mã hóa đơn</option>
									<?php if(isset($hoadon_result) && $hoadon_result != null): ?>
										<?php foreach ($hoadon_result as $key => $item): ?>
											<option <?php echo $item['ID'] == @$bill_id ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Ma_Hoa_Don']; ?></option>
										<?php endforeach; ?>
									<?php endif; ?>
								</select>
							</div>
							<div class="form-group text-right">
								<a href="#" class="btn btn-primary btn-add-data" data-toggle="modal" data-target="#upload-modal">Chọn Excel file</a>
								<a href="#" class="btn btn-primary btn-add-data" data-toggle="modal" data-target="#dmvt-modal">Cập nhật đơn giá theo hóa đơn</a>
								<a href="<?php echo backend_url($folder_view);?>" class="btn btn-default">Hủy bỏ</a>
								<input type="hidden" name="path_file" >
							</div>
						</div>
						<div class="col-sm-6">
							<div class="bill-info">
								<?php if(@$bill_id != null): ?>
									<?php $this->load->view($backend_asset.'/'.$folder_view.'/bill-info',array('hoadon' => @$bill,'media' => @$media)); ?>
								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<div class="data-excel">
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div id="dmvt-modal" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg" style="max-width: 700px;">
        <!-- Modal content-->
        <form action="" method="post">
	        <div class="modal-content">
	        	<div class="modal-header">
	                <button type="button" class="close" data-dismiss="modal">&times;</button>
	                <h4 class="modal-title">Chọn vật tư</h4>
	            </div>
	            <div class="modal-body" style="height: 450px;overflow-y:auto;">
	                <div class="message alert alert-success" style="display: none;"></div>
					<div class="message alert alert-danger" style="display: none;"></div>
	                <div class="file-sample table-responsive" style="box-shadow: none;">
						<table class="table table-bordered not-datatable">
							<thead>
								<tr class="">
									<th class="text bg-blue"><p>#</p></th>
									<th class="text bg-blue"><p>Danh mục vật tư</p></th>
									<th class="text bg-blue"><p>Số lượng</p></th>
									<th class="text bg-blue"><p>Đơn giá</p></th>
								</tr>
							</thead>
							<tbody>
								<?php if(isset($results) && $results != null): ?>
									<?php foreach ($results as $key => $item): ?>
										<tr>
											<td><?php echo ($key+1); ?></td>
											<td class="name"><?php echo $item['Name']; ?></td>
											<td>
												<div class="form-group">
													<input type="text" value="" name="soluong[<?php echo $item['ID']; ?>]" min='1' placeholder="Nhập số lượng" class="form-control format-number soluong">
												</div>
											</td>
											<td>
												<div class="form-group">
													<input type="text" value="" name="dongia[<?php echo $item['ID']; ?>]" min='1' placeholder="Nhập đơn giá" class="form-control format-number dongia">
												</div>
											</td>
										</tr>
									<?php endforeach; ?>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
	            </div>
	            <div class="modal-footer">
	            	<div class="text-right">
			    		<a type="button" class="btn btn-gray" data-dismiss="modal">Hủy bỏ</a> 
			    		<button type="submit" class="btn action-bnt btn-primary relative">Nhập dữ liệu</button> 
			    	</div>
	            </div>
		    </div>
		    <input type="hidden" name="HoaDon_ID">
	    </form>
    </div>
</div>


<div id="upload-modal" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg" style="max-width: 700px;">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><?php echo @$title_page; ?></h4>
            </div>
            <div class="modal-body" style="height: 450px;overflow-y:auto;">
	            <form class="form-horizontal form-export form-label-left" action="<?php echo backend_url($folder_view."/export_excel/"); ?>" method="post" enctype="multipart/form-data">    
	                <div class="message alert alert-success" style="display: none;"></div>
	                <div class="message alert alert-danger" style="display: none;"></div>
	                <div class="file-sample table-responsive" style="box-shadow: none;">
						<table class="table table-bordered">
							<thead>
								<tr>
									<th class="text-center top-number"></th>
									<?php for($char = 'A',$i = 0; $char <= 'Z',$i < count($header); $char++,$i++): ?>
										<th class="text-center"><?php echo $char; ?></th>
									<?php endfor; ?>
								</tr>
								<tr>
									<th>
										<p>1</p>
									</th>
									<?php foreach ($header as $key => $item): ?>
										<th class="bg-blue">
											<p data-toggle="tooltip" data-placement="top" title="<?php echo $item; ?>"><?php echo $item; ?></p>
										</th>
									<?php endforeach; ?>
								</tr>
							</thead>
							<tbody>
								<?php if(isset($results) && $results != null): ?>
									<?php foreach ($results as $key => $item): ?>
										<tr>
											<td><?php echo ($key+2); ?></td>
											<td class="name"><?php echo $item['Name']; ?></td>
											<td>
												<div class="form-group">
													<input type="text" value="" onblur="check_func(this)" name="soluong[<?php echo $item['ID']; ?>]" placeholder="Nhập số lượng" class="form-control soluong format-number">
												</div>
											</td>
											<td>
												<div class="form-group">
													<input type="text" name="dongia[<?php echo $item['ID']; ?>]" min='1' placeholder="đơn giá" class="form-control format-number dongia" readonly>
												</div>
											</td>
										</tr>
									<?php endforeach; ?>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</form>
            </div>
            <div class="modal-footer">
            	<div class="text-right">
            		<p class="text-right dowload-excel-sample">
						<a href="#<?php //echo base_url('/uploads/template-excel/nhap-kho.xls'); ?>" class="export-excel">Tải file Excel</a>
					</p>
            		<form class="form-horizontal form-label-left" action="<?php echo backend_url($folder_view."/import/"); ?>" method="post" enctype="multipart/form-data">
			    		<a type="button" class="btn btn-gray" data-dismiss="modal">Hủy bỏ</a> 
			    		<button id="upload-from-now" type="button" onclick="$('#file-upload').trigger('click');return false;" class="btn action-bnt btn-primary relative">Chọn file Excel</button> 
			    		<input type="file" name="excel" class="hidden" id="file-upload" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" > 
		    		</form>
		    	</div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
		$('#file-upload').change(function(){
			var current = $(this);
			current.parents('form').find(".message").hide();
			var options = {
                dataType:'json',
                type: 'POST',
	            url: "<?php echo backend_url($folder_view."/get_data_excel/"); ?>",
                success: function(data){
                    if(data['status'] == 'success'){
                    	$('.data-excel').html(data['response']);
                    	$('input[name="path_file"]').val(data['path_file']);
                    	$("#upload-modal").modal('hide');
                    	$('#file-upload').val('');
                    }
                    else if(data['status'] == 'fail'){
                    	current.parents('form').find(".alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.parents('form').ajaxSubmit(options);
		});

		if($('select[name="HoaDon_ID"]').val() != ''){
			var bill = $('select[name="HoaDon_ID"]').find("option:selected").text();
			$('#upload-modal .modal-title, #dmvt-modal .modal-title').html('Cập nhập cho hóa đơn ' + bill);
			$('.btn-add-data').show();
		}
		else{
			$('.btn-add-data').hide();
		}

		$('select[name="HoaDon_ID"]').change(function(){
			var val = $(this).val();
			$('#dmvt-modal input[name="HoaDon_ID"]').val(val);
			if(val != ''){
				var bill = $(this).find("option:selected").text();
				$('#upload-modal .modal-title, #dmvt-modal .modal-title').html('Cập nhập cho hóa đơn ' + bill);
				$('.btn-add-data').show();
			}
			else{
				$('.btn-add-data').hide();
			}
		});

		$('.export-excel').click(function(){
			$('form.form-export').submit();
			return false;
		});

		$('#dmvt-modal form').submit(function(){
			var check = true;
			var check_input = false;
			$(this).find('.soluong').each(function(){
				var current = $(this);
				var soluong = current.val();
				var current_dongia = current.parents('tr').find('.dongia');
				var dongia = current_dongia.val();
				if(soluong != ''){
					if(dongia == ''){
						current_dongia.addClass('border-error');
						check = false;
					}
					else{
						current_dongia.removeClass('border-error');
					}
					check_input = true;
				}

				if(dongia != ''){
					if(soluong == ''){
						current.addClass('border-error');
						check = false;
					}
					else{
						current.removeClass('border-error');
					}
					check_input = true;
				}
			});
			if(!check_input){
				alert('Vui lòng nhập đầy đủ dữ liêu.');
				return check_input;
			}
			if(check){
				var current = $(this);
				current.find(".message").hide();
				var options = {
	                dataType:'json',
	                type: 'POST',
		            url: "<?php echo backend_url($folder_view."/insert_data/"); ?>",
	                success: function(data){
	                    if(data['status'] == 'success'){
	                    	alert('Nhập kho thành công.');
                    		location.href = "<?php echo backend_url($folder_view."/");?>";	
	                    }
	                    else if(data['status'] == 'fail'){
	                    	current.find(".alert-danger").html(data['message']).show();
	                    }
	                }
	            }; 
	            current.ajaxSubmit(options);
			}
			return false;
		});

		/*$('.form-export').submit(function(){
			var current = $(this);
			
			current.find(".message").hide();
			var options = {
                type: 'POST',
	            url: "<?php echo backend_url($folder_view."/export_excel/"); ?>",
                success: function(message){
                	if(message == '-1'){
                		alert('Vui lòng nhập số lượng và đơn giá');
                	}
                },
                error:function(){
                	alert('Xuất file không thành công');
                }
            }; 
            current.ajaxSubmit(options);
            //return false;
            setTimeout(function(){
            	current.parents('.modal').modal('toggle');
            },1000);
		});*/
	});
</script>

<style type="text/css">
	.bill-info table td, 
	.bill-info table th {
	    border: 1px solid black !important;
	    padding: 5px;
	}
	.border-error{border:1px solid #ff0000 !important;}
</style>

<script type="text/javascript">
	function check_func(element) {
	    var val = $(element).val();
	    if(isNaN(val) || val < 0){
	    	$(element).val('0');
	    }
	}

	$(document).ready(function(){
		$(document).on('submit','.form-add-bill',function(){
			var current = $(this);
			current.find(".message").hide();
			var options = {
                dataType:'json',
                success: function(data){
                    if(data['status'] == 'success'){
                    	alert('Nhập kho thành công.');
                    	location.href = "<?php echo backend_url($folder_view."/");?>";	
                    }
                    else if(data['status'] == 'fail'){
                    	current.find(".alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.ajaxSubmit(options);
			return false;
		});


		$('select[name="HoaDon_ID"]').change(function(){
			var bill_id = $(this).val();
			if(bill_id != '' && bill_id != null){
				$.ajax({
	                type: 'POST',
	                dataType:'json',
	                url: "<?php echo backend_url($folder_view."/get_bill/");?>" + bill_id,
	                data:{},
	                success: function(data) {
	                	console.log(data);
	                	if(data['status'] == 'success'){
	                		$('.bill-info').html(data['response']);
	                	}
	                	else if(data['status'] == 'fail'){
	                		alert(data['message']);
	                	}
	                }
	            });
			}
		});
	});
</script>
<style type="text/css">
	.btn-add-data{display: none;}
</style>