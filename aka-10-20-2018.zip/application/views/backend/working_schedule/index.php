<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="box-common-edit-add relative" style="display: none;">			
			<a class="collapse-link-custom"><i class="fa fa-chevron-up"></i></a>
			<div class="form-slider" style="max-width: 450px;margin:0 auto;">
				<form id="form-common-edit-add"  method="post" action="<?php echo backend_url($folder_view.'/add'); ?>">
					<div class="form-group"> 
						<label class="control-label">Tên phòng ban <span class="required">*</span></label>
						<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required">
					</div>
					<div class="form-group"> 
						<label class="control-label" for="Status">Trạng thái<span class="required">*</span></label>
						<select id="Status" class="form-control" name="Status" required="required">   
					    	<option value="1">Hoạt động</option>
						    <option value="0" <?php echo @$record["Status"] != null && @$record["Status"] == 0 ? 'selected' : ''; ?>>Ngưng hoạt động</option>
						</select>
					</div>
					<div class="ln_solid"></div>
					<div class="form-group" style="text-align: center;">
					    <a onclick="$('.collapse-link-custom').trigger('click');return false;" href="javascript:;" class="btn btn-primary">Đóng lại</a>
						<button id="send" type="submit" class="btn btn-success relative">Lưu</button> 
					</div>
				</form>
			</div>
		</div>
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-8">
						<h2>
							<?php echo @$title_page; ?> 
							 
						</h2>
					</div>
					 
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
				    <?php $countworking = count($working_slots);?>
					<table class="table table-striped jambo_table not-datatable">
					    <thead>
					        <tr class="headings">
					            <th>Stt </th>
					            <th>Tên phòng ban </th>
					            <th>Thời gian làm việc</th>
					            <th>Lựa chọn</th>
					        </tr>
					    </thead>
					    <tbody>
					    	<?php
					    		if(@$departments){
					    			$index = 1;
					    			foreach ($departments as $key => $value) {
					    				$value['Slot_Working_IDs'] = ','.$value['Slot_Working_IDs'].',';
					    				echo '<tr>';
					    				echo '<td rowspan="'.$countworking.'">'.($index++).'</td>';
					    				echo '<td rowspan="'.$countworking.'">'.$value['Name'].'</td>';
					    				
					    				if($working_slots){
					    					foreach ($working_slots as $key_1 => $value_1) {
					    						$c = (strpos ( trim($value['Slot_Working_IDs']), trim(",".$value_1["ID"]."-1,") ) !== false) ? 'checked' : '';
					    						if($key_1 !== 0){
					    							echo '</tr>';
					    							echo '<tr>';
					    						}
					    						echo '<td>'.$value_1['Name'].'</td>';
					    						echo '<td>
									        		<label>
									        			<input name="department[]" data-slot="'.$value_1["ID"].'" data-department="'.$value['ID'].'" type="checkbox" class="onchange_department js-switch" '.$c.'>
									        		</label>
									        	</td>';
									        	if($key_1 !== 0)
									        		echo '</tr>';
					    					}
					    				}
		
					    			}
					    		}
					    	?>						
					    </tbody>
					</table>
				</div>
				<?php if(isset($this->pagination)): ?>
					<div class="row">
						<div class="col-sm-12 text-center">
							<?php echo @$this->pagination->create_links();?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<!-- Modal -->
<div id="upload-modal" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg" style="max-width: 700px;">
        <!-- Modal content-->
        <form class="form-horizontal form-label-left" action="<?php echo backend_url($folder_view."/import/"); ?>" method="post" enctype="multipart/form-data">
	        <div class="modal-content">
	            <div class="modal-header">
	                <button type="button" class="close" data-dismiss="modal">&times;</button>
	                <h4 class="modal-title"><?php echo @$title_page; ?></h4>
	            </div>
	            <div class="modal-body">
	                <div class="message alert alert-success" style="display: none;"></div>
	                <div class="message alert alert-danger" style="display: none;"></div>
	                <div class="file-sample table-responsive">
						<table class="table table-bordered">
							<thead>
								<tr>
									<th class="text-center top-number"></th>
									<?php for($char = 'A',$i = 0; $char <= 'Z',$i < count($header); $char++,$i++): ?>
										<th class="text-center"><?php echo $char; ?></th>
									<?php endfor; ?>
								</tr>
								<tr>
									<th>
										<p>1</p>
									</th>
									<?php foreach ($header as $key => $item): ?>
										<th class="bg-blue">
											<p data-toggle="tooltip" data-placement="top" title="<?php echo $item; ?>"><?php echo $item; ?></p>
										</th>
									<?php endforeach; ?>
								</tr>
							</thead>
						</table>
					</div>
					<p class="text-right dowload-excel-sample">
						<a href="<?php echo base_url('/uploads/template-excel/phòng-ban.xlsx'); ?>" download="">Tải file Excel mẫu</a>
					</p>
	            </div>
	            <div class="modal-footer">
	            	<div class="text-right">
			    		<a type="button" class="btn btn-gray" data-dismiss="modal">Hủy bỏ</a> 
			    		<button id="upload-from-now" type="button" onclick="$('#file-upload').trigger('click');return false;" class="btn action-bnt btn-primary relative">Chọn file Excel</button> 
			    		<input type="file" name="excel" class="hidden" id="file-upload" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" > 
			    	</div>
	            </div>
	        </div>
	    </form>
    </div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		 $(".onchange_department").click(function(){
		 	var slot = $(this).attr("data-slot");
		 	var department = $(this).attr("data-department");
		 	$.ajax({
		 		url : "<?php echo backend_url($folder_view.'/add'); ?>",
		 		data : {slot : slot , department : department},
		 		type : 'post',
		 		dataType : 'json',
		 		success: function(data){
		 			console.log(data);
		 		}
		 	})
		 })
	});
</script>
 
<style type="text/css">
	.select2-container{width: 100% !important;}
	.table>tbody>tr>td{
		border: 1px solid #ccc !important;
	}
</style>