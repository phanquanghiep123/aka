<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="form-group"> 
		<label class="control-label">Tên phòng ban <span class="required">*</span></label>
		<select class="form-control" name="Department_ID">
			<?php if(@$departments):?>
				<?php 
					foreach ($departments as $key => $value) {
						echo '<option value="'.$value["ID"].'">'.$value["Name"].'</option>';
					}
				?>
			<?php endif;?>
			
		</select>
	</div>
	<div class="form-group"> 
		<label class="control-label">Khung giờ làm việc: <span class="required">*</span></label>
		<select class="form-control" name="Time_Slot_Working_ID ">
			<?php if(@$time_working_slots):?>
				<?php 
					foreach ($time_working_slots as $key => $value) {
						echo '<option value="'.$value["ID"].'">'.$value["Name"].'</option>';
					}
				?>
			<?php endif;?>
			
		</select>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" class="btn btn-default" onclick="$('.collapse-link-custom').trigger('click');return false;" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>
<script type="text/javascript">
	$(document).ready(function(){
		$('select[name="Status"]').change(function(){
			var val = $(this).val();
			if(val == 0){
				$('.input_date_end input').attr('required','required');
				$('.input_date_end').show();
			} else{
				$('.input_date_end input').removeAttr('required');
				$('.input_date_end').hide();
			}
		});

		$('select[name="Type"]').change(function(){
			var val = $(this).val();
			if(val == 1){
				$('.input_type_id select').attr('required','required');
				$('.input_type_id').show();
			} else{
				$('.input_type_id select').removeAttr('required');
				$('.input_type_id').hide();
			}
		});
	});
</script>