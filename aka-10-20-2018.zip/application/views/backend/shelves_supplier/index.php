<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="box-common-edit-add relative" style="display: none;">
			<a class="collapse-link-custom" href="#" style="color: #ff0000;"><i class="fa fa-times" aria-hidden="true"></i></a>
			<div class="form-slider" style="max-width: 600px;margin:0 auto;"></div>
		</div>
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-12">
						<h2>
							<?php echo @$title_page; ?> 
							<a class="btn btn-success create-item is_ajax" href="<?php echo backend_url($folder_view."/add");?>"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Thêm mới</a>
							<a class="btn btn-success" href="#" data-toggle="modal" data-target="#upload-modal"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Nhập dữ nhiều</a>
							<a class="btn btn-success" href="<?php echo backend_url($folder_view."/export");?>"><i class="fa fa-download" aria-hidden="true"></i> Xuất Excel</a>
							<a class="btn btn-success" href="#" data-toggle="modal" data-target="#excel-modal"><i class="fa fa-file-excel-o" aria-hidden="true"></i> Nhập Excel</a>
						</h2>
					</div>
					<div class="col-sm-12">
						<form method="" method="get">
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<select class="form-control" name="NCC">
											<option value="">Nhà cung cấp</option>
											<?php if(isset($ncc_result) && $ncc_result != null): ?>
												<?php foreach ($ncc_result as $key => $item): ?>
													<option <?php echo $item['ID'] == $this->input->get('NCC') ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
												<?php endforeach; ?>
											<?php endif; ?>
										</select>
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<select class="form-control" name="DMVT">
											<option value="">Danh mục vật tư</option>
											<?php if(isset($dmvt_result) && $dmvt_result != null): ?>
												<?php foreach ($dmvt_result as $key => $item): ?>
													<option <?php echo $item['ID'] ==  $this->input->get('DMVT') ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
												<?php endforeach; ?>
											<?php endif; ?>
										</select>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="form-group">
										<button type="submit" class="btn btn-primary">Tìm kiếm</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
					<table class="table table-striped jambo_table bulk_action">
						<thead>
							<tr class="headings">
								<th>Stt</th>
								<th>Nhà cung cấp</th>
								<th>Ngày báo giá</th>
								<th>Danh mục vật tư</th>
								<th>Đơn giá</th>
								<th>Hành động</th>
							</tr>
						</thead>
						<tbody>
						    <?php if(isset($results) && $results != null): ?>
						        <?php foreach ($results as $key => $value): ?>
						    		<tr data-id="<?php echo $value['ID']; ?>">
										<td data-column="Stt"><?php echo $key+1;?></td>
										<td data-column="NCCName"><?php echo $value["NCCName"]; ?></td>
										<td data-column="Date"><?php echo date($date_format,strtotime($value["Date"])); ?></td>
										<td data-column="DMVTName"><?php echo $value["DMVTName"]; ?></td>
										<td data-column="DonGia" class="text-right"><?php echo number_format($value["DonGia"]).' VNĐ'; ?></td>
										<td data-column="Action">
											<a class="is_ajax" title="Chỉnh sửa" href="<?php echo backend_url($folder_view."/edit/".$value["ID"])?>"><i class="fa fa-edit" aria-hidden="true"></i></a> | 
											<a class="is_ajax_delete" title="Xóa" href="<?php echo backend_url($folder_view.'/delete/'.$value["ID"])?>"><i class="fa fa-trash" aria-hidden="true"></i></a> 
										</td>
									</tr>
							    <?php endforeach; ?>
						    <?php endif; ?>
						</tbody>
					</table>
				</div>
				<?php if(isset($this->pagination)): ?>
					<div class="row">
						<div class="col-sm-12 text-center">
							<?php echo @$this->pagination->create_links();?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div id="excel-modal" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg" style="max-width: 700px;">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><?php echo @$title_page; ?></h4>
            </div>
            <div class="modal-body" style="height: 450px;overflow-y:auto;">
	            <form class="form-horizontal form-export form-label-left" action="<?php echo backend_url($folder_view."/export_excel/"); ?>" method="post" enctype="multipart/form-data">    
	                <div class="message alert alert-success" style="display: none;"></div>
	                <div class="message alert alert-danger" style="display: none;"></div>
	                <div class="row">
						<div class="col-sm-6">
							<div class="form-group">
								<label class="control-label">Nhà cung cấp <span class="required">*</span></label>
								<select class="form-control" name="NCC" required="required">
									<option value="">Chọn</option>
									<?php if(isset($ncc_result) && $ncc_result != null): ?>
										<?php foreach ($ncc_result as $key => $item): ?>
											<option value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
										<?php endforeach; ?>
									<?php endif; ?>
								</select>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group"> 
								<label class="control-label">Ngày báo giá <span class="required">*</span></label>
								<input class="form-control form_datetime" value="<?php echo date('Y/m/d'); ?>" name="Date" type="text" required="required">
							</div>
						</div>
					</div>
	                <div class="file-sample table-responsive" style="box-shadow: none;">
						<table class="table table-bordered">
							<thead>
								<tr>
									<th class="text-center top-number"></th>
									<?php for($char = 'A',$i = 0; $char <= 'Z',$i < count($header); $char++,$i++): ?>
										<th class="text-center"><?php echo $char; ?></th>
									<?php endfor; ?>
								</tr>
								<tr>
									<th>
										<p>1</p>
									</th>
									<th class="bg-blue">
										<p data-toggle="tooltip" data-placement="top" title="Danh mục vật tư">Danh mục vật tư</p>
									</th>
									<th class="bg-blue">
										<p data-toggle="tooltip" data-placement="top" title="Đơn giá">Đơn giá</p>
									</th>
								</tr>
							</thead>
							<tbody>
								<?php if(isset($dmvt_result) && $dmvt_result != null): ?>
									<?php foreach ($dmvt_result as $key => $item): ?>
										<tr>
											<td><?php echo ($key+2); ?></td>
											<td class="name"><?php echo $item['Name']; ?></td>
											<td>
												<div class="form-group">
													<input type="text" name="dongia[<?php echo $item['ID']; ?>]" min='1' placeholder="đơn giá" class="form-control format-number dongia">
												</div>
											</td>
										</tr>
									<?php endforeach; ?>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
					<button type="submit" class="btn-submit" style="display: none;"></button>
				</form>
            </div>
            <div class="modal-footer">
            	<div class="text-right">
            		<p class="text-right dowload-excel-sample">
						<a href="#<?php //echo base_url('/uploads/template-excel/nhap-kho.xls'); ?>" class="export-excel">Tải file Excel</a>
					</p>
            		<form class="form-horizontal form-label-left import-excel" action="<?php echo backend_url($folder_view."/import_excel"); ?>" method="post" enctype="multipart/form-data">
			    		<div class="message alert alert-success text-left" style="display: none;"></div>
	                	<div class="message alert alert-danger text-left" style="display: none;"></div>
			    		<a type="button" class="btn btn-gray" data-dismiss="modal">Hủy bỏ</a> 
			    		<button id="upload-from-now" type="button" onclick="$('#file-upload').trigger('click');return false;" class="btn action-bnt btn-primary relative">Chọn file Excel</button> 
			    		<input type="file" name="excel" class="hidden" id="file-upload" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" > 
		    		</form>
		    	</div>
            </div>
        </div>
    </div>
</div>


<div id="upload-modal" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg" style="max-width: 700px;">
        <!-- Modal content-->
        <form class="form-horizontal form-label-left" action="<?php echo backend_url($folder_view."/import/"); ?>" method="post" enctype="multipart/form-data">
	        <div class="modal-content">
	            <div class="modal-header">
	                <button type="button" class="close" data-dismiss="modal">&times;</button>
	                <h4 class="modal-title"><?php echo @$title_page; ?></h4>
	            </div>
	            <div class="modal-body" style="height: 450px;overflow-y:auto;">
	                <div class="message alert alert-success" style="display: none;"></div>
	                <div class="message alert alert-danger" style="display: none;"></div>
	                <div class="row">
						<div class="col-sm-6">
							<div class="form-group">
								<label class="control-label">Nhà cung cấp <span class="required">*</span></label>
								<select class="form-control" name="NCC" required="required">
									<option value="">Chọn</option>
									<?php if(isset($ncc_result) && $ncc_result != null): ?>
										<?php foreach ($ncc_result as $key => $item): ?>
											<option value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
										<?php endforeach; ?>
									<?php endif; ?>
								</select>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group"> 
								<label class="control-label">Ngày nhập <span class="required">*</span></label>
								<input class="form-control form_datetime" value="<?php echo date('Y/m/d'); ?>" name="Date" type="text" required="required">
							</div>
						</div>
					</div>
	                <div class="file-sample table-responsive" style="box-shadow: none;">
						<table class="table table-bordered">
							<thead>
								<tr>
									<th>
										#
									</th>
									<?php foreach ($header as $key => $item): ?>
										<th class="bg-blue">
											<p data-toggle="tooltip" data-placement="top" title="<?php echo $item; ?>"><?php echo $item; ?></p>
										</th>
									<?php endforeach; ?>
								</tr>
							</thead>
							<tbody>
								<?php if(isset($dmvt_result) && $dmvt_result != null): ?>
									<?php foreach ($dmvt_result as $key => $item): ?>
										<tr>
											<td><?php echo ($key + 1); ?></td>
											<td><?php echo $item['Name']; ?></td>
											<td><?php echo $item['NameDVT']; ?></td>
											<td>
												<div class="form-group">
													<input type="text" name="dongia[<?php echo $item['ID']; ?>]" min="0" placeholder="Nhập đơn giá" class="form-control format-number">
												</div>
											</td>
										</tr>
									<?php endforeach; ?>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
	            </div>
	            <div class="modal-footer">
	            	<div class="text-right">
			    		<a type="button" class="btn btn-gray" data-dismiss="modal">Hủy bỏ</a> 
			    		<button type="submit" class="btn action-bnt btn-primary">Nhập dữ liệu</button> 
			    	</div>
	            </div>
	        </div>
	    </form>
    </div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$('#upload-modal form').submit(function(){
			var current = $(this);
			current.parents('form').find(".message").hide();
			var options = {
                dataType:'json',
                type: 'POST',
	            url: "<?php echo backend_url($folder_view."/import/"); ?>",
                success: function(data){
                    if(data['status'] == 'success'){
                    	alert(data['message']);
                    	location.reload();
                    }
                    else if(data['status'] == 'fail'){
                    	current.find(".alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.ajaxSubmit(options);
            return false;
		});

		$('#file-upload').change(function(){
			var current = $(this).parents('form');
			current.find(".message").hide();
			var options = {
                dataType:'json',
                type: 'POST',
	            url: "<?php echo backend_url($folder_view."/import_excel/"); ?>",
                success: function(data){
                    if(data['status'] == 'success'){
                    	alert(data['message']);
                    	location.reload();
                    }
                    else if(data['status'] == 'fail'){
                    	current.find(".alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.ajaxSubmit(options);
		});
	});
</script>


<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('click','a.is_ajax',function(){
			$(".box-common-edit-add .message").hide();
			var url = $(this).attr('href');
            $.ajax({
                type: 'POST',
                dataType:'html',
                url: url,
                data:{},
                success: function(html) {
                	if(html != -1){
                    	$(".box-common-edit-add .form-slider").html(html);
                    	$(".box-common-edit-add").slideDown();
                    	$("body,html").animate({scrollTop:0}, 'slow');
                    	$(".box-common-edit-add .form_datetime").each(function(){
							$(this).datetimepicker({
						        format: 'Y/m/d',
						        timepicker: false,
						        autoclose: true,
						        todayBtn: true
						    });
						});
                	}
                    else{
                    	alert('Đơn giá NCC - Vật tư này không tồn tại.');
                    }
                }
            });
			return false;
		});

		$(document).on('click','a.is_ajax_delete',function(){
			if(confirm('Bạn thật sự muốn xóa?')){
				var current = $(this);
				var url = $(this).attr('href');
	            $.ajax({
	                type: 'POST',
	                dataType:'json',
	                url: url,
	                data:{},
	                success: function(data) {
	                	if(data['status'] == 'success'){
	                		current.parents('tr').remove();
	                		$('tr td[data-column="Stt"]').each(function(i){
	                    		$(this).html(i+1);
	                    	});
	                	}
	                }
	            });
            }
			return false;
		});

		$(document).on('submit','.box-common-edit-add form',function(){
			var current = $(this);
			$(".box-common-edit-add .message").hide();
			var options = {
                dataType:'json',
                success: function(data){
                    if(data['status'] == 'success'){
                    	var fields = ["NCCName","Date","DMVTName",'DonGia'];
                        if(data['action'] == 'add'){
                        	var html = '<tr data-id="' + data['responsive']['ID'] + '">';
                        		html += '	<td data-column="Stt"></td>';
                        		fields.forEach(function(element) {
                        			if(element == 'DonGia'){
                        				html += '<td data-column="' + element + '" class="text-right">' + data['responsive'][element] + '</td>';
                        			}
                        			else{
                        				html += '<td data-column="' + element + '">' + data['responsive'][element] + '</td>';
                        			}
								});
                        		html += '	<td data-column="Action">';
                        		html += '		<a class="is_ajax" href="<?php echo backend_url($folder_view."/edit/"); ?>' + data['responsive']['ID'] + '"><i class="fa fa-edit" aria-hidden="true"></i></a> | ';
								html += '		<a class="is_ajax_delete" href="<?php echo backend_url($folder_view.'/delete/'); ?>' + data['responsive']['ID'] + '"><i class="fa fa-trash" aria-hidden="true"></i></a>';
                        		html += '	</td>';
                        		html += '</tr>';
                        	$('.x_content table').prepend(html);

                        	$('tr td[data-column="Stt"]').each(function(i){
                        		$(this).html(i+1);
                        	});
                        }
                        else{
                        	fields.forEach(function(element) {
							  	$('tr[data-id="' + data['responsive']['ID'] + '"] td[data-column="' + element + '"]').html(data['responsive'][element]);
							});
                        }
                        $(".box-common-edit-add").slideUp();
                    }
                    else if(data['status'] == 'fail'){
                    	$(".box-common-edit-add .alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.ajaxSubmit(options);
			return false;
		});

		$(document).on('change', '.form-slider select[name="DMVT_ID"]', function() {
			var barcode = $(this).find(":selected").attr('data-barcode');
			if (typeof barcode !== typeof undefined && barcode !== false) {
			    $('.form-slider .barcode-mdvt').val(barcode);
			}
			else{
				$('.form-slider .barcode-mdvt').val('');
			}
		});

		$(document).on('change', '.form-slider .barcode-mdvt', function() {
			var barcode = $(this).val().toString();
			var val = '';
			$('.form-slider select[name="DMVT_ID"] option').each(function(){
			    var data_barcode = $(this).attr('data-barcode');
				if (typeof data_barcode !== typeof undefined && data_barcode !== false && barcode == data_barcode) {
					val = $(this).attr('value');
				}
			});
			$('.form-slider select[name="DMVT_ID"]').val(val).trigger("change");
			console.log($('.form-slider select[name="DMVT_ID"]').val());
		});

		$("#upload-modal .form_datetime").each(function(){
			$(this).datetimepicker({
		        format: 'Y/m/d',
		        timepicker: false,
		        autoclose: true,
		        todayBtn: true
		    });
		});

		$('#upload-modal select').each(function(){
            if(!$(this).hasClass('select2-hidden-accessible')){
                var is_multiple = $(this).prop('multiple');
                $(this).select2();
                if(is_multiple){
                    $(this).on("select2:selecting", function(e) { 
                        $(this).val(null).trigger('change');
                    });
                }
            }
        });

        $('.export-excel').click(function(){
			$('form.form-export .btn-submit').trigger('click');
			return false;
		});


		$('.collapse-link-custom').click(function(){
			$(".box-common-edit-add").slideUp();
			return false;
		});
	});
</script>