<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="google-signin-client_id" content="34899387470-psp04agnf18jf0gsdn3dd8r9goircija.apps.googleusercontent.com">
  <title>Công ty TNHH MTV AKA </title>
  <!-- Bootstrap -->
  <link href="<?php echo skin_url('backend/vendors/bootstrap/dist/css/bootstrap.min.css');?>" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="<?php echo skin_url('backend/vendors/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet">
  <!-- NProgress -->
  <link href="<?php echo skin_url('backend/vendors/nprogress/nprogress.css');?>" rel="stylesheet">
  <!-- Animate.css -->
  <link href="<?php echo skin_url('backend/vendors/animate.css/animate.min.css');?>" rel="stylesheet">
  <!-- Custom Theme Style -->
  <link href="<?php echo skin_url('backend/css/login.css');?>" rel="stylesheet">
  <script src="<?php echo skin_url('backend/vendors/jquery/dist/jquery.min.js');?>"></script>
          <link rel="shortcut icon" href="<?= base_url();?>skins/frontend/images/ico/favicon.ico">

</head>

<body class="login" style="background: #fff;">

<div class="container">
	<div class="logo">
		<a href="/"><img class="wix-logo" relative-src="images/wix-logo.svg" src="<?php echo skin_url('backend/images/logo.png');?>" /></a>
    <p></p>
	</div>
</div>

  <div class="container">
    <a class="hiddenanchor" id="signup"></a>
    <a class="hiddenanchor" id="signin"></a>
    <a class="hiddenanchor" id="forgot"></a>
    <div class="login_wrapper">
      <div class="animate form login_form">
        <section class="login_content">
          <form method="post" action="<?php echo backend_url("acounts/login")?>">
            <h2 class="title-form">Đăng nhập</h2>
    		<p class="change_link question_create">Bạn chưa có tài khoản? <a href="#signup" class="to_register"> Tạo tài khoản </a> </p>
            <?php ($this->input->get("messenger") == "reset_success") ? $messenger[] = "Mật khẩu được cập nhật thành công. Vui lòng hãy đăng nhập" : $abc = null ;?>
            <?php 
                if(isset($messenger)){
                  echo '<div class="messenger">';
                  echo '<ul>';
                  foreach ($messenger as $key => $value) {
                    echo '<li><p>'. $value.'</p></li>';
                  }
                  echo '</ul>';
                  echo '</div>';
                }
            ?>
            <div class="row">
              <div class="col-md-6 left-form">
                <div> <input type="text" name="username" class="form-control" placeholder="Tên đăng nhập" required="" /> </div>
                <div> <input type="password" name="password" class="form-control" placeholder="Mật khẩu đăng nhập" required="" /> </div>
                <div> <button type="submit" class="btn btn-default submit" href="index.html">Đăng nhập</button> <a href="#forgot" class="to_register"> Quên mật khẩu </a> </div>
                <div class="clearfix"></div>
              </div>
              <div class="col-md-6 right-form">
                <div class="sign-left">
                    <ul>
                      <li><a class="fb" onclick="fb_login();return false;" href="#"><i></i>Đăng nhập với Facebook</a></li>
                      <li><a class="goog customGPlusSignIn" id="GooglePlus" href="#"><i></i>Đăng nhập với Google</a></li>
                    </ul>
                  </div>
              </div>
            </div>
          </form>
        </section>
      </div>
      <div id="register" class="animate form registration_form">
        <section class="login_content">
          <form method="post" action="<?php echo backend_url("acounts/signup");?>">
            <h2 class="title-form">Tạo tài khoản</h2>
            <div class="row">
              <div class="col-md-6 left-form">
                <div> <input name="user_name" type="text" class="form-control" placeholder="Tên người dùng" required=""> </div>
                <div> <input name="email" type="email" class="form-control" placeholder="Email đăng nhập"> </div>
                <div> <input name="password" type="password" minlength="6" class="form-control" placeholder="Mật khẩu đăng nhập" required=""> </div>
                <div> <button class="btn btn-default submit" type="submit">Tạo tài khoản</button> </div>
                <div class="clearfix"></div>
                <div class="separator">
                  <p class="change_link">Đã là thành viên hay chưa ? <a href="#signin" class="to_register"> Đăng nhập </a> </p>
                  <div class="clearfix"></div> <br>
                </div>
              </div>
              <div class="col-md-6 right-form">
                  <div class="sign-left">
                      <ul>
                        <li><a class="fb" onclick="fb_login(); return false;" href="#"><i></i>Tạo tài khoản với Facebook</a></li>
                        <li><a class="goog customGPlusSignIn" id="GooglePlus" href="#"><i></i>Tạo tài khoản với Google</a></li>
                      </ul>
                    </div>
              </div>
            </div>
          </form>
        </section>
      </div>
      <div id="lost_password" class="animate form forgot_form">
        <section class="login_content">
          <form method="post" action="<?php echo backend_url("acounts/lost_password");?>">
            <h2 class="title-form">Quên mật khẩu</h2>
            <div class="row">
              <div class="col-md-6 left-form">
                <div>
                  <input name="email" type="email" class="form-control" placeholder="Vui lòng nhập email đăng nhập của bạn" required="" />
                </div>
                <div>
                  <button type="submit" class="btn btn-default submit">Gửi yêu cầu</button> 
                </div>
                <div class="clearfix"></div>
                <div class="separator">
                  <p class="change_link">Đã là thành viên hay chưa ?
                    <a href="#signin" class="to_register"> Đăng nhập </a>
                  </p>
                  <div class="clearfix"></div>
                </div>
              </div>
            <div class="col-md-6 right-form">
                <div class="sign-left">
                    <ul>
                      <li><a class="fb" href="#"><i></i>Đăng nhập với Facebook</a></li>
                      <li><a class="goog" href="#"><i></i>Đăng nhập với Google</a></li>
                    </ul>
                  </div>
              </div>
            </div>
          </form>
        </section>
      </div>
    </div>
  </div>
  <style type="text/css">
    .messenger ul {
      padding-left: 15px;
      text-align: left;
    }
    .messenger ul li {
      display: list-item;
    }
    body .login {
        background: #ffffff;
    }
    body .login_wrapper{max-width: 750px}
  </style>
  <script src="https://apis.google.com/js/platform.js" async defer></script>
  <script src="https://apis.google.com/js/api:client.js"></script>
  <script type="text/javascript">
    var googleUser = {};
    var startApp = function() {
      gapi.load('auth2', function(){
        auth2 = gapi.auth2.init({
          client_id: '34899387470-psp04agnf18jf0gsdn3dd8r9goircija.apps.googleusercontent.com',
          cookiepolicy: 'single_host_origin',
        });
        attachSignin(document.getElementById('GooglePlus'));
      });
    };
    function attachSignin(element) {
      auth2.attachClickHandler(element,{},
        function(googleUser) {
            var item = (googleUser.getBasicProfile());
            var profile = {
              "name" : item.wea +' '+ item.ofa,
              "email" : item.U3,
              "id"    : item.Eea,
              "avater" : item.Paa
            };
            social_signup(profile);
        }, function(error) {
          alert(JSON.stringify(error, undefined, 2));
      });
      return false
    }
    startApp();
    window.fbAsyncInit = function () {
        FB.init({
            appId: '886938148112799',
            xfbml: true,
            version: 'v2.8'
        });
    };
    (function (d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id))
            return;
        js = d.createElement(s);
        js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
    function fb_login() {
        FB.login(function (response) {
            FB.api('/me',{"fields":"id,name,email,first_name,last_name"}, function (response) {
                console.log(response);
                data_response = response;
                if (typeof response["email"] != "undefined" || response["email"] != null) {
                  social_signup(response);
                } 
            });

        },{scope: 'public_profile,email'});
        return false;
    }
    function social_signup(response) {
        $.ajax({
            url: "<?php echo backend_url('acounts/social')?>",
            type: "post",
            dataType: "json",
            data: {
                data: response
            }, 
            success: function (data, textStatus, jqXHR) {
                console.log(data);
                if (data["success"] == "success") {
                    window.location.href = data["reload"];
                } else {
                     alert("Error !!!", data["messenger"]);
                }
            }, error: function (jqXHR, textStatus, errorThrown) {
                alert("Error !!!",'lỗi không xác định!');
            }

        });

    }
  </script>
</body>
</html>