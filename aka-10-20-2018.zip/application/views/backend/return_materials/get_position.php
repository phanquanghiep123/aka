<h4><?php echo @$dmvt['Name']; ?></h4>
<div id="tab" class="btn-group" data-toggle="buttons">
	<a href="#giadung" class="btn btn-primary active" data-toggle="tab">
        <input type="radio" name="position" value="gia" checked="" />
        Giá đựng
    </a>
	<a href="#hop" class="btn btn-primary" data-toggle="tab">
        <input type="radio" name="position" value="hop" />
        Hộp
    </a>
</div>
<div class="tab-content" style="border: 1px solid #ccc;padding: 20px;">
	<div class="tab-pane active" id="giadung">
		<div class="row">
			<div class="col-xs-4">
				<p>Tên giá đựng</p>
			</div>
			<div class="col-xs-4">
				<p>Số lượng hiện tại</p>
			</div>
			<div class="col-xs-4">
				<p>Số lượng trả</p>
			</div>
		</div>
		<ul>
            <?php if(isset($gia_result) && $gia_result != null): ?>
				<?php foreach ($gia_result as $key => $item): ?>
					<li>
						<div class="row">
							<div class="col-xs-4">
								<label for="gia-<?php echo $item['ID']; ?>">
									<span class="name"><?php echo $item['Name'].'-'.$item['Hang'].'-'.$item['Cot']; ?></span>
								</label>
							</div>
							<div class="col-xs-4">
								<p><?php echo @$item['SoLuongVT'] != null ? ($item['SoLuongVT'] + (@$item['SoLuongTra'] != null ? $item['SoLuongTra'] : 0)).' '.@$dvt['Name'] : 'Chưa có vật tư này'; ?></p>
							</div>
							<div class="col-xs-4">
								<div class="form-group">
									<input type="number" value="<?php echo @$item['SoLuongTra'] != null ? $item['SoLuongTra'] : ''; ?>" onblur="check_func(this)" name="gia[<?php echo $item['ID']; ?>]" min='0' placeholder="Nhập số lượng" class="form-control">
								</div>
							</div>
						</div>
					</li>
				<?php endforeach; ?>
			<?php endif; ?>
		</ul>
	</div>
	<div class="tab-pane" id="hop">
		<div class="row">
			<div class="col-xs-4">
				<p>Tên hộp</p>
			</div>
			<div class="col-xs-4">
				<p>Số lượng hiện tại</p>
			</div>
			<div class="col-xs-4">
				<p>Số lượng</p>
			</div>
		</div>
		<ul>
            <?php if(isset($hop_result) && $hop_result != null): ?>
				<?php foreach ($hop_result as $key => $item): ?>
					<li>
						<div class="row">
							<div class="col-xs-4">
								<label for="hop-<?php echo $item['ID']; ?>">
									<span class="name"><?php echo $item['Name']; ?></span>
								</label>
							</div>
							<div class="col-xs-4">
								<p><?php echo @$item['SoLuongVT'] != null ? ($item['SoLuongVT'] + (@$item['SoLuongNhap'] != null ? $item['SoLuongNhap'] : 0)).' '.@$dvt['Name'] : 'Chưa có vật tư này'; ?></p>
							</div>
							<div class="col-xs-4">
								<div class="form-group">
									<input type="number" value="<?php echo @$item['SoLuongNhap'] != null ? $item['SoLuongNhap'] : ''; ?>" onblur="check_func(this)" min='0' name="hop[<?php echo $item['ID']; ?>]" placeholder="Nhập số lượng" class="form-control">
								</div>
							</div>
						</div>
					</li>
				<?php endforeach; ?>
			<?php endif; ?>
		</ul>
	</div>
</div>
<script type="text/javascript">
	function check_func(element) {
	    var val = $(element).val();
	    if(isNaN(val) || val < 0){
	    	$(element).val('0');
	    }
	}
</script>