<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="row">
		<div class="col-sm-4">
			<div class="form-group"> 
				<label class="control-label">Nhập barcode</label>
				<input type="text" class="form-control barcode-mdvt" <?php echo @$record['Status'] == 1 ? 'disabled' : ''; ?>>
			</div>
		</div>
		<div class="col-sm-4">
			<div class="form-group"> 
				<label class="control-label">Danh mục vật tư <span class="required">*</span></label>
				<select class="form-control" name="DMVT_ID" required="required">
					<option value="">Chọn</option>
					<?php if(isset($dmvt_result) && $dmvt_result != null): ?>
						<?php foreach ($dmvt_result as $key => $item): ?>
							<option data-barcode="<?php echo $item['Barcode']; ?>" <?php echo $item['ID'] == @$record['DMVT_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
		</div>
		<div class="col-sm-4">
			<div class="form-group"> 
				<label class="control-label">Vị trí xuất<span class="required">*</span></label>
				<a class="modal-position-input" href="#">Popup cập nhật vị trí</a>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-4">
			<div class="form-group"> 
				<label class="control-label">Nhập barcode</label>
				<input type="text" class="form-control barcode-employee">
			</div>
		</div>
		<div class="col-sm-4">
			<div class="form-group"> 
				<label class="control-label">Công nhân <span class="required">*</span></label>
				<select class="form-control" name="Employee_CongNhan_ID" required="required">
					<option value="">Chọn</option>
					<?php if(isset($employees_result) && $employees_result != null): ?>
						<?php foreach ($employees_result as $key => $item): ?>
							<option data-barcode="<?php echo $item['Barcode']; ?>" <?php echo $item['ID'] == @$record['Employee_CongNhan_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
		</div>
		<div class="col-sm-4">
			<div class="form-group"> 
				<label class="control-label">Ngày tháng <span class="required">*</span></label>
				<input class="form-control form_datetime" value="<?php echo @$record["Ngay"] != null ? date('Y/m/d',strtotime(@$record["Ngay"])) : date('Y/m/d'); ?>" name="Ngay" type="text" required="required">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<label class="control-label">Số lượng</label>
			<input type="number" class="form-control soluong-postion" value="<?php echo @$record['SoLuong']; ?>" min="1" name="SoLuong" required>
		</div>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>

	<!-- Modal -->
	<div id="position-modal" class="modal fade" role="dialog">
	    <div class="modal-dialog modal-md" style="max-width: 700px;">
	        <!-- Modal content-->
	        <div class="modal-content">
	            <div class="modal-header">
	                <button type="button" class="close" data-dismiss="modal" style="top:20px;font-size: 20px;">&times;</button>
	                <h4 class="modal-title">Trả vật tư</h4>
	            </div>
	            <div class="modal-body" style="height: 450px;overflow-y:auto;">
	                <?php 
	                	if(isset($get_postion) && $get_postion != null){
	                		$this->load->view($backend_asset."/".$folder_view."/get_position",$get_postion); 
	                	}
	                ?>
	            </div>
	            <div class="modal-footer text-right">
	            	<button type="button" data-dismiss="modal" class="btn btn-primary">Ok</button>
	            </div>
	        </div>
	    </div>
	</div>
</form>
<style type="text/css">
	.modal-position-input{
		display: block;
	    padding: 6px 12px;
	    font-size: 14px;
	    line-height: 1.42857143;
	    color: #555;
	    background-color: #fff;
	    background-image: none;
	    border: 1px solid #ccc;
	}
</style>
<script type="text/javascript">
	$(document).ready(function(){
		$('#position-modal').on('hidden.bs.modal', function () {
			var soluong = 0;
		    $('#position-modal input[type="number"]').each(function(){
		    	var val = $(this).val();
		    	if(val != null && !isNaN(val) && val > 0){
		    		soluong += parseInt(val);	
		    	}
		    });
		    var number = $('.soluong-postion').val();
		    if(number == '' || number == null){
		    	$('.soluong-postion').val(soluong);
		    }
		    else if(number != soluong && soluong != 0){
		    	alert('Số lượng xuất và vị trí không trùng nhau.');
		    }
		});
		
		$('.modal-position-input').click(function(){
			var val = $('.box-common-edit-add select[name="DMVT_ID"]').val();
			if(val != null && val != ''){
				var url = "<?php echo backend_url('/'.$folder_view.'/get_position/'); ?>";
	            $.ajax({
	                type: 'POST',
	                dataType:'json',
	                url: url + val,
	                data:{'Tra_ID':'<?php echo @$record['ID']; ?>'},
	                success: function(data) {
	                	if(data['status'] == 'success'){
	                    	$('#position-modal .modal-body').html(data['response']);
	                    	$('#position-modal').modal();
	                	}
	                	else if(data['status'] == 'fail'){
	                		alert(data['message']);
	                	}
	                }
	            });
			}
			else{
				alert('Vui lòng chọn danh mục vật tư.');
			}
			return false;
		});
	});
</script>