<form class="form-horizontal form-label-left form-user" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="form-group"> 
		<label class="control-label">Họ và tên <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Công việc <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Work"]; ?>" name="Work" type="text" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Địa chỉ <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Address"]; ?>" name="Address" type="text" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Số điện thoại</label>
		<input class="form-control" value="<?php echo @$record["Phone"]; ?>" name="Phone" type="text">
	</div>
	<div class="form-group"> 
		<label class="control-label">Nơi sinh</label>
		<input class="form-control" value="<?php echo @$record["Birthplace"]; ?>" name="Birthplace" type="text">
	</div>
	<div class="form-group"> 
		<label class="control-label">Giới tính</label>
		<select class="form-control" name="Gender">
			<option value="1">Nam</option>
			<option <?php echo @$record["Gender"] != null && @$record["Gender"] == 0 ? 'selected' : ''; ?> value="0">Nữ</option>
		</select>
	</div>
	<div class="form-group"> 
		<label class="control-label">Ngày sinh</label>
		<input class="form-control form_datetime" value="<?php echo @$record["Birthday"] != null && @$record["Birthday"] != '0000-00-00' ? date('Y/m/d',strtotime($record["Birthday"])) : ''; ?>" name="Birthday" type="text">
	</div>
	<div class="form-group"> 
		<label class="control-label">CMND</label>
		<input class="form-control" value="<?php echo @$record["CMND"]; ?>" name="CMND" type="text">
	</div>
	<div class="form-group"> 
		<label class="control-label">Ngày cấp</label>
		<input class="form-control form_datetime" value="<?php echo @$record["Date_Of_Issue"] != null && @$record["Date_Of_Issue"] != '0000-00-00' ? date('Y/m/d',strtotime($record["Date_Of_Issue"])) : ''; ?>" name="Date_Of_Issue" type="text">
	</div>
	<div class="form-group"> 
		<label class="control-label">Nơi cấp</label>
		<input class="form-control" value="<?php echo @$record["Issued_By"]; ?>" name="Issued_By" type="text">
	</div>
	<div class="form-group"> 
		<label class="control-label">Tiếp nhận</label>
		<input class="form-control form_datetime" value="<?php echo @$record["Receive"] != null && @$record["Receive"] != '0000-00-00' ? date('Y/m/d',strtotime($record["Receive"])) : ''; ?>" name="Receive" type="text">
	</div>
	<div class="form-group"> 
		<label class="control-label">TG/ Thôi việc </label>
		<input class="form-control form_datetime" value="<?php echo @$record["Time_Out_Word"] != null && @$record["Time_Out_Word"] != '0000-00-00' ? date('Y/m/d',strtotime($record["Time_Out_Word"])) : ''; ?>" name="Time_Out_Word" type="text">
	</div>
	<div class="form-group"> 
		<label class="control-label">Phòng ban</label>
		<select class="form-control" name="Department_ID">
			<option value="0">Chọn phòng ban</option>
			<?php if(isset($departments) && $departments != null): ?>
				<?php foreach ($departments as $key => $item): ?>
					<option <?php echo $item['ID'] == @$record['Department_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group"> 
		<label class="control-label">Chức vụ</label>
		<select class="form-control" name="Position_ID">
			<option value="0">Chọn chức vụ</option>
			<?php if(isset($positions) && $positions != null): ?>
				<?php foreach ($positions as $key => $item): ?>
					<option <?php echo $item['ID'] == @$record['Position_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group"> 
		<label class="control-label">Trạng thái <span class="required">*</span></label>
		<select class="form-control" name="Is_Active">
			<option value="1">Hoạt động</option>
			<option value="0" <?php echo @$record["Is_Active"] != null && @$record["Is_Active"] == 0 ? 'selected' : ''; ?>>Ngưng hoạt động</option>
		</select>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>