<form class="form-label-left form-user" id="form-common-edit-add" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="row">
		<div class="col-md-12">
			<div class="row form-group"> 
				<label class="control-label col-md-12">Phòng ban</label>
				<div class="col-md-12">
					<input class="form-control" value="<?php echo @$record["DepartmentName"]; ?>" type="text" readonly>
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Chức danh</label>
				<div class="col-md-12">
					<input class="form-control" value="<?php echo @$record["DesignationName"]; ?>" type="text" readonly>
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Thời gian bắt đầu</label>
				<div class="col-md-12">
					<input class="form-control" value="<?php echo date($date_format,strtotime(@$record["Start_Date"])); ?>" type="text" readonly>
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Thời gian kết thúc</label>
				<div class="col-md-12">
					<input class="form-control form_datetime" value="<?php echo @$record["End_Date"] != null && @$record["End_Date"] != '0000-00-00' ? date($date_format,strtotime($record["End_Date"])) : ''; ?>" name="End_Date" type="text">
				</div>
			</div>
		</div>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group" style="text-align: center;">
	    <a onclick="$('.collapse-link-custom').trigger('click');return false;" href="javascript:;" class="btn btn-primary">Hủy bỏ</a>
		<button id="send" type="submit" class="btn btn-success relative">Lưu</button> 
	</div>
</form>