<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="box-common-edit-add relative" style="display: none;max-width: 800px;margin: 0 auto;">
			<a class="collapse-link-custom hidden"><i class="fa fa-chevron-up"></i></a>
			<div class="result-html">
			</div>
		</div>
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-12">
						<h2>
							<?php echo @$title_page; ?> 
						</h2>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
					<table class="table table-striped jambo_table bulk_action">
						<thead>
							<tr>
								<th>Stt</th>
								<th>Phòng ban</th>
								<th>Chức danh</th>
								<th>Thời gian bắt đầu</th>
								<th>Thời gian kết thúc</th>
								<th>Hành động</th>
							</tr>
						</thead>
						<tbody>
						    <?php if(isset($results) && $results != null): ?>
						        <?php foreach ($results as $key => $value): ?>
						    		<tr data-id="<?php echo $value['ID']; ?>">
										<td data-column="Stt"><?php echo $key+1;?></td>
										<td data-column="DepartmentName"><?php echo $value["DepartmentName"]; ?></td>
										<td data-column="DesignationName"><?php echo $value["DesignationName"]; ?></td>
										<td data-column="Start_Date"><?php echo date($date_format,strtotime($value["Start_Date"])); ?></td>
										<td data-column="End_Date"><?php echo $value["End_Date"] != null && $value["End_Date"] != '' ? date($date_format,strtotime($value["End_Date"])) : ''; ?></td>
										<td data-column="Action">
											<a class="is_ajax" href="<?php echo backend_url($folder_view."/history_edit/".$value["ID"]); ?>"><i class="fa fa-edit" aria-hidden="true"></i></a>
										</td>
									</tr>
							    <?php endforeach; ?>
						    <?php endif; ?>
						</tbody>
					</table>
				</div>
				<?php if(isset($this->pagination)): ?>
					<div class="row">
						<div class="col-sm-12 text-center">
							<?php echo @$this->pagination->create_links();?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function() {
		$("#form-common-edit-add .form_datetime").each(function(){
			$(this).datetimepicker({
		        format: 'Y/m/d',
		        timepicker: false,
		        autoclose: true,
		        todayBtn: true
		    });
		});

		$(document).on("click",".main-page .collapse-link-custom",function(e){
			$("body .box-common-edit-add").slideUp("slow");
			return false;
		});

		$(document).on("click",".main-page .is_ajax",function(e){
			$("#form-modal .modal-body .message").hide();
			var url = $(this).attr('href');
			var parents = $(this).parents("tr");
			$.ajax({
                type: 'POST',
                dataType:'html',
                url: url,
                data:{},
                success: function(html) {
                	if(html != -1){
                		$(".box-common-edit-add .result-html").html(html);
                		$("#form-common-edit-add .form_datetime").each(function(){
							$(this).datetimepicker({
						        format: 'Y/m/d',
						        timepicker: false,
						        autoclose: true,
						        todayBtn: true
						    });
						});
						$("html, body").animate({scrollTop:0}, 500);
						$("body .box-common-edit-add").slideDown("slow");
						$(".title-from-common").html("Cập nhật");
                	}
                    else{
                    	alert('Người dùng không tồn tại.');
                    }
                }
            });
            return false;
		});

		$(document).on('submit','#form-common-edit-add',function(){
			var current = $(this);
			var url = current.attr('action');
			$("#form-modal .modal-body .message").hide();
			var options = {
	            dataType:'json',
	            url: url,
	            success: function(data){
                    if(data['status'] == 'success'){
                        location.reload();
                    }
                    else if(data['status'] == 'fail'){
                    	$("#form-common-edit-add .alert-danger").html(data['message']).show();
                    	$("#form-common-edit-add").scrollTop(0);
                    }
                }
	        }; 
	        current.ajaxSubmit(options);
			return false;
		});
	});
</script>
<style type="text/css">
	.select2-container{width: 100% !important;}
	.box-common-edit-add{display: block;}
</style>