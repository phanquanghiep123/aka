<form class="form-label-left form-user" id="form-common-edit-add" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="row">
		<div class="col-md-6">
			<div class="row form-group"> 
				<label class="control-label col-md-12">Barcode</label>
				<div class="col-md-12">
					<input class="form-control" value="<?php echo @$record["Barcode"]; ?>" name="Barcode" type="text">
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Họ và tên <span class="required">*</span></label>
				<div class="col-md-12">
					<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required">
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Địa chỉ</label>
				<div class="col-md-12">
					<input class="form-control" value="<?php echo @$record["Address"]; ?>" name="Address" type="text">
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Nơi sinh</label>
				<div class="col-md-12">
					<input class="form-control" value="<?php echo @$record["Birthplace"]; ?>" name="Birthplace" type="text">
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Ngày sinh</label>
				<div class="col-md-12">
					<input class="form-control form_datetime" value="<?php echo @$record["Birthday"] != null && @$record["Birthday"] != '0000-00-00' ? date('Y/m/d',strtotime($record["Birthday"])) : ''; ?>" name="Birthday" type="text">
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Ngày cấp</label>
				<div class="col-md-12">
					<input class="form-control form_datetime" value="<?php echo @$record["Date_Of_Issue"] != null && @$record["Date_Of_Issue"] != '0000-00-00' ? date('Y/m/d',strtotime($record["Date_Of_Issue"])) : ''; ?>" name="Date_Of_Issue" type="text">
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Tiếp nhận</label>
				<div class="col-md-12">
					<input class="form-control form_datetime" value="<?php echo @$record["Receive"] != null && @$record["Receive"] != '0000-00-00' ? date('Y/m/d',strtotime($record["Receive"])) : ''; ?>" name="Receive" type="text">
				</div>
			</div>
			<div class="form-group"> 
				<label class="control-label">Ảnh đại diện</label>
				<input name="avatar" type="file" accept="images/*">
				<?php if(@$record["User_Avatar"] != null): ?>
					<div style="height: 15px;"></div>
					<img src="<?php echo base_url($record["User_Avatar"]); ?>" width="100px;">
				<?php endif; ?>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Phòng ban <span class="required">*</span></label>
				<div class="col-md-12">
					<select class="form-control" name="Department_ID">
						<option value="">Chọn phòng ban</option>
						<?php if(isset($departments) && $departments != null): ?>
							<?php foreach ($departments as $key => $item): ?>
								<option <?php echo $item['ID'] == @$department['Department_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
							<?php endforeach; ?>
						<?php endif; ?>
					</select>
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Chức danh <span class="required">*</span></label>
				<div class="col-md-12">
					<select class="form-control" name="Designation_ID">
						<option value="">Chọn chức danh</option>
						<?php if(isset($designation) && $designation != null): ?>
							<?php foreach ($designation as $key => $item): ?>
								<option <?php echo $item['ID'] == @$department['Designation_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
							<?php endforeach; ?>
						<?php endif; ?>
					</select>
				</div>
			</div>
		</div>
		<div class="col-md-6">
	        <div class="row form-group"> 
				<label class="control-label col-md-12">Số điện thoại</label>
				<div class="col-md-12">
					<input class="form-control" value="<?php echo @$record["Phone"]; ?>" name="Phone" type="text">
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Giới tính</label>
				<div class="col-md-12">
					<select class="form-control" name="Gender">
						<option value="1">Nam</option>
						<option <?php echo @$record["Gender"] != null && @$record["Gender"] == 0 ? 'selected' : ''; ?> value="0">Nữ</option>
					</select>
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">CMND <span class="required">*</span></label>
				<div class="col-md-12">
					<input class="form-control" value="<?php echo @$record["CMND"]; ?>" name="CMND" type="text" required>
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Nơi cấp</label>
				<div class="col-md-12">
					<input class="form-control" value="<?php echo @$record["Issued_By"]; ?>" name="Issued_By" type="text">
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">TG/ Thôi việc </label>
				<div class="col-md-12">
					<input class="form-control form_datetime" value="<?php echo @$record["Time_Out_Word"] != null && @$record["Time_Out_Word"] != '0000-00-00' ? date('Y/m/d',strtotime($record["Time_Out_Word"])) : ''; ?>" name="Time_Out_Word" type="text">
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Trạng thái <span class="required">*</span></label>
				<div class="col-md-12">
					<select class="form-control" name="Is_Active">
						<option value="1">Hoạt động</option>
						<option value="0" <?php echo @$record["Is_Active"] != null && @$record["Is_Active"] == 0 ? 'selected' : ''; ?>>Ngưng hoạt động</option>
					</select>
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Ngày bắt đầu công việc <span class="required">*</span></label>
				<div class="col-md-12">
					<input class="form-control form_datetime required" value="<?php echo @$department["Start_Date"] != null && @$department["Start_Date"] != '0000-00-00' ? date('Y/m/d',strtotime($department["Start_Date"])) : ''; ?>" name="NgayLam" type="text">
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label col-md-12">Ngày kết thúc</label>
				<div class="col-md-12">
					<input class="form-control form_datetime" value="" name="End_Date" type="text">
				</div>
			</div>
			<div class="row form-group"> 
				<label class="control-label">File đính kèm</label>
				<input name="files[]" multiple type="file" accept="application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,image/*,application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
				<div style="height: 15px;"></div>
				<ul>
					<?php if(@$media != null && @$record["ID"] != null): ?>
						<?php foreach ($media as $key => $item): ?>
							<li>
								<a href="<?php echo base_url($item['URL']); ?>" target="_blank"><?php echo $item['Name'].@$item['FileType']; ?></a>
								<a href="<?php echo backend_url($folder_view."/remove_media/".$record["ID"] ."/".$item['ID']); ?>" class="remove-media" data-id="<?php echo $item['ID']; ?>" style="color: #ff0000;margin-left: 10px;"><i class="fa fa-times" aria-hidden="true"></i></a>
							</li>
						<?php endforeach; ?>
					<?php endif; ?>
				</ul>
			</div>
		</div>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group" style="text-align: center;">
	    <a onclick="$('.collapse-link-custom').trigger('click');return false;" href="javascript:;" class="btn btn-primary">Hủy bỏ</a>
		<button id="send" type="submit" class="btn btn-success relative">Lưu</button> 
	</div>
</form>