<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-8">
						<h2>
							<?php echo @$title_page; ?> 
							<a class="btn btn-success create-item is_ajax" href="<?php echo backend_url($folder_view."/add");?>"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Thêm mới</a>
						</h2>
					</div>
					<div class="col-sm-4">
						<form method="" method="get">
							<div class="row">
								<div class="col-sm-8">
									<div class="form-group">
										<input type="text" class="form-control" placeholder="Từ khóa" name="keyword" value="<?php echo $this->input->get('keyword'); ?>">
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<button type="submit" class="btn btn-primary">Tìm kiếm</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
					<table class="table table-striped jambo_table bulk_action">
						<thead>
							<tr>
								<th>Stt </th>
								<th>Tên</th>
								<th>Tên bang2</th>
								<th>Trạng thái </th>
								<th>Ngày tạo</th>
								<th>Hành động</th>
							</tr>
						</thead>
						<tbody>
						    <?php if(isset($results) && $results != null): ?>
						        <?php foreach ($results as $key => $value): ?>
						    		<tr data-id="<?php echo $value['ID']; ?>">
										<td data-column="Stt"><?php echo $key+1;?></td>
										<td data-column="ten"><?php echo $value["ten"]; ?></td>
										<td data-column="ten_bang2"><?php echo $value["ten_bang2"]; ?></td>
										<td data-column="status"><?php echo ($value["status"] == 1) ? "Hoạt động" : "Ngừng hoạt động";?></td>
										<td data-column="ngay"><?php echo date($datetime_format,strtotime($value["ngay"])); ?></td>
										<td data-column="Action">
											<a  href="<?php echo backend_url($folder_view."/edit/".$value["ID"])?>"><i class="fa fa-edit" aria-hidden="true"></i></a>
											<a  onclick="return confirm('Bạn thật sự muốn xóa?');" href="<?php echo backend_url($folder_view.'/delete/'.$value["ID"])?>"><i class="fa fa-trash" aria-hidden="true"></i></a> 
										</td>
									</tr>
							    <?php endforeach; ?>
						    <?php endif; ?>
						</tbody>
					</table>
				</div>
				<?php if(isset($this->pagination)): ?>
					<div class="row">
						<div class="col-sm-12 text-center">
							<?php echo @$this->pagination->create_links();?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>