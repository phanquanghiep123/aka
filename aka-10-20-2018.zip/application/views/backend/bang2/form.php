<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="form-group"> 
		<label class="control-label">Tên <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["ten"]; ?>" name="ten" type="text" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Trạng thái <span class="required">*</span></label>
		<select class="form-control" name="status">
			<option value="1">Hoạt động</option>
			<option value="0" <?php echo @$record["status"] != null && @$record["status"] == 0 ? 'selected' : ''; ?>>Ngưng hoạt động</option>
		</select>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>