<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tên nhà cung cấp <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Địa chỉ</label>
				<input class="form-control" value="<?php echo @$record["Address"]; ?>" name="Address" type="text">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Số điện thoại</label>
				<input class="form-control" value="<?php echo @$record["SDT"]; ?>" name="SDT" type="text">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tên công ty</label>
				<input class="form-control" value="<?php echo @$record["CompanyName"]; ?>" name="CompanyName" type="text">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">MST</label>
				<input class="form-control" value="<?php echo @$record["MST"]; ?>" name="MST" type="text">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Ngân hàng</label>
				<input class="form-control" value="<?php echo @$record["NganHang"]; ?>" name="NganHang" type="text">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tài khoản ngân hàng</label>
				<input class="form-control" value="<?php echo @$record["TaiKhoanNganHang"]; ?>" name="TaiKhoanNganHang" type="text">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Địa chỉ website</label>
				<input class="form-control" value="<?php echo @$record["Website"]; ?>" name="Website" type="text">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">Ghi chú</label>
				<textarea class="form-control" rows="6" name="GhiChu"><?php echo @$record["GhiChu"]; ?></textarea>
			</div>
		</div>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>