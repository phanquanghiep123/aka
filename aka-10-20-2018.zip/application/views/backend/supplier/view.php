<div class="form-horizontal form-label-left">
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tên nhà cung cấp</label>
				<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Địa chỉ</label>
				<input class="form-control" value="<?php echo @$record["Address"]; ?>" name="Address" type="text" readonly>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Số điện thoại</label>
				<input class="form-control" value="<?php echo @$record["SDT"]; ?>" name="SDT" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tên công ty</label>
				<input class="form-control" value="<?php echo @$record["CompanyName"]; ?>" name="CompanyName" type="text" readonly>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">MST</label>
				<input class="form-control" value="<?php echo @$record["MST"]; ?>" name="MST" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Ngân hàng</label>
				<input class="form-control" value="<?php echo @$record["NganHang"]; ?>" name="NganHang" type="text" readonly>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tài khoản ngân hàng</label>
				<input class="form-control" value="<?php echo @$record["TaiKhoanNganHang"]; ?>" name="TaiKhoanNganHang" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Địa chỉ website</label>
				<input class="form-control" value="<?php echo @$record["Website"]; ?>" name="Website" type="text" readonly>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">Ghi chú</label>
				<textarea class="form-control" rows="6" name="GhiChu" readonly><?php echo @$record["GhiChu"]; ?></textarea>
			</div>
		</div>
	</div>
	<div class="ln_solid"></div>
	<div class="text-right">
		<button type="button" class="btn btn-primary" data-dismiss="modal">Đóng</button>
	</div>
</div>