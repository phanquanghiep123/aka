<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="box-common-edit-add relative" style="display: none;">
			<a class="collapse-link-custom" href="#" style="color: #ff0000;"><i class="fa fa-times" aria-hidden="true"></i></a>
			<div class="form-slider" style="max-width: 600px;margin:0 auto;"></div>
			<hr />
		</div>
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-8">
						<h2>
							<?php echo @$title_page; ?> 
							<a class="btn btn-success create-item is_ajax" href="<?php echo backend_url($folder_view."/add");?>"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Thêm mới</a>
						</h2>
					</div>
					<div class="col-sm-4">
						<form method="" method="get">
							<div class="row">
								<div class="col-sm-8">
									<div class="form-group">
										<input type="text" class="form-control" placeholder="Từ khóa" name="keyword" value="<?php echo $this->input->get('keyword'); ?>">
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<button type="submit" class="btn btn-primary">Tìm kiếm</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
					<table class="table table-striped jambo_table bulk_action">
						<thead>
							<tr>
								<th class="text-center">Stt </th>
								<th class="text-center">Tên đăng nhập</th>
								<th class="text-center">Email </th>
								<th class="text-center">Họ và tên</th>
								<th class="text-center">Quyền </th>
								<th class="text-center">Trạng thái </th>
								<th class="text-center">Ngày tạo </th>
								<th class="text-center">Hành động</th>
							</tr>
						</thead>
						<tbody>
						    <?php if(isset($results) && $results != null): ?>
						        <?php foreach ($results as $key => $value): ?>
						    		<tr data-id="<?php echo $value['ID']; ?>">
										<td data-column="Stt"><?php echo $key+1;?></td>
										<td data-column="User_Name"><?php echo $value["User_Name"]; ?></td>
										<td data-column="User_Email"><?php echo $value["User_Email"]; ?></td>
										<td data-column="Name"><?php echo $value["Name"]; ?></td>
										<td data-column="Role_Title"><?php echo $value["Role_Title"]; ?></td>
										<td data-column="Is_Login" class="text-center"><?php echo (@$value["Is_Login"] == "1") ? '<i class="fa fa-circle online" aria-hidden="true"></i>' : '<i class="fa fa-circle ofline" aria-hidden="true"></i>';?></td>
										<td data-column="Created_At"><?php echo date($datetime_format,strtotime($value["Created_At"])); ?></td>
										<td class="text-center" data-column="Action">
											<a class="status_ajax" href="<?php echo backend_url($folder_view."/status/".$value["ID"])?>" ><?php echo $value["Status"] == 1 ? '<i class="fa fa-lock" aria-hidden="true" title="Hoạt động"></i>' : '<i class="fa fa-unlock-alt" aria-hidden="true" title="Khóa"></i>'; ?></a> |
											<a class="is_ajax" href="<?php echo backend_url($folder_view."/edit/".$value["ID"])?>"><i class="fa fa-edit" aria-hidden="true"></i></a>
											<?php if($value["Is_Lock"] != 1):?> 
											 | <a class="is_ajax_delete" href="<?php echo backend_url($folder_view.'/delete/'.$value["ID"])?>"><i class="fa fa-trash" aria-hidden="true"></i></a> 
											<?php endif;?>
										</td>
									</tr>
							    <?php endforeach; ?>
						    <?php endif; ?>
						</tbody>
					</table>
				</div>
				<?php if(isset($this->pagination)): ?>
					<div class="row">
						<div class="col-sm-12 text-center">
							<?php echo @$this->pagination->create_links();?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('click','a.is_ajax',function(){
			$("#form-modal .modal-body .message").hide();
			var url = $(this).attr('href');
            $.ajax({
                type: 'POST',
                dataType:'html',
                url: url,
                data:{},
                success: function(html) {
                	if(html != -1){
                		$(".box-common-edit-add .form-slider").html(html);
                    	$(".box-common-edit-add").slideDown();
                    	$("body,html").animate({scrollTop:0}, 'slow');
                	}
                    else{
                    	alert('Người dùng không tồn tại.');
                    }
                }
            });
			return false;
		});

		$(document).on('click','a.is_ajax_delete',function(){
			if(confirm('Bạn thật sự muốn xóa?')){
				var current = $(this);
				var url = $(this).attr('href');
	            $.ajax({
	                type: 'POST',
	                dataType:'json',
	                url: url,
	                data:{},
	                success: function(data) {
	                	if(data['status'] == 'success'){
	                		current.parents('tr').remove();
	                		$('tr td[data-column="Stt"]').each(function(i){
	                    		$(this).html(i+1);
	                    	});
	                	}
	                }
	            });
            }
			return false;
		});

		$(document).on('click','a.status_ajax',function(){
			var current = $(this);
			var url = $(this).attr('href');
            $.ajax({
                type: 'POST',
                dataType:'json',
                url: url,
                data:{},
                success: function(data) {
                	if(data['status'] == 'success'){
                		var status = (data["is_status"] == 1) ? '<i class="fa fa-lock" aria-hidden="true" title="Hoạt động"></i>' : '<i class="fa fa-unlock-alt" aria-hidden="true" title="Khóa"></i>';
                		current.html(status);
                	}
                }
            });
			return false;
		});

		$(document).on('submit','.box-common-edit-add form',function(){
			var current = $(this);
			$(".box-common-edit-add .message").hide();
			var options = {
                dataType:'json',
                success: function(data){
                    if(data['status'] == 'success'){
                    	var fields = ["Name","Barcode","Created_At"];
                        if(data['action'] == 'add'){
                        	//window.location.reload();
                        	var html = '<tr data-id="' + data['responsive']['ID'] + '">';
                        		html += '	<td data-column="Stt"></td>';
                        		fields.forEach(function(element) {
								  	html += '<td data-column="' + element + '">' + data['responsive'][element] + '</td>';
								});
                        		html += '	<td data-column="Action">';
                        		html += '		<a class="status_ajax" href="<?php echo backend_url($folder_view."/status/"); ?>' + (data['responsive']['ID'] + '" >' + (data['responsive']['ID']["Status"] == 1) ? '<i class="fa fa-lock" aria-hidden="true" title="Hoạt động"></i>' : '<i class="fa fa-unlock-alt" aria-hidden="true" title="Khóa"></i>') + '</a>';
                        		html += '		<a class="is_ajax" href="<?php echo backend_url($folder_view."/edit/"); ?>' + data['responsive']['ID'] + '"><i class="fa fa-edit" aria-hidden="true"></i></a> | ';
								html += '		<a class="is_ajax_delete" href="<?php echo backend_url($folder_view.'/delete/'); ?>' + data['responsive']['ID'] + '"><i class="fa fa-trash" aria-hidden="true"></i></a>';
                        		html += '	</td>';
                        		html += '</tr>';
                        	$('.x_content table').prepend(html);

                        	$('tr td[data-column="Stt"]').each(function(i){
                        		$(this).html(i+1);
                        	});
                        }
                        else{
                        	fields.forEach(function(element) {
							  	$('tr[data-id="' + data['responsive']['ID'] + '"] td[data-column="' + element + '"]').html(data['responsive'][element]);
							});
                        }
                        $(".box-common-edit-add").slideUp();
                        window.location.reload();
                    }
                    else if(data['status'] == 'fail'){
                    	$(".box-common-edit-add .alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.ajaxSubmit(options);
			return false;
		});

		$(document).on('click','.btn-generate',function(){
			$('input[name="User_Pwd"]').attr('type','text').val(randomPassword(9));
			return false;
		});

		$('.collapse-link-custom').click(function(){
			$(".box-common-edit-add").slideUp();
			return false;
		});

		function randomPassword(length) {
		    var chars = "abcdefghijklmnopqrstuvwxyz!@#$%^&*()-+<>ABCDEFGHIJKLMNOP1234567890";
		    var pass = "";
		    for (var x = 0; x < length; x++) {
		        var i = Math.floor(Math.random() * chars.length);
		        pass += chars.charAt(i);
		    }
		    return pass;
		}
	});
</script>