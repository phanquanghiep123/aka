<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="form-group"> 
		<label class="control-label">Tên đăng nhập <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["User_Name"]; ?>" name="User_Name" type="text" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Email</label>
		<input class="form-control" value="<?php echo @$record["User_Email"]; ?>" name="User_Email" type="email">
	</div>
	<div class="form-group"> 
		<label class="control-label">Mật khẩu <?php echo @$type == 'add' ? '<span class="required">*</span>' : ''; ?></label>
		<div class="row">
			<div class="col-sm-9">
				<input class="form-control" name="User_Pwd" type="password" minlength="6" <?php echo @$type == 'add' ? 'required="required"' : ''; ?>>
			</div>
			<div class="col-sm-3">
				<button class="btn btn-primary btn-generate" type="button">Generate</button>
			</div>
		</div>
	</div>
	<div class="form-group"> 
		<label class="control-label">Nhân viên <span class="required">*</span></label>
		<a data-toggle="modal" class="modal-user-input" data-target="#user-modal" href="#">
			<?php $label = 'Chọn nhân viên'; ?>
			<?php if(isset($employees) && $employees != null): ?>
				<?php foreach ($employees as $key => $item): ?>
					<?php if($item['ID'] == @$record['Employee_ID']): ?>
						<?php $label = 'Bạn đã chon: '.$item['Name']; ?>
					<?php endif; ?>
				<?php endforeach; ?>
			<?php endif; ?>
			<?php echo $label; ?>
		</a>
	</div>
	<div class="form-group"> 
		<label class="control-label">Quyền <span class="required">*</span></label>
		<select class="form-control" name="Role_ID" required="">
			<option value="0">Chọn quyền</option>
			<?php if(isset($rols) && $rols != null): ?>
				<?php foreach ($rols as $key => $item): ?>
					<option <?php echo $item['ID'] == @$record['Role_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Role_Title']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group"> 
		<label class="control-label">Trạng thái <span class="required">*</span></label>
		<select class="form-control" name="Status">
			<option value="1">Hoạt động</option>
			<option value="0" <?php echo @$record["Status"] != null && @$record["Status"] == 0 ? 'selected' : ''; ?>>Khóa</option>
		</select>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" class="btn btn-default" onclick="$('.collapse-link-custom').trigger('click');return false;" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
	<!-- Modal -->
	<div id="user-modal" class="modal fade" role="dialog">
	    <div class="modal-dialog modal-md" style="max-width: 420px;">
	        <!-- Modal content-->
	        <div class="modal-content">
	            <div class="modal-header">
	                <button type="button" class="close" data-dismiss="modal" style="top:20px;font-size: 20px;">&times;</button>
	                <h4 class="modal-title">Nhân viên</h4>
	            </div>
	            <div style="height: 15px;"></div>
	            <div style="padding: 15px;">
	            	<div class="row">
						<div class="col-xs-1"></div>
						<div class="col-xs-6">
							<div class="form-group">
								<input type="text" class="form-control" id="keyword-name" placeholder="Từ khóa...">
							</div>
						</div>
						<div class="col-xs-5">
							<div class="form-group">
								<input type="text" class="form-control" id="keyword-position" placeholder="Từ khóa...">
							</div>
						</div>
					</div>
	            </div>
	            <div class="modal-body" style="height: 250px;overflow-y:auto;">
	                <ul>
		                <?php if(isset($employees) && $employees != null): ?>
							<?php foreach ($employees as $key => $item): ?>
								<li>
									<div class="row">
										<div class="col-xs-1">
											<input type="radio" id="user-<?php echo $item['ID']; ?>" name="Employee_ID" value="<?php echo $item['ID']; ?>" <?php echo $item['ID'] == @$record['Employee_ID'] ? 'checked' : ''; ?>>
										</div>
										<div class="col-xs-6">
											<label for="user-<?php echo $item['ID']; ?>">
												<span class="name"><?php echo $item['Name']; ?></span>
											</label>
										</div>
										<div class="col-xs-5">
											<label for="user-<?php echo $item['ID']; ?>">
												<span class="position"><?php echo @$item['DepartmentName']; ?></span>
											</label>
										</div>
									</div>
								</li>
							<?php endforeach; ?>
						<?php endif; ?>
					</ul>
	            </div>
	            <div class="modal-footer">
	                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	            </div>
	        </div>
	    </div>
	</div>
</form>
<style type="text/css">
	.modal-user-input{
		display: block;
	    padding: 6px 12px;
	    font-size: 14px;
	    line-height: 1.42857143;
	    color: #555;
	    background-color: #fff;
	    background-image: none;
	    border: 1px solid #ccc;
	}
</style>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('keydown',function(e){
            var tag = e.target.tagName.toLowerCase();
            var id  = e.target.id;
            console.log(e.keyCode);
            if (id == 'keyword-name' || id == 'keyword-position') {
                var searchStringName = $('#keyword-name').val();
				var searchStringPostion = $('#keyword-position').val();
	            if((searchStringName != null && searchStringName != '') || (searchStringPostion != null && searchStringPostion != '')){
	            	var results = $('#user-modal .modal-body ul li');
                	results.each(function(i){
                		var str1 = $(this).find('.position').text();
                		var str2 = $(this).find('.name').text();
						if(str1.toLowerCase().indexOf(searchStringPostion.toLowerCase()) != -1 && str2.toLowerCase().indexOf(searchStringName.toLowerCase()) != -1){
						    $(this).show();
						}
						else{
							$(this).hide();
						}
	                });
	            }
	            else{
	            	$('#user-modal .modal-body ul li').removeClass('is_show').show();
	            } 
            }

            if (e.keyCode == 13) {               
			    e.preventDefault();
			    return false;
			}
        });

        $('#user-modal .modal-body ul li input[type="radio"]').click(function(){
    		var name = $(this).parents('li').find('.name').text();
    		var position = $(this).parents('li').find('.position').text();
    		if(position != '' && position != null){
    			name += ' ('+position+')';
    		}
    		$('.modal-user-input').html('Bạn đang chọn: ' + name);
			$('#user-modal').modal('hide');
		});
	});
</script>