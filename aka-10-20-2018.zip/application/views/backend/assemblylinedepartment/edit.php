<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-12">
						<h2><?php echo @$title_page; ?> </h2>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
				    <?php 
					    if($this->session->flashdata('record')){
					    	$record = $this->session->flashdata('record');
					    	$employees = @$record['employee'];
					    } 
					    $html = '';
					    if(isset($employee) && $employee != null){
					    	foreach ($employee as $key => $item) {
					    		$html .= '<option value="'.$item['ID'].'">'.$item['Name'].'</option>';
					    	}
					    }
				    ?>
				    <form action="" method="post">
						<table class="table table-striped jambo_table bulk_action">
							<tbody>
								<?php $soluong = 0; ?>
							    <?php if(isset($results) && $results != null): ?>
							        <?php foreach ($results as $key => $item): ?>
							        	<?php $soluong = $item['ScenarioSoLuong']; ?>
							    		<tr>
											<td><?php echo $key+1;?></td>
											<td><?php echo $item["ScenarioName"]; ?></td>
											<td><?php echo $item["ProcessName"]; ?></td>
											<td><?php echo number_format($item["WorkStation_ID"]); ?></td>
											<td><?php echo @$item['SoLuong']; ?></td>
											<td>
												<select class="form-control employee" data-value="<?php echo @$employees[$item['ID']] != null ? @$employees[$item['ID']] : @$item['Employee_ID']; ?>" name="employee[<?php echo $item['ID']; ?>]">
													<option value="">Chọn nhân viên</option>
													<?php echo $html; ?>
												</select>
											</td>
										</tr>
								    <?php endforeach; ?>
							    <?php endif; ?>
							</tbody>
							<thead>
								<tr class="headings">
									<th>STT</th>
									<th>Kịch bản</th>
									<th>Quy trình</th>
									<th>Trạm làm việc</th>
									<th>Số lượng (Tổng: <?php echo $soluong; ?>)</th>
									<th>Nhân viên</th>
								</tr>
							</thead>
						</table>
						<div class="form-group text-right">
							<a class="btn btn-default" href="<?php echo backend_url($folder_view);?>">Quay lại</a>
							<button type="submit" class="btn btn-success">Cập nhật</button> 
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$('.jambo_table select.employee').each(function(){
			var val = $(this).attr('data-value');
			if(val != 0){
				$(this).val(val);
			}
		});
	});
</script>