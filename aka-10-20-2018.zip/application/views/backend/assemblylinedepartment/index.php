<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="box-common-edit-add relative" style="display: none;">
			<a class="collapse-link-custom" href="#" style="color: #ff0000;"><i class="fa fa-times" aria-hidden="true"></i></a>
			<div class="form-slider" style="max-width: 600px;margin:0 auto;"></div>
		</div>
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-8">
						<h2><?php echo @$title_page; ?> </h2>
					</div>
					<div class="col-sm-4">
						<form method="" method="get">
							<div class="row">
								<div class="col-sm-8">
									<div class="form-group">
										<input type="text" class="form-control" placeholder="Từ khóa" name="keyword" value="<?php echo $this->input->get('keyword'); ?>">
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<button type="submit" class="btn btn-primary">Tìm kiếm</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
					<table class="table table-striped jambo_table bulk_action">
						<thead>
							<tr class="headings">
								<th>STT</th>
								<th>Kịch bản</th>
								<th>Quy trình</th>
								<th>Số trạm làm việc</th>
								<th>Ngày tạo</th>
								<th>Hành động</th>
							</tr>
						</thead>
						<tbody>
						    <?php if(isset($results) && $results != null): ?>
						        <?php foreach ($results as $key => $value): ?>
						    		<tr data-id="<?php echo $value['ID']; ?>">
										<td data-column="Stt"><?php echo $key+1;?></td>
										<td data-column="ScenarioName"><?php echo $value["ScenarioName"]; ?></td>
										<td data-column="ProcessName"><?php echo $value["ProcessName"]; ?></td>
										<td data-column="SoTram"><?php echo number_format($value["SoTram"]); ?></td>
										<td data-column="Created_At"><?php echo date($datetime_format,strtotime($value["Created_At"])); ?></td>
										<td data-column="Action">
											<a title="Chỉnh sửa" href="<?php echo backend_url($folder_view."/edit/".$value["Scenario_ID"])?>"><i class="fa fa-edit" aria-hidden="true"></i></a>
										</td>
									</tr>
							    <?php endforeach; ?>
						    <?php endif; ?>
						</tbody>
					</table>
				</div>
				<?php if(isset($this->pagination)): ?>
					<div class="row">
						<div class="col-sm-12 text-center">
							<?php echo @$this->pagination->create_links();?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>