<!-- page content -->
<div class="main-page <?php echo @$main_page;?>">
  
    <!-- top tiles -->
    <div class="row tile_count">
      <div class="col-md-12 tile_stats_count">
        <h3 style="text-align: center; color: red;">Bạn không được cấp phép sử dụng chức năng này !</h3>
      </div>
    </div>
  </div>
<!-- /page content -->