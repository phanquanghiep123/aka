<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="form-group"> 
		<label class="control-label">Tên nguyên phụ liệu <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Code <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Code"]; ?>" name="Code" type="text" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Trạng thái <span class="required">*</span></label>
		<select class="form-control" name="Status">
			<option value="1">Hoạt động</option>
			<option value="0" <?php echo @$record["Status"] != null && @$record["Status"] == 0 ? 'selected' : ''; ?>>Ngưng hoạt động</option>
		</select>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>