<div class="main-page <?php echo @$main_page;?>">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<h2>Quản Lý Vai Trò Hệ Thống  <a class="btn btn-success create-item" href="<?php echo backend_url("sysroles/create");?>"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Thêm mới</a></h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view("backend/includes/messenger");?>
					<table id="sys-roles" class="table table-striped jambo_table bulk_action">
						<thead>
							<tr class="headings">
								<th class="column-title">Stt </th>
								<th class="column-title">Tên vai trò </th>
								<th class="column-title">Mô tả</th>
								<th class="column-title">Trạng thái</th>
								<th class="column-title">Ngày tạo </th>
								<th class="column-title no-link last"><span class="nobr">Hành động</span> </th>
							</tr>
						</thead>
						<tbody>
						    <?php
						        if(isset($table_data)){
						        	$i = 1;
						        	foreach ($table_data as $key => $value) {?>
							    		<tr class="even pointer">
											<td class="a-center "> <?php echo $i++;?> </td>
											<td><?php echo $value["Role_Title"]; ?></td>
											<td><?php echo $value["Role_Description"]; ?></td>
											<td><?php echo $value["Status"] == 1 ? 'Hoạt động' : 'Ngưng hoạt động'; ?></td>
											<td><?php echo date('d/m/Y', strtotime($value["Created_At"])); ?></td>
											<td class="last">
												<a href="<?php echo backend_url('sysroles/unactive/'.$value["ID"])?>" title="<?php echo $value["Status"] == 1 ? 'Hoạt động' : 'Ngưng hoạt động'; ?>"><?php echo ($value["Status"] == "1") ? '<i class="fa fa-lock" aria-hidden="true"></i>' : '<i class="fa fa-unlock-alt" aria-hidden="true"></i>'; ?></a> 
												| <a href="<?php echo backend_url('sysroles/edit/'.$value["ID"])?>" title="Chỉnh sửa"><i class="fa fa-edit" aria-hidden="true"></i></a>
												<?php if($value["System_Default"] != '1'):?> 
													| 
													<a onclick="return confirm('Bạn thật sự muốn xóa?');" href="<?php echo backend_url('sysroles/delete/'.$value["ID"])?>" title="Xóa"><i class="fa fa-trash-o" aria-hidden="true"></i></a> 
													| 
													<a data-href="<?php echo backend_url('sysroles/details/'.$value["ID"])?>" id="open_modal_details" href="javascript:;" title="Gán quyền"><i class="fa fa-shield" aria-hidden="true"></i></a> 
												<?php endif;?>
											</td>
										</tr>
							    	<?php }
						        }
						    	
						    ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	$(document).on("click","#open_modal_details",function(){
		var url = $(this).data("href");
		$.ajax({
			url : url,
			success: function(r){
				$("#form-modal .result-form").html(r);
				$("#form-modal").modal();
			}
		});
	})
	$(document).on("click",".js-switch",function(){
		if($(this).is(':checked')){
			$(this).val(1);
			$(this).parent().find(".allow").val(1);
		}else{
			$(this).parent().find(".allow").val(0);
			$(this).val(0);
		}
	});
	$(document).on("submit","#details-submit",function(){
		var data = $(this).serializeArray();
		var url = $(this).attr("action");
		$.ajax({
			url      : url,
			type     : "post",
			dataType : "json",
			data     : data ,
			success  : function(r){
				console.log(r);
				if(r['status'] == 'success'){
					alert('Cập nhật thành công.');
					location.reload();
				}
			}
		});
		return false;
	})
</script>
<style type="text/css">
	#form-modal .modal-dialog{
		width: 800px !important;
    	max-width: 100% !important;
	}
</style>