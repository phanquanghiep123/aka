<div class="x_panel">
	<div class="x_title">
		<h2>Cập nhật quyền sử dụng hệ thống
			<?php echo @$record["Module_Name"];?>
		</h2>
		<div class="clearfix"></div>
	</div>
	<div class="x_content">
	    <?php $this->load->view("backend/includes/messenger");?>
		<form action="<?php echo backend_url("/sysroles/details/".@$Role_ID)?>" id="details-submit" class="form-horizontal form-label-left" method="post" action="">
		    <div class="table-responsive">
				<table class="table table-striped jambo_table bulk_action">
					<thead>
						<tr class="headings">
							<th class="column-title">Stt </th>
							<th colspan="2" class="column-title">Tên hệ thống </th>
							<th style="width: 125px;" class="column-title">Quyền sử dụng</th>
						</tr>
					</thead>
					<tbody>
			    		<?php echo @$html_modules;?>								
					</tbody>
				</table>
			</div>
			<div class="row">
				<div class="col-xs-12 text-right">
					<button type="submit" class="btn btn-success"></span> Cập nhật</button>
				</div>
			</div>
		</form>
	</div>
</div>
