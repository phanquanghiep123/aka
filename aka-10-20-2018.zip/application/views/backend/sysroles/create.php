<div class="main-page <?php echo @$main_page;?>">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<h2>Thêm mới vai trò hệ thống</h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
			    <?php $this->load->view("backend/includes/messenger");?>
				<form class="form-horizontal form-label-left" method="post">
					<div class="item form-group"> 
						<label class="control-label col-md-3 col-sm-3 col-xs-12" for="Role_Title">Tên vai trò <span class="required">*</span></label>
						<div class="col-md-6 col-sm-6 col-xs-12"> <input id="Role_Title" class="form-control col-md-7 col-xs-12" value="<?php echo @$post["Role_Title"];?>" name="Role_Title" placeholder="Tên vai trò" required="required" type="text"> </div>
					</div>
					<div class="item form-group"> 
						<label class="control-label col-md-3 col-sm-3 col-xs-12" for="Role_Description">Mô tả</label>
						<div class="col-md-6 col-sm-6 col-xs-12"> <input id="Role_Description" class="form-control col-md-7 col-xs-12" value="<?php echo @$post["Role_Description"];?>" name="Role_Description" placeholder="Mô tả" type="text"> </div>
					</div>
					<div class="item form-group"> 
						<label class="control-label col-md-3 col-sm-3 col-xs-12" for="Status">Trạng thái<span class="required">*</span></label>
						<div class="col-md-6 col-sm-6 col-xs-12"> 
							<select id="Status" class="form-control col-md-7 col-xs-12" name="Status" required="required">   
						    	<option value="1">Hoạt động</option>
							    <option value="0">Ngưng hoạt động</option>
							</select>
						</div>
					</div>
					<div class="ln_solid"></div>
					<div class="form-group">
						<div class="col-md-6 col-md-offset-3"><a href="<?php echo backend_url("sysroles");?>" class="btn btn-primary">Trở lại</a><button id="send" type="submit" class="btn btn-success">Thêm mới</button> </div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>