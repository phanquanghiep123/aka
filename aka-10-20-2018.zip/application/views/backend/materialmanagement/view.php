<div class="form-horizontal form-label-left">
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tên danh mục</label>
				<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Barcode</label>
				<input class="form-control" value="<?php echo @$record["Barcode"]; ?>" name="Barcode" type="text" readonly>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Trạng thái</label>
				<input class="form-control" value="<?php echo @$record["Status"] == 0 ? 'Tạm khóa' : 'Kích hoạt'; ?>" name="Barcode" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Đơn vị tính</label>
				<?php if(isset($dvt_result) && $dvt_result != null): ?>
					<?php foreach ($dvt_result as $key => $item): ?>
						<?php if($item['ID'] == @$record['DVT_ID']): ?>
							<input class="form-control" value="<?php echo @$item["Name"]; ?>" type="text" readonly>
						<?php endif; ?>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Mô tả</label>
				<textarea class="form-control" style="max-width: 100%;" readonly name="Description" rows="4"><?php echo @$record["Description"]; ?></textarea>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Hình ảnh</label>
				<?php if(@$record["URL_Image"] != null): ?>
					<img src="<?php echo base_url($record["URL_Image"]); ?>" class="img-responsive">
				<?php endif; ?>
			</div>
		</div>
	</div>
	<div class="ln_solid"></div>
	<div class="text-right">
		<button type="button" class="btn btn-primary" data-dismiss="modal">Đóng</button>
	</div>
</div>