<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tên danh mục <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Hình ảnh</label>
				<input name="Image" type="file"  accept="image/*">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">Đơn vị tính <span class="required">*</span></label>
				<select class="form-control" name="DVT_ID" required="required">
					<option value="">Chọn</option>
					<?php if(isset($dvt_result) && $dvt_result != null): ?>
						<?php foreach ($dvt_result as $key => $item): ?>
							<option <?php echo $item['ID'] == @$record['DVT_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">Mô tả</label>
				<textarea class="form-control" name="Description" rows="6"><?php echo @$record["Description"]; ?></textarea>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">Trạng thái <span class="required">*</span></label>
				<select class="form-control" name="Status" required="">
					<option value="1">Kích hoạt</option>
					<option value="0" <?php echo @$record["Status"] != null && @$record["Status"] == 0 ? 'selected' : ''; ?>>Tạm khóa</option>
				</select>
			</div>
		</div>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>