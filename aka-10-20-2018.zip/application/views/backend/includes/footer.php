                    </div>
                    <!--end row-->
                </div>
                <!-- footer content -->
                <footer style="background: #F7F7F7;" class="<?php echo @$footer_class;?>">
                      <div class="pull-right">© 2017 <a href="http://aka.vn">AKA</a>. All Rights Reserved.</div>
                      <div class="clearfix"></div>
                </footer>
                <!-- /footer content -->
            </div>
        </div>

        <div class="custom-loading" style="display: none;">
            <div>
                <img width="32" src="<?php echo skin_url('images/loading.gif'); ?>">
            </div>
        </div>

        <!-- Modal -->
        <div id="form-modal" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
            <div class="modal-dialog modal-lg">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><?php echo @$title_page; ?> </h4>
                    </div>
                    <div class="modal-body">
                        <div class="message alert alert-success" style="display: none;"></div>
                        <div class="message alert alert-danger" style="display: none;"></div>
                        <div class="result-form"></div>
                    </div>
                </div>
            </div>
        </div>
        <style type="text/css">
            .custom-loading {
                position: fixed;
                top: 0;
                bottom: 0;
                left: 0;
                right: 0;
                background: rgba(0, 0, 0, 0.55);
                z-index: 99999999;
                display: none;
            }
            .custom-loading > div {
                text-align: center;
                position: absolute;
                top: 43%;
                left: 0;
                width: 100%;
            }
            .calendar-table thead td,
            .calendar-table thead th{color: #000;}
        </style>
        <script type="text/javascript">
            $(document).ready(function(){
                $(document).ajaxStart(function(){
                    $('.custom-loading').show();
                });

                $(document).ajaxSuccess(function (event,xhr,options,data) {
                    console.log(data);
                    console.log(options['data']);
                });

                $(document).ajaxError(function (event,xhr,options,exc) {
                    console.log(xhr['responseText']);
                });

                $(document).ajaxComplete(function(event, xhr, settings) {
                    $('.datetimepicker').each(function(){
                        var option = {format: "d/m/Y", timepicker: false};
                        if($(this).attr('max-date')){
                            option = {format: "d/m/Y", timepicker: false,maxDate: new Date};
                        }
                        $(this).datetimepicker(option);
                    });
                    $('.box-common-edit-add select').each(function(){
                        if(!$(this).hasClass('select2-hidden-accessible')){
                            var is_multiple = $(this).prop('multiple');
                            $(this).select2();
                            if(is_multiple){
                                $(this).on("select2:selecting", function(e) { 
                                    $(this).val(null).trigger('change');
                                });
                            }
                        }
                    });
                    $('#form-modal select').each(function(){
                        if(!$(this).hasClass('select2-hidden-accessible')){
                            var is_multiple = $(this).prop('multiple');
                            $(this).select2();
                            if(is_multiple){
                                $(this).on("select2:selecting", function(e) { 
                                    $(this).val(null).trigger('change');
                                });
                            }
                        }
                    });
                    $('#view-action-modal select').each(function(){
                        if(!$(this).hasClass('select2-hidden-accessible')){
                            var is_multiple = $(this).prop('multiple');
                            $(this).select2();
                            if(is_multiple){
                                $(this).on("select2:selecting", function(e) { 
                                    $(this).val(null).trigger('change');
                                });
                            }
                        }
                    });
                    $('.box-common-edit-add .color-picker').each(function(){
                        $(this).colorpicker().on('changeColor', function(ev){
                            $('.color-reference').css('background-color', ev.color.toHex());
                        });
                    });
                    $('#view-action-modal .color-picker').each(function(){
                        $(this).colorpicker().on('changeColor', function(ev){
                            $('.color-reference').css('background-color', ev.color.toHex());
                        });
                    });
                    if($('input[name="daterange"]').length > 0){
                        $('input[name="daterange"]').daterangepicker({
                            opens: 'left',
                            locale: {
                                format: 'YYYY/MM/DD'
                            }
                        }, function(start, end, label) {
                            //console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
                            $($(this)[0].element).parent().find('input[name="StartDate"]').val(start.format('YYYY/MM/DD'));
                            $($(this)[0].element).parent().find('input[name="EndDate"]').val(end.format('YYYY/MM/DD'));
                        });
                    }
                    $('.dataTable').each(function(){
                        if($(this).find('tbody > tr').length > 1){
                            $(this).find('tbody .dataTables_empty').hide();
                        }
                    });
                    $('.custom-loading').hide();
                });

                $('.main-page select').each(function(){
                    $(this).select2();
                });
                $('.color-picker').each(function(){
                    $(this).colorpicker();
                    $(this).on('colorpickerChange', function(event) {
                        $.find('.color-reference').css('background-color', event.color.toString());
                    });
                });
                $('input.format-number').mask("#,##0", {reverse: true});
            });
        </script>
        <!-- Bootstrap -->
        <script src="<?php echo skin_backend('vendors/bootstrap/dist/js/bootstrap.min.js');?>"></script>
        <!-- FastClick -->
        <script src="<?php echo skin_backend('vendors/fastclick/lib/fastclick.js');?>"></script>
        <!-- NProgress -->
        <script src="<?php echo skin_backend('vendors/nprogress/nprogress.js');?>"></script>
        <!-- Chart.js -->
        <script src="<?php echo skin_backend('vendors/Chart.js/dist/Chart.min.js');?>"></script>
        <!-- gauge.js -->
        <script src="<?php echo skin_backend('vendors/gauge.js/dist/gauge.min.js');?>"></script>
        <!-- bootstrap-progressbar -->
        <script src="<?php echo skin_backend('vendors/bootstrap-progressbar/bootstrap-progressbar.min.js');?>"></script>
        <!-- iCheck -->
        <script src="<?php echo skin_backend('vendors/iCheck/icheck.min.js');?>"></script>
        <!-- Skycons -->
        <script src="<?php echo skin_backend('vendors/skycons/skycons.js');?>"></script>
        <!-- Flot -->
        <script src="<?php echo skin_backend('vendors/Flot/jquery.flot.js');?>"></script>
        <script src="<?php echo skin_backend('vendors/Flot/jquery.flot.pie.js');?>"></script>
        <script src="<?php echo skin_backend('vendors/Flot/jquery.flot.time.js');?>"></script>
        <script src="<?php echo skin_backend('vendors/Flot/jquery.flot.stack.js');?>"></script>
        <script src="<?php echo skin_backend('vendors/Flot/jquery.flot.resize.js');?>"></script>
        <!-- Flot plugins -->
        <script src="<?php echo skin_backend('vendors/flot.orderbars/js/jquery.flot.orderBars.js');?>"></script>
        <script src="<?php echo skin_backend('vendors/flot-spline/js/jquery.flot.spline.min.js');?>"></script>
        <script src="<?php echo skin_backend('vendors/flot.curvedlines/curvedLines.js');?>"></script>
        <!-- DateJS -->
        <script src="<?php echo skin_backend('vendors/DateJS/build/date.js');?>"></script>
        <!-- JQVMap -->
        <script src="<?php echo skin_backend('vendors/jqvmap/dist/jquery.vmap.js');?>"></script>
        <script src="<?php echo skin_backend('vendors/jqvmap/dist/maps/jquery.vmap.world.js');?>"></script>
        <script src="<?php echo skin_backend('vendors/jqvmap/examples/js/jquery.vmap.sampledata.js');?>"></script>

        <script src="<?php echo skin_backend('build/js/custom.min.js');?>"></script>
        <script src="<?php echo skin_backend('vendors/switchery/dist/switchery.min.js');?>"></script>
        <script src="<?php echo skin_backend('js/main.js');?>"></script>
    </body>
</html>
