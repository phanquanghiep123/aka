<?php if(@$this->input->get("create") == "success"):?>
    <div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
	    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
	    <strong>Thêm mới thành công!</strong> Bạn có thể cập nhật dữ liệu tại đây
	</div>
<?php endif;?>
<?php if(@$this->input->get("edit") == "success"):?>
    <div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
	    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
	    <strong>Cập nhật thành công!</strong> Bạn có thể cập nhật dữ liệu tại đây
	</div>
<?php endif;?>
<?php if(@$post["status"] == "error"):?>
    <div class="alert alert-danger fade in alert-dismissable">
	    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
	    <strong>Lỗi thêm cập nhật!</strong> Vui lòng kiểm tra dữ liệu đầu vào
	    <?php echo @$post["error"];?>
	</div>
<?php endif;?>

<?php if(@$this->input->get("delete") == "success"):?>
    <div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
	    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
	    <strong>Xóa thành công!</strong>
	</div>
<?php endif;?>