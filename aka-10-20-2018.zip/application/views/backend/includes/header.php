<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!-- Meta, title, CSS, favicons, etc. -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>AKA <?php echo (@$title_page != null) ? " | ".$title_page : "";?></title>
        <link rel="shortcut icon" href="<?= base_url();?>skins/frontend/images/ico/favicon.ico">
        <!-- Bootstrap -->
        <link href="<?php echo skin_backend('vendors/bootstrap/dist/css/bootstrap.min.css');?>" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="<?php echo skin_backend('vendors/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet">
        <!-- NProgress -->
        <link href="<?php echo skin_backend('vendors/nprogress/nprogress.css');?>" rel="stylesheet">
        <!-- iCheck -->
        <link href="<?php echo skin_backend('vendors/iCheck/skins/flat/green.css');?>" rel="stylesheet">
      
        <!-- bootstrap-progressbar -->
        <link href="<?php echo skin_backend('vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css');?>" rel="stylesheet">
        <!-- JQVMap -->
        <link href="<?php echo skin_backend('vendors/jqvmap/dist/jqvmap.min.css');?>" rel="stylesheet"/>
        <!-- Custom Theme Style -->
        <link href="<?php echo skin_backend('build/css/custom.min.css');?>" rel="stylesheet">
        <link href="<?php echo skin_backend('vendors/switchery/dist/switchery.min.css');?>" rel="stylesheet">
        <link href="<?php echo skin_backend('css/style.css');?>" rel="stylesheet">
        <link href="<?php echo skin_backend('js/bootstrap-select/dist/css/bootstrap-select.min.css');?>" rel="stylesheet"/>
        <link href="<?php echo skin_backend("js/datetimepicker/jquery.datetimepicker.css");?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo skin_backend("js/datatables/dataTables.bootstrap.css");?>" rel="stylesheet">
        <link href="<?php echo skin_backend("lib/dist/fastselect.css");?>" rel="stylesheet">
        <link href="<?php echo skin_backend('vendors/select2/dist/css/select2.css');?>" rel="stylesheet"/>
        <link href="<?php echo skin_backend('css/bootstrap-colorpicker.css');?>" rel="stylesheet"/>
        <link href="<?php echo skin_backend('vendors/bootstrap-daterangepicker/daterangepicker.css');?>" rel="stylesheet"/>

        <script type="text/javascript">
            var base_url = "<?php echo backend_url(); ?>";
        </script>
        <script src="<?php echo skin_backend('vendors/jquery/dist/jquery.min.js');?>"></script>
        <script src="<?php echo skin_backend('js/datetimepicker/build/jquery.datetimepicker.full.js');?>"></script>
        <script src="<?php echo skin_backend("js/datatables/jquery.dataTables.min.js");?>"></script>
        <script src="<?php echo skin_backend("js/datatables/dataTables.bootstrap.min.js");?>"></script>
        <script src="<?php echo skin_backend("js/jquery.form.js")?>" type="text/javascript"></script>
        <script src="<?php echo skin_backend("js/jquery.mask.min.js")?>" type="text/javascript"></script>
        <script src="<?php echo skin_backend("js/bootstrap-select/dist/js/bootstrap-select.min.js")?>" type="text/javascript"></script>
        <script src="<?php echo skin_backend("lib/dist/fastselect.standalone.js")?>" type="text/javascript"></script>
        <script src="<?php echo skin_backend("vendors/select2/dist/js/select2.js")?>" type="text/javascript"></script>
        <script src="<?php echo skin_backend("js/bootstrap-colorpicker.js")?>" type="text/javascript"></script>
        <script src="<?php echo skin_backend("vendors/bootstrap-daterangepicker/moment.min.js")?>" type="text/javascript"></script>
        <script src="<?php echo skin_backend("vendors/bootstrap-daterangepicker/daterangepicker.js")?>" type="text/javascript"></script>
    </head>
    <body class="nav-md <?php echo @$body_class;?>">
        <div class="container body">
            <div class="main_container">
                <div class="col-md-3 left_col">
                    <div class="left_col scroll-view">
                        <div class="navbar nav_title" style="border: 0;">
                            <a href="<?php echo backend_url(); ?>" class="site_title"><img src="<?php echo skin_url("frontend/images/logo.png");?>"></a>
                        </div>
                        <div class="clearfix"></div>

                        <!-- menu profile quick info -->
                        <div class="profile clearfix">
                            <div class="profile_pic">
                                <?php if(@$admin_info["User_Avatar"] == ""):?>
                                    <img src="<?php echo skin_backend('images/img.jpg');?>" alt="..." class="img-circle profile_img">
                                <?php else:?>
                                    <img src="<?php echo base_url(@$admin_info["User_Avatar"]);?>" alt="..." class="img-circle profile_img">
                                <?php endif;?>
                            </div>
                            <div class="profile_info">
                                <span>Xin chào,</span>
                                <h2><?php echo @$admin_info["User_Name"];?></h2>
                            </div>
                        </div>
                        <!-- /menu profile quick info -->
                        <br>

                        <!-- sidebar menu -->
                        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                            <div class="menu_section active">
                                <?php echo @$_menu;?>
                            </div>
                        </div>
                        <!-- /sidebar menu -->

                        <!-- /menu footer buttons -->
                        <div class="sidebar-footer hidden-small">
                            <a data-toggle="tooltip" data-placement="top" title="" data-original-title="Settings">
                                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                            </a>
                            <a data-toggle="tooltip" data-placement="top" title="" data-original-title="FullScreen">
                                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
                            </a>
                            <a data-toggle="tooltip" data-placement="top" title="" data-original-title="Lock">
                                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
                            </a>
                            <a data-toggle="tooltip" data-placement="top" title="" href="<?php echo backend_url("acounts/logout");?>" data-original-title="Logout">
                                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                            </a>
                        </div>
                        <!-- /menu footer buttons -->
                    </div>
                </div>
                <!-- top navigation -->
                <div class="top_nav">
                    <div class="nav_menu">
                        <nav>
                            <div class="nav toggle">
                                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                            </div>
                            <ul class="nav navbar-nav navbar-right">
                                <li>
                                    <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                        <?php if(@$admin_info["User_Avatar"] == ""):?>
                                          <img src="<?php echo skin_url('backend/images/img.jpg');?>" alt="">
                                        <?php else:?>
                                          <img src="<?php echo base_url(@$admin_info["User_Avatar"]);?>" alt="">
                                        <?php endif;?>
                                        <?php echo @$admin_info["User_Name"];?>
                                        <span class=" fa fa-angle-down"></span>
                                    </a>
                                    <ul class="dropdown-menu dropdown-usermenu pull-right">
                                      <li><a href="<?php echo backend_url("profile");?>"> Thông tin cá nhân</a></li>
                                      <li><a href="<?php echo backend_url("acounts/logout");?>"><i class="fa fa-sign-out pull-right"></i> Đăng xuất - Thoát</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
                <!-- /top navigation -->
                <div class="right_col" role="main">
                    <div class="row">
                       <div class="col-md-12"><?php echo breadcrumb();?></div>
                    </div>
                    <div class="row">
          