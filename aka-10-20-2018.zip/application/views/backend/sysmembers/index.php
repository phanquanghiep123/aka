<div class="main-page <?php echo @$main_page;?>">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<h2>Quản Lý Người Dùng Hệ Thống  <a class="btn btn-success create-item" href="<?php echo backend_url("sysmembers/create");?>"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Thêm mới</a></h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view("backend/includes/messenger");?>
					<table class="table table-striped jambo_table bulk_action">
						<thead>
							<tr class="headings">
								<th class="column-title">Stt </th>
								<th class="column-title">Tên người dùng </th>
								<th class="column-title">Email </th>
								<th class="column-title">Ngày tạo </th>
								<th class="column-title">Avatar </th>
								<th class="column-title">Quyền </th>
								<th class="column-title">Online</th>
								<th class="column-title no-link last"><span class="nobr">Hành động</span> </th>
							</tr>
						</thead>
						<tbody>
						    <?php
						        if(isset($table_data)){
						        	$i = 1;
						        	foreach ($table_data as $key => $value) {?>
							    		<tr class="even pointer">
											<td class="a-center "> <?php echo $i++;?> </td>
											<td class=" "><?php echo $value["User_Name"]?></td>
											<td class=" "><?php echo $value["User_Email"]?></td>
											<td class=" "><?php echo $value["Created_At"]?></td>
											<td class=" "><?php echo ($value["User_Avatar"] != null) ? '<img style="max-width: 50px;" src= "'.base_url($value["User_Avatar"]).'">' : "" ;?></td>
											<td class=" "><?php if(isset($role)){
												foreach($role as $k => $v){
													if($v["ID"] == $value["Role_ID"]){
														echo $v["Role_Title"];
													}
												}
										    }?></td>
										    <td class=""><?php echo ($value["Status"] == "1") ? '<i class="fa fa-circle online" aria-hidden="true"></i>' : '<i class="fa fa-circle ofline" aria-hidden="true"></i>';?></td>
											<td class=" last"><a href="<?php echo backend_url('sysmembers/edit/'.$value["ID"])?>"><i class="fa fa-edit" aria-hidden="true"></i></a><?php if($value["Is_Lock"] != '1'):?> | <a onclick="return confirm('Bạn thật sự muốn xóa?');" href="<?php echo backend_url('sysmembers/delete/'.$value["ID"])?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a> <?php endif;?></td>
										</tr>
							    	<?php }
						        }
						    	
						    ?>
							
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>