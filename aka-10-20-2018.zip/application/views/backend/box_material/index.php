<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="box-common-edit-add relative" style="display: none;">
			<a class="collapse-link-custom" href="#" style="color: #ff0000;"><i class="fa fa-times" aria-hidden="true"></i></a>
			<div class="form-slider" style="max-width: 600px;margin:0 auto;"></div>
		</div>
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-6">
						<h2>
							<?php echo @$title_page; ?> 
							<a class="btn btn-success create-item is_ajax" href="<?php echo backend_url($folder_view."/add");?>"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Thêm mới</a>
							<a class="btn btn-success" href="<?php echo backend_url($folder_view."/export");?>"><i class="fa fa-download" aria-hidden="true"></i> Xuất Excel</a>
							<a class="btn btn-success" href="#<?php //echo backend_url($folder_view."/import");?>" data-toggle="modal" data-target="#upload-modal"><i class="fa fa-file-excel-o" aria-hidden="true"></i> Nhập Excel</a>
						</h2>
					</div>
					<div class="col-sm-6">
						<form method="" method="get">
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<select class="form-control" name="Box">
											<option value="">Hộp</option>
											<?php if(isset($box_result) && $box_result != null): ?>
												<?php foreach ($box_result as $key => $item): ?>
													<option <?php echo $item['ID'] == $this->input->get('Box') ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
												<?php endforeach; ?>
											<?php endif; ?>
										</select>
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<select class="form-control" name="DMVT">
											<option value="">Danh mục vật tư</option>
											<?php if(isset($dmvt_result) && $dmvt_result != null): ?>
												<?php foreach ($dmvt_result as $key => $item): ?>
													<option <?php echo $item['ID'] ==  $this->input->get('DMVT') ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
												<?php endforeach; ?>
											<?php endif; ?>
										</select>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="form-group">
										<button type="submit" class="btn btn-primary">Tìm kiếm</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
					<table class="table table-striped jambo_table bulk_action">
						<thead>
							<tr class="headings">
								<th>Stt </th>
								<th>Hộp</th>
								<th>Danh mục vật tư</th>
								<th>Số lượng</th>
								<th>Ngày Tạo</th>
								<th>Hành động</th>
							</tr>
						</thead>
						<tbody>
						    <?php if(isset($results) && $results != null): ?>
						        <?php foreach ($results as $key => $value): ?>
						    		<tr data-id="<?php echo $value['ID']; ?>">
										<td data-column="Stt"><?php echo $key+1;?></td>
										<td data-column="BoxName"><?php echo $value["BoxName"]; ?></td>
										<td data-column="DMVTName"><?php echo $value["DMVTName"]; ?></td>
										<td data-column="SoLuong"><?php echo $value["SoLuong"]; ?></td>
										<td data-column="Created_At"><?php echo date($datetime_format,strtotime($value["Created_At"])); ?></td>
										<td data-column="Action">
											<a class="is_ajax" title="Chỉnh sửa" href="<?php echo backend_url($folder_view."/edit/".$value["ID"])?>"><i class="fa fa-edit" aria-hidden="true"></i></a> | 
											<a class="is_ajax_delete" title="Xóa" href="<?php echo backend_url($folder_view.'/delete/'.$value["ID"])?>"><i class="fa fa-trash" aria-hidden="true"></i></a> 
										</td>
									</tr>
							    <?php endforeach; ?>
						    <?php endif; ?>
						</tbody>
					</table>
				</div>
				<?php if(isset($this->pagination)): ?>
					<div class="row">
						<div class="col-sm-12 text-center">
							<?php echo @$this->pagination->create_links();?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div id="upload-modal" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg" style="max-width: 700px;">
        <!-- Modal content-->
        <form class="form-horizontal form-label-left" action="<?php echo backend_url($folder_view."/import/"); ?>" method="post" enctype="multipart/form-data">
	        <div class="modal-content">
	            <div class="modal-header">
	                <button type="button" class="close" data-dismiss="modal">&times;</button>
	                <h4 class="modal-title"><?php echo @$title_page; ?></h4>
	            </div>
	            <div class="modal-body">
	                <div class="message alert alert-success" style="display: none;"></div>
	                <div class="message alert alert-danger" style="display: none;"></div>
	                <div class="file-sample table-responsive">
						<table class="table table-bordered">
							<thead>
								<tr>
									<th class="text-center top-number"></th>
									<?php for($char = 'A',$i = 0; $char <= 'Z',$i < count($header); $char++,$i++): ?>
										<th class="text-center"><?php echo $char; ?></th>
									<?php endfor; ?>
								</tr>
								<tr>
									<th>
										<p>1</p>
									</th>
									<?php foreach ($header as $key => $item): ?>
										<th class="bg-blue">
											<p data-toggle="tooltip" data-placement="top" title="<?php echo $item; ?>"><?php echo $item; ?></p>
										</th>
									<?php endforeach; ?>
								</tr>
							</thead>
						</table>
					</div>
					<p class="text-right dowload-excel-sample">
						<a href="<?php echo base_url('/uploads/template-excel/hop-vattu.xls'); ?>" download="">Tải file Excel mẫu</a>
					</p>
	            </div>
	            <div class="modal-footer">
	            	<div class="text-right">
			    		<a type="button" class="btn btn-gray" data-dismiss="modal">Hủy bỏ</a> 
			    		<button id="upload-from-now" type="button" onclick="$('#file-upload').trigger('click');return false;" class="btn action-bnt btn-primary relative">Chọn file Excel</button> 
			    		<input type="file" name="excel" class="hidden" id="file-upload" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" > 
			    	</div>
	            </div>
	        </div>
	    </form>
    </div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$('#file-upload').change(function(){
			var current = $(this);
			current.parents('form').find(".message").hide();
			var options = {
                dataType:'json',
                type: 'POST',
	            url: "<?php echo backend_url($folder_view."/import/"); ?>",
                success: function(data){
                    if(data['status'] == 'success'){
                    	alert(data['message']);
                    	location.reload();
                    }
                    else if(data['status'] == 'fail'){
                    	current.parents('form').find(".alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.parents('form').ajaxSubmit(options);
		});
	});
</script>

<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('click','a.is_ajax',function(){
			$(".box-common-edit-add .message").hide();
			var url = $(this).attr('href');
            $.ajax({
                type: 'POST',
                dataType:'html',
                url: url,
                data:{},
                success: function(html) {
                	if(html != -1){
                    	$(".box-common-edit-add .form-slider").html(html);
                    	$(".box-common-edit-add").slideDown();
                    	$("body,html").animate({scrollTop:0}, 'slow');
                	}
                    else{
                    	alert('Hộp - Vật tư này không tồn tại.');
                    }
                }
            });
			return false;
		});

		$(document).on('click','a.is_ajax_delete',function(){
			if(confirm('Bạn thật sự muốn xóa?')){
				var current = $(this);
				var url = $(this).attr('href');
	            $.ajax({
	                type: 'POST',
	                dataType:'json',
	                url: url,
	                data:{},
	                success: function(data) {
	                	if(data['status'] == 'success'){
	                		current.parents('tr').remove();
	                		$('tr td[data-column="Stt"]').each(function(i){
	                    		$(this).html(i+1);
	                    	});
	                	}
	                }
	            });
            }
			return false;
		});

		$(document).on('submit','.box-common-edit-add form',function(){
			var current = $(this);
			$(".box-common-edit-add .message").hide();
			var options = {
                dataType:'json',
                success: function(data){
                    if(data['status'] == 'success'){
                    	var fields = ["BoxName","DMVTName","SoLuong","Created_At"];
                        if(data['action'] == 'add'){
                        	var html = '<tr data-id="' + data['responsive']['ID'] + '">';
                        		html += '	<td data-column="Stt"></td>';
                        		fields.forEach(function(element) {
								  	html += '<td data-column="' + element + '">' + data['responsive'][element] + '</td>';
								});
                        		html += '	<td data-column="Action">';
                        		html += '		<a class="is_ajax" href="<?php echo backend_url($folder_view."/edit/"); ?>' + data['responsive']['ID'] + '"><i class="fa fa-edit" aria-hidden="true"></i></a> | ';
								html += '		<a class="is_ajax_delete" href="<?php echo backend_url($folder_view.'/delete/'); ?>' + data['responsive']['ID'] + '"><i class="fa fa-trash" aria-hidden="true"></i></a>';
                        		html += '	</td>';
                        		html += '</tr>';
                        	$('.x_content table').prepend(html);

                        	$('tr td[data-column="Stt"]').each(function(i){
                        		$(this).html(i+1);
                        	});
                        }
                        else{
                        	fields.forEach(function(element) {
							  	$('tr[data-id="' + data['responsive']['ID'] + '"] td[data-column="' + element + '"]').html(data['responsive'][element]);
							});
                        }
                        $(".box-common-edit-add").slideUp();
                    }
                    else if(data['status'] == 'fail'){
                    	$(".box-common-edit-add .alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.ajaxSubmit(options);
			return false;
		});

		$('.collapse-link-custom').click(function(){
			$(".box-common-edit-add").slideUp();
			return false;
		});
	});
</script>