<div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Mã đơn hàng</label>
				<input class="form-control" value="<?php echo @$record["MaDonHang"]; ?>" name="MaDonHang" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tên đơn hàng</label>
				<input class="form-control" value="<?php echo @$record["TenDonHang"]; ?>" name="TenDonHang" type="text" readonly>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Hợp đồng</label>
				<select class="form-control" name="HopDong_ID" disabled="">
					<option value="">Chọn</option>
					<?php if(isset($contract_result) && $contract_result != null): ?>
						<?php foreach ($contract_result as $key => $item): ?>
							<option <?php echo $item['ID'] == @$record["HopDong_ID"] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Ngày bắt đầu - ngày kết thúc</label>
				<input class="form-control" value="<?php echo @$record["StartDate"] != null ? date('Y/m/d',strtotime($record["StartDate"])).' - ' : ''; ?> <?php echo @$record["EndDate"] != null ? date('Y/m/d',strtotime($record["EndDate"])) : ''; ?>" name="daterange" type="text" disabled>
			</div>
		</div>
	</div>
</div>
<?php
	$today = new DateTime(date("Y-m-d H:i:s"));
	$datetime1 = new DateTime($record["StartDate"]);
	$datetime2 = new DateTime($record["EndDate"]);
	$interval = $datetime1->diff($datetime2);
	$total =  (int)$interval->format('%a'); 
	$interval = $datetime1->diff($today);
	$totaltoday =  (int)$interval->format('%a');
	$status = 0;
	if($total != 0){
		if($total < $totaltoday){
			$class="progress-bar-success";
			$status = '100%';
		}else{
			$class="progress-bar-info";
			$status = round( ($totaltoday/$total) * 100 ) . "%"; 
		}
	}else{
		$class="progress-bar-success";
		$status = '100%';
	}
?>
<div class="row">
	<div class="col-sm-12">
		<div class="form-group"> 
			<label class="control-label">Tiến độ</label>
			<div class="progress">
				<div class="progress-bar <?php echo $class;?>" role="progressbar" aria-valuenow="40"
				aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $status;?>">
					<?php echo $status?> Complete (success)
				</div>
			</div>
		</div>
	</div>
</div>
	<label class="control-label">File đính kèm</label>
	<ul>
		<?php if(@$media != null && @$record["ID"] != null): ?>
			<?php foreach ($media as $key => $item): ?>
				<li>
					<a href="<?php echo base_url($item['URL']); ?>" target="_blank"><?php echo $item['Name'].@$item['FileType']; ?></a>
					<a href="<?php echo backend_url($folder_view."/remove_media/".$record["ID"] ."/".$item['ID']); ?>" class="remove-media" data-id="<?php echo $item['ID']; ?>" style="color: #ff0000;margin-left: 10px;"><i class="fa fa-times" aria-hidden="true"></i></a>
				</li>
			<?php endforeach; ?>
		<?php endif; ?>
	</ul>
</div>
<div class="row">
	<div class="col-sm-12">
		<div class="form-group"> 
			<label class="control-label" style="margin-bottom: 20px;">Danh sách mã hàng <a class="btn btn-success create-item view-is_ajax" href="<?php echo backend_url('plu/add?order_id='.$record["ID"])?>"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Thêm mới</a></label>
			<table class="table table-striped jambo_table bulk_action dataTable no-footer">
				<thead>
					<tr>
						<th>Tên MH</th>
						<th>SL</th>
						<th>DGHD</th>
						<th>NBD</th>
						<th>NKT</th>
						<th>Tiến độ</th>
						<th>Hành động</th>
					</tr>
				</thead>
				<tbody>
					<?php if(@$plus):?>	
					<?php foreach($plus AS $key => $value):?>
						<tr data-id="<?php echo $value['ID']?>">
							<td data-column="Name"><?php echo $value["Name"]?></td>
							<td data-column="TongSoLuong"><?php echo $value["TongSoLuong"]?></td>
							<td data-column="DonGiaHD"><?php echo $value["DonGiaHD"]?></td>
							<td data-column="StartDate"><?php echo $value["StartDate"]?></td>
							<td data-column="EndDate"><?php echo $value["EndDate"]?></td>
							<td data-column="Progress">
								<?php
									$datetime1 = new DateTime($value["StartDate"]);
									$datetime2 = new DateTime($value["EndDate"]);
									$interval = $datetime1->diff($datetime2);
									$total =  (int)$interval->format('%a'); 
									$interval = $datetime1->diff($today);
									$totaltoday =  (int)$interval->format('%a');
									$status = 0;
									if($total != 0){
										if($total < $totaltoday){
											$class="progress-bar-success";
											$status = '100%';
										}else{
											$class="progress-bar-info";
											$status = round( ($totaltoday/$total) * 100 ) . "%"; 
										}
									}else{
										$class="progress-bar-success";
										$status = '100%';
									}
									//echo $status;
									
								?>
								<div class="progress">
									<div class="progress-bar <?php echo $class;?>" role="progressbar" aria-valuenow="40"
									aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $status?>">
										<?php echo $status?> Complete (success)
									</div>
								</div>
							</td>
							<td data-column="Action">
								<a title="Chỉnh sửa" class="view-is_ajax" target="_blank" href="<?php echo backend_url('/plu/edit/'.$value["ID"])?>"><i class="fa fa-edit" aria-hidden="true"></i></a> | 
								<a title="Xem chi tiết" class="view-view_ajax" target="_blank" href="<?php echo backend_url('/plu/view/'.$value["ID"])?>"><i class="fa fa-eye" aria-hidden="true"></i></a> 
							</td>
						</tr>
					<?php endforeach;?>
					<?php endif;?>
				</tbody>
			</table>
		</div>
	</div>
</div>