<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="form-group"> 
		<label class="control-label">Họ tên <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Giới tính <span class="required">*</span></label>
		<select class="form-control" name="GioiTinh">
			<option value="1">Nam</option>
			<option value="0" <?php echo @$record["GioiTinh"] != null && @$record["GioiTinh"] == 0 ? 'selected' : ''; ?>>Nữ</option>
		</select>
	</div>
	<div class="form-group"> 
		<label class="control-label">Ngày sinh <span class="required">*</span></label>
		<input class="form-control datetimepicker" value="<?php echo @$record["NgaySinh"] != null ? date('d/m/Y',strtotime($record["NgaySinh"])) : ''; ?>" name="NgaySinh" type="text" required="required">
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" class="btn btn-default" onclick="$('.collapse-link-custom').trigger('click');return false;" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>