<?php
/*
  Plugin Name: TCC Tracking
  Plugin URI: http://www.telberia.com
  Description: Just another
  Author: Jon henry
  Author URI: http://ideasilo.wordpress.com/
  Text Domain: auto-get-post
  Domain Path: /languages/vietnames
  Version: 1.0
*/
class TrackingHowFind
{
  
    public function __construct(){
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
        $this->init();
    }

    public function init(){
        add_action("wpcf7_before_send_mail",array($this,'save_post_Track'));
        add_action('admin_menu', array($this,'my_admin_menu') );
        add_action('admin_enqueue_scripts', array($this,'add_script') );
    }

    public function add_script(){
        wp_enqueue_script('jquery-ui-datepicker');
        wp_register_style('jquery-ui','http://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css' );
        wp_enqueue_style('jquery-ui');
    }

    public function save_post_Track($WPCF7_ContactForm){
        $wpcf7      = WPCF7_ContactForm::get_current();
        $submission = WPCF7_Submission::get_instance();
        if ($submission) {
            $data = $submission->get_posted_data();
            if (empty($data)) return;
            if(isset($data["another_text"])){
                $id = wp_insert_post ([
                    "post_title"   => wp_strip_all_tags(@$data["another_text"]),
                    "post_status"  => "publish",
                    "post_type"    => "tracking_another",
                ]);
                add_post_meta($id,"tracking_another_email",@$data["email-89"]);
                add_post_meta($id,"tracking_another_value",@$data["another_text"]);
                add_post_meta($id,"tracking_another_id",@$wpcf7->id);
                add_post_meta($id,"tracking_another_title",@$wpcf7->title);
            }
        }
    }

    public function my_admin_menu() {
        add_menu_page( 
            'TCC Tracking', 
            'TCC Tracking', 
            'manage_categories', 
            'tracking-how-find',
            array($this,'traking_find_page'), 
            'dashicons-tickets', 
            6 
        );
    }

    public function traking_find_page(){
      global $wpdb,$title;
      $where = "";
      if(isset($_GET["contact"]) && $_GET["contact"] != null && is_numeric($_GET["contact"])){
          $where .= " AND tbl3.ID = '".@$_GET["contact"]."' ";
      }
      if(isset($_GET["date"]) && $_GET["date"] != null){
          $where .= " AND DATE_FORMAT(tbl1.post_date, '%Y-%m-%d') = '".date('Y-m-d',strtotime($_GET["date"]))."' ";
      }
      if(isset($_GET["year"]) && $_GET["year"] != null && is_numeric($_GET["year"])){
          $where .= " AND DATE_FORMAT(tbl1.post_date, '%Y') = '".$_GET["year"]."' ";
      }
      $sql = "SELECT tbl3.* 
              FROM $wpdb->posts AS tbl1 
              JOIN $wpdb->postmeta AS tbl2 ON tbl2.post_id = tbl1.ID AND tbl2.meta_key = 'tracking_another_id'
              JOIN $wpdb->posts AS tbl3 ON tbl3.ID = tbl2.meta_value 
              WHERE tbl1.post_type = 'tracking_another' 
              GROUP BY tbl3.ID";
      $byform = $wpdb->get_results($sql,ARRAY_A);

      $sql = "SELECT tbl1.* ,count(tbl1.ID) AS number_track, tbl3.post_title AS contact_title 
              FROM $wpdb->posts AS tbl1 
              JOIN $wpdb->postmeta AS tbl2 ON tbl2.post_id = tbl1.ID AND tbl2.meta_key = 'tracking_another_id'
              JOIN $wpdb->posts AS tbl3 ON tbl3.ID = tbl2.meta_value 
              WHERE tbl1.post_type = 'tracking_another' $where 
              GROUP BY tbl1.post_title ,tbl3.ID";
      $plfsByState = $wpdb->get_results($sql,ARRAY_A);

      $sql = "SELECT DATE_FORMAT(tbl1.post_date, '%Y') AS year
              FROM $wpdb->posts AS tbl1 
              JOIN $wpdb->postmeta AS tbl2 ON tbl2.post_id = tbl1.ID AND tbl2.meta_key = 'tracking_another_id'
              JOIN $wpdb->posts AS tbl3 ON tbl3.ID = tbl2.meta_value 
              WHERE tbl1.post_type = 'tracking_another' 
              GROUP BY year";
      $years = $wpdb->get_results($sql,'ARRAY_A');
    ?>
      <div class="wrap">
          <h1><?php echo $title; ?></h1>
          <div class="search-from">
              <form action="<?php echo admin_url(); ?>" method="get">
                  <input type="hidden" name="page" value="tracking-how-find">
                  <!--<input type="text" name="date" value="<?php //echo @$_GET["date"] != null ? date('d.m.Y',strtotime($_GET["date"])) : ''; ?>" class="datepicker" style="height: 30px;">-->
                  <select name="year" style="height: 30px;min-width: 150px;">
                      <option value="">Jahr</option>
                      <?php foreach ($years  as $key => $value): ?>
                          <option value="<?php echo $value["year"]; ?>" <?php echo @$_GET["year"] == $value["year"] ? 'selected' : ''; ?>><?php echo $value["year"]; ?></option>
                      <?php endforeach; ?>
                  </select>
                  <select name="contact" style="height: 30px;">
                      <option value="">Alle</option>
                      <?php foreach ($byform as $key => $value): ?>
                          <option value="<?php echo $value["ID"]; ?>" <?php echo @$_GET["contact"] == $value["ID"] ? 'selected' : ''; ?>><?php echo $value["post_title"]; ?></option>
                      <?php endforeach; ?>
                  </select>
                  <input class="button button-primary button-large" type="submit" value="Filter">
              </form>
          </div>
          <table class="wp-list-table widefat fixed striped pages">
              <thead>
                  <tr>
                      <th class="manage-column column-title" width="50px">#</th>
                      <th class="manage-column column-title">Plattform</th>
                      <th class="manage-column column-title">Anzahl</th>
                      <th class="manage-column column-title">Kontaktformular</th>
                  </tr>
              </thead>
              <tbody>
                  <?php foreach ($plfsByState as $key => $value): ?>
                      <tr class="iedit author-other">
                          <td width="50px"><?php echo $key+1; ?></td>
                          <td><?php echo $value['post_title']; ?></td>
                          <td><?php echo $value['number_track']; ?></td>
                          <td><?php echo $value['contact_title']; ?></td>
                      </tr>
                  <?php endforeach; ?>
              </tbody>
              <tfoot>
                  <tr>
                      <th class="manage-column column-title" width="50px">#</th>
                      <th class="manage-column column-title">Plattform</th>
                      <th class="manage-column column-title">Anzahl</th>
                      <th class="manage-column column-title">Kontaktformular</th>
                  </tr>
              </tfoot>
          </table>
          <script type="text/javascript">
              jQuery(document).ready(function($){
                  $('.datepicker').datepicker({
                      'dateFormat': 'dd.mm.yy'
                  }); 
              });
          </script>
          <style type="text/css">
              .search-from{
                  margin-bottom: 20px;
                  float: right;
              }
          </style>
      </div>
    <?php }
}
$TrackingHowFind = new TrackingHowFind;