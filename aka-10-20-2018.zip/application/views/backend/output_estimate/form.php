<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="form-group"> 
		<label class="control-label">Tiêu đề <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required>
	</div>
	<div class="form-group">
		<label class="control-label">Phòng ban <span class="required">*</span></label>
		<select class="form-control required" name="Department_ID">
			<option value="">Chọn phòng ban</option>
			<?php if(isset($department) && $department != null): ?>
				<?php foreach ($department as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" <?php echo @$record["Department_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group">
		<label class="control-label">Mã hàng <span class="required">*</span></label>
		<select class="form-control required" name="MaHang_ID">
			<option value="">Chọn mã hàng</option>
			<?php if(isset($mahang) && $mahang != null): ?>
				<?php foreach ($mahang as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" <?php echo @$record["MaHang_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group"> 
		<label class="control-label">Số trạm <span class="required">*</span></label>
		<input class="form-control format-number" value="<?php echo @$record["SoTram"]; ?>" name="SoTram" type="text">
	</div>
	<div class="form-group"> 
		<label class="control-label">Số lượng <span class="required">*</span></label>
		<input class="form-control format-number" value="<?php echo @$record["SoLuong"]; ?>" name="SoLuong" type="text">
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>