<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-9">
						<h2>
							<?php echo @$title_page; ?> 
						</h2>
					</div>
					<div class="col-sm-3">
						<form>
							<div class="form-group">
								<select class="form-control" name="year" onchange="location.href='?year=' + $(this).val();">
									<option value="">Chọn năm</option>
									<?php for ($i = date('Y'); $i < date('Y') + 10; $i++): ?>
										<option value="<?php echo $i; ?>" <?php echo $this->input->get('year') == $i ? 'selected' : ''; ?>><?php echo $i; ?></option>
									<?php endfor; ?>
								</select>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="row">
					<div class="col-md-3">
						 <div class="list-moths">
						 	<ul class="ver-inline-menu tabbable margin-bottom-10">
						 		<?php for($i = 1 ;$i <= 12 ; $i++){
						 			echo '<li class="month-'.$i.'" id="tomonth" data-month="'.$i.'">
		                                    <i class="fa fa-calendar"></i><a href="javascript:;">
		                                    Tháng '.$i.'</a>
		                                    <span class="after">
		                                    </span>
		                            </li>';
						 		}?>
						 	</ul>
						 </div>
					</div>
					<div class="col-md-9">
						<h2 id="title-multiDatesPicker" class="text-center"></h2>
						<div id="multiDatesPicker"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="myModalUpdateHoliday" class="modal fade" role="dialog">
  	<div class="modal-dialog">
	    <!-- Modal content-->
	    <div class="modal-content">
		    <div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		        <h4 class="modal-title">Cập nhật ngày nghỉ</h4>
		    </div>
	      	<form method="post" class="saveholiday">
			    <div class="modal-body">
			        	<div class="form-group"> 
							<label class="control-label">Tên<span class="required">*</span></label>
							<input class="form-control" value="" name="Name" type="text" required="required">
						</div>
						<div class="form-group"> 
							<label class="control-label">Ngày<span class="required">*</span></label>
							<input class="form-control" value="" name="HolidayDate" type="text" required="required" readonly>
						</div>
						<div class="form-group"> 
							<label class="control-label">Mô tả</label>
							<textarea class="form-control" value="" name="Description"></textarea>
						</div> 
			    </div>
			    <div class="modal-footer">
			        <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
			        <a href="javascript:;" class="btn btn-success updateholiday">Lưu</a>
			        <a href="javascript:;" class="btn btn-warning deleteholiday">Xóa</a>
			    </div>
	      	</form>
	    </div>
  	</div>
</div>
<div id="myModalAddHoliday" class="modal fade" role="dialog">
  	<div class="modal-dialog">
	    <!-- Modal content-->
	    <div class="modal-content">
	      	<div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		        <h4 class="modal-title">Thêm ngày nghỉ</h4>
	      	</div>
	      	<form method="post" class="saveholiday">
		      	<div class="modal-body">
		        	<div class="form-group"> 
						<label class="control-label">Tên<span class="required">*</span></label>
						<input class="form-control" value="" name="Name" type="text" required="required">
					</div>
					<div class="form-group"> 
						<label class="control-label">Ngày<span class="required">*</span></label>
						<input class="form-control" value="" name="HolidayDate" type="text" required="required" readonly>
					</div>
					<div class="form-group"> 
						<label class="control-label">Mô tả</label>
						<textarea class="form-control" value="" name="Description"></textarea>
					</div>
		      	</div>
		      	<div class="modal-footer">
			        <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
			        <a href="javascript:;" class="btn btn-success updateholiday">Thêm</a>
		      	</div>
	     	</form>
	    </div>
  	</div>
</div>
<link rel="stylesheet" type="text/css" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css">
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"/></script>
<script src="<?php echo skin_url("backend/js/jquery-ui.min.js")?>"/></script>
<link rel="stylesheet" type="text/css" href="<?php echo skin_url("backend/js/multiple-dates-picker/jquery-ui.multidatespicker.css")?>">
<script src="<?php echo skin_url("backend/js/multiple-dates-picker/jquery-ui.multidatespicker.js")?>"/></script>
<script type="text/javascript">
	jQuery.browser = {};
	(function () {
	    jQuery.browser.msie = false;
	    jQuery.browser.version = 0;
	    if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
	        jQuery.browser.msie = true;
	        jQuery.browser.version = RegExp.$1;
	    }
	})();
	var date = new Date();
	var MonthSelect = date.getMonth();
	var YearSelect = date.getFullYear();
	var DaySelect = date.getDay();
	<?php if($this->input->get('year') >= date('Y')): ?>
		YearSelect = '<?php echo $this->input->get('year'); ?>';
	<?php endif; ?>
	var listHolidates = <?php echo ($result) ?  json_encode($result) : '[]';?>;
	var holiday;
	$("#title-multiDatesPicker").text("Tháng: "+ (MonthSelect + 1));
	$(".list-moths li.month-"+(MonthSelect + 1)+"").addClass("active");
	MonthSelect = MonthSelect + 1;
	$.datepicker._selectDay = function($element,$month,$year,$this){
		var day = $($this).find("a").text();
		date = new Date(YearSelect + "-" + MonthSelect + "-" + day);
		holiday = getMathHoliDay(date);
		if(holiday){
			$.each(holiday,function($key,$value){
				$("#myModalUpdateHoliday form [name="+$key+"]").val($value);
			})
			$("#myModalUpdateHoliday").modal();
		}else{
			holiday = {
				ID   : 0,
				Name : "",
				HolidayDate : YearSelect + "-" + MonthSelect + "-" + day,
				Description : ""
			}
			$.each(holiday,function($key,$value){
				$("#myModalAddHoliday form [name="+$key+"]").val($value);
			})
			$("#myModalAddHoliday").modal();
		}	
		return false;
	}
	function getMathHoliDay($date){
		var getholiday = false;
		var onDay;
		$.each(listHolidates,function($key,$value){
			onDay = new Date($value["HolidayDate"]) ;
			if(onDay.getDate() == $date.getDate() && onDay.getMonth() == $date.getMonth() ){
				getholiday = $value;
				return false;
			}
		});
		return getholiday;
	}
	$(document).ready(function(){
		var addDates = [];
		$.each(listHolidates,function($key,$value){
			addDates.push(new Date($value["HolidayDate"]));
		});
		<?php if($result):?>
			$('#multiDatesPicker').multiDatesPicker({
				dateFormat : 'Y-mm-dd',
				addDates: addDates, 
			});
		<?php else : ?>
			$('#multiDatesPicker').multiDatesPicker({
				dateFormat : 'Y-mm-dd'		
			});
		<?php endif ;?>
		$(".list-moths li#tomonth").click(function(){
			$(".list-moths li.active").removeClass("active");
			MonthSelect = $(this).attr("data-month");
			$("#title-multiDatesPicker").text("Tháng "+ MonthSelect);
			date = new Date(YearSelect + "-" + MonthSelect + "-01" );
			$("#multiDatesPicker").datepicker("setDate",date);
			$(this).addClass("active");
			return false;
		});
		$(document).on("click","form.saveholiday a.updateholiday",function(){
			var form = $(this).parents("form").serializeArray();
			$.each(form,function($key,$value){
				holiday[ $value ["name"]] = $value["value"];
			});
			$.ajax({
				type:"post",
				dataType:"json",
				url : "<?php echo backend_url("holidays/add")?>",
				data : holiday,
				success : function(data){
					if(data.status =="success"){
						if(data.action == "add"){
							var adddate = (new Date(data.responsive["HolidayDate"]));
							$('#multiDatesPicker').multiDatesPicker('addDates',[adddate]);
							listHolidates.push(data.responsive);
							$("#myModalAddHoliday").modal('hide');
						}else{
							$.each(listHolidates,function($key,$value){
								if($value["ID"] == data.responsive["ID"]){
									listHolidates[$key] = $value;
									return false;
								}
							});
							$("#myModalUpdateHoliday").modal('hide');
						}
					}else{
						alert(data.message);
					}
					return false;
				}
			})
		});
		$(document).on("click","form.saveholiday a.deleteholiday",function(){
			if(confirm('Bạn thật sự muốn xóa?')){
				$.ajax({
					type:"post",
					dataType:"json",
					url : "<?php echo backend_url("holidays/delete/")?>" + holiday.ID,
					data : holiday,
					success : function(data){
						if(data.status =="success"){
							var removedate = (new Date(data.responsive["HolidayDate"]));
							$.each(listHolidates,function($key,$value){
								if($value["ID"] == data.responsive["ID"]){
									listHolidates.splice($key,1);
									return false;
								}
							});
							$('#multiDatesPicker').multiDatesPicker('removeDates', [removedate]);
						}else{
							alert(data.message);
						}
						$("#myModalUpdateHoliday").modal('hide');
					}
				});
			}
		});
		$(document).on({
		    mouseenter: function () {
		        var day = $(this).text();
				date = new Date(YearSelect + "-" + MonthSelect + "-" + day);
				var holidayset = getMathHoliDay(date);
				if(holidayset){
					var tip = `<div class="tooltip fade bottom in" role="tooltip" id="tooltip362151" style="top: 100%; left: 0; display: block;">
								<div class="tooltip-arrow" style="left: 50%;"></div><div class="tooltip-inner">
									<p>Tên ngày nghỉ: `+holidayset["Name"]+`</p>
									<p>Ghi chú: `+holidayset["Description"]+`</p>
									<p>Ngày: `+holidayset["HolidayDate"]+`</p>
								</div>
							</div>`;
					$(this).parent("td").append(tip);
				}
		    },
		    mouseleave: function () {
		        $(this).parent("td").find(".tooltip").remove();
		    }
		},".ui-datepicker-calendar td > a"); //pass the element as an argument to .on
	});
</script>
<style type="text/css">
	.ver-inline-menu {
	    padding: 0;
	    margin: 0;
	    list-style: none;
	}
	.margin-bottom-10 {
	    margin-bottom: 10px !important;
	}
	.tabbable:before, .tabbable:after {
	    content: " ";
	    display: table;
	}
	.ver-inline-menu li {
	    position: relative;
	    margin-bottom: 1px;
	    background-color: #e0e9f0;
	}
	.ver-inline-menu li a {
	    font-size: 14px;
	    font-weight: 300;
	    color: #557386;
	    display: block;
	    border-left: solid 2px #c4d5df;
	    display: inline-block;
	    padding-left: 10px;
	}
	.ver-inline-menu li i {
	    width: 37px;
	    height: 37px;
	    display: inline-block;
	    color: #b9cbd5;
	    font-size: 15px;
	    padding: 12px 10px 10px 8px;
	    margin: 0 8px 0 0;
	    text-align: center;
	    background: #e0eaf0 !important;
	}
	.tabbable:after {
	    clear: both;
	}
	.ver-inline-menu li.active, .ver-inline-menu li:hover {
	    font-size: 14px;
	}
	.ver-inline-menu li:hover,.ver-inline-menu li:hover i,.ver-inline-menu li.active, .ver-inline-menu li.active i {
	    color: #fff;
	    background: #169ef4;
	    text-decoration: none;
	}
	.ver-inline-menu li:hover,.ver-inline-menu li.active {
	    border-left: solid 2px #0c91e5;
	}
	.x_content .ui-datepicker {
		width: 100%;
	}
	.x_content .ui-datepicker td {
	    border: 0;
	    padding: 1px;
	    height: 75px;
	    position: relative;
	    background: #f1f1f1;
	}
	.x_content thead {
		border-bottom: 2px solid #ccc;
    	background-color: #337ab7;
	}
	.x_content thead th {
		color: #000;
	}
	 .x_content .ui-datepicker td{
	 	border: 1px solid #d3d3d3;
	 }
	.ui-state-highlight, .ui-widget-content .ui-state-highlight{
		border: 1px solid #d3d3d3;
	    background: #e6e6e6;
	    font-weight: bold;
	}
	.x_content .ui-datepicker td a{
		text-align: center;
    	font-size: 16px;
	}
	.ui-state-default{
		background-color: transparent;
	}
	.ui-datepicker .ui-datepicker-header{
		display: none;
	}
	.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default {
	    border: 1px solid #d3d3d3;
	    background: #fff;
	    font-weight: normal;
	    color: #555555;
	}
	.modal-footer {
	    float: left;
	    width: 100%;
	}
	.ui-datepicker .ui-datepicker-calendar a {
	    width: 50px;
	    margin: auto;
	    height: 50px;
	    padding: 0;
	    border-radius: 100%;
	    line-height: 3;
	}
	.ui-datepicker .ui-datepicker-calendar .ui-state-highlight a {
	    background: #743620 none;
	    color: white;
	    width: 50px;
	    margin: auto;
	    height: 50px;
	    padding: 0;
	    border-radius: 100%;
	    line-height: 3;
	}
	.x_content .ui-datepicker td.ui-datepicker-week-end {
		background: #ccc;
	}
	.x_content .ui-datepicker td.ui-state-disabled{
		background: #fff;
	}
</style>