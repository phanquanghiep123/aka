<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="form-group">
		<label class="control-label">Kịch bản <span class="required">*</span></label>
		<select class="form-control required" name="Scenario_ID">
			<option value="">Chọn kịch bản</option>
			<?php if(isset($scenario) && $scenario != null): ?>
				<?php foreach ($scenario as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" <?php echo @$record["Scenario_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group">
		<label class="control-label">Quy trình <span class="required">*</span></label>
		<select class="form-control required" name="Process_ID">
			<option value="">Chọn quy trình</option>
			<?php if(isset($process) && $process != null): ?>
				<?php foreach ($process as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" <?php echo @$record["Process_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>