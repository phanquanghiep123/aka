<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<form action="" method="post" class="form-add">
			<div class="x_panel">
				<div class="x_title">
					<div class="row">
						<div class="col-sm-8">
							<h2><?php echo @$title_page; ?> </h2>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<label class="control-label">Kịch bản <span class="required">*</span></label>
								<select class="form-control required" name="Scenario_ID">
									<option value="">Chọn kịch bản</option>
									<?php if(isset($scenario) && $scenario != null): ?>
										<?php foreach ($scenario as $key => $item): ?>
											<option value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
										<?php endforeach; ?>
									<?php endif; ?>
								</select>
							</div>
						</div>
					</div>
				</div>
				<div class="x_content">
					<div class="message alert alert-success" style="display: none;"></div>
    				<div class="message alert alert-danger" style="display: none;"></div>
					<div class="table-responsive">
					    <?php $this->load->view($backend_asset."/includes/message");?>
					    <?php 
						    if($this->session->flashdata('record')){
						    	$record = $this->session->flashdata('record');
						    	$soluongs = @$record['soluong'];
						    } 
					    ?>
						<table class="table table-striped jambo_table bulk_action">
							<tbody>
							    <?php if(isset($results) && $results != null): ?>
							        <?php foreach ($results as $key => $item): ?>
							    		<tr>
											<td><?php echo $key+1;?></td>
											<td><?php echo $item["ScenarioName"]; ?></td>
											<td><?php echo $item["ProcessName"]; ?></td>
											<td><?php echo number_format($item["WorkStation_ID"]); ?></td>
											<td>
												<input type="text" class="form-control format-number" value="<?php echo @$soluongs[$item['ID']] != null ? $soluongs[$item['ID']] : @$item['SoLuong']; ?>" name="soluong[<?php echo $item['ID']; ?>]">
											</td>
										</tr>
								    <?php endforeach; ?>
							    <?php endif; ?>
							</tbody>
							<thead>
								<tr class="headings">
									<th>STT</th>
									<th>Kịch bản</th>
									<th>Quy trình</th>
									<th>Trạm làm việc</th>
									<th>Số lượng</th>
								</tr>
							</thead>
						</table>
					</div>
				</div>
			</div>
		</form>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change','select[name="Scenario_ID"]',function(){
			var current = $(this).parents('form');
			var val = $(this).val();
			if(val != ''){
	            $.ajax({
	                type: 'POST',
	                dataType:'json',
	                url: '<?php echo backend_url($folder_view.'/get_table/');?>' + val,
	                data:{},
	                success: function(data) {
	                	console.log(data);
	                	if(data['status'] == 'success'){
	                		current.find('.table-responsive').html(data['response']);
	                	}
	                	else if(data['status'] == 'fail'){
	                		alert(data['message']);
	                	}
	                }
	            });
            }
            else{
            	current.find('.table-responsive table tbody').html('');
            } 
		});

		$(document).on('submit','form.form-add',function(){
			var current = $(this);
			current.find(".message").hide();
			var options = {
                dataType:'json',
                success: function(data){
                    if(data['status'] == 'success'){
                    	location.href = data['url'];
                    }
                    else if(data['status'] == 'fail'){
                    	current.find(".alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.ajaxSubmit(options);
			return false;
		});
	});
</script>