<?php
	$html = '';
    if(isset($process) && $process != null){
    	foreach ($process as $key => $item) {
    		$html .= '<option value="'.$item['ID'].'">'.$item['Name'].'</option>';
    	}
    }
?>
<table class="table table-striped jambo_table bulk_action">
	<tbody>
		<?php $soluong = 0; ?>
	    <?php if(isset($scenario['SoTram']) && $scenario['SoTram'] != null): ?>
	        <?php for ($i = 1; $i <= $scenario['SoTram'] ; $i++): ?>
	    		<tr>
					<td><?php echo $i;?></td>
					<td><?php echo $scenario["Name"]; ?></td>
					<td><?php echo $i; ?></td>
					<td>
						<select class="form-control" name="process[<?php echo $i; ?>]" required>
							<option value="">Chọn quy trình</option>
							<?php echo $html; ?>
						</select>
					</td>
					<td><input type="text" class="form-control format-number" name="soluong[<?php echo $i; ?>]" value="0" required></td>
				</tr>
		    <?php endfor; ?>
	    <?php endif; ?>
	</tbody>
	<thead>
		<tr class="headings">
			<th>STT</th>
			<th>Kịch bản</th>
			<th>Trạm làm việc</th>
			<th>Quy trình</th>
			<th>Số lượng (Tổng: <?php echo $scenario['SoLuong']; ?>)</th>
		</tr>
	</thead>
</table>
<div class="form-group text-right">
	<a class="btn btn-default" href="<?php echo backend_url($folder_view);?>">Quay lại</a>
	<button type="submit" class="btn btn-success">Lưu dữ liệu</button> 
</div>