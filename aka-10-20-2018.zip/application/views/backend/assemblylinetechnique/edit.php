<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-12">
						<h2><?php echo @$title_page; ?> </h2>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
				    <?php 
					    if($this->session->flashdata('record')){
					    	$record = $this->session->flashdata('record');
					    	$soluongs = @$record['soluong'];
					    	$processs = @$record['process'];
					    } 

						$html = '';
					    if(isset($process) && $process != null){
					    	foreach ($process as $key => $item) {
					    		$html .= '<option value="'.$item['ID'].'">'.$item['Name'].'</option>';
					    	}
					    }
					?>
				    <form action="" method="post">
						<table class="table table-striped jambo_table bulk_action">
							<tbody>
								<?php $soluong = 0; ?>
							    <?php if(isset($results) && $results != null): ?>
							        <?php foreach ($results as $key => $item): ?>
							        	<?php $soluong = $item['ScenarioSoLuong']; ?>
							    		<tr>
											<td><?php echo $key+1;?></td>
											<td><?php echo $item["ScenarioName"]; ?></td>
											<td><?php echo number_format($item["WorkStation_ID"]); ?></td>
											<td>
												<select class="form-control process" data-value="<?php echo @$processs[$item['ID']] != null ? $processs[$item['ID']] : @$item['Process_ID']; ?>" name="process[<?php echo $item['ID']; ?>]" required>
													<option value="">Chọn quy trình</option>
													<?php echo $html; ?>
												</select>
											</td>
											<td>
												<input type="text" class="form-control format-number" value="<?php echo @$soluongs[$item['ID']] != null ? $soluongs[$item['ID']] : @$item['SoLuong']; ?>" name="soluong[<?php echo $item['ID']; ?>]">
											</td>
										</tr>
								    <?php endforeach; ?>
							    <?php endif; ?>
							</tbody>
							<thead>
								<tr class="headings">
									<th>STT</th>
									<th>Kịch bản</th>
									<th>Trạm làm việc</th>
									<th>Quy trình</th>
									<th>Số lượng (Tổng: <?php echo $soluong; ?>)</th>
								</tr>
							</thead>
						</table>
						<div class="form-group text-right">
							<a class="btn btn-default" href="<?php echo backend_url($folder_view);?>">Quay lại</a>
							<button type="submit" class="btn btn-success">Cập nhật</button> 
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$('.jambo_table select.process').each(function(){
			var val = $(this).attr('data-value');
			if(val != 0){
				$(this).val(val);
			}
		});
	});
</script>