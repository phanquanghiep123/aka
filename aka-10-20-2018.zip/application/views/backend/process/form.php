<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
    <div class="form-group"> 
		<label class="control-label">Key Process <?php if(isset($edit) && $edit == 'edit'): ?><span class="required">*</span><?php endif; ?></label>
		<input class="form-control" value="<?php echo @$record["Key_Process"]; ?>" name="Key_Process" type="text" <?php if(isset($edit) && $edit == 'edit'): ?>required="required"<?php endif; ?>>
	</div>
	<div class="form-group"> 
		<label class="control-label">Tiêu đề <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required">
	</div>
	<div class="form-group">
		<label class="control-label">Máy <span class="required">*</span></label>
		<select class="form-control required" name="Machine_ID">
			<option value="">Chọn máy</option>
			<?php if(isset($machine) && $machine != null): ?>
				<?php foreach ($machine as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" <?php echo @$record["Machine_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['FullName']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group">
		<label class="control-label">Cấp độ <span class="required">*</span></label>
		<select class="form-control required" name="Employee_Level_ID">
			<option value="">Chọn cấp độ</option>
			<?php if(isset($level) && $level != null): ?>
				<?php foreach ($level as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" <?php echo @$record["Employee_Level_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group">
		<label class="control-label">Nhóm <span class="required">*</span></label>
		<select class="form-control required" name="Group_ID">
			<option value="">Chọn nhóm</option>
			<?php if(isset($group) && $group != null): ?>
				<?php foreach ($group as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" <?php echo @$record["Group_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group">
		<label class="control-label">Yêu cầu <span class="required">*</span></label>
		<select class="form-control required" name="Request_ID">
			<option value="">Chọn yêu cầu</option>
			<?php if(isset($request) && $request != null): ?>
				<?php foreach ($request as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" <?php echo @$record["Request_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group">
		<label class="control-label">Mã hàng <span class="required">*</span></label>
		<select class="form-control required" name="MaHang_ID">
			<option value="">Chọn mã hàng</option>
			<?php if(isset($mahang) && $mahang != null): ?>
				<?php foreach ($mahang as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" <?php echo @$record["MaHang_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group" style="position: relative;"> 
		<label class="control-label">Màu sắc <span class="required">*</span></label>
		<input class="form-control color-picker" value="<?php echo @$record["Color"]; ?>" name="Color" type="text" required>
		<div style="position: absolute;top: 28px;right: 0;height: 33px;width: 33px;background-color: <?php echo @$record["Color"]; ?>" class="color-reference"></div>
	</div>
	<div class="form-group"> 
		<label class="control-label">Độ khó <span class="required">*</span></label>
		<input type="number" name="DoKho" class="form-control" value="<?php echo @$record['DoKho']; ?>" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Mô tả</label>
		<textarea class="form-control" rows="5" name="Description" maxlength="255"><?php echo @$record["Description"]; ?></textarea>
	</div>
	<div class="row form-group"> 
		<label class="control-label">File đính kèm</label>
		<input name="files[]" multiple type="file" accept="application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,image/*,application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
		<div style="height: 15px;"></div>
		<ul>
			<?php if(@$media != null && @$record["ID"] != null): ?>
				<?php foreach ($media as $key => $item): ?>
					<li>
						<a href="<?php echo base_url($item['URL']); ?>" target="_blank"><?php echo $item['Name'].@$item['FileType']; ?></a>
						<a href="<?php echo backend_url($folder_view."/remove_media/".$record["ID"] ."/".$item['ID']); ?>" class="remove-media" data-id="<?php echo $item['ID']; ?>" style="color: #ff0000;margin-left: 10px;"><i class="fa fa-times" aria-hidden="true"></i></a>
					</li>
				<?php endforeach; ?>
			<?php endif; ?>
		</ul>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>