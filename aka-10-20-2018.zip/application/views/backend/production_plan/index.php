<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-12">
						<h2><?php echo @$title_page; ?> </h2>
					</div>
				</div>
			</div>
			<div class="x_content">
			    <?php $this->load->view($backend_asset."/includes/message");?>
			    <form action="<?php echo backend_url($folder_view.'/index/'.strtotime($current_date)); ?>" method="post">
			    	<div class="row">
			    		<div class="col-xs-6"></div>
			    		<div class="col-xs-6">
			    			<div class="text-right">
					    		<button type="submit" class="btn btn-primary">Lưu dữ liệu</button>
					    	</div>
			    		</div>
			    	</div>
			    	<div class="table-responsive" style="overflow-x: auto !important;min-height: auto;">
				    	<table class="table table-striped jambo_table bulk_action not-datatable">
							<thead>
								<tr class="headings">
									<th>#</th>
									<th style="min-width: 150px;">Chi tiết mã hàng</th>
									<th style="min-width: 100px;">Ngày bắt đầu</th>
									<th style="min-width: 105px;">Ngày kết thúc</th>
									<th style="min-width: 100px;">SL kế hoạch</th>
									<th style="min-width: 100px;">SL đã bố trí</th>
									<th style="min-width: 100px;">% đã bố trí</th>
									<?php for($i = 0; $i < $numberDays; $i++): ?>
										<th class="text-center" style="min-width:80px;"><?php echo date('d/m',strtotime("+".$i." day", strtotime($current_date))); ?></th>
									<?php endfor; ?>
								</tr>
							</thead>
							<tbody>
								<?php if(isset($results) && $results != null): ?>
									<?php foreach ($results as $key => $item): ?>
										<tr>
											<td><?php echo $key+1; ?></td>
											<td><?php echo $item['PluName'].' | '.$item['SizeName'].' | '.$item['MaMau']; ?></th>
											<td><?php echo date($date_format,strtotime($item["StartDate"])); ?></td>
											<td><?php echo date($date_format,strtotime($item["EndDate"])); ?></td>
											<td><?php echo $item["SoLuong"]; ?></td>
											<td><?php echo @$item['total']['Total'] != null ? $item['total']['Total'] : '0'; ?></td>
											<td><?php echo @$item['total']['Total'] != null ? round(($item['total']['Total']/$item["SoLuong"])*100).'%' : '0%'; ?></td>
											<?php for($i = 0; $i < $numberDays; $i++): ?>
												<?php $next_date = date('Y-m-d',strtotime("+".$i." day", strtotime($current_date))); ?>
												<?php if($next_date >= date('Y-m-d',strtotime($item["StartDate"])) && $next_date <= date('Y-m-d',strtotime($item["EndDate"])) ): ?>
													<?php
														$sl = '';
														if(isset($item['kehoachsx']) && $item['kehoachsx'] != null){
															foreach ($item['kehoachsx'] as $key1 => $item1) {
																if($next_date == date('Y-m-d',strtotime($item1['Date']))){
																	$sl = $item1['SoLuong'];
																	break;
																}
															}
														}
													?>
													<td>
														<input type="text" class="format-number form-control"  value="<?php echo $sl; ?>" placeholder="SL" name="soluong[<?php echo $item['ID']; ?>][]" style="background-color: #FFEB3C;">
														<input type="hidden" value="<?php echo $next_date; ?>"  name="date[<?php echo $item['ID']; ?>][]">
													</td>
												<?php else: ?>
													<td>
														<input type="text" class="format-number form-control"  value="" placeholder="SL" name="soluong[<?php echo $item['ID']; ?>][]">
														<input type="hidden" value="<?php echo $next_date; ?>"  name="date[<?php echo $item['ID']; ?>][]">
													</td>
												<?php endif; ?>
											<?php endfor; ?>
										</tr>
									<?php endforeach; ?>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
			    </form>
			    <div style="height: 15px;"></div>
			    <div class="row">
			    	<div class="col-xs-6">
			    		<p><a href="<?php echo backend_url($folder_view.'/index/'.strtotime("-7 day",strtotime($current_date))); ?>"><i class="fa fa-angle-double-left" aria-hidden="true"></i> Sau</a></p>
			    	</div>
			    	<div class="col-xs-6">
			    		<p class="text-right"><a href="<?php echo backend_url($folder_view.'/index/'.strtotime("+7 day",strtotime($current_date))); ?>">Trước <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></p>
			    	</div>
			    </div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		/*$('form').submit(function(){
			var check = true;
			$(this).find('input[type="text"]').each(function(){
				var current = $(this);
				var soluong = current.val();
				if(soluong == '' || soluong == null){
					current.addClass('border-error');
					check = false;
				}
				else{
					current.removeClass('border-error');
				}
			});
			return check;
		});*/
	});
</script>
<style type="text/css">
	.calendar-table table tr th {color: #000;}
	.border-error{border:1px solid #ff0000 !important;}
</style>