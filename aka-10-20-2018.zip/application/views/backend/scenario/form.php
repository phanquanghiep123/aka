<form class="form-horizontal form-label-left form-scenario" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="form-group"> 
		<label class="control-label">Tiêu đề <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required>
	</div>
	<div class="form-group">
		<label class="control-label">Ước tính <span class="required">*</span></label>
		<select class="form-control required" name="Output_Estimate_ID">
			<option value="">Chọn ước tính</option>
			<?php if(isset($estimate) && $estimate != null): ?>
				<?php foreach ($estimate as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" data-sotram="<?php echo @$item['SoTram']; ?>" data-soluong="<?php echo @$item['SoLuong']; ?>" <?php echo @$record["Output_Estimate_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group"> 
		<label class="control-label">Số trạm <span class="required">*</span></label>
		<input class="form-control format-number" value="<?php echo @$record["SoTram"]; ?>" name="SoTram" type="text">
	</div>
	<div class="form-group"> 
		<label class="control-label">Số lượng <span class="required">*</span></label>
		<input class="form-control format-number" value="<?php echo @$record["SoLuong"]; ?>" name="SoLuong" type="text">
	</div>
	<div class="form-group"> 
		<label class="control-label">Thời gian của kịch bản <span class="required">*</span></label>
		<input class="form-control datetimepicker" value="<?php echo @$record["ScenarioDate"] != null && @$record["ScenarioDate"] != '0000-00-00' ? date(@$date_format,strtotime(@$record["ScenarioDate"])) : ''; ?>" name="ScenarioDate" type="text">
	</div>
	<div class="form-group"> 
		<label class="control-label">Mô tả</label>
		<textarea class="form-control" name="Description" rows="6"><?php echo @$record["Description"]; ?></textarea>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>
<script type="text/javascript">
	$(document).ready(function(){
		$('.form-scenario select[name="Output_Estimate_ID"]').change(function(){
			if($(this).val() != ''){
				var sotram = $(this).find(":selected").attr('data-sotram');
				var soluong = $(this).find(":selected").attr('data-soluong');
				if($('.form-scenario input[name="SoTram"]').val() == 0 || $('.form-scenario input[name="SoTram"]').val() == ''){
					$('.form-scenario input[name="SoTram"]').val(sotram);
				}
				if($('.form-scenario input[name="SoLuong"]').val() == 0 || $('.form-scenario input[name="SoLuong"]').val() == ''){
					$('.form-scenario input[name="SoLuong"]').val(soluong);
				}
			}
		});
	});
</script>