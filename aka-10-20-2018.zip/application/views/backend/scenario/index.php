<div class="main-page <?php echo @$main_page;?> row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="box-common-edit-add relative" style="display: none;">
            <a class="collapse-link-custom" href="#" style="color: #ff0000;"><i class="fa fa-times" aria-hidden="true"></i></a>
            <div class="form-slider" style="max-width: 600px;margin:0 auto;"></div>
        </div>
        <div class="x_panel">
            <div class="x_title">
                <div class="row">
                    <div class="col-sm-8">
                        <h2>
                            <?php echo @$title_page; ?> 
                            <a class="btn btn-success create-item is_ajax" href="<?php echo backend_url($folder_view."/add");?>"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Thêm mới</a>
                            <?php /*<a class="btn btn-success" href="<?php echo backend_url($folder_view."/export");?>"><i class="fa fa-download" aria-hidden="true"></i> Xuất Excel</a>
                            <a class="btn btn-success" href="#<?php //echo backend_url($folder_view."/import");?>" data-toggle="modal" data-target="#upload-modal"><i class="fa fa-file-excel-o" aria-hidden="true"></i> Nhập Excel</a>*/ ?>
                        </h2>
                    </div>
                    <div class="col-sm-4">
                        <form method="" method="get">
                            <div class="row">
                                <div class="col-sm-8">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Từ khóa" name="keyword" value="<?php echo $this->input->get('keyword'); ?>">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">Tìm kiếm</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="x_content">
                <div class="table-responsive">
                    <?php $this->load->view($backend_asset."/includes/message");?>
                    <table class="table table-striped jambo_table bulk_action">
                        <thead>
                            <tr class="headings">
                                <th>STT</th>
                                <th>Tiêu đề</th>
                                <th>Ước tính</th>
                                <th>TG của kịch bản</th>
                                <th>Số trạm</th>
                                <th>Số lượng</th>
                                <th>Ngày tạo</th>
                                <th>Hành động</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($results) && $results != null): ?>
                                <?php foreach ($results as $key => $value): ?>
                                    <tr data-id="<?php echo $value['ID']; ?>">
                                        <td data-column="Stt"><?php echo $key+1;?></td>
                                        <td data-column="Name"><?php echo $value["Name"]; ?></td>
                                        <td data-column="EstimateName"><?php echo $value["EstimateName"]; ?></td>
                                        <td data-column="ScenarioDate"><?php echo date($date_format,strtotime($value["ScenarioDate"])); ?></td>
                                        <td data-column="SoTram"><?php echo $value["SoTram"]; ?></td>
                                        <td data-column="SoLuong"><?php echo $value["SoLuong"]?></td>
                                        <td data-column="Created_At"><?php echo date($datetime_format,strtotime($value["Created_At"])); ?></td>
                                        <td data-column="Action">
                                            <a class="is_ajax" title="Chỉnh sửa" href="<?php echo backend_url($folder_view."/edit/".$value["ID"])?>"><i class="fa fa-edit" aria-hidden="true"></i></a> | 
                                            <a class="is_ajax_delete" title="Xóa" href="<?php echo backend_url($folder_view.'/delete/'.$value["ID"])?>"><i class="fa fa-trash" aria-hidden="true"></i></a> 
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php if(isset($this->pagination)): ?>
                    <div class="row">
                        <div class="col-sm-12 text-center">
                            <?php echo @$this->pagination->create_links();?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<!-- Large modal -->

<div id="my-map-modal" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div id="sample">
          <div id="myDiagramDiv" style="border: solid 1px black; width:100%; height:600px"></div>
          <div>
            <textarea class="none" id="mySavedModel" style="display: none; width:100%;height:250px">
              { "class": "go.GraphLinksModel",
                "nodeDataArray": [ 
               
               ],
                "linkDataArray": [ 
               
               ]}
            </textarea>
          </div>
            <div class="list-process">
                <ul>
                    <?php foreach ($process as $key => $value) {
                        echo '<li class="addNode" data=\''.json_encode($value).'\'">
                            '.$value["Name"].'
                            <div class="action">
                                <a href="javascript:;"><i class="fa fa-plus-square" aria-hidden="true"></i></a>
                            </div>
                        </li>';
                    }?>
                </ul>
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" onclick="save()">Save changes</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="fix-menu-right">
  <ul>
    <li><a href="javascript:;" id="add-node"><i class="mdi mdi-folder-plus"></i>Thêm tiến trình</a></li>
  </ul>
</div>
<style type="text/css">
    .fix-menu-right {
        position: fixed;
        display: none;
        top: 0;
        right:  auto;
        width: 160px;
        z-index: 9999;
    }
    .fix-menu-right.open {
        display: block;
    }
    .fix-menu-right ul {
        background: #ffffff;
        border:  1px solid #cccccc;
        padding:  5px;
        border-radius:  4px;
    }
    .fix-menu-right ul li {
        list-style:  none;
        margin-bottom: 5px;
        border-bottom:  1px solid #cccccc;
    }
    .fix-menu-right ul li:last-child{
        margin-bottom: 0;
        border-bottom:  none;
    }
    .fix-menu-right ul li a {
        cursor:  pointer;
    }

    .fix-menu-right ul li:hover{
        background:  #f1f1f1;
    }
    #sample{
        position: relative;
        overflow: hidden;
    }
    .list-process{
        position: absolute;
        top: 0;
        right: -100%;
        width: 300px;
        z-index: 9999;
        -webkit-transition: right .5s; /* Safari */
        transition: right .5s;
    }
    .list-process.open{
        right: 0%; 
    }
    .list-process ul {
        margin: 0;
        padding: 0;
        padding: 9px 5px 0px 5px;
        background: #f1f1f1;
        border: 1px solid #ccc;
    }
    .list-process li {
        list-style: none;
        border: 1px solid #ccc;
        margin-bottom: 10px;
        padding: 5px 10px;
        background-color: #fff;
        position: relative;
        cursor: pointer;
    }
    .list-process li .action{
        position: absolute;
        right: 5px;
        top: 5px;
    }
</style>
<script src="<?php echo skin_url('backend/js/website/go.js')?>"></script> 
<script type="text/javascript">
var _button, _event, _nodeInfo,_ROOT = 0,_ID = 0;
var init = function () {
    if (window.goSamples) goSamples(); // init for these samples -- you don't need to call this
    var $go = go.GraphObject.make; // for conciseness in defining templates
    myDiagram = $go(go.Diagram, "myDiagramDiv", // create a Diagram for the DIV HTML element
        {
            initialContentAlignment: go.Spot.Center, // center the content
            "linkingTool.isEnabled": false, // invoked explicitly by drawLink function, below
            "linkingTool.direction": go.LinkingTool.ForwardsOnly, // only draw "from" towards "to"
            "undoManager.isEnabled": true // enable undo & redo
        }
    );
    myDiagram.linkTemplate = $go(go.Link, {
            routing: go.Link.AvoidsNodes,
            corner: 5
        },
        $go(go.Shape, {
            strokeWidth: 1.5
        }),
        $go(go.Shape, {
            toArrow: "OpenTriangle"
        })
    );
    myDiagram.nodeTemplate = $go(go.Node, "Auto", {
            desiredSize: new go.Size(150, 30),
            // rearrange the link points evenly along the sides of the nodes as links are
            // drawn or reconnected -- these event handlers only make sense when the fromSpot
            // and toSpot are Spot.xxxSides
            linkConnected: function (node, link, port) {
                if (link.fromNode !== null) link.fromNode.invalidateConnectedLinks();
                if (link.toNode !== null) link.toNode.invalidateConnectedLinks();
            },
            linkDisconnected: function (node, link, port) {
                if (link.fromNode !== null) link.fromNode.invalidateConnectedLinks();
                if (link.toNode !== null) link.toNode.invalidateConnectedLinks();
            },
            locationSpot: go.Spot.Center
        },
        new go.Binding("location", "location", go.Point.parse).makeTwoWay(go.Point.stringify),
        $go(go.Shape, {
                name: "SHAPE", // named so that changeColor can modify it
                strokeWidth: 0, // no border
                fill: "lightgray", // default fill color
                portId: "",
                // use the following property if you want users to draw new links
                // interactively by dragging from the Shape, and re-enable the LinkingTool
                // in the initialization of the Diagram
                //cursor: "pointer",
                fromSpot: go.Spot.AllSides,
                fromLinkable: true,
                fromLinkableDuplicates: true,
                fromLinkableSelfNode: true,
                toSpot: go.Spot.AllSides,
                toLinkable: true,
                toLinkableDuplicates: true,
                toLinkableSelfNode: true
            },
            new go.Binding("fill", "color").makeTwoWay()),
        $go(go.TextBlock, {
                name: "TEXTBLOCK", // named so that editText can start editing it
                margin: 3,
                // use the following property if you want users to interactively start
                // editing the text by clicking on it or by F2 if the node is selected:
                //editable: true,
                overflow: go.TextBlock.OverflowEllipsis,
                maxLines: 5
            },
            new go.Binding("text").makeTwoWay())
    );

    // a selected node shows an Adornment that includes both a blue border
    // and a row of Buttons above the node
    myDiagram.nodeTemplate.selectionAdornmentTemplate = $go(go.Adornment, "Spot",
        $go(go.Panel, "Auto",
            $go(go.Shape, {
                stroke: "dodgerblue",
                strokeWidth: 2,
                fill: null
            }),
            $go(go.Placeholder)
        ),
        $go(go.Panel, "Horizontal", {
                alignment: go.Spot.Top,
                alignmentFocus: go.Spot.Bottom
            },
            $go("Button", {
                    click: editText
                }, // defined below, to support editing the text of the node
                $go(go.TextBlock, "t", {
                    font: "bold 10pt sans-serif",
                    desiredSize: new go.Size(15, 15),
                    textAlign: "center"
                })
            ),
            $go("Button", {
                    click: changeColor,
                    "_buttonFillOver": "transparent"
                }, // defined below, to support changing the color of the node
                new go.Binding("ButtonBorder.fill", "color", nextColor),
                $go(go.Shape, {
                    fill: null,
                    stroke: null,
                    desiredSize: new go.Size(14, 14)
                })
            ),
            $go("Button", { // drawLink is defined below, to support interactively drawing new links
                    click: drawLink, // click on Button and then click on target node
                    actionMove: drawLink // drag from Button to the target node
                },
                $go(go.Shape, {
                    geometryString: "M0 0 L8 0 8 12 14 12 M12 10 L14 12 12 14"
                })
            ),
            $go("Button", {
                    actionMove: dragNewNode, // defined below, to support dragging from the button
                    _dragData: {
                        text: "a Node",
                        color: "lightgray"
                    }, // node data to copy
                    click: clickNewNode // defined below, to support a click on the button
                },
                $go(go.Shape, {
                    geometryString: "M0 0 L3 0 3 10 6 10 x F1 M6 6 L14 6 14 14 6 14z",
                    fill: "gray"
                })
            )
        )
    );

    function editText(e, button) {
        var node = button.part.adornedPart;
        e.diagram.commandHandler.editTextBlock(node.findObject("TEXTBLOCK"));
    }

    // used by nextColor as the list of colors through which we rotate
    var myColors = ["lightgray", "lightblue", "lightgreen", "yellow", "orange", "pink"];

    // used by both the Button Binding and by the changeColor click function
    function nextColor(c) {
        var idx = myColors.indexOf(c);
        if (idx < 0) return "lightgray";
        if (idx >= myColors.length - 1) idx = 0;
        return myColors[idx + 1];
    }

    function changeColor(e, button) {
        var node = button.part.adornedPart;
        var shape = node.findObject("SHAPE");
        if (shape === null) return;
        node.diagram.startTransaction("Change color");
        shape.fill = nextColor(shape.fill);
        button["_buttonFillNormal"] = nextColor(shape.fill); // update the button too
        node.diagram.commitTransaction("Change color");
    }

    function drawLink(e, button) {
        var node = button.part.adornedPart;
        var tool = e.diagram.toolManager.linkingTool;
        tool.startObject = node.port;
        e.diagram.currentTool = tool;
        tool.doActivate();
    }

    // used by both clickNewNode and dragNewNode to create a node and a link
    // from a given node to the new node
    function createNodeAndLink(data, fromnode,nodeInfo) {
        var diagram = fromnode.diagram;
        var model = diagram.model;
        var nodedata = model.copyNodeData(data);
        nodedata.key = nodeInfo.ID;
        nodedata.text = nodeInfo.Name;
        model.addNodeData(nodedata);
        var newnode = diagram.findNodeForData(nodedata);
        var linkdata = model.copyLinkData({});
        model.setFromKeyForLinkData(linkdata, model.getKeyForNodeData(fromnode.data));
        model.setToKeyForLinkData(linkdata, model.getKeyForNodeData(newnode.data));
        model.addLinkData(linkdata);
        diagram.select(newnode);
        $(".list-process").removeClass("open");
        return newnode;
    }
    function createNodeAndLinkRoot (_event,nodeInfo){
        var left = (_event.clientX);
        var top = (_event.clientY);
        var nodedata = {
            key : nodeInfo.ID,
            text : nodeInfo.Name,
            x : left,
            y : top
        }
        myDiagram.model.addNodeData(nodedata);
        $(".list-process").removeClass("open");
        return true;
    }
    // the Button.click event handler, called when the user clicks the "N" button
    function clickNewNode(e, button = null) {
        var data_Tree = JSON.parse(myDiagram.model.toJson());
        var nodeDataArray = data_Tree.nodeDataArray;
        var notIn = [];
        $.each(nodeDataArray ,function(key,value){
            notIn.push(value.key);
        });
        $.ajax({
            url : "<?php echo backend_url("scenario/get")?>",
            type : "post",
            dataType:"json",
            data : { id : _ID },
            success : function(data){
               var processData = (data.process);
               notIn = notIn.concat(data.notIN);
               var html = "";
               if(processData){
                    $.each (processData,function($key,$value){
                        if(notIn.indexOf($value["ID"]) === -1){
                            html +=`<li class="addNode" data='`+JSON.stringify($value)+`'>
                               `+$value["Name"]+`
                                <div class="action">
                                    <a href="javascript:;"><i class="fa fa-plus-square" aria-hidden="true"></i></a>
                                </div>
                            </li>`;
                        }
                    });
                    $(".list-process ul").html(html);
                    $(".list-process").addClass("open");
               }
            },
            error : function(){
            }
        });
        _button = button;
        _event  = e;
        return false;
    }
    $(document).on("click","#add-node",function(){
        _ROOT = 1;
        clickNewNode(_event,null);
    });
    $(document).on('click', '#sample .list-process li.addNode', function () {
        _nodeInfo = $(this).attr("data");
        _nodeInfo = JSON.parse(_nodeInfo);
        if(_ROOT == 0){
            var data = _button._dragData;
            if (!data) return;
            _event.diagram.startTransaction("Create Node and Link");
            var fromnode = _button.part.adornedPart;
            var newnode = createNodeAndLink(_button._dragData, fromnode,_nodeInfo);
            newnode.location = new go.Point(fromnode.location.x + 200, fromnode.location.y);
            _event.diagram.commitTransaction("Create Node and Link");
        }else if(_ROOT == 1){
            _ROOT = 0;
            createNodeAndLinkRoot(_event,_nodeInfo);
        }
        
        return false;
    });
    $("body").click(()=>{
      $(".fix-menu-right").removeClass("open");
    });
    $(document).on("contextmenu","#my-map-modal #myDiagramDiv", function(event){
        event.stopPropagation();
        event.preventDefault();
        _event = event;
        var left = (event.clientX);
        var top = (event.clientY);
        console.log(event);
        $(".fix-menu-right").css({
            left: left + "px",
            top: top + "px"
        }).addClass("open");
        return false;
    })
    // the Button.actionMove event handler, called when the user drags within the "N" button
    function dragNewNode(e, button) {
        var tool = e.diagram.toolManager.draggingTool;
        if (tool.isBeyondDragSize()) {
            var data = button._dragData;
            if (!data) return;
            e.diagram.startTransaction("button drag"); // see doDeactivate, below
            var newnode = createNodeAndLink(data, button.part.adornedPart);
            newnode.location = e.diagram.lastInput.documentPoint;
            // don't commitTransaction here, but in tool.doDeactivate, after drag operation finished
            // set tool.currentPart to a selected movable Part and then activate the DraggingTool
            tool.currentPart = newnode;
            e.diagram.currentTool = tool;
            tool.doActivate();
        }
    }

    // using dragNewNode also requires modifying the standard DraggingTool so that it
    // only calls commitTransaction when dragNewNode started a "button drag" transaction;
    // do this by overriding DraggingTool.doDeactivate:
    var tool = myDiagram.toolManager.draggingTool;
    tool.doDeactivate = function () {
        // commit "button drag" transaction, if it is ongoing; see dragNewNode, above
        if (tool.diagram.undoManager.nestedTransactionNames.elt(0) === "button drag") {
            tool.diagram.commitTransaction();
        }
        go.DraggingTool.prototype.doDeactivate.call(tool); // call the base method
    };

    //Chiết xuất từ csdl ra model
}

function save() {
    document.getElementById("mySavedModel").value = myDiagram.model.toJson();
    var data_Tree = JSON.parse(myDiagram.model.toJson());
    var nodeDataArray = data_Tree.nodeDataArray;
    var relationship = data_Tree.linkDataArray;
    $.ajax({
        url : "<?php echo backend_url("scenario/update")?>",
        type : "post",
        dataType:"json",
        data : {id : _ID ,nodeDataArray: nodeDataArray ,relationship : relationship},
        success : function (data){
            console.log(data);
        }
    })
    myDiagram.isModified = false;
}

function load() {
    myDiagram.model = go.Model.fromJson(document.getElementById("mySavedModel").value);
    // When copying a node, we need to copy the data that the node is bound to.
    // This JavaScript object includes properties for the node as a whole, and
    // four properties that are Arrays holding data for each port.
    // Those arrays and port data objects need to be copied too.
    // Thus Model.copiesArrays and Model.copiesArrayObjects both need to be true.

    // Link data includes the names of the to- and from- ports;
    // so the GraphLinksModel needs to set these property names:
    // linkFromPortIdProperty and linkToPortIdProperty.
}
$(document).ready(function () {
    init();
    $('#my-map-modal').on('shown.bs.modal', function (e) {
        load();
    });
    $(document).on('click', 'a.is_ajax', function () {
        $("#form-modal .modal-body .message").hide();
        var url = $(this).attr('href');
        $.ajax({
            type: 'POST',
            dataType: 'html',
            url: url,
            data: {},
            success: function (html) {
                if (html != -1) {
                    $(".box-common-edit-add .form-slider").html(html);
                    $(".box-common-edit-add").slideDown();
                    $("body,html").animate({
                        scrollTop: 0
                    }, 'slow');
                } else {
                    alert('Kịch bản này không tồn tại.');
                }
            }
        });
        return false;
    });
    $(document).on('click', 'a.is_ajax_delete', function () {
        if (confirm('Bạn thật sự muốn xóa?')) {
            var current = $(this);
            var url = $(this).attr('href');
            $.ajax({
                type: 'POST',
                dataType: 'json',
                url: url,
                data: {},
                success: function (data) {
                    if (data['status'] == 'success') {
                        current.parents('tr').remove();
                        $('tr td[data-column="Stt"]').each(function (i) {
                            $(this).html(i + 1);
                        });
                    } else if (data['status'] == 'fail') {
                        alert(data['message']);
                    }
                }
            });
        }
        return false;
    });

    $(document).on('submit', '.box-common-edit-add form', function () {
        var current = $(this);
        $(".box-common-edit-add .message").hide();
        var options = {
            dataType: 'json',
            success: function (data) {
                if (data['status'] == 'success') {
                    var fields = ["Name", "EstimateName", "ScenarioDate", 'SoTram', "SoLuong", "Created_At"];
                    if (data['action'] == 'add') {
                        var html = '<tr data-id="' + data['responsive']['ID'] + '">';
                        html += '   <td data-column="Stt"></td>';
                        fields.forEach(function (element) {
                            html += '<td data-column="' + element + '">' + data['responsive'][element] + '</td>';
                        });
                        html += '   <td data-column="Action">';
                        html += '       <a class="is_ajax" href="<?php echo backend_url($folder_view."/edit/"); ?>' + data['responsive']['ID'] + '"><i class="fa fa-edit" aria-hidden="true"></i></a> | ';
                        html += '       <a class="is_ajax_delete" href="<?php echo backend_url($folder_view.' / delete / '); ?>' + data['responsive']['ID'] + '"><i class="fa fa-trash" aria-hidden="true"></i></a>';
                        html += '   </td>';
                        html += '</tr>';
                        $('.x_content table').prepend(html);

                        $('tr td[data-column="Stt"]').each(function (i) {
                            $(this).html(i + 1);
                        });
                    } else {
                        fields.forEach(function (element) {
                            $('tr[data-id="' + data['responsive']['ID'] + '"] td[data-column="' + element + '"]').html(data['responsive'][element]);
                        });
                    }
                    $(".box-common-edit-add").slideUp();
                } else if (data['status'] == 'fail') {
                    $(".box-common-edit-add .alert-danger").html(data['message']).show();
                }
            }
        };
        current.ajaxSubmit(options);
        return false;
    });
    $(document).on("click", "a.map-modal", function () {
        _ID = $(this).attr("data-id");
        $("#my-map-modal").modal();
    });
    $('.collapse-link-custom').click(function () {
        $(".box-common-edit-add").slideUp();
        return false;
    });
});
</script>