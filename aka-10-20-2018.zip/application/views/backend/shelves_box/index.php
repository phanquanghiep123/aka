<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo skin_backend('js/jquery-ui.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo skin_backend('js/jquery.ui.nestedSortable.js'); ?>"></script>
<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_content">
				<div class="row">
					<div class="col-sm-12">
						<h4>Hộp</h4>
						<ol class="sortable sortable-box ui-sortable">
							<?php if(isset($boxs) && $boxs != null): ?>
								<?php foreach ($boxs as $key => $item): ?>
									<li class="box" data-box-id="<?php echo $item['ID']; ?>">
								        <div>
								        	<a href="#" class="remove"><i class="fa fa-times" aria-hidden="true"></i></a>
								        	<?php echo $item['Name']; ?>
								        </div>
								    </li>
								<?php endforeach; ?>
							<?php endif; ?>
						</ol>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<?php if(isset($results) && $results != null): ?>
							<?php foreach ($results as $key => $item): ?>
								<div class="group-shelves">
									<?php foreach ($item['boxs'] as $i => $item1): ?>
										<div class="row-shelves">
											<?php foreach ($item1 as $j => $item2): ?>
												<?php if(count($item1) > 0): ?>
													<div class="shelves" style="width: <?php echo (100/count($item1)).'%'; ?> ">
														<div class="shelves-wrap">
															<h4><?php echo $item2['current']['Name']; ?> - <?php echo $i; ?> - <?php echo $j; ?></h4>
															<ol class="sortable sortable-shelves ui-sortable" style="min-height: 150px;" data-shelves-id="<?php echo $item2['current']['ID']; ?>">
																<?php foreach ($item2['result'] as $key => $box): ?>
																	<li class="box item-box" data-shelves-id="<?php echo $item2['current']['ID']; ?>" data-box-id="<?php echo $box['Hop_ID']; ?>" style="display: list-item;">
																        <div style="">
																        	<a href="#" class="remove"><i class="fa fa-times" aria-hidden="true"></i></a>
																        	<?php echo $box['BoxName']; ?>
																       	</div>
																    </li>
																<?php endforeach; ?>
															</ol>
														</div>
													</div>
												<?php endif; ?>
											<?php endforeach; ?>
										</div>
									<?php endforeach; ?>
								</div>
								<div style="height: 50px;"></div>
							<?php endforeach; ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<style type="text/css">
	.row-shelves:before,
	.row-shelves:after{content: '';display: table;}
	.row-shelves:after{clear: both;}
	.row-shelves{display: flex;}
	.shelves{
		float:left;
		border-bottom:1px solid #000;
		border-right:1px solid #000;
	}
	.shelves .shelves-wrap{
		padding: 10px;
	}
	.shelves .shelves-wrap > h4{
		text-align: center;
    	margin-bottom: 15px;
	}
	.row-shelves:first-child  .shelves{
		border-top:1px solid #000;
	}
	.row-shelves .shelves:first-child{
		border-left:1px solid #000;
	}

    ol.sortable,
    ol.sortable ol {
        padding: 0;
        list-style-type: none;
    }
    ol.sortable ol{
    	padding: 0 0 0 25px;
    }
    
    ol.sortable {
        width: 100%;
    }
    
    .sortable li {
        margin: 7px 0 0 0;
        padding: 0;
        display: inline-block;
        min-width: 125px;
    }
    .sortable-shelves li{display: block !important;}
    
    .sortable li div {
        border: 1px solid #ccc;
	    padding: 7px 15px;
	    margin: 0;
	    cursor: move;
	    font-size: 17px;
	    position: relative;
    }
    .sortable li div .remove{
    	color: #ff0000;
    	position: absolute;
    	right: 7px;
    	top: 10px;
    	z-index: 100;
    	font-size: 13px;
    	display: none;
    }
    .shelves-wrap .item-box .remove{
    	display: block !important;
    }
    .sortable li[id^="list_1_"] > div {
        background: #fff;
    }
    .main_menu ul ul li span.fa{display: none;}
</style>
<script type="text/javascript">
	$(document).ready(function(){
	    $(window).load(function() {
	    	var js_ajax = true;
	    	var shelves_first = null,shelves_last = null;
	        $('ol.sortable-shelves').nestedSortable({
	            disableNesting: 'no-nest',
	            forcePlaceholderSize: true,
	            handle: 'div',
	            helper: 'clone',
	            items: 'li',
	            maxLevels: 1,
	            opacity: .6,
	            placeholder: 'placeholder',
	            revert: 250,
	            tabSize: 25,
	            tolerance: 'pointer',
	            toleranceElement: '> div',
	            connectWith: '.sortable',
	            start: function(evt, ui) {
	            	shelves_first = ui.item.parents('ol.sortable-shelves').attr('data-shelves-id');
	            },
	            stop: function(evt, ui) {
	            	shelves_last = ui.item.parents('ol.sortable-shelves').attr('data-shelves-id');
	            	var box_id = ui.item.attr('data-box-id');
	            	if (typeof box_id !== typeof undefined && box_id !== false && typeof shelves_first !== typeof undefined && shelves_first !== false && typeof shelves_last !== typeof undefined && shelves_last !== false) {
		            	if(js_ajax){
		            		js_ajax = false;
		            		$.ajax({
				                type: 'POST',
				                dataType:'json',
				                url: "<?php echo backend_url($folder_view."/edit/"); ?>",
				                data:{'Hop_ID' : box_id, 'Gia_Old' : shelves_first, 'Gia_New' : shelves_last},
				                success: function(data) {
				                	if(data['status'] == 'success'){
				                    	
				                	}
				                    else{
				                    	alert('Chuyển giá đựng thất bại.');
				                    }
				                },
				                complete:function(){
				                	js_ajax = true;
				                }
				            });
		            	}
		            }
	            },
	            update: function(e, ui) {
	            	if(ui.item.hasClass('item-box')){
	            		if(!ui.item.parent().hasClass('sortable-shelves')){
	            			return false;
	            		}
	            	}
	            }
	        });

	        $('ol.sortable-box').nestedSortable({
	            disableNesting: 'no-nest',
	            forcePlaceholderSize: true,
	            handle: 'div',
	            helper: 'clone',
	            items: 'li',
	            maxLevels: 1,
	            opacity: .6,
	            placeholder: 'placeholder',
	            revert: 250,
	            tabSize: 25,
	            tolerance: 'pointer',
	            toleranceElement: '> div',
	            connectWith: '.sortable-shelves',
	            stop: function(evt, ui) {
	            	ui.item.addClass('item-box');
	            	var box_id = ui.item.attr('data-box-id');
	            	var shelves_id = $('ol.sortable-shelves .box[data-box-id="' + box_id + '"]').parents('ol.sortable-shelves').attr('data-shelves-id');
	            	if (typeof box_id !== typeof undefined && shelves_id !== false && shelves_id !== false) {
		            	if(js_ajax){
		            		js_ajax = false;
		            		$.ajax({
				                type: 'POST',
				                dataType:'json',
				                url: "<?php echo backend_url($folder_view."/add/"); ?>",
				                data:{'Hop_ID' : box_id, 'Gia_ID' : shelves_id},
				                success: function(data) {
				                	if(data['status'] == 'success'){
				                    	ui.item.attr('data-shelves-id',shelves_id);
				                	}
				                    else{
				                    	alert('Thêm mới thất bại.');
				                    	location.reload();
				                    }
				                },
				                complete:function(){
				                	js_ajax = true;
				                }
				            });
		            	}
		            }
	            }
	        });
	    });

	    $(".side-menu > li > a").click(function(){
	    	$(".side-menu > li").not($(this).parent()).removeClass('active');
	    	$(".side-menu > li ul").not($(this).parent().find('> ul')).slideUp();
	    	$(this).parent().toggleClass('active');
	    	$(this).parent().find('> ul').slideToggle();
	    	return false;
	    });

	    $(document).on('click','.item-box .remove',function(){
	    	var current = $(this);
	    	var box = current.parents('.item-box');
	    	var html = box.html();
	    	var box_id = box.attr('data-box-id');
	        var shelves_id = box.attr('data-shelves-id');
	        if (typeof box_id !== typeof undefined && shelves_id !== false && shelves_id !== false) {
		    	$.ajax({
	                type: 'POST',
	                dataType:'json',
	                url: "<?php echo backend_url($folder_view."/delete/"); ?>",
	                data:{'Hop_ID' : box_id, 'Gia_ID' : shelves_id},
	                success: function(data) {
	                	if(data['status'] == 'success'){
	                		$('ol.sortable-box').prepend('<li class="box" data-box-id="' + box_id + '">' + html + '</li>');
	    					box.remove();
	                	}
	                }
	            });
	        }
	    	return false;
	    });
	});
</script>