<div class="main-page row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-12">
						<h2><?php echo @$title_page; ?> </h2>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
					<form method="post" action="<?php echo backend_url('/'.@$folder_view.'/import/'); ?>" class="form-import-data">
						<div class="row">
							<div class="col-sm-8 col-sm-offset-2">
								<div class="table-responsive">
  									<table class="table table-striped jambo_table not-datatable">
  										<thead>
									        <tr>
									            <th>Tiêu đề</th>
									            <th>Trường dữ liệu</th>
									        </tr>
									    </thead>
									    <tbody>
									    	<?php if(isset($header) && $header != null): ?>
									    		<?php foreach ($header as $key => $item): ?>
											        <tr>
											            <td style="width: 50%;"><?php echo $item; ?></td>
											            <td style="width: 50%;">
											            	<select class="form-control" name="field[<?php echo $key; ?>]">
											            		<option value="">Chọn trường</option>
											            		<?php if(isset($colums) && $colums != null): ?>
									    							<?php foreach ($colums as $key1 => $item1): ?>
									    								<option value="<?php echo $item1['COLUMN_NAME']; ?>"><?php echo $item1['COLUMN_COMMENT']; ?></option>
									    							<?php endforeach; ?>	
									    						<?php endif; ?>
											            	</select>
											            </td>
											        </tr>
											    <?php endforeach; ?>
											    <tr>
											    	<td colspan="2" class="text-right">
											    		<input type="hidden" name="table" value="<?php echo @$table; ?>">
											    		<input type="hidden" name="path_file" value="<?php echo @$path_file; ?>">
											    		<button type="submit" class="btn btn-primary">Nhập dữ liệu</button>
											    	</td>
											    </tr>
										    <?php endif; ?>
									    </tbody>
									</table>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('submit','.form-import-data',function(){
			var current = $(this);
			var options = {
                dataType:'json',
                success: function(data){
                	//console.log(data);
                    if(data['status'] == 'success'){
                    	alert('Nhập thành công.');
                    	location.reload();
                    }
                    else if(data['status'] == 'fail'){
                    	alert(data['message']);
                    }
                }
            }; 
            current.ajaxSubmit(options);
			return false;
		});
	});
</script>