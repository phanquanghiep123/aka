<div class="main-page row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-12">
						<h2><?php echo @$title_page; ?> </h2>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
					<form action="" method="post" enctype="multipart/form-data">
						<div class="row">
							<div class="col-sm-3"></div>
							<div class="col-sm-3">
								<div class="input-group">
					                <input type="text" class="form-control" readonly>
					                <label class="input-group-btn">
					                    <span class="btn btn-primary">
					                        <input type="file" style="display: none;" name="excel" accept=".xls,.xlsx"> Browse&hellip; 
					                    </span>
					                </label>
					            </div>
							</div>
							<div class="col-sm-2">
								<button type="submit" name="sumit" class="btn btn-primary">Tải file</button>
							</div>
							<div class="col-sm-3"></div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change', ':file', function() {
		    var input = $(this),
		        numFiles = input.get(0).files ? input.get(0).files.length : 1,
		        label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
		    input.trigger('fileselect', [numFiles, label]);
		});

		$(document).ready( function() {
		    $(':file').on('fileselect', function(event, numFiles, label) {
		        var input = $(this).parents('.input-group').find(':text'),
		              log = numFiles > 1 ? numFiles + ' files selected' : label;
		        if( input.length ) {
		            input.val(log);
		        }
		    });
		});
	});
</script>