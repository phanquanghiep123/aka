<div class="row">
	<div class="col-md-12">
		<div class="row">
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Tên kịch bản <span class="required">*</span></label>
					<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required" readonly disable>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Chi phí chưa lương <span class="required">*</span> </label>
					<input class="form-control" value="<?php echo @$record["ChiPhiChuaLuong"]; ?>" name="ChiPhiChuaLuong" type="text" required="required" readonly disable>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Chi phí có lương <span class="required">*</span></label>
					<input class="form-control" value="<?php echo @$record["ChiPhiCoLuong"]; ?>" name="ChiPhiCoLuong" type="text" required="required" readonly disable>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Số CN trực tiếp SX <span class="required">*</span></label>
					<input class="form-control" value="<?php echo @$record["SoCNTrucTiepSX"]; ?>" name="SoCNTrucTiepSX" type="number" required="required" readonly disable>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Số ngày/năm SX <span class="required">*</span></label></label>
					<input class="form-control" value="<?php echo @$record["SoNgaySX_Nam"]; ?>" name="SoNgaySX_Nam" type="text" required="required" readonly disable>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Số liệu theo (Năm/tháng) <span class="required">*</span></label>
					<input class="form-control" value="<?php echo @$record["SoLieuTheoNam_Thang"]; ?>" name="SoLieuTheoNam_Thang" type="text" required="required" readonly disable>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<div class="form-group"> 
					<label class="control-label">Ghi chú</label>
					<textarea class="form-control" rows="6" name="Description" readonly disable><?php echo @$record["Description"]; ?></textarea>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Para1</label>
					<input class="form-control" value="<?php echo @$record["Para1"]; ?>" name="Para1" type="text" required="required" readonly disable>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Para2</label>
					<input class="form-control" value="<?php echo @$record["Para2"]; ?>" name="Para2" type="text" required="required" readonly disable>
				</div>
			</div>
		</div>
		 
		<div class="row">
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Para3</label>
					<input class="form-control" value="<?php echo @$record["Para3"]; ?>" name="Para3" type="text" required="required" readonly disable>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Para4</label>
					<input class="form-control" value="<?php echo @$record["Para4"]; ?>" name="Para4" type="text" required="required" readonly disable>
				</div>
			</div>
		</div>
		 
		<div class="row">
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Para5</label>
					<input class="form-control" value="<?php echo @$record["Para5"]; ?>" name="Para5" type="text" required="required" readonly disable>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Trạng thái</label>
			    	<?php if(@$record["Status"] == 1){
			    		echo '<input class="form-control" value="Hoạt động" type="text" required="required" readonly disable>';
			    	}else {
			    		echo '<input class="form-control" value="Ngưng hoạt type="text" required="required" readonly disable>';  
			    	}?>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-12">
		<div class="ln_solid"></div>
		<h3>Chi tiết</h3>
		<?php
			if(@$details){
				foreach ($details as $key => $detail) {?>
					<div class="row"> 
						<div class="col-sm-6">
							<div class="form-group"> 
								<label class="control-label">Tên<span class="required">*</span></label>
								<input class="form-control" value="<?php echo @$detail["Name"] ?>" name="detail[Name][]" type="text" readonly disable>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group"> 
								<label class="control-label">Số tiền<span class="required">*</span></label>
								<input class="form-control" value="<?php echo @$detail["SoTien"] ?>" name="detail[SoTien][]" type="text" readonly disable>
							</div>
						</div>
					</div>
				<?php }
			} 
		?>	 	 
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="ln_solid"></div>
		<div class="text-right">
			<button type="button" class="btn btn-primary" data-dismiss="modal">Đóng</button>
		</div>
	</div>
</div>