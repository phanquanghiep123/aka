<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="box-common-edit-add relative" style="display: none;">
			<a class="collapse-link-custom" href="#" style="color: #ff0000;"><i class="fa fa-times" aria-hidden="true"></i></a>
			<div class="form-slider" style="max-width: 800px;margin:0 auto;"></div>
		</div>
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-8">
						<h2>
							<?php echo @$title_page; ?> 
							<a class="btn btn-success create-item is_ajax" href="<?php echo backend_url($folder_view."/order_add");?>"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Thêm mới</a>
						</h2>
					</div>
					<div class="col-sm-4">
						<form method="" method="get">
							<div class="row">
								<div class="col-sm-8">
									<div class="form-group">
										<input type="text" class="form-control" placeholder="Từ khóa" name="keyword" value="<?php echo $this->input->get('keyword'); ?>">
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<button type="submit" class="btn btn-primary">Tìm kiếm</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
					<table class="table table-striped jambo_table bulk_action">
						<thead>
							<tr class="headings">
								<td>Stt</td>
								<?php foreach ($header as $key => $value) {
									echo "<td>".$value."</td>";
								}?>
							</tr>
						</thead>
						<tbody>
						    <?php if(isset($results) && $results != null): ?>
						        <?php foreach ($results as $key => $value): ?>
						    		<tr data-id="<?php echo $value['ID']; ?>">
										<td data-column="Stt"><?php echo $key+1;?></td>
										<td data-column="Name"><?php echo $value["Name"]; ?></td>
										<td data-column="KichBan"><?php echo $value["KichBan"]; ?></td>
										<td data-column="Para1"><?php echo $value["Para1"]; ?></td>
										<td data-column="Para2"><?php echo $value["Para2"]; ?></td>
										<td data-column="Para3"><?php echo $value["Para3"]; ?></td>
										<td data-column="Para4"><?php echo $value["Para4"]; ?></td>
										<td data-column="Para5"><?php echo $value["Para5"]; ?></td>
										<td data-column="Action">
											<a class="is_ajax" title="Chỉnh sửa" href="<?php echo backend_url($folder_view."/order_edit/".$value["ID"])?>"><i class="fa fa-edit" aria-hidden="true"></i></a> | 
											<a class="is_ajax_delete" title="Xóa" href="<?php echo backend_url($folder_view.'/order_delete/'.$value["ID"])?>"><i class="fa fa-trash" aria-hidden="true"></i></a> | 
											<a class="view_ajax" title="Xem chi tiết" href="<?php echo backend_url($folder_view."/order_view/".$value["ID"])?>" ><i class="fa fa-eye" aria-hidden="true"></i></a> 
										</td>
									</tr>
							    <?php endforeach; ?>
						    <?php endif; ?>
						</tbody>
					</table>
				</div>
				<?php if(isset($this->pagination)): ?>
					<div class="row">
						<div class="col-sm-12 text-center">
							<?php echo @$this->pagination->create_links();?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div id="upload-modal" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg" style="max-width: 700px;">
        <!-- Modal content-->
        <form class="form-horizontal form-label-left" action="<?php echo backend_url($folder_view."/import/"); ?>" method="post" enctype="multipart/form-data">
	        <div class="modal-content">
	            <div class="modal-header">
	                <button type="button" class="close" data-dismiss="modal">&times;</button>
	                <h4 class="modal-title">Chi tiết kịch bản</h4>
	            </div>
	            <div class="modal-body">
	                <div class="message alert alert-success" style="display: none;"></div>
	                <div class="message alert alert-danger" style="display: none;"></div>
	                <div class="file-sample table-responsive">
						<table class="table table-bordered">
							<thead>
								<tr>
									<th class="text-center top-number"></th>
									<?php for($char = 'A',$i = 0; $char <= 'Z',$i < count($header); $char++,$i++): ?>
										<th class="text-center"><?php echo $char; ?></th>
									<?php endfor; ?>
								</tr>
								<tr>
									<th>
										<p>1</p>
									</th>
									<?php foreach ($header as $key => $item): ?>
										<th class="bg-blue">
											<p data-toggle="tooltip" data-placement="top" title="<?php echo $item; ?>"><?php echo $item; ?></p>
										</th>
									<?php endforeach; ?>
								</tr>
							</thead>
						</table>
					</div>
					<p class="text-right dowload-excel-sample">
						<a href="<?php echo base_url('/uploads/template-excel/nha-cung-cap.xls'); ?>" download="">Tải file Excel mẫu</a>
					</p>
	            </div>
	            <div class="modal-footer">
	            	<div class="text-right">
			    		<a type="button" class="btn btn-gray" data-dismiss="modal">Hủy bỏ</a> 
			    		<button id="upload-from-now" type="button" onclick="$('#file-upload').trigger('click');return false;" class="btn action-bnt btn-primary relative">Chọn file Excel</button> 
			    		<input type="file" name="excel" class="hidden" id="file-upload" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" > 
			    	</div>
	            </div>
	        </div>
	    </form>
    </div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$('#file-upload').change(function(){
			var current = $(this);
			current.parents('form').find(".message").hide();
			var options = {
                dataType:'json',
                type: 'POST',
	            url: "<?php echo backend_url($folder_view."/import/"); ?>",
                success: function(data){
                    if(data['status'] == 'success'){
                    	alert(data['message']);
                    	location.reload();
                    }
                    else if(data['status'] == 'fail'){
                    	current.parents('form').find(".alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.parents('form').ajaxSubmit(options);
		});
	});
</script>

<script type="text/javascript">
	$(document).ready(function(){

		$(document).on('click','a.view_ajax',function(){
			var url = $(this).attr('href');
            $.ajax({
                type: 'POST',
                dataType:'json',
                url: url,
                data:{},
                success: function(data) {
                	if(data['status'] == 'success'){
                		$("#form-modal .modal-body .result-form").html(data['response']);
                    	$("#form-modal").modal('show');
                	}
                }
            });
			return false;
		});
		$(document).on('click','a.is_ajax',function(){
			$("#form-modal .modal-body .message").hide();
			var url = $(this).attr('href');
            $.ajax({
                type: 'POST',
                dataType:'html',
                url: url,
                data:{},
                success: function(html) {
                	if(html != -1){
                    	$(".box-common-edit-add .form-slider").html(html);
                    	$(".box-common-edit-add").slideDown();
                    	$("body,html").animate({scrollTop:0}, 'slow');
                	}
                    else{
                    	alert('Nhà cung cấp không tồn tại.');
                    }
                }
            });
			return false;
		});

		$(document).on('click','a.is_ajax_delete',function(){
			if(confirm('Bạn thật sự muốn xóa?')){
				var current = $(this);
				var url = $(this).attr('href');
	            $.ajax({
	                type: 'POST',
	                dataType:'json',
	                url: url,
	                data:{},
	                success: function(data) {
	                	if(data['status'] == 'success'){
	                		current.parents('tr').remove();
	                		$('tr td[data-column="Stt"]').each(function(i){
	                    		$(this).html(i+1);
	                    	});
	                	}
	                	else if(data['status'] == 'fail'){
	                		alert(data['message']);
	                	}
	                }
	            });
            }
			return false;
		});

		$(document).on('submit','.box-common-edit-add form',function(){
			var current = $(this);
			$(".box-common-edit-add .message").hide();
			var options = {
                dataType:'json',
                success: function(data){
                    if(data['status'] == 'success'){
                    	var fields = [
	                    	'Name',
				            'KichBan',
				            'Para1',
				            'Para2',
				            'Para3',
				            'Para4',
				            'Para5'
                    	];
                        if(data['action'] == 'add'){
                        	var html = '<tr data-id="' + data['responsive']['ID'] + '">';
                    		html += '	<td data-column="Stt"></td>';
                    		fields.forEach(function(element) {
							  	html += '<td data-column="' + element + '">' + data['responsive'][element] + '</td>';
							});
                    		html += '<td data-column="Action">';
			            		html += '<a class="is_ajax" href="<?php echo backend_url($folder_view."/edit/"); ?>' + data['responsive']['ID'] + '"><i class="fa fa-edit" aria-hidden="true"></i></a> | ';
								html += '<a class="is_ajax_delete" href="<?php echo backend_url($folder_view."/delete/"); ?>' + data['responsive']['ID'] + '"><i class="fa fa-trash" aria-hidden="true"></i></a> | ';
			            		html +=	'<a class="view_ajax" title="Xem chi tiết" href="<?php echo backend_url($folder_view."/view/"); ?>' + data['responsive']['ID'] + '" ><i class="fa fa-eye" aria-hidden="true"></i></a>';
	                    		html += '</td>';
                    		html += '</tr>';
                        	$('.x_content table').prepend(html);
                        	$('tr td[data-column="Stt"]').each(function(i){
                        		$(this).html(i+1);
                        	});
                        }
                        else{
                        	fields.forEach(function(element) {
							  	$('tr[data-id="' + data['responsive']['ID'] + '"] td[data-column="' + element + '"]').html(data['responsive'][element]);
							});
                        }
                        $(".box-common-edit-add").slideUp();
                    }
                    else if(data['status'] == 'fail'){
                    	$(".box-common-edit-add .alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.ajaxSubmit(options);
			return false;
		});

		$('.collapse-link-custom').click(function(){
			$(".box-common-edit-add").slideUp();
			return false;
		});
	});
</script>

<style type="text/css">
	.plus-detail-script{
		position: absolute;
		right: 0px;
		top: 0;
	}
	.actions-detail{
		position: absolute;
		right: 10px;
		top: 0;
	}
	.content-detail-script{
		position: relative;
	}
	.item-detail{
		position: relative;
		float: left;
	}
</style>
<script type="text/javascript">
	var detail = '<div class="row item-detail">\
			<input class="form-control" value="0" name="detail[ID][]" type="hidden" required="required">\
			<div class="col-sm-6">\
				<div class="form-group">\
					<label class="control-label">Số công nhân<span class="required">*</span></label>\
					<input class="form-control" value="" name="detail[SoCN][]" type="text">\
				</div>\
			</div>\
			<div class="col-sm-6">\
				<div class="form-group"> \
					<label class="control-label">Số chuyền<span class="required">*</span></label>\
					<input class="form-control" value="" name="detail[SoChuyen][]" type="text">\
				</div>\
			</div>\
			<div class="col-sm-12">\
				<div class="form-group"> \
					<label class="control-label">Sản lượng<span class="required">*</span></label>\
					<input class="form-control" value="" name="detail[SanLuong][]" type="text">\
				</div>\
			</div>\
			<div class="actions-detail">\
				<a class="move-item" data-index="2" href="javascript:;"><i class="fa fa-arrow-down" aria-hidden="true"></i></a>\
				<a class="move-item" data-index="-1" href="javascript:;"><i class="fa fa-arrow-up" aria-hidden="true"></i></a>\
				<a class="delete-item" href="javascript:;"><i class="fa fa-trash" aria-hidden="true"></i></a>\
			</div>\
			<div class="col-sm-12"><div class="ln_solid"></div></div>\
		</div>';
	$(document).on("click",".item-detail .actions-detail .move-item",function(){
        var number_current = $(this).parents(".item-detail").index();
        var dataAction = $(this).attr("data-index");
        dataAction = parseInt(dataAction);
        if(dataAction == 2 && number_current + 1 >= $(".form-slider .content-detail .item-detail").length) return false;
        if(dataAction == -1 && number_current == 0) return false;
        $data = $(this).parents(".item-detail");
        if(dataAction == 2 ){
        	$data.insertAfter($(this).parents(".content-detail").find(".item-detail").eq(number_current + 1)); 
        }else{
        	$data.insertBefore($(this).parents(".content-detail").find(".item-detail").eq(number_current - 1)); 
        }
        
        return false;
    });
    $(document).on("click",".item-detail .actions-detail .delete-item",function(){
        $(this).parents(".item-detail").remove();
        return false;
    });
     $(document).on("click",".form-slider .plus-detail",function(){
        $(".form-slider .content-detail").append(detail);
        return false;
    });
</script>