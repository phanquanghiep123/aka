<div class="row">
	<div class="col-md-12">
		<h3> Thông tin ước tính</h3>
		<div class="ln_solid"></div>
		<div class="row">
			<div class="col-sm-12">
				<div class="form-group"> 
					<label class="control-label">Tên ước tính<span class="required">*</span></label>
					<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" readonly disable>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<div class="form-group"> 
					<label class="control-label">Kịch bản <span class="required">*</span> </label>
					<?php if($scripts):?>
			    		<?php foreach ($scripts AS $key_script => $script):?>
			    			<?php if( $script["ID"] == @$record["KichBan_ID"] ) :?>
			    				<input class="form-control" value="<?php echo @$script["Name"]; ?>" name="Name" type="text" readonly disable>
			    			<?php endif;?>
			    		<?php endforeach;?>
			    	<?php endif;?>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<div class="form-group"> 
					<label class="control-label">Ghi chú</label>
					<textarea class="form-control" rows="6" name="Description" readonly disable><?php echo @$record["Description"]; ?></textarea>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Para1</label>
					<input class="form-control" value="<?php echo @$record["Para1"]; ?>" name="Name" type="text" readonly disable>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Para2</label>
					<input class="form-control" value="<?php echo @$record["Para2"]; ?>" name="Name" type="text" readonly disable>
				</div>
			</div>
		</div>
		 
		<div class="row">
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Para3</label>
					<input class="form-control" value="<?php echo @$record["Para3"]; ?>" name="Name" type="text" readonly disable>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Para4</label>
					<input class="form-control" value="<?php echo @$record["Para4"]; ?>" name="Name" type="text" readonly disable>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Para5</label>
					<input class="form-control" value="<?php echo @$record["Para5"]; ?>" name="Name" type="text" readonly disable>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Trạng thái</label>
			    	<?php if(@$record["Status"] == 1){
			    		echo '<input class="form-control" value="Hoạt động" name="Name" type="text" readonly disable>';
			    	}else {
			    		echo '<input class="form-control" value="Ngưng hoạt động" name="Name" type="text" readonly disable>';
			    	}?>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-12">
		<h3>Chi tiết ước tính</h3>
		<div class="ln_solid"></div>
		<div class="content-detail-script">
			<div class="content-detail">
				<?php
					if(@$details){
						foreach ($details as $key => $detail) {?>
							<div class="row item-detail">
								<input class="form-control" value="<?php echo @$detail["ID"] ?>" name="detail[ID][]" type="hidden" readonly disable>
								<div class="col-sm-6">
									<div class="form-group"> 
										<label class="control-label">Số công nhân<span class="required">*</span></label>
										<input class="form-control" value="<?php echo @$detail["SoCN"] ?>" name="detail[SoCN][]" type="text" readonly disable>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group"> 
										<label class="control-label">Số chuyền<span class="required">*</span></label>
										<input class="form-control" value="<?php echo @$detail["SoChuyen"] ?>" name="detail[SoChuyen][]" type="text" readonly disable>
									</div>
								</div>
								<div class="col-sm-12">
									<div class="form-group"> 
										<label class="control-label">Sản lượng<span class="required">*</span></label>
										<input class="form-control" value="<?php echo @$detail["SanLuong"] ?>" name="detail[SanLuong][]" type="text" readonly disable>
									</div>
								</div>
							</div>
							<div class="ln_solid"></div>
						<?php }
					}
				?>	 
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="ln_solid"></div>
		<div class="text-right">
			<button type="button" class="btn btn-primary" data-dismiss="modal">Đóng</button>
		</div>
	</div>
</div>