<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="row">
		<div class="col-md-6">
			<h3> Thông tin kịch bản</h3>
			<div class="ln_solid"></div>
			<div class="row">
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Tên kịch bản <span class="required">*</span></label>
					<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required">
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group"> 
					<label class="control-label">Chi phí chưa lương <span class="required">*</span> </label>
					<input class="form-control" value="<?php echo @$record["ChiPhiChuaLuong"]; ?>" name="ChiPhiChuaLuong" type="text" required="required">
				</div>
			</div>
			</div>
			<div class="row">
				<div class="col-sm-6">
					<div class="form-group"> 
						<label class="control-label">Chi phí có lương <span class="required">*</span></label>
						<input class="form-control" value="<?php echo @$record["ChiPhiCoLuong"]; ?>" name="ChiPhiCoLuong" type="text" required="required">
					</div>
				</div>
				<div class="col-sm-6">
					<div class="form-group"> 
						<label class="control-label">Số CN trực tiếp SX <span class="required">*</span></label>
						<input class="form-control" value="<?php echo @$record["SoCNTrucTiepSX"]; ?>" name="SoCNTrucTiepSX" type="number" required="required">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6">
					<div class="form-group"> 
						<label class="control-label">Số ngày/năm SX <span class="required">*</span></label></label>
						<input class="form-control" value="<?php echo @$record["SoNgaySX_Nam"]; ?>" name="SoNgaySX_Nam" type="text" required="required">
					</div>
				</div>
				<div class="col-sm-6">
					<div class="form-group"> 
						<label class="control-label">Số liệu theo (Năm/tháng) <span class="required">*</span></label>
						<input class="form-control" value="<?php echo @$record["SoLieuTheoNam_Thang"]; ?>" name="SoLieuTheoNam_Thang" type="text" required="required">
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-sm-12">
					<div class="form-group"> 
						<label class="control-label">Ghi chú</label>
						<textarea class="form-control" rows="6" name="Description"><?php echo @$record["Description"]; ?></textarea>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12">
					<div class="form-group"> 
						<label class="control-label">Trạng thái</label>
						<select id="Status" class="form-control" name="Status" required="required" tabindex="-1" aria-hidden="true">   
					    	<?php if(@$record["Status"] == 1){
					    		echo '<option value="1" selected>Hoạt động</option>
						    		<option value="0">Ngưng hoạt động</option>';
					    	}else {
					    		echo '<option value="1">Hoạt động</option>
						    	<option value="0" selected>Ngưng hoạt động</option>';
					    	}?>
						</select>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<h3>Chi tiết kịch bản</h3>
			<div class="ln_solid"></div>
			<div class="content-detail-script">
				<div class="plus-detail-script">
					<a class="plus-detail" href="javascript"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></a>
				</div>
				<div class="content-detail">
					<?php
						if(@$details){
							foreach ($details as $key => $detail) {?>
								<div class="row item-detail">
									<input class="form-control" value="<?php echo @$detail["ID"] ?>" name="detail[ID][]" type="hidden" required="required">
									<div class="col-sm-6">
										<div class="form-group"> 
											<label class="control-label">Tên<span class="required">*</span></label>
											<input class="form-control" value="<?php echo @$detail["Name"] ?>" name="detail[Name][]" type="text">
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group"> 
											<label class="control-label">Số tiền<span class="required">*</span></label>
											<input class="form-control" value="<?php echo @$detail["SoTien"] ?>" name="detail[SoTien][]" type="text">
										</div>
									</div>
									<div class="actions-detail">
										<a class="move-item" data-index="2" href="javascript:;"><i class="fa fa-arrow-down" aria-hidden="true"></i></a>
										<a class="move-item" data-index="-1" href="javascript:;"><i class="fa fa-arrow-up" aria-hidden="true"></i></a>
										<a class="delete-item" href="javascript:;"><i class="fa fa-trash" aria-hidden="true"></i></a>
									</div>
								</div>
							<?php }
						}else {
					?>
					<?php for($i = 0 ; $i < 5; $i++):?>
						<div class="row item-detail">
							<input class="form-control" value="0" name="detail[ID][]" type="hidden" required="required">
							<div class="col-sm-6">
								<div class="form-group"> 
									<label class="control-label">Tên<span class="required">*</span></label>
									<input class="form-control" value="" name="detail[Name][]" type="text">
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group"> 
									<label class="control-label">Số tiền<span class="required">*</span></label>
									<input class="form-control" value="" name="detail[SoTien][]" type="text">
								</div>
							</div>
							<div class="actions-detail">
								<a class="move-item" data-index="2" href="javascript:;"><i class="fa fa-arrow-down" aria-hidden="true"></i></a>
								<a class="move-item" data-index="-1" href="javascript:;"><i class="fa fa-arrow-up" aria-hidden="true"></i></a>
								<a class="delete-item" href="javascript:;"><i class="fa fa-trash" aria-hidden="true"></i></a>
							</div>
						</div>
					<?php endfor;?>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>
