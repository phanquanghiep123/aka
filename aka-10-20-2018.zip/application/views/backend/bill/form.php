<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Mã hóa đơn <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["Ma_Hoa_Don"] ; ?>" name="Ma_Hoa_Don" type="text" required="required">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">VAT <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["VAT"]; ?>" name="VAT" type="number" min="0" required="required">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Phí vận chuyển <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["PhiVanChuyen"]; ?>" name="PhiVanChuyen" type="number" min="0" required="required">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tổng tiền <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["TongSoTien"]; ?>" name="TongSoTien" type="number" min="0" required="required">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Trạng thái <span class="required">*</span></label>
				<select class="form-control" name="Status" required="">
					<option value="1">Đã thanh toán</option>
					<option value="0" <?php echo @$record["Status"] != null && @$record["Status"] == 0 ? 'selected' : ''; ?>>Chưa thanh toán</option>
				</select>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Nhà cung cấp <span class="required">*</span></label>
				<select class="form-control" name="NCC_ID" required="required">
					<option value="">Chọn</option>
					<?php if(isset($ncc_result) && $ncc_result != null): ?>
						<?php foreach ($ncc_result as $key => $item): ?>
							<option <?php echo $item['ID'] == @$record['NCC_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Mô tả</label>
				<textarea class="form-control" name="Description" rows="4"><?php echo @$record["Description"]; ?></textarea>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Ngày tháng <span class="required">*</span></label>
				<input class="form-control form_datetime" value="<?php echo @$record["NgayThang"] != null ? date('Y/m/d',strtotime(@$record["NgayThang"])) : ''; ?>" name="NgayThang" type="text" required="required">
			</div>
		</div>
	</div>
	<div class="form-group"> 
		<label class="control-label">File đính kèm</label>
		<input name="files[]" multiple type="file" accept="application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,image/*,application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
		<div style="height: 15px;"></div>
		<ul>
			<?php if(@$media != null && @$record["ID"] != null): ?>
				<?php foreach ($media as $key => $item): ?>
					<li>
						<a href="<?php echo base_url($item['URL']); ?>" target="_blank"><?php echo $item['Name'].@$item['FileType']; ?></a>
						<a href="<?php echo backend_url($folder_view."/remove_media/".$record["ID"] ."/".$item['ID']); ?>" class="remove-media" data-id="<?php echo $item['ID']; ?>" style="color: #ff0000;margin-left: 10px;"><i class="fa fa-times" aria-hidden="true"></i></a>
					</li>
				<?php endforeach; ?>
			<?php endif; ?>
		</ul>
	</div>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>