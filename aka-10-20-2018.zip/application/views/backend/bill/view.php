<div class="form-horizontal form-label-left">
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Mã hóa đơn</label>
				<input class="form-control" value="<?php echo @$record["Ma_Hoa_Don"] ; ?>" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">VAT</label>
				<input class="form-control" value="<?php echo  number_format(@$record["VAT"]).' VNĐ'; ?>" name="VAT" type="text" readonly>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Phí vận chuyển</label>
				<input class="form-control" value="<?php echo number_format(@$record["PhiVanChuyen"]).' VNĐ'; ?>" name="PhiVanChuyen" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tổng tiền</label>
				<input class="form-control" value="<?php echo number_format(@$record["TongSoTien"]).' VNĐ'; ?>" name="TongSoTien" type="text" readonly>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Trạng thái</label>
				<input class="form-control" value="<?php echo @$record["Status"] == 0 ? 'Chưa thanh toán' : 'Đã thanh toán'; ?>" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Nhà cung cấp <span class="required">*</span></label>
				<?php if(isset($ncc_result) && $ncc_result != null): ?>
					<?php foreach ($ncc_result as $key => $item): ?>
						<?php if($item['ID'] == @$record['NCC_ID']): ?>
							<input class="form-control" value="<?php echo $item['Name']; ?>" type="text" readonly>
						<?php endif; ?>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Barcode</label>
				<input class="form-control" value="<?php echo @$record['Barcode']; ?>" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Ngày tháng</label>
				<input class="form-control" value="<?php echo @$record["NgayThang"] != null ? date('Y/m/d',strtotime(@$record["NgayThang"])) : ''; ?>" name="NgayThang" type="text" readonly>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">Mô tả</label>
				<textarea class="form-control" style="max-width: 100%;" readonly name="Description" rows="4"><?php echo @$record["Description"]; ?></textarea>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">File đính kèm</label>
				<ul>
					<?php if(@$media != null): ?>
						<?php foreach ($media as $key => $item): ?>
							<li><a href="<?php echo base_url($item['URL']); ?>" target="_blank"><?php echo $item['Name'].@$item['FileType']; ?></a></li>
						<?php endforeach; ?>
					<?php endif; ?>
				</ul>
			</div>
		</div>
	</div>
	<div style="height: 20px;"></div>
	<div class="row">
		<div class="col-sm-12">
			<label>Danh sách mặt hàng</label>
			<div class="file-sample table-responsive" style="min-height: auto;">
			    <table class="table table-bordered not-datatable">
			        <thead>
			            <tr class="">
			                <th class="text bg-blue">
			                    <p>#</p>
			                </th>
			                <th class="text bg-blue">
			                    <p>Danh mục vật tư</p>
			                </th>
			                <th class="text bg-blue">
			                    <p>Số lượng</p>
			                </th>
			                <th class="text bg-blue">
			                    <p>Đơn giá</p>
			                </th>
			            </tr>
			        </thead>
			        <tbody>
			        	<?php if(isset($info) && $info != null): ?>
				        	<?php foreach ($info as $key => $item): ?>
					        	<tr>
					        		<td><?php echo ($key+1); ?></td>
					        		<td><?php echo @$item['DMVTName']; ?></td>
					        		<td><?php echo number_format(@$item['SoLuong']); ?></td>
					        		<td><?php echo number_format(@$item['DonGia']) . 'VNĐ'; ?></td>
					        	</tr>
					        <?php endforeach; ?>
				        <?php endif; ?>
			        </tbody>
			    </table>
			</div>
		</div>
	</div>
	
	<div class="ln_solid"></div>
	<div class="text-right">
		<button type="button" class="btn btn-primary" data-dismiss="modal">Đóng</button>
	</div>
</div>