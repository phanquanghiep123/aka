<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="form-group"> 
		<label class="control-label">Tên phòng ban <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Mô tả</label>
		<textarea class="form-control" name="description" rows="8"><?php echo @$record["Description"]; ?></textarea>
	</div>
	<div class="form-group"> 
		<label class="control-label">Kiểu phòng ban <span class="required">*</span></label>
		<select class="form-control" name="Type">
			<option value="2" <?php echo @$record["Type"] == 2 ? 'selected' : ''; ?>>Hành chính</option>
			<option value="1" <?php echo @$record["Type"] == 1 ? 'selected' : ''; ?>>Sản xuất</option>
			<option value="3" <?php echo @$record["Type"] == 3 ? 'selected' : ''; ?>>Kỹ thuật</option>
			<option value="3" <?php echo @$record["Type"] == 4 ? 'selected' : ''; ?>>Bộ phận khác</option>
		</select>
	</div>
	<div class="form-group input_type_id" <?php echo @$record["Type"] == 1 ? 'style="display:block;"' : 'style="display:none;"'; ?>> 
		<label class="control-label">Loại hình sản xuất</label>
		<select class="form-control" name="Type_ID">
			<?php if(isset($types) && $types != null): ?>
				<?php foreach ($types as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" <?php echo @$record["Type_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group"> 
		<label class="control-label">Trạng thái <span class="required">*</span></label>
		<select class="form-control" name="Status">
			<option value="1">Hoạt động</option>
			<option value="0" <?php echo @$record["Status"] != null && @$record["Status"] == 0 ? 'selected' : ''; ?>>Ngưng hoạt động</option>
		</select>
	</div>
	<div class="form-group input_date_end" <?php echo @$record["Status"] != null && @$record["Status"] == 0 ? 'style="display:block;"' : 'style="display:none;"'; ?>> 
		<label class="control-label">Ngày ngưng hoạt động</label>
		<input type="text" name="Date_End" class="datetimepicker form-control" <?php echo @$record["Status"] != null && @$record["Status"] == 0 ? 'required' : ''; ?> value="<?php echo @$record["Date_End"] != null ? date('d/m/Y',strtotime($record["Date_End"])) : ''; ?>">
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" class="btn btn-default" onclick="$('.collapse-link-custom').trigger('click');return false;" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>
<script type="text/javascript">
	$(document).ready(function(){
		$('select[name="Status"]').change(function(){
			var val = $(this).val();
			if(val == 0){
				$('.input_date_end input').attr('required','required');
				$('.input_date_end').show();
			} else{
				$('.input_date_end input').removeAttr('required');
				$('.input_date_end').hide();
			}
		});

		$('select[name="Type"]').change(function(){
			var val = $(this).val();
			if(val == 1){
				$('.input_type_id select').attr('required','required');
				$('.input_type_id').show();
			} else{
				$('.input_type_id select').removeAttr('required');
				$('.input_type_id').hide();
			}
		});
	});
</script>