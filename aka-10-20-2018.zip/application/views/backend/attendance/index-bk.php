<?php
$year = $get["Year"];
$month = $get["Month"];
function get_list_holiday($holidays){
	$holidaysArg = [];
	foreach ($holidays as $key => $value) {
		$date = new DateTime($value["HolidayDate"]);
		$holidaysArg [] = $date->format('d');
	}
	return $holidaysArg;
}
function days_in_month($month, $year) 
{ 
	return $month == 2 ? ($year % 4 ? 28 : ($year % 100 ? 29 : ($year % 400 ? 28 : 29))) : (($month - 1) % 7 % 2 ? 30 : 31); 
} 
function get_listTimeSlot ($Employees,$days,$year,$month,$holidays){
	$memberIDs = [];
	foreach ($Employees as $key => $value) {
		if(!in_array($value["ID"], $memberIDs)){
			$memberIDs [] = $value["ID"];
			echo '<tr>';
			echo '<td>'.$value["Name"].'</td>';
			for ($i = 1; $i <= $days; $i++) {
				$class = (in_array($i, $holidays))  ? 'is_holiday' : 'item-day';
				$stringI = ($i < 10) ? "0".$i : $i;
				echo '<td class="'.$class.'" data-department="'.$value["Department_ID"].'" data-member="'.$value["ID"].'" data-date="'.$year.'-'.$month.'-'.$stringI.'" data-month="'.$month.'" data-day="'.$i.'">';
				$timeSlots = [];
				$data = Date($year ."-" . $month . "-" . $stringI);
				foreach ($Employees as $key_1 => $value_1) {
					if($value["ID"] == $value_1["ID"]){
						$fDate = Date($value_1["WorkingDate"]);
						if($fDate == $data){
							echo "<a data-item='".json_encode($value_1)."' href=\"javascript:;\">".$value_1["symbol"]."</a>";
							unset($Employees[$key_1]);
						}
					}
				}
				echo '</td>';
			}
			echo '</tr>';
		}
	}
}
$holidays = get_list_holiday($holidays);
$days     = days_in_month($month, $year);
?>
<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-4">
						<h2>
							<?php echo @$title_page; ?>  
						</h2>
					</div>
					<div class="col-sm-8">
						<form method="" method="get">
							<div class="row">
								<div class="col-sm-3">
									<div class="form-group">
										<select onchange="return $(this).parents('form').submit()" class="form-control" name="Department_ID">
											<?php foreach (@$Departments as $key => $value) {	
												if(@$get["Department_ID"] == $value["ID"])						 
											 		echo '<option value="'.$value["ID"].'" selected>'.$value["Name"].'</option>'; 		
											 	else 
											 		echo '<option value="'.$value["ID"].'">'.$value["Name"].'</option>'; 		
											}?>
										</select>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="form-group">
										<?php 
											$currentyear = date("Y");
											$beforeyear =  $currentyear ;
											$afteryear  =  $currentyear + 5;
										?>
										<select class="form-control" onchange="return $(this).parents('form').submit()" name="Year">
											<?php for ($i= $beforeyear; $i <= $afteryear; $i++) { 
												if(@$get["Year"] == $i)			
											 		echo '<option value="'.$i.'" selected >Năm: '.$i.'</option>'; 
											 	else 
											 		echo '<option value="'.$i.'">Năm: '.$i.'</option>';		
											}?>
										</select>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="form-group">
										<select class="form-control" onchange="return $(this).parents('form').submit()" name="Month">
											<?php for ($i= 1; $i <= 12; $i++) { 
												if(@$get["Month"] == $i)
											 		echo '<option value="'.$i.'" selected >Tháng: '.$i.'</option>'; 	
											 	else 
											 		echo '<option value="'.$i.'">Tháng: '.$i.'</option>';	
											}?>
										</select>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="form-group">
										<button type="submit" class="btn btn-primary">Tìm kiếm</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
					<table class="table not-datatable no-footer" id="list-working-month">
						<thead>
							<tr>
								<th>Tên NV</th>
								<?php
									
									for ($i = 1; $i <= $days; $i++) { 
										$stringI = ($i < 10) ? "0".$i : $i;
										echo '<th>'.$stringI.'</th>';
									}
								?>
							</tr>
						</thead>
						<tbody>
							<?php if(@$Employees):?>
								<?php get_listTimeSlot($Employees,$days,$year,$month,$holidays);?>
							<?php endif;?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="myModalViewListSlot" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Cập nhật ca làm viêc</h4>
      </div>
      <form method="post" class="saveupdatetimeslot">
	      <div class="modal-body">
	        	<div class="row">
	        		<div class="col-md-12">
	        			<p>Ngày: <span id="stringDateWorking"></span></p>
	        			<p>Nhân viên: <span id="stringNameWorking"></span></p>
	        		</div>
	        		<div class="col-md-6">
	        			<h4>Danh sách ca</h4>
		        		<ul id="sortable1" class="connectedSortable">
						   
						</ul>
					</div>
					<div class="col-md-6">
						<h4>Danh sách ca của NV</h4> 
						<ul id="sortable2" class="connectedSortable">
						   
						</ul>
					</div>
	        	</div>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
	        <a href="javascript:;" class="btn btn-success updatetimeslot">Lưu</a>
	      </div>
      </form>
    </div>
  </div>
</div>
<!-- Modal -->
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript">
	jQuery.browser = {};
	(function () {
	    jQuery.browser.msie = false;
	    jQuery.browser.version = 0;
	    if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
	        jQuery.browser.msie = true;
	        jQuery.browser.version = RegExp.$1;
	    }
	})();
	$("#sortable1, #sortable2").sortable({
      connectWith: ".connectedSortable"
    }).disableSelection();
    var memberID = 0;
    var CurentDay = null;
	$(document).on("click","#list-working-month td.item-day",function(){
	 	var date  = $(this).attr("data-date");
	 	var member  = $(this).attr("data-member");
	 	memberID = member;
	 	CurentDay = date;
	 	$("#myModalViewListSlot #stringDateWorking").text(date);
	 	if(date && member){
	 		$.ajax({
	 			url : "<?php echo backend_url("working_schedule/view")?>",
	 			type :"post",
	 			dataType : "json",
	 			data : {member : member , date : date},
	 			success : function(data){
	 				var time_slots = data.responsive.time_slots;
	 				var time_slots_member = data.responsive.time_slots_member;
	 				if(time_slots){
	 					var html = "";
	 					$.each(time_slots,function(){
	 						html += '<li class="slot_item ui-state-default" data-id="'+this.ID+'">'+this.name+'</li>';
	 					});
	 					$("#myModalViewListSlot #sortable1").html(html);
	 				}
	 				if(time_slots){
	 					html = "";
	 					$.each(time_slots_member,function(){
	 						html += '<li class="slot_item ui-state-highlight" data-id="'+this.Time_Slot_ID+'">'+this.name+'</li>';
	 					});
	 					$("#myModalViewListSlot #sortable2").html(html);
	 				}
	 				member = data.responsive.member;
	 				$("#myModalViewListSlot #stringNameWorking").text(member.Name);
	 				$("#sortable1, #sortable2").sortable( "refresh" );
	 				$("#myModalViewListSlot").modal();
	 			}	
	 		})
	 	}
	 });
	$(document).on("click",".saveupdatetimeslot .updatetimeslot",function(){
		var listAdd = [];
		var listDelete = [];
		$.each($("#sortable1 li"),function(){
			listDelete.push($(this).attr("data-id"));
		});
		$.each($("#sortable2 li"),function(){
			listAdd.push($(this).attr("data-id"));
		});
		$.ajax({
 			url : "<?php echo backend_url("working_schedule/update")?>",
 			type :"post",
 			dataType : "json",
 			data : {listAdd : listAdd , listDelete : listDelete,memberID : memberID,CurentDay:CurentDay},
 			success : function(data){
 				console.log(data);
 			}
	 	})
	});
	$(document).on({
	    mouseenter: function () {
	       	var timeSlot = [];
	       	var tip = `<div class="tooltip fade bottom in" role="tooltip" id="tooltip362151" style="top: 100%; left: -78px ; display: block;width:200px;">
			<div class="tooltip-arrow" style="left: 50%;"></div><div class="tooltip-inner">
				<h5 class="text-left"><b>Các ca làm việc:</b></h5><div class="text-left">`;
			var item = {};
	       	$.each($(this).find("a"),function($key){
	       		item = (JSON.parse($(this).attr("data-item")));
	       		tip += `<p>`+ ($key + 1) + `. ` + item.Time_Slot_Name + `</p>`;

	       	});
	       	tip += `</div>
	       		</div>
					</div>`;
			$(this).append(tip);
	    },
	    mouseleave: function () {
	        $(this).find(".tooltip").remove();
	    }
	},"#list-working-month td.item-day");
</script>
<style type="text/css">
	.select2-container{width: 100% !important;}
 	.table>tbody>tr>td {
	    padding: 8px;
	    line-height: 1.42857143;
	    vertical-align: top;
	    border: 1px solid #0c0c0c;
	}
	.table>thead>tr>th {
	    vertical-align: bottom;
	    border: 1px solid #0c0c0c;
	    border-top: 1px solid #0c0c0c !important;
	    background: #ccc;
	}
	#list-working-month td.item-day{
		cursor: pointer;
	}
	#list-working-month td.item-day:hover{
		background-color: yellow;
	}
	#list-working-month td.is_holiday{
		background-color: #770303;
		cursor: not-allowed;
	}
	#sortable1, #sortable2 {
	    border: 1px solid #eee;
	    width: 100%;
	    min-height: 20px;
	    list-style-type: none;
	    margin: 0;
	    padding: 5px 0 0 0;
	    float: left;
	    min-height: 200px;
	    padding: 10px;
	}
    #sortable1 li, #sortable2 li {
	    margin: 5px 0;
	    padding: 5px;
	    font-size: 1.2em;
	    width: 100%;
	}
</style>