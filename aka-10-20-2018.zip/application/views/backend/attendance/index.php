<?php
$year = $get["Year"];
$month = $get["Month"];
function get_list_holiday($holidays){
	$holidaysArg = [];
	foreach ($holidays as $key => $value) {
		$date = new DateTime($value["HolidayDate"]);
		$holidaysArg [] = $date->format('d');
	}
	return $holidaysArg;
}

function days_in_month($month, $year) { 
	return $month == 2 ? ($year % 4 ? 28 : ($year % 100 ? 29 : ($year % 400 ? 28 : 29))) : (($month - 1) % 7 % 2 ? 30 : 31); 
} 

function get_listTimeSlot ($Employees,$days,$year,$month,$holidays){
	$memberIDs = [];
	foreach ($Employees as $key => $value) {
		if(!in_array($value["ID"], $memberIDs)){
			$memberIDs [] = $value["ID"];
			echo '<tr>';
			echo '<td class="td-name" style="width:auto">'.($key + 1).'</td>';
			echo '<td class="td-name" style="width:auto">'.$value["Name"].'</td>';
			for ($i = 1; $i <= $days; $i++) {
				$class = (in_array($i, $holidays))  ? 'is_holiday' : 'item-day';
				if($class == 'item-day' && $i > date('d')){
					$class = 'not-item-day';
				}
				$stringI = ($i < 10) ? "0".$i : $i;
				$timeSlots = [];
				$data = Date($year ."-" . $month . "-" . $stringI);
				$items = [];
				foreach ($Employees as $key_1 => $value_1) {
					if($value["ID"] == $value_1["ID"]){
						$fDate = Date($value_1["WorkingDate"]);
						if($fDate == $data){
							$items[] = $value_1; 
							unset($Employees[$key_1]);
						}
					}
				}
				$activeClass = count($items) > 0 ? 'has_working' : 'not_working';
				echo '<td data-item=\''.json_encode($items).'\' class="'.$class.' '.$activeClass.'" data-department="'.$value["Department_ID"].'" data-member="'.$value["ID"].'" data-date="'.$year.'-'.$month.'-'.$stringI.'" data-month="'.$month.'" data-day="'.$i.'"><div class="maker-type"></div>';
				echo '</td>';
			}
			echo '</tr>';
		}
	}
}
$holidays = get_list_holiday($holidays);
$days     = days_in_month($month, $year);

?>
<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-4">
						<h2>
							<?php echo @$title_page; ?>  
						</h2>
					</div>
					<div class="col-sm-8">
						<form method="" method="get">
							<div class="row">
								<div class="col-sm-3">
									<div class="form-group">
										<select onchange="return $(this).parents('form').submit()" class="form-control" name="Department_ID">
											<?php foreach (@$Departments as $key => $value) {	
												if(@$get["Department_ID"] == $value["ID"])					 
											 		echo '<option value="'.$value["ID"].'" selected>'.$value["Name"].'</option>'; 		
											 	else 
											 		echo '<option value="'.$value["ID"].'">'.$value["Name"].'</option>'; 		
											}?>
										</select>
									</div>
								</div>
								<div class="col-sm-2">
									<div class="form-group">
										<?php 
											$currentyear = date("Y");
											$beforeyear =  $currentyear ;
											$afteryear  =  $currentyear + 5;
										?>
										<select class="form-control" onchange="return $(this).parents('form').submit()" name="Year">
											<?php for ($i= $beforeyear; $i <= $afteryear; $i++) { 

												if(@$get["Year"] == $i)			
											 		echo '<option value="'.$i.'" selected >Năm: '.$i.'</option>'; 
											 	else 
											 		echo '<option value="'.$i.'">Năm: '.$i.'</option>';		
											}?>
										</select>
									</div>
								</div>
								<div class="col-sm-2">
									<div class="form-group">
										<select class="form-control" onchange="return $(this).parents('form').submit()" name="Month">
											<?php for ($i= 1; $i <= 12; $i++) { 
												$stringI = ($i < 10) ? "0".$i : $i;
												if(@$get["Month"] == $stringI)
											 		echo '<option value="'.$stringI.'" selected >Tháng: '.$stringI.'</option>'; 	
											 	else 
											 		echo '<option value="'.$stringI.'">Tháng: '.$stringI.'</option>';	
											}?>
										</select>
									</div>
								</div>
								<div class="col-sm-2">
									<div class="form-group">
										<input type="text" class="form-control" value="<?php echo @$this->input->get("Name")?>" name="Name" placeholder="Tên nhân viên">
									</div>
								</div>
								<div class="col-sm-2">
									<div class="form-group">
										<button type="submit" class="btn btn-primary">Tìm kiếm</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
					<table class="table not-datatable no-footer" id="list-working-month">
						<thead>
							<tr>
								<th>#Stt</th>
								<th>Tên NV</th>
								<?php
									for ($i = 1; $i <= $days; $i++) { 
										$stringI = ($i < 10) ? "0".$i : $i;
										echo '<th>'.$stringI.'</th>';
									}
								?>
							</tr>
						</thead>
						<tbody>
							<?php if(@$Employees):?>
								<?php get_listTimeSlot($Employees,$days,$year,$month,$holidays);?>
							<?php endif;?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="myModalViewListSlot" class="modal fade" role="dialog">
  	<div class="modal-dialog">
	    <!-- Modal content-->
	    <div class="modal-content">
	      	<div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		        <h4 class="modal-title">Cập nhật ca làm việc</h4>
	      	</div>
	      	<form method="post" class="saveupdatetimeslot">
		      <div class="modal-body">
		        	<div class="row">
		        		<div class="col-md-12">
		        			<p>Ngày: <span id="stringDateWorking"></span></p>
		        			<p>Nhân viên: <span id="stringNameWorking"></span></p>
		        		</div>
		        		<div class="col-md-6">
		        			<h4>Danh sách ca của phòng ban</h4>
			        		<ul id="sortable1" class="connectedSortable">
							   
							</ul>
						</div>
						<div class="col-md-6">
							<h4>Ca nhân viên có làm</h4> 
							<ul id="sortable2" class="connectedSortable">
							   
							</ul>
						</div>
		        	</div>
		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
		        <a href="javascript:;" class="btn btn-success updatetimeslot">Lưu</a>
		      </div>
	      	</form>
	    </div>
  	</div>
</div>
<div id="editSlotTime" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Chi tiết ca làm việc</h4>
      </div>
      <form method="post" class="saveupdatetimeslotdetail">
	      <div class="modal-body">	
	      <div class="item form-group"> 
				<label class="control-label col-md-6" for="is-inTime-time-slo">Vắng mặt</label>
				<div class="col-md-6">
					<select id="Status" class="form-control" name="Is_Absent" id="is-absent-time-slot">   
				    	<option value="1" selected="">Có</option>
					    <option value="0">Không</option>
					</select>
				</div>
			</div> 
			<div class="item form-group"> 
				<label class="control-label col-md-6" for="is-inTime-time-slo">Vào làm đúng giờ hay không</label>
				<div class="col-md-6">
					<select id="Status" class="form-control" name="Is_InTime" id="is-inTime-time-slot">   
				    	<option value="1" selected="">Có</option>
					    <option value="0">Không</option>
					</select>
				</div>
			</div>
			<div class="item form-group"> 
				<label class="control-label col-md-6" for="is-outTime-time-slot">Về đúng giờ hay không</label>
				<div class="col-md-6">
					<select id="Status" class="form-control" name="Is_OutTime" id="is-outTime-time-slot">   
				    	<option value="1" selected="">Có</option>
					    <option value="0">Không</option>
					</select>
				</div>
			</div>
			<div class="item form-group"> 
				<label class="control-label col-md-6" for="absent_resion-time-slot">Lí do vắng</label>
				<div class="col-md-6 ">
					<textarea class="form-control" name="Absent_Resion" id="absent_resion-time-slot"></textarea>
				</div>
			</div>
			<div class="item form-group"> 
				<label class="control-label col-md-6" for="discription-time-slot">Ghi chú</label>
				<div class="col-md-6 ">
					<textarea class="form-control" name="Description" id="discription-time-slot"></textarea>
				</div>
			</div>
			
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
	        <a href="javascript:;" class="btn btn-success updatetimeslotdetail">Lưu</a>
	      </div>
      </form>
    </div>
  </div>
</div>
<!-- Modal -->
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript">
	jQuery.browser = {};
	(function () {
	    jQuery.browser.msie = false;
	    jQuery.browser.version = 0;
	    if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
	        jQuery.browser.msie = true;
	        jQuery.browser.version = RegExp.$1;
	    }
	})();
	$("#sortable1, #sortable2").sortable({
      	connectWith: $('ul.connectedSortable'),
      	items : '>li:not(.not-li)',
    }).disableSelection();
    var memberID = 0;
    var CurentDay = null;
    var TD = null;
    var _ID;

	$(document).on("click","#list-working-month td.item-day",function(){
	 	var date  = $(this).attr("data-date");
	 	var member  = $(this).attr("data-member");
	 	memberID = member;
	 	CurentDay = date;
	 	TD = $(this);
	 	var department = $(this).attr("data-department");
	 	$("#myModalViewListSlot #stringDateWorking").text(date);
	 	if(date && member){
	 		$.ajax({
	 			url : "<?php echo backend_url("attendance/view")?>",
	 			type :"post",
	 			dataType : "json",
	 			data : {member : member , date : date,department: department},
	 			success : function(data){
	 				var time_slots = data.responsive.time_slots;
	 				var time_slots_member = data.responsive.time_slots_member;
	 				var not_class = "";
	 				if(time_slots){
	 					var html = "";
	 					not_class = "not-li";
	 					$.each(time_slots,function(){
	 						try{
	 							if(data.responsive.absent_schedules.indexOf(this.ID) > - 1) not_class = "not-li";
	 							else not_class = "";
	 						}catch(e){}
	 						html += '<li class="slot_item ui-state-default '+not_class+'" data-slot="'+this.ID+'">'+this.Time_Slot_Name+'</li>';
	 					});
	 					$("#myModalViewListSlot #sortable1").html(html);
	 				}
	 				if(time_slots_member){
	 					html = "";
	 					$.each(time_slots_member,function(){
	 						html += `<li class="slot_item ui-state-highlight" data-id="`+this.ID+`" data-slot="`+this.Time_Slot_ID+`">`+this.Time_Slot_Name+`
	 							<a href="javascript:;" class="onchange-info-item"><i class="fa fa-edit" aria-hidden="true"></i></a>
	 						</li>`;
	 					});
	 					$("#myModalViewListSlot #sortable2").html(html);
	 				}
	 				member = data.responsive.member;
	 				$("#myModalViewListSlot #stringNameWorking").text(member.Name);
	 				$("#sortable1, #sortable2").sortable( "refresh" );
	 				$("#myModalViewListSlot").modal();
	 			}	
	 		})
	 	}
	 });

	$( "#sortable1").on( "sortstop", function( event, ui ) {
		var id = (ui.item.parent().attr("id"));
		var listAdd =[ui.item.attr("data-slot")];
		if(listAdd && id =="sortable2"){
			$.ajax({
	 			url : "<?php echo backend_url("attendance/update")?>",
	 			type :"post",
	 			dataType : "json",
	 			data : {listAdd : listAdd , listDelete : null ,memberID : memberID,CurentDay:CurentDay},
	 			success : function(data){
	 				var ojb = JSON.parse(data.responsive);
	 				try{
	 					if(ojb.length > 0){
	 				    	TD.removeClass('not_working').addClass('has_working');
	 				    }else{
	 				    	TD.removeClass('has_working').addClass('not_working');
	 				    }
		 				TD.attr("data-item",data.responsive);
	 				}catch(e){}
	 				ui.item.attr("data-id",data.ID);
	 				ui.item.removeClass('ui-state-default').addClass("ui-state-highlight");
	 				ui.item.append(`<a href="javascript:;" class="onchange-info-item"><i class="fa fa-edit" aria-hidden="true"></i></a>`);
	 			}
		 	})
		}
	} );

	$( "#sortable2").on( "sortstop", function( event, ui ) {
		var id = _ID = (ui.item.parent().attr("id"));
		var listDelete =[ui.item.attr("data-slot")];
		if(listDelete && id =="sortable1"){
			$.ajax({
	 			url : "<?php echo backend_url("attendance/update")?>",
	 			type :"post",
	 			dataType : "json",
	 			data : {listAdd : null , listDelete : listDelete ,memberID : memberID,CurentDay:CurentDay},
	 			success : function(data){
	 				try{	
	 					var ojb = JSON.parse(data.responsive);
	 				    if(ojb.length > 0){
	 				    	TD.removeClass('not_working').addClass('has_working');
	 				    }else{
	 				    	TD.removeClass('has_working').addClass('not_working');
	 				    }
	 				}catch(e){}
	 				
	 				TD.attr("data-item",data.responsive);
	 				ui.item.removeClass("ui-state-highlight").addClass('ui-state-default');
	 				ui.item.find('a.onchange-info-item').remove();
	 			}
		 	})
		}
	});

	$(document).on("click",".saveupdatetimeslot .updatetimeslot",function(){
		var listAdd = [];
		var listDelete = [];
		$.each($("#sortable1 li"),function(){
			listDelete.push($(this).attr("data-slot"));
		});
		$.each($("#sortable2 li"),function(){
			listAdd.push($(this).attr("data-slot"));
		});
		$.ajax({
 			url : "<?php echo backend_url("attendance/update")?>",
 			type :"post",
 			dataType : "json",
 			data : {listAdd : listAdd , listDelete : listDelete,memberID : memberID,CurentDay:CurentDay},
 			success : function(data){
 				TD.attr("data-item",data.responsive);
 				try{	
 					var ojb = JSON.parse(data.responsive);
 				    if(ojb.length > 0){
 				    	TD.removeClass('not_working').addClass('has_working');
 				    }else{
 				    	TD.removeClass('has_working').addClass('not_working');
 				    }
 				}catch(e){}
 				$("#myModalViewListSlot").modal('hide');
 			}
	 	})
	});

	$(document).on("click","#editSlotTime .updatetimeslotdetail",function(){
		var data = $("#editSlotTime .saveupdatetimeslotdetail").serialize();
		data += "&id=" + _ID;;
		$.ajax({
 			url : "<?php echo backend_url("attendance/edit")?>",
 			type :"post",
 			dataType : "json",
 			data : data,
 			success : function(data){
 				TD.attr("data-item",data.responsive);
 				try{	
 					var ojb = JSON.parse(data.responsive);
 				    if(ojb.length > 0){
 				    	TD.removeClass('not_working').addClass('has_working');
 				    }else{
 				    	TD.removeClass('has_working').addClass('not_working');
 				    }
 				}catch(e){}
 				$("#editSlotTime").modal('hide');
 			}
	 	})
	});

	$(document).on("click","#sortable2 .onchange-info-item",function(){
		var id = _ID = $(this).parent().attr("data-id");
		$.ajax({
 			url : "<?php echo backend_url("attendance/edit/")?>",
 			type :"get",
 			dataType : "json",
 			data : {id : id},
 			success : function(data){
 				$.each(data.responsive,function($key,$value){
 					$("#editSlotTime").find("[name="+$key+"]").val($value);
 				});
 				$("#editSlotTime").modal();
 			}
	 	})
	});

	$(document).on({
	    mouseenter: function () {
	       	var timeSlot = [];
	       	var tip = `<div class="tooltip fade bottom in" role="tooltip" id="tooltip362151" style="top: 100%; left: -78px ; display: block;width:200px;">
			<div class="tooltip-arrow" style="left: 50%;"></div><div class="tooltip-inner">
				<h5 class="text-left"><b>Các ca xin nghỉ:</b></h5><div class="text-left">`;
			var items = JSON.parse($(this).attr("data-item"));
			if(items.length){
				var status = '<i class="fa fa-thumbs-down right" aria-hidden="true"></i>';
				$.each(items,function($key,item){
					status = '<i class="fa fa-thumbs-down right" aria-hidden="true"></i>';
					if(item.Is_Absent == 0) status = '<i class="fa fa-thumbs-up right" aria-hidden="true"></i>';
		       		tip += `<p>`+ ($key + 1) + `. ` + item.Time_Slot_Name + status +`</p>`;
		       	});
			}
	       	tip += `</div>
	       		</div>
					</div>`;
			if(items.length)
				$(this).append(tip);
	    },
	    mouseleave: function () {
	        $(this).find(".tooltip").remove();
	    }
	},"#list-working-month td.item-day");

	$(document).on({
	    mouseenter: function () {
	       	var tip = `<div class="tooltip fade bottom in" role="tooltip" id="tooltip362151" style="top: 100%; left: -78px ; display: block;width:200px;">
			<div class="tooltip-arrow" style="left: 50%;"></div><div class="tooltip-inner">
				<h5 class="text-left"><b>Thông báo:</b></h5><div class="text-left">`;
			tip += `<p>Ca này nằm trong danh sách nghỉ của NV này</p>`;
	       	tip += `</div></div></div>`;
			$(this).append(tip);
	    },
	    mouseleave: function () {
	        $(this).find(".tooltip").remove();
	    }
	},"#sortable1 li.not-li");

</script>
<style type="text/css">
	.select2-container{width: 100% !important;}
 	.table>tbody>tr>td {
	    padding: 8px;
	    line-height: 1.42857143;
	    vertical-align: top;
	    border: 1px solid #0c0c0c;
	}
	.table>thead>tr>th {
	    vertical-align: bottom;
	    border: 1px solid #0c0c0c;
	    border-top: 1px solid #0c0c0c !important;
	    background: #f1f1f1;
	    text-align: center;
	    color: #000;
	}
	#list-working-month td.item-day{
		cursor: pointer;
	}
	#list-working-month td.item-day:hover div.maker-type{
		background-color: yellow;
	}
	#list-working-month td.not-item-day div.maker-type{
		background-color: #ff0000;
	}
	#list-working-month td.is_holiday{
		cursor: not-allowed;
	}
	#sortable1, #sortable2 {
	    border: 1px solid #eee;
	    width: 100%;
	    min-height: 20px;
	    list-style-type: none;
	    margin: 0;
	    padding: 5px 0 0 0;
	    float: left;
	    min-height: 200px;
	    padding: 10px;
	}
    #sortable1 li, #sortable2 li {
	    margin: 5px 0;
	    padding: 5px;
	    font-size: 1.2em;
	    width: 100%;
	    position: relative;
	    cursor: move;
	}
	#sortable2 li a.onchange-info-item {
		position: absolute;
		right: 5px;
		top: 5px;
		display: block;
	}
	.onchange-info-item{
		display: none;
	}
	.modal-footer{
		width: 100%;
		float: left;
	}
	
	#list-working-month td{
		width: 40px;
		height: 40px;
		background: #ccc;
		padding: 0;
		vertical-align: middle;
		text-align:center;
	}
	#list-working-month td div.maker-type{
		width: 30px;
		height: 30px;
		border-radius: 100%;
		background: #fff;
		margin: 0 auto;
	}
	#list-working-month td.td-name{
		background: #fff;
		padding: 0 10px;
	}
	#list-working-month td.has_working div.maker-type{
		background: #26B99A
	}
	#list-working-month td.is_holiday div.maker-type{
		background: #770303
	}
	#list-working-month td.is_holiday div.maker-type:after {
	    content: "\f00d";
	    color: #fff;
	    display: inline-block;
	    font: normal normal normal 14px/1 FontAwesome;
	    font-size: inherit;
	    text-rendering: auto;
	    -webkit-font-smoothing: antialiased;
	    -moz-osx-font-smoothing: grayscale;
	    line-height: 1.5;
	    font-size: 20px;
	}
	#list-working-month td.item-day.has_working div.maker-type:after {
		content: "\f164";
		color: #fff;
	    display: inline-block;
	    font: normal normal normal 14px/1 FontAwesome;
	    font-size: inherit;
	    text-rendering: auto;
	    -webkit-font-smoothing: antialiased;
	    -moz-osx-font-smoothing: grayscale;
	    line-height: 1.5;
	    font-size: 19px;
	}
	#sortable1 li.not-li{
		cursor: not-allowed;
	}
	#sortable1 li.not-li .tooltip{
		z-index: 999;
		opacity: 1;
	}
	
</style>