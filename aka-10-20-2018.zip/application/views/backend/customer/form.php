<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tên người đại diện <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["TenNguoiDaiDien"]; ?>" name="TenNguoiDaiDien" type="text" required="required">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Mã số thuế <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["MaSoThue"]; ?>" name="MaSoThue" type="text" required="required">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Địa chỉ</label>
				<input class="form-control" value="<?php echo @$record["Diachi"]; ?>" name="Diachi" type="text">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Số điện thoại</label>
				<input class="form-control" value="<?php echo @$record["DienThoaiLienHe"]; ?>" name="DienThoaiLienHe" type="text">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Ngân hàng</label>
				<input class="form-control" value="<?php echo @$record["NganHang"]; ?>" name="NganHang" type="text">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tên công ty <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["TenCongTy"]; ?>" name="TenCongTy" type="text" required="required">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Chủ tài khoản</label>
				<input class="form-control" value="<?php echo @$record["ChuTaiKhoan"]; ?>" name="ChuTaiKhoan" type="text">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Số tài khoản</label>
				<input class="form-control" value="<?php echo @$record["SoTaiKhoan"]; ?>" name="SoTaiKhoan" type="text">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">Ghi chú</label>
				<textarea class="form-control" rows="6" name="GhiChu"><?php echo @$record["GhiChu"]; ?></textarea>
			</div>
		</div>
	</div>
	<div class="form-group"> 
		<label class="control-label">File đính kèm</label>
		<input name="files[]" multiple type="file" accept="application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,image/*,application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
		<div style="height: 15px;"></div>
		<ul>
			<?php if(@$media != null && @$record["ID"] != null): ?>
				<?php foreach ($media as $key => $item): ?>
					<li>
						<a href="<?php echo base_url($item['URL']); ?>" target="_blank"><?php echo $item['Name'].@$item['FileType']; ?></a>
						<a href="<?php echo backend_url($folder_view."/remove_media/".$record["ID"] ."/".$item['ID']); ?>" class="remove-media" data-id="<?php echo $item['ID']; ?>" style="color: #ff0000;margin-left: 10px;"><i class="fa fa-times" aria-hidden="true"></i></a>
					</li>
				<?php endforeach; ?>
			<?php endif; ?>
		</ul>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>