<?php $today = new DateTime(date("Y-m-d H:i:s")); ?>
<div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tên người đại diện</label>
				<input class="form-control" value="<?php echo @$record["TenNguoiDaiDien"]; ?>" name="TenNguoiDaiDien" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Mã số thuế</label>
				<input class="form-control" value="<?php echo @$record["MaSoThue"]; ?>" name="MaSoThue" type="text" readonly>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Địa chỉ</label>
				<input class="form-control" value="<?php echo @$record["Diachi"]; ?>" name="Diachi" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Số điện thoại</label>
				<input class="form-control" value="<?php echo @$record["DienThoaiLienHe"]; ?>" name="DienThoaiLienHe" type="text" readonly>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Tên công ty</label>
				<input class="form-control" value="<?php echo @$record["TenCongTy"]; ?>" name="TenCongTy" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Ngân hàng</label>
				<input class="form-control" value="<?php echo @$record["NganHang"]; ?>" name="NganHang" type="text" readonly>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Số tài khoản</label>
				<input class="form-control" value="<?php echo @$record["SoTaiKhoan"]; ?>" name="SoTaiKhoan" type="text" readonly>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Chủ tài khoản</label>
				<input class="form-control" value="<?php echo @$record["ChuTaiKhoan"]; ?>" name="ChuTaiKhoan" type="text" readonly>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">Ghi chú</label>
				<textarea class="form-control" rows="6" name="GhiChu" readonly><?php echo @$record["GhiChu"]; ?></textarea>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">File đính kèm</label>
				<ul>
					<?php if(@$media != null): ?>
						<?php foreach ($media as $key => $item): ?>
							<li><a href="<?php echo base_url($item['URL']); ?>" target="_blank"><?php echo $item['Name'].@$item['FileType']; ?></a></li>
						<?php endforeach; ?>
					<?php endif; ?>
				</ul>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label" style="margin-bottom: 20px;">Danh sách hợp đồng <a class="btn btn-success create-item view-is_ajax" href="<?php echo backend_url('contract/add?member_id='.$record["ID"])?>"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Thêm mới</a></label>
				<table class="table table-striped jambo_table bulk_action dataTable no-footer">
					<thead>
						<tr>
							<th>Tên</th>
							<th>NBD</th>
							<th>NKT</th>
							<th>Tiến độ</th>
							<th>Hành động</th>
						</tr>
					</thead>
					<tbody>
						<?php if(@$contracts):?>	
						<?php foreach($contracts AS $key => $value):?>
							<tr data-id="<?php echo $value["ID"];?>">
								<td data-column="Name"><?php echo $value["Name"]?></td>
								<td data-column="StartDate"><?php echo $value["StartDate"]?></td>
								<td data-column="EndDate"><?php echo $value["EndDate"]?></td>
								<td data-column="Progress">
									<?php
										$datetime1 = new DateTime($value["StartDate"]);
										$datetime2 = new DateTime($value["EndDate"]);
										$interval = $datetime1->diff($datetime2);
										$total =  (int)$interval->format('%a'); 
										$interval = $datetime1->diff($today);
										$totaltoday =  (int)$interval->format('%a');
										$status = 0;
										if($total != 0){
											if($total < $totaltoday){
												$class="progress-bar-success";
												$status = '100%';
											}else{
												$class="progress-bar-info";
												$status = round( ($totaltoday/$total) * 100 ) . "%"; 
											}
										}else{
											$class="progress-bar-success";
											$status = '100%';
										}
										//echo $status;
										
									?>
									<div class="progress">
										<div class="progress-bar <?php echo $class;?>" role="progressbar" aria-valuenow="40"
										aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $status?>">
											<?php echo $status?> Complete (success)
										</div>
									</div>
								</td>
								<td data-column="Action">
									<a title="Chỉnh sửa" class="view-is_ajax" target="_blank" href="<?php echo backend_url('/contract/edit/'.$value["ID"])?>"><i class="fa fa-edit" aria-hidden="true"></i></a> | 
									<a title="Xem chi tiết" class="view-view_ajax" target="_blank" href="<?php echo backend_url('/contract/view/'.$value["ID"])?>"><i class="fa fa-eye" aria-hidden="true"></i></a> 
								</td>
							</tr>
						<?php endforeach;?>
						<?php endif;?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>