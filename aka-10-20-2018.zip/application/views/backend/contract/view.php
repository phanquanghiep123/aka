<?php $today = new DateTime(date("Y-m-d H:i:s")); ?>
<div class="row">
	<div class="col-sm-6">
		<div class="form-group"> 
			<label class="control-label">Hợp đồng</label>
			<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" readonly>
		</div>
	</div>
	<div class="col-sm-6">
		<div class="form-group"> 
			<label class="control-label">Khách hàng</label>
			<select class="form-control" name="KhachHang_ID" readonly>
				<option value="">Chọn</option>
				<?php if(isset($customer_result) && $customer_result != null): ?>
					<?php foreach ($customer_result as $key => $item): ?>
						<option <?php echo $item['ID'] == @$record["KhachHang_ID"] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['TenNguoiDaiDien']; ?></option>
					<?php endforeach; ?>
				<?php endif; ?>
			</select>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-sm-12">
		<div class="form-group"> 
			<label class="control-label">Mô tả</label>
			<textarea class="form-control" rows="6" name="Description" readonly><?php echo @$record["Description"]; ?></textarea>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-sm-12">
		<div class="form-group"> 
			<label class="control-label">Ngày bắt đầu - ngày kết thúc</label>
			<input class="form-control" value="<?php echo @$record["StartDate"] != null ? date('Y/m/d',strtotime($record["StartDate"])).' - ' : ''; ?> <?php echo @$record["EndDate"] != null ? date('Y/m/d',strtotime($record["EndDate"])) : ''; ?>" name="daterange" type="text" disabled>
		</div>
	</div>
</div>
<?php
	$today = new DateTime(date("Y-m-d H:i:s"));
	$datetime1 = new DateTime($record["StartDate"]);
	$datetime2 = new DateTime($record["EndDate"]);
	$interval = $datetime1->diff($datetime2);
	$total =  (int)$interval->format('%a'); 
	$interval = $datetime1->diff($today);
	$totaltoday =  (int)$interval->format('%a');
	$status = 0;
	if($total != 0){
		if($total < $totaltoday){
			$class="progress-bar-success";
			$status = '100%';
		}else{
			$class="progress-bar-info";
			$status = round( ($totaltoday/$total) * 100 ) . "%"; 
		}
	}else{
		$class="progress-bar-success";
		$status = '100%';
	}
	//echo $status;
	
?>
<div class="row">
	<div class="col-sm-12">
		<div class="form-group"> 
			<label class="control-label">Tiến độ</label>
			<div class="progress">
				<div class="progress-bar <?php echo $class;?>" role="progressbar" aria-valuenow="40"
				aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $status?>">
					<?php echo $status?> Complete (success)
				</div>
			</div>
		</div>
	</div>
</div>
<label class="control-label">File đính kèm</label>
<ul>
	<?php if(@$media != null && @$record["ID"] != null): ?>
		<?php foreach ($media as $key => $item): ?>
			<li>
				<a href="<?php echo base_url($item['URL']); ?>" target="_blank"><?php echo $item['Name'].@$item['FileType']; ?></a>
			</li>
		<?php endforeach; ?>
	<?php endif; ?>
</ul>
<div class="row">
	<div class="col-sm-12">
		<div class="form-group"> 
			<label class="control-label" style="margin-bottom: 20px;">Danh sách đơn hàng <a class="btn btn-success create-item view-is_ajax" href="<?php echo backend_url('order/add?contract_id='.$record["ID"])?>"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Thêm mới</a></label>
			<table class="table table-striped jambo_table bulk_action dataTable no-footer">
				<thead>
					<tr>
						<th>MDH</th>
						<th>Tên DH</th>
						<th>NBD</th>
						<th>NKT</th>
						<th>Tiến độ</th>
						<th>Hành động</th>
					</tr>
				</thead>
				<tbody>
					<?php if(@$orders):?>	
					<?php foreach($orders AS $key => $value):?>
						<tr data-id="<?php echo $value['ID']?>">
							<td data-column="MaDonHang"><?php echo $value["MaDonHang"]?></td>
							<td data-column="TenDonHang"><?php echo $value["TenDonHang"]?></td>
							<td data-column="StartDate"><?php echo $value["StartDate"]?></td>
							<td data-column="EndDate"><?php echo $value["EndDate"]?></td>
							<td data-column="Progress">
								<?php
									$datetime1 = new DateTime($value["StartDate"]);
									$datetime2 = new DateTime($value["EndDate"]);
									$interval = $datetime1->diff($datetime2);
									$total =  (int)$interval->format('%a'); 
									$interval = $datetime1->diff($today);
									$totaltoday =  (int)$interval->format('%a');
									$status = 0;
									if($total != 0){
										if($total < $totaltoday){
											$class="progress-bar-success";
											$status = '100%';
										}else{
											$class="progress-bar-info";
											$status = round( ($totaltoday/$total) * 100 ) . "%"; 
										}
									}else{
										$class="progress-bar-success";
										$status = '100%';
									}
									//echo $status;
									
								?>
								<div class="progress">
									<div class="progress-bar <?php echo $class;?>" role="progressbar" aria-valuenow="40"
									aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $status?>">
										<?php echo $status?> Complete (success)
									</div>
								</div>
							</td>
							<td data-column="Action">
								<a title="Chỉnh sửa" class="view-is_ajax" target="_blank" href="<?php echo backend_url('/order/edit/'.$value["ID"])?>"><i class="fa fa-edit" aria-hidden="true"></i></a> | 
								<a title="Xem chi tiết" class="view-view_ajax" target="_blank" href="<?php echo backend_url('/order/view/'.$value["ID"])?>"><i class="fa fa-eye" aria-hidden="true"></i></a> 
							</td>
						</tr>
					<?php endforeach;?>
					<?php endif;?>
				</tbody>
			</table>
		</div>
	</div>
</div>