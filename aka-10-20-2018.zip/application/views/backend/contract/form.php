<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Hợp đồng <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Khách hàng <span class="required">*</span></label>
				<select class="form-control" name="KhachHang_ID" required="">
					<option value="">Chọn</option>
					<?php if(isset($customer_result) && $customer_result != null): ?>
						<?php foreach ($customer_result as $key => $item): ?>
							<option <?php echo $item['ID'] == @$record["KhachHang_ID"] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['TenNguoiDaiDien']; ?></option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">Ngày bắt đầu - ngày kết thúc <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["StartDate"] != null ? date('Y/m/d',strtotime($record["StartDate"])).' - ' : ''; ?> <?php echo @$record["EndDate"] != null ? date('Y/m/d',strtotime($record["EndDate"])) : ''; ?>" name="daterange" type="text" required="required">
				<input class="form-control" value="<?php echo @$record["StartDate"] != null ? date('Y/m/d',strtotime($record["StartDate"])) : ''; ?>" name="StartDate" type="hidden">
				<input class="form-control" value="<?php echo @$record["EndDate"] != null ? date('Y/m/d',strtotime($record["EndDate"])) : ''; ?>" name="EndDate" type="hidden">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">Mô tả</label>
				<textarea class="form-control" rows="6" name="Description"><?php echo @$record["Description"]; ?></textarea>
			</div>
		</div>
	</div>
	<div class="form-group"> 
		<label class="control-label">File đính kèm</label>
		<input name="files[]" multiple type="file" accept="application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,image/*,application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
		<div style="height: 15px;"></div>
		<ul>
			<?php if(@$media != null && @$record["ID"] != null): ?>
				<?php foreach ($media as $key => $item): ?>
					<li>
						<a href="<?php echo base_url($item['URL']); ?>" target="_blank"><?php echo $item['Name'].@$item['FileType']; ?></a>
						<a href="<?php echo backend_url($folder_view."/remove_media/".$record["ID"] ."/".$item['ID']); ?>" class="remove-media" data-id="<?php echo $item['ID']; ?>" style="color: #ff0000;margin-left: 10px;"><i class="fa fa-times" aria-hidden="true"></i></a>
					</li>
				<?php endforeach; ?>
			<?php endif; ?>
		</ul>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>