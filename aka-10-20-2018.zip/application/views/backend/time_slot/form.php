<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="form-group"> 
		<label class="control-label">Tiêu đề <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["name"]; ?>" name="name" type="text" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Ký hiệu <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["symbol"]; ?>" name="symbol" type="text" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Loại thời gian <span class="required">*</span></label>
		<select class="form-control" name="working_slot_ID">
			<option value="">Chọn loại thời gian</option>
			<?php if(isset($working_slot) && $working_slot != null): ?>
				<?php foreach ($working_slot as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" <?php echo @$record["working_slot_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group"> 
		<label class="control-label">Giờ bắt đầu <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["start_hour"]; ?>" name="start_hour" type="number" min="1" max="24" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Giờ kết thúc <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["end_hour"]; ?>" name="end_hour" type="number" min="1" max="24" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Thời gian bắt đầu <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["start_minute"]; ?>" name="start_minute" type="number" min="0" max="59" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Thời gian kết thúc <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["end_minute"]; ?>" name="end_minute" type="number" min="0" max="59" required="required">
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" class="btn btn-default" onclick="$('.collapse-link-custom').trigger('click');return false;" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>