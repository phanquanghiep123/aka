<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="form-group"> 
		<label class="control-label">Tên chức danh <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Mô tả</label>
		<textarea class="form-control" name="Description" rows="8"><?php echo @$record["Description"]; ?></textarea>
	</div>
	<div class="form-group"> 
		<label class="control-label">Phòng ban</label>
		<select class="form-control" name="Department_ID">
			<?php if(isset($phongban) && $phongban != null): ?>
				<?php foreach ($phongban as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" <?php echo @$record["Department_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group"> 
		<label class="control-label">Trạng thái <span class="required">*</span></label>
		<select class="form-control" name="Status">
			<option value="1">Hoạt động</option>
			<option value="0" <?php echo @$record["Status"] != null && @$record["Status"] == 0 ? 'selected' : ''; ?>>Ngưng hoạt động</option>
		</select>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" class="btn btn-default" onclick="$('.collapse-link-custom').trigger('click');return false;" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>