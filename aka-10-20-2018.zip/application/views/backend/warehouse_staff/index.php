<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="box-common-edit-add relative" style="display: none;">
			<a class="collapse-link-custom" href="#" style="color: #ff0000;"><i class="fa fa-times" aria-hidden="true"></i></a>
			<div class="form-slider" style="max-width: 600px;margin:0 auto;"></div>
		</div>
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-7">
						<h2>
							<?php echo @$title_page; ?> 
							<a class="btn btn-success create-item is_ajax"  href="<?php echo backend_url($folder_view."/add");?>"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Thêm mới</a>
							<a class="btn btn-success" href="<?php echo backend_url($folder_view."/export");?>"><i class="fa fa-download" aria-hidden="true"></i> Xuất Excel</a>
						</h2>
					</div>
					<div class="col-sm-5">
						<form method="" method="get">
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<select class="form-control" name="DMVT">
											<option value="">Danh mục vật tư</option>
											<?php if(isset($dmvt_result) && $dmvt_result != null): ?>
												<?php foreach ($dmvt_result as $key => $item): ?>
													<option <?php echo $item['ID'] ==  $this->input->get('DMVT') ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
												<?php endforeach; ?>
											<?php endif; ?>
										</select>
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<select class="form-control" name="Status">
											<option value="">Trạng thái</option>
											<option value="1" <?php echo $this->input->get('DMVT') == 1 ? 'selected' : ''; ?>>Kế toán kho nhập</option>
											<option value="2" <?php echo $this->input->get('DMVT') == 2 ? 'selected' : ''; ?>>Nhân viên kho nhập</option>
											<option value="3" <?php echo $this->input->get('DMVT') == 3 ? 'selected' : ''; ?>>Đã xác nhận</option>
										</select>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="form-group">
										<button type="submit" class="btn btn-primary">Tìm kiếm</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
					<table class="table table-striped jambo_table bulk_action">
						<thead>
							<tr class="headings">
								<th>Stt </th>
								<th>Barcode</th>
								<th>Danh mục vật tư</th>
								<th>Đơn vị tính</th>
								<th>Số lượng</th>
								<th>Trạng thái</th>
								<th>Vị trí</th>
								<th>Ngày tạo</th>
								<th>Hành động</th>
							</tr>
						</thead>
						<tbody>
						    <?php if(isset($results) && $results != null): ?>
						        <?php foreach ($results as $key => $value): ?>
						        	<?php
						        		$status = 'Hoàn thành';
						        		if($value["Status"] == 1){
						        			$status = 'Đợi xác nhận vật tư';
						        		}
						        		else if($value["Status"] == 2){
						        			$status = 'Đợi xác nhận đơn giá';
						        		}
						        	?>
						    		<tr data-id="<?php echo $value['ID']; ?>">
										<td data-column="Stt"><?php echo $key+1;?></td>
										<td data-column="Barcode"><?php echo $value["Barcode"]; ?></td>
										<td data-column="DMVTName"><?php echo $value["DMVTName"]; ?></td>
										<td data-column="DVTName"><?php echo @$value["DVTName"]; ?></td>
										<td data-column="SoLuong"><?php echo $value["SoLuong"]; ?></td>
										<td data-column="Status"><?php echo $status; ?></td>
										<td data-column="Position"><?php echo $value["Position"] == 1 ? 'Đã cập nhật' : '<a class="modal-position-list" href="#" data-id="'.$value['ID'].'" data-dmvt-id="'.$value['DMVT_ID'].'">Chưa cập nhật</a>'; ?></td>
										<td data-column="Created_At"><?php echo date($datetime_format,strtotime($value["Created_At"])); ?></td>
										<td data-column="Action">
											<?php if($value["Status"] == 1 || $value["Status"] == 2 || ($value["Status"] == 3 && $value["Position"] == 0)): ?>
												<a class="is_ajax" title="Chỉnh sửa" href="<?php echo backend_url($folder_view."/edit/".$value["ID"])?>"><i class="fa fa-edit" aria-hidden="true"></i></a>
											<?php endif; ?>
											<?php if($value["Status"] == 2 && ($admin_info['Employee_ID'] == 0 || $value['Employee_NVKho_ID'] == $admin_info['Employee_ID'] )): ?>
												 |  <a class="is_ajax_delete" title="Xóa" href="<?php echo backend_url($folder_view.'/delete/'.$value["ID"])?>"><i class="fa fa-trash" aria-hidden="true"></i></a> 
											<?php endif; ?>
										</td>
									</tr>
							    <?php endforeach; ?>
						    <?php endif; ?>
						</tbody>
					</table>
				</div>
				<?php if(isset($this->pagination)): ?>
					<div class="row">
						<div class="col-sm-12 text-center">
							<?php echo @$this->pagination->create_links();?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div id="position-list-modal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-md" style="max-width: 700px;">
        <!-- Modal content-->
        <form class="modal-content" action="" method="post">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" style="top:20px;font-size: 20px;">&times;</button>
                <h4 class="modal-title">Nhập Kho</h4>
            </div>
            <div class="modal-body" style="height: 450px;overflow-y:auto;"></div>
            <div class="modal-footer text-right">
            	<button type="button" data-dismiss="modal" class="btn btn-default">Hủy bỏ</button>
            	<button type="submit" class="btn btn-primary">Cập nhật</button>
            </div>
        </form>
    </div>
</div>
<style type="text/css">
	#position-list-modal .modal-body ul {
	    list-style: none;
	    padding: 0;
	}
</style>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('click','.modal-position-list',function(){
			var val = $(this).attr('data-dmvt-id');
			var id  = $(this).attr('data-id');
			if(val != null && val != '' && id != null && id != ''){
				var url = "<?php echo backend_url('/'.$folder_view.'/get_position/'); ?>";
	            $.ajax({
	                type: 'POST',
	                dataType:'json',
	                url: url + val,
	                data:{'Nhap_ID':id},
	                success: function(data) {
	                	if(data['status'] == 'success'){
	                    	$('#position-list-modal .modal-body').html(data['response']);
	                    	$('#position-list-modal').modal();
	                	}
	                	else if(data['status'] == 'fail'){
	                		alert(data['message']);
	                	}
	                }
	            });
			}
			return false;
		});


		$(document).on('submit','#position-list-modal form',function(){
			var current = $(this);
			var url = "<?php echo backend_url('/'.$folder_view.'/update_position/'); ?>";
			var options = {
				url: url,
                dataType:'json',
                success: function(data){
                    if(data['status'] == 'success'){
                    	location.reload();
                    }
                    else if(data['status'] == 'fail'){
                    	$(".box-common-edit-add .alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.ajaxSubmit(options);
			return false;
		});


		$(document).on('click','a.is_ajax',function(){
			$(".box-common-edit-add .message").hide();
			var url = $(this).attr('href');
            $.ajax({
                type: 'POST',
                dataType:'html',
                url: url,
                data:{},
                success: function(html) {
                	if(html != -1){
                    	$(".box-common-edit-add .form-slider").html(html);
                    	$(".box-common-edit-add").slideDown();
                    	$("body,html").animate({scrollTop:0}, 'slow');
                	}
                    else{
                    	alert('Lần nhập này không tồn tại.');
                    }
                }
            });
			return false;
		});

		$(document).on('click','a.is_ajax_delete',function(){
			if(confirm('Bạn thật sự muốn xóa?')){
				var current = $(this);
				var url = $(this).attr('href');
	            $.ajax({
	                type: 'POST',
	                dataType:'json',
	                url: url,
	                data:{},
	                success: function(data) {
	                	if(data['status'] == 'success'){
	                		current.parents('tr').remove();
	                		$('tr td[data-column="Stt"]').each(function(i){
	                    		$(this).html(i+1);
	                    	});
	                	}
	                }
	            });
            }
			return false;
		});

		$(document).on('submit','.box-common-edit-add form',function(){
			var current = $(this);
			$(".box-common-edit-add .message").hide();
			var options = {
                dataType:'json',
                success: function(data){
                    if(data['status'] == 'success'){
                    	var fields = ["Barcode","DMVTName","DVTName","SoLuong","Status","Position","Created_At"];
                        if(data['action'] == 'add'){
                        	var html = '<tr data-id="' + data['responsive']['ID'] + '">';
                        		html += '	<td data-column="Stt"></td>';
                        		fields.forEach(function(element) {
								  	html += '<td data-column="' + element + '">' + data['responsive'][element] + '</td>';
								});
                        		html += '	<td data-column="Action">';
                        		html += '		<a class="is_ajax" href="<?php echo backend_url($folder_view."/edit/"); ?>' + data['responsive']['ID'] + '"><i class="fa fa-edit" aria-hidden="true"></i></a> | ';
								html += '		<a class="is_ajax_delete" href="<?php echo backend_url($folder_view.'/delete/'); ?>' + data['responsive']['ID'] + '"><i class="fa fa-trash" aria-hidden="true"></i></a>';
                        		html += '	</td>';
                        		html += '</tr>';
                        	$('.x_content table').prepend(html);

                        	$('tr td[data-column="Stt"]').each(function(i){
                        		$(this).html(i+1);
                        	});
                        }
                        else{
                        	fields.forEach(function(element) {
							  	$('tr[data-id="' + data['responsive']['ID'] + '"] td[data-column="' + element + '"]').html(data['responsive'][element]);
							});
							if(data['responsive']['Status'] == 'Đã xác nhận'){
								location.reload();
							}
                        }
                        $(".box-common-edit-add").slideUp();
                    }
                    else if(data['status'] == 'fail'){
                    	$(".box-common-edit-add .alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.ajaxSubmit(options);
			return false;
		});

		$(document).on('change', '.form-slider select[name="DMVT_ID"]', function() {
			var barcode = $(this).find(":selected").attr('data-barcode');
			if (typeof barcode !== typeof undefined && barcode !== false) {
			    $('.form-slider .barcode-mdvt').val(barcode);
			}
			else{
				$('.form-slider .barcode-mdvt').val('');
			}
		});

		$(document).on('change', '.form-slider .barcode-mdvt', function() {
			var barcode = $(this).val().toString();
			var val = '';
			$('.form-slider select[name="DMVT_ID"] option').each(function(){
			    var data_barcode = $(this).attr('data-barcode');
				if (typeof data_barcode !== typeof undefined && data_barcode !== false && barcode == data_barcode) {
					val = $(this).attr('value');
				}
			});
			$('.form-slider select[name="DMVT_ID"]').val(val).trigger("change");
			console.log($('.form-slider select[name="DMVT_ID"]').val());
		});

		$('.collapse-link-custom').click(function(){
			$(".box-common-edit-add").slideUp();
			return false;
		});
	});
</script>