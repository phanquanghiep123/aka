<h4 style="line-height: 30px;">
	<?php echo @$dmvt['Name']; ?>
	<?php if(@$nhap['Status'] == 1 || true): ?>
		(Số lượng nhập: <?php echo @$nhap['SoLuong'].' '.(@$dvt['Name'] != '-' ? $dvt['Name'] : ''); ?>)
	<?php endif; ?>
	<?php if(isset($tonkho) && $tonkho != null) :?>
		<br>Số lượng tồn kho: <?php echo ($tonkho['TotalTon'] <= 0 ? '' : 'Thiếu ').abs($tonkho['TotalTon']) .' '. (@$dvt['Name'] != '-' ? $dvt['Name'] : ''); ?>
	<?php endif; ?>
</h4>
<div id="tab" class="btn-group" data-toggle="buttons">
	<a href="#giadung1" class="btn btn-primary active" data-toggle="tab">
        <input type="radio" name="position" value="gia" checked="" />
        Giá đựng
    </a>
	<a href="#hop1" class="btn btn-primary" data-toggle="tab">
        <input type="radio" name="position" value="hop" />
        Hộp
    </a>
</div>
<div class="tab-content" style="border: 1px solid #ccc;padding: 20px;">
	<div class="tab-pane active" id="giadung1">
		<div class="row">
			<div class="col-xs-4">
				<p>Tên giá đựng</p>
			</div>
			<div class="col-xs-4">
				<p>Số lượng hiện tại</p>
			</div>
			<div class="col-xs-4">
				<p>Số lượng nhập</p>
			</div>
		</div>
		<ul>
            <?php if(isset($gia_result) && $gia_result != null): ?>
				<?php foreach ($gia_result as $key => $item): ?>
					<li>
						<div class="row">
							<div class="col-xs-4">
								<label for="gia-<?php echo $item['ID']; ?>">
									<span class="name"><?php echo $item['Name']; ?> - <?php echo $item['Hang']; ?> - <?php echo $item['Cot']; ?></span>
								</label>
							</div>
							<div class="col-xs-4">
								<p><?php echo @$item['SoLuongVT'] != null ? ($item['SoLuongVT']  - (@$item['SoLuongNhap'] != null ? $item['SoLuongNhap'] : 0)).' '.@$dvt['Name'] : 'Chưa có vật tư này'; ?></p>
							</div>
							<div class="col-xs-4">
								<div class="form-group">
									<input type="text" value="<?php echo @$item['SoLuongNhap'] != null ? $item['SoLuongNhap'] : ''; ?>" name="gia[<?php echo $item['ID']; ?>]" placeholder="Nhập số lượng" class="form-control format-number">
								</div>
							</div>
						</div>
					</li>
				<?php endforeach; ?>
			<?php endif; ?>
		</ul>
	</div>
	<div class="tab-pane" id="hop1">
		<div class="row">
			<div class="col-xs-4">
				<p>Tên hộp</p>
			</div>
			<div class="col-xs-4">
				<p>Số lượng hiện tại</p>
			</div>
			<div class="col-xs-4">
				<p>Số lượng</p>
			</div>
		</div>
		<ul>
            <?php if(isset($hop_result) && $hop_result != null): ?>
				<?php foreach ($hop_result as $key => $item): ?>
					<li>
						<div class="row">
							<div class="col-xs-4">
								<label for="hop-<?php echo $item['ID']; ?>">
									<span class="name"><?php echo $item['Name']; ?></span>
								</label>
							</div>
							<div class="col-xs-4">
								<p><?php echo @$item['SoLuongVT'] != null ? ($item['SoLuongVT'] - (@$item['SoLuongNhap'] != null ? $item['SoLuongNhap'] : 0)).' '.@$dvt['Name'] : 'Chưa có vật tư này'; ?></p>
							</div>
							<div class="col-xs-4">
								<div class="form-group">
									<input type="text" value="<?php echo @$item['SoLuongNhap'] != null ? $item['SoLuongNhap'] : ''; ?>" name="hop[<?php echo $item['ID']; ?>]" placeholder="Nhập số lượng" class="form-control format-number">
								</div>
							</div>
						</div>
					</li>
				<?php endforeach; ?>
			<?php endif; ?>
		</ul>
	</div>
</div>
<input type="hidden" name="nhap_id" value="<?php echo @$nhap_id; ?>">
<input type="hidden" name="dmvt_id" value="<?php echo @$dmvt_id; ?>">
<script type="text/javascript">
	function check_func(element) {
	    var val = $(element).val();
	    if(isNaN(val) || val < 0){
	    	$(element).val('0');
	    }
	}
</script>