<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-12">
						<h2><?php echo @$title_page; ?> </h2>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
				    <form action="" method="post">
				    	<div class="row">
				    		<div class="col-sm-3">
								<div class="form-group"> 
									<select class="form-control" name="MaHang_ID" required="required">
										<option value="">Chọn Mã hàng *</option>
										<?php if(isset($plu_result) && $plu_result != null): ?>
											<?php foreach ($plu_result as $key => $item): ?>
												<option <?php echo $item['ID'] == @$record['MaHang_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
											<?php endforeach; ?>
										<?php endif; ?>
									</select>
								</div>
							</div>
							<div class="col-sm-3"></div>
							<div class="col-sm-6">
								<div class="text-right">
									<a href="<?php echo backend_url($folder_view);?>" class="btn btn-default">Hủy bỏ</a>
									<button type="submit" class="btn btn-primary">Lưu dữ liệu</button>
								</div>
							</div>
				    	</div>
				    	<table class="table table-striped jambo_table bulk_action not-datatable">
							<thead>
								<tr class="headings">
									<th>#</th>
									<th>Loại hình</th>
									<th>Số ngày đợi</th>
									<th>Đơn giá</th>
									<th>Hành động</th>
								</tr>
							</thead>
							<tbody id="sortable">
							    <?php if(isset($type_result) && $type_result != null): ?>
							        <?php foreach ($type_result as $key => $item): ?>
							    		<tr style="background-color: #fff;">
											<td><?php echo ($key+1); ?></td>
											<td><?php echo $item['Name']; ?></td>
											<td>
												<div class="form-group" style="max-width: 300px;">
													<input type="number" min="0" class="form-control delay" value="0" placeholder="Số ngày đợi" name="delay[]">
													<input type="hidden" name="type[]" value="<?php echo $item['ID']; ?>">
												</div>
											</td>
											<td>
												<div class="form-group" style="max-width: 300px;">
													<input type="text" class="form-control format-number" value="" placeholder="Đơn giá" name="dongia[]">
												</div>
											</td>
											<td>
												<a title="Xóa" class="remove-type-item" href="#"><i class="fa fa-trash" aria-hidden="true"></i></a> 
											</td>
										</tr>
								    <?php endforeach; ?>
							    <?php endif; ?>
							</tbody>
						</table>
						<p class="text-right"><a href="<?php echo backend_url("/type/add");?>" class="btn btn-primary is_ajax">Thêm mới loại hình</a></p>
				    </form>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('click','a.is_ajax',function(){
			$("#form-modal .modal-body .message").hide();
			var url = $(this).attr('href');
            $.ajax({
                type: 'POST',
                dataType:'html',
                url: url,
                data:{},
                success: function(html) {
                	if(html != -1){
                    	$("#form-modal .modal-body .result-form").html(html);
                    	$("#form-modal").modal('show');
                	}
                }
            });
			return false;
		});

		$(document).on('submit','#form-modal .modal-body .result-form form',function(){
			var current = $(this);
			current.find(".message").hide();
			var options = {
                dataType:'json',
                success: function(data){
                    if(data['status'] == 'success'){
                    	var count = $('table #sortable tr').length;
                        var html  = '<tr>';
                        	html += '	<td>'+ (count + 1) +'</td>';
                    		html += '	<td>' + data['responsive']['Name'] + '</td>';
                    		html += '	<td>';
							html += '		<div class="form-group" style="max-width: 300px;">';
							html += '			<input type="number" min="0" class="form-control delay" value="0" placeholder="Số ngày đợi" name="delay[]">';
							html += '			<input type="hidden" name="type[]" value="' + data['responsive']['ID'] + '">';
							html += '		</div>';
							html += '	</td>';
							html += '	<td>';
							html += '		<div class="form-group" style="max-width: 300px;">';
							html += '			<input type="text" class="form-control format-number" value="" placeholder="Đơn giá" name="dongia[]">';
							html += '		</div>';
							html += '	</td>';
                    		html += '	<td data-column="Action">';
                    		html += '		<a title="Xóa" class="remove-type-item" href="#"><i class="fa fa-trash" aria-hidden="true"></i></a>';
                    		html += '	</td>';
                    		html += '</tr>';
                    	$('table #sortable').append(html);
                    	$("#form-modal").modal('toggle');
                    }
                    else if(data['status'] == 'fail'){
                    	current.find(".alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.ajaxSubmit(options);
			return false;
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$("#sortable").sortable({
			stop: function(evt, ui) {
	            ui.item.parents('tbody').find('> tr').each(function(i){
	            	$(this).find('td:first-child').html(i+1);
	            });
	        }
		});
    	$("#sortable").disableSelection();

    	$(document).on('click','.remove-type-item',function(){
    		if(confirm('Bạn thật sự muốn xóa?')){
    			$(this).parents('tr').remove();
    		}
    		return false;	
    	});

		$('form').submit(function(){
			var check = true;
			var check_input = false;
			$(this).find('.delay').each(function(){
				var current = $(this);
				var delay_val = current.val();
				if(delay_val == '' || delay_val == null){
					current.addClass('border-error');
					check = false;
				}
				else{
					current.removeClass('border-error');
				}
			});
			//if(!check_input){
				//alert('Vui lòng nhập đầy đủ dữ liêu.');
				//return check_input;
			//}
			return check;
		});
	});
</script>
<style type="text/css">
	.calendar-table table tr th {color: #000;}
	.border-error{border:1px solid #ff0000 !important;}
	#sortable tr{cursor: move;}
	#form-modal .modal-dialog{max-width: 450px;}
</style>