<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">Danh mục vật tư <span class="required">*</span></label>
				<select class="form-control" name="DMVT_ID" required="required" <?php echo @$record['DMVT_ID'] != null ? 'disabled' : ''; ?>>
					<option value="">Chọn</option>
					<?php if(isset($dmvt_result) && $dmvt_result != null): ?>
						<?php foreach ($dmvt_result as $key => $item): ?>
							<option <?php echo $item['ID'] == @$record['DMVT_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
		</div>
		<?php /*
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Hộp</label>
				<select class="form-control" disabled>
					<option value="">Chọn</option>
					<?php if(isset($box_result) && $box_result != null): ?>
						<?php foreach ($box_result as $key => $item): ?>
							<option <?php echo $item['ID'] == @$record['Hop_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
		</div>*/ ?>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="form-group"> 
				<label class="control-label">Số lượng <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["SoLuong"]; ?>" name="SoLuong" type="number" min="0" required="required">
			</div>
		</div>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>