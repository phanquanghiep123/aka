<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_content">
				<div class="row">
					<div class="col-sm-12">
						<h4>Hộp</h4>
						<ol class="sortable sortable-box ui-sortable">
							<?php if(isset($boxs) && $boxs != null): ?>
								<?php foreach ($boxs as $key => $item): ?>
									<li class="box item-box" data-box-id="<?php echo $item['ID']; ?>">
								        <div>
								        	<span class="action">
								        		<a href="<?php echo backend_url($folder_view."/add_box/".@$item['ID']);?>" class="is_ajax box"><i class="fa fa-plus" aria-hidden="true"></i></a>
								        	</span>
								        	<?php echo $item['Name']; ?>
								        	<ol class="sortable sortable-box ui-sortable">
										       	<?php if(isset($item['dmvt']) && $item['dmvt'] != null): ?>
										       		<?php foreach ($item['dmvt'] as $key11 => $dmvt): ?>
														<li class="item-dmvt" style="display: list-item;">
													        <div>
													        	<span class="action">
													        		<a href="<?php echo backend_url($folder_view."/edit_box/".@$item['ID'].'/'.$dmvt['ID']);?>" class="edit is_ajax"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
													        		<a href="<?php echo backend_url($folder_view."/delete_box/".@$item['ID'].'/'.$dmvt['ID']);?>" class="remove is_ajax_delete"><i class="fa fa-times" aria-hidden="true"></i></a>
													        	</span>
													        	<?php echo @$dmvt['Name']; ?> (<?php echo @$dmvt['SoLuong']; ?>)
													       	</div>
													    </li>
													<?php endforeach; ?>
											    <?php endif; ?>
										    </ol>
								        </div>
								    </li>
								<?php endforeach; ?>
							<?php endif; ?>
						</ol>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<?php if(isset($results) && $results != null): ?>
							<?php foreach ($results as $key => $item): ?>
								<div class="group-shelves">
									<?php foreach ($item['boxs'] as $i => $item1): ?>
										<div class="row-shelves">
											<?php foreach ($item1 as $j => $item2): ?>
												<?php if(count($item1) > 0): ?>
													<div class="shelves" style="width: <?php echo (100/count($item1)).'%'; ?> ">
														<div class="shelves-wrap">
															<span class="action">
												        		<a style="border: none;" href="<?php echo backend_url($folder_view."/add_shelves/".$item2['current']['ID']);?>" class="is_ajax shelves"><i class="fa fa-plus" aria-hidden="true"></i></a>
												        	</span>
															<h4><?php echo $item2['current']['Name']; ?> - <?php echo $i; ?> - <?php echo $j; ?></h4>
															<ol class="sortable sortable-shelves ui-sortable" style="min-height: 50px;" data-shelves-id="<?php echo $item2['current']['ID']; ?>">
																<?php foreach ($item2['result']['current'] as $key => $box): ?>
																	<li class="box item-box" data-shelves-id="<?php echo $item2['current']['ID']; ?>" data-box-id="<?php echo @$box['Hop_ID']; ?>" style="display: list-item;">
																        <div>
																        	<span class="action">
																        		<a href="<?php echo backend_url($folder_view."/add_box/".@$box['Hop_ID']);?>" class="is_ajax box"><i class="fa fa-plus" aria-hidden="true"></i></a>
																        	</span>
																        	<?php echo @$box['BoxName']; ?>
																        	<ol class="sortable sortable-box ui-sortable">
																		       	<?php if(isset($box['dmvt']) && $box['dmvt'] != null): ?>
																		       		<?php foreach ($box['dmvt'] as $key11 => $dmvt): ?>
																						<li class="item-dmvt" style="display: list-item;">
																					        <div>
																					        	<span class="action">
																					        		<a href="<?php echo backend_url($folder_view."/edit_box/".@$box['Hop_ID'].'/'.$dmvt['ID']);?>" class="edit is_ajax"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
																					        		<a href="<?php echo backend_url($folder_view."/delete_box/".@$box['Hop_ID'].'/'.$dmvt['ID']);?>" class="remove is_ajax_delete"><i class="fa fa-times" aria-hidden="true"></i></a>
																					        	</span>
																					        	<?php echo @$dmvt['Name']; ?> (<?php echo @$dmvt['SoLuong']; ?>)
																					       	</div>
																					    </li>
																					<?php endforeach; ?>
																			    <?php endif; ?>
																		    </ol>
																	    </div>
																    </li>
																<?php endforeach; ?>
																<?php foreach ($item2['dmvt'] as $key11 => $dmvt): ?>
																	<li class="item-dmvt" style="display: list-item;">
																        <div>
																        	<span class="action">
																        		<a href="<?php echo backend_url($folder_view."/edit_shelves/".$item2['current']['ID'].'/'.$dmvt['ID']);?>" class="edit is_ajax"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
																        		<a href="<?php echo backend_url($folder_view."/delete_shelves/".$item2['current']['ID'].'/'.$dmvt['ID']);?>" class="remove is_ajax_delete"><i class="fa fa-times" aria-hidden="true"></i></a>
																        	</span>
																        	<?php echo @$dmvt['Name']; ?> (<?php echo @$dmvt['SoLuong']; ?>)
																       	</div>
																    </li>
																<?php endforeach; ?>
															</ol>
														</div>
													</div>
												<?php endif; ?>
											<?php endforeach; ?>
										</div>
									<?php endforeach; ?>
								</div>
								<div style="height: 50px;"></div>
							<?php endforeach; ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		var element = null;
		$(document).on('click','a.is_ajax',function(){
			element = $(this);
			$("#form-modal .modal-body .message").hide();
			var url = $(this).attr('href');
            $.ajax({
                type: 'POST',
                dataType:'html',
                url: url,
                data:{},
                success: function(html) {
                	if(html != -1){
                		$("#form-modal .modal-body .result-form").html(html);
                    	$("#form-modal").modal('show');
                	}
                }
            });
			return false;
		});

		$(document).on('click','a.is_ajax_delete',function(){
			if(confirm('Bạn thật sự muốn xóa?')){
				var current = $(this);
				var url = $(this).attr('href');
	            $.ajax({
	                type: 'POST',
	                dataType:'json',
	                url: url,
	                data:{},
	                success: function(data) {
	                	if(data['status'] == 'success'){
	                		current.parents('.item-dmvt').remove();
	                	}
	                }
	            });
            }
			return false;
		});

		$(document).on('submit','#form-modal form',function(){
			var current = $(this);
			$("#form-modal .modal-body .message").hide();
			var options = {
                dataType:'json',
                success: function(data){
                    if(data['status'] == 'success'){
                        if(data['action'] == 'add'){
                        	var responsive = data['responsive'];
							if(element.hasClass('box')){
								element.parents('.item-box').find('.sortable-box').append(responsive);
							}
							else{
								element.parents('.shelves-wrap').find('.sortable-shelves').append(responsive);
							}
                        }
                        $("#form-modal").modal('toggle');
                    }
                    else if(data['status'] == 'fail'){
                    	$("#form-modal .modal-body .alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.ajaxSubmit(options);
			return false;
		});
	});
</script>
<style type="text/css">
	.row-shelves:before,
	.row-shelves:after{content: '';display: table;}
	.row-shelves:after{clear: both;}
	.row-shelves{display: flex;}
	.shelves{
		float:left;
		border-bottom:1px solid #000;
		border-right:1px solid #000;
	}
	.shelves .shelves-wrap{
		padding: 10px;
	}
	.shelves .shelves-wrap > h4{
		text-align: center;
    	margin-bottom: 15px;
	}
	.row-shelves:first-child  .shelves{
		border-top:1px solid #000;
	}
	.row-shelves .shelves:first-child{
		border-left:1px solid #000;
	}

    ol.sortable,
    ol.sortable ol {
        padding: 0;
        list-style-type: none;
    }
    ol.sortable ol{
    	padding: 0 0 0 0;
    }
    
    ol.sortable {
        width: 100%;
    }
    
    .sortable li {
        margin: 7px 0 0 0;
        padding: 0;
    }
    
    .sortable li div {
        border: 1px solid #ccc;
	    padding: 7px 15px;
	    margin: 0;
	    font-size: 17px;
	    position: relative;
    }
    .sortable li.item-dmvt div{
    	font-size: 13px;
    	padding: 3px 15px 3px 5px;
    }
    .shelves-wrap{
    	position: relative;
    }
    .sortable li div .action,
    .shelves-wrap > .action{
    	position: absolute;
    	right: 7px;
    	top: 10px;
    	z-index: 100;
    	font-size: 13px;
    }
    .item-dmvt .action{
    	display: none;
    	background-color: #fff;
    }
    .item-dmvt:hover .action{
    	display: block;
    }
    .sortable li.item-dmvt div .action{
    	top: 3px;
    }
    .sortable li div .action .remove{
    	color: #ff0000;
    	margin-left: 5px;
    }
    .sortable li[id^="list_1_"] > div {
        background: #fff;
    }
    .main_menu ul ul li span.fa{display: none;}
    .sortable-box li {
	    margin: 7px 0 0 0;
	    padding: 0;
	    display: inline-block;
	    min-width: 125px;
	    vertical-align: top;
	}
</style>