<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="form-group"> 
		<label class="control-label">Tên giá đựng <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label"><?php echo @$record["Hang"] != null ? 'Hàng' : 'Số Hàng'; ?> <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Hang"]; ?>" name="Hang"  type="number" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label"><?php echo @$record["Cot"] != null ? 'Cột' : 'Số Cột'; ?> <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Cot"]; ?>" name="Cot" type="number" required="required">
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>