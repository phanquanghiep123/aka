<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="form-group">
		<label class="control-label">Nhân viên <span class="required">*</span></label>
		<select class="form-control required" name="Employee_ID">
			<option value="">Chọn nhân viên</option>
			<?php if(isset($employee) && $employee != null): ?>
				<?php foreach ($employee as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" <?php echo @$record["Employee_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group">
		<label class="control-label">Quy trình <span class="required">*</span></label>
		<select class="form-control required" name="Process_ID">
			<option value="">Chọn quy trình</option>
			<?php if(isset($process) && $process != null): ?>
				<?php foreach ($process as $key => $item): ?>
					<option value="<?php echo $item['ID']; ?>" <?php echo @$record["Process_ID"] == $item['ID'] ? 'selected' : ''; ?>><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group"> 
		<label class="control-label">Thời gian xử lý <span class="required">*</span></label>
		<input type="text" name="TimeProcess" class="form-control format-number" value="<?php echo @$record['TimeProcess']; ?>" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Ngày lấy mẫu <span class="required">*</span></label>
		<input type="text" name="DateGetSample" class="form-control datetimepicker" value="<?php echo @$record['DateGetSample'] != null ? date($date_format,strtotime($record['DateGetSample'])) : ''; ?>" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Số lượng mẫu <span class="required">*</span></label>
		<input type="text" name="NumOfSample" class="form-control format-number" value="<?php echo @$record['NumOfSample']; ?>" required="required">
	</div>
	<div class="form-group"> 
		<label class="control-label">Mô tả</label>
		<textarea class="form-control" name="Description" rows="6"><?php echo @$record['Description']; ?></textarea>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>