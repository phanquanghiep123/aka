<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="box-common-edit-add relative" style="display: none;">
			<a class="collapse-link-custom" href="#" style="color: #ff0000;"><i class="fa fa-times" aria-hidden="true"></i></a>
			<div class="form-slider" style="max-width: 600px;margin:0 auto;"></div>
		</div>
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-7">
						<h2>
							<?php echo @$title_page; ?> 
							<a class="btn btn-success create-item is_ajax" href="<?php echo backend_url($folder_view."/add");?>"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Thêm mới</a>
						</h2>
					</div>
					<div class="col-sm-5">
						<form method="" method="get">
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<select class="form-control" name="NCC">
											<option value="">Nhà cung cấp</option>
											<?php if(isset($ncc_result) && $ncc_result != null): ?>
												<?php foreach ($ncc_result as $key => $item): ?>
													<option <?php echo $item['ID'] == $this->input->get('NCC') ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
												<?php endforeach; ?>
											<?php endif; ?>
										</select>
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<select class="form-control" name="DMVT">
											<option value="">Danh mục vật tư</option>
											<?php if(isset($dmvt_result) && $dmvt_result != null): ?>
												<?php foreach ($dmvt_result as $key => $item): ?>
													<option <?php echo $item['ID'] ==  $this->input->get('DMVT') ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
												<?php endforeach; ?>
											<?php endif; ?>
										</select>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="form-group">
										<button type="submit" class="btn btn-primary">Tìm kiếm</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="x_content">
				<div class="table-responsive">
				    <?php $this->load->view($backend_asset."/includes/message");?>
					<table class="table table-striped jambo_table bulk_action">
						<thead>
							<tr class="headings">
								<th class="column-title">Stt </th>
								<th class="column-title">Tên Chuyền </th>
								<th class="column-title">Tên hàng</th>
								<th class="column-title">Số lượng thực hiện</th>
								<th class="column-title">Số lượng kế hoạch </th>
								<th class="column-title">Màu</th>
								<th class="column-title">Size</th>
								<th class="column-title">Ngày sản xuất </th>
								<th class="column-title no-link last"><span class="nobr">Hành động</span> </th>
							</tr>
						</thead>
						<tbody>
						    <?php
						        if(isset($table_data)){
						        	$i = 1;
						        	foreach ($table_data as $key => $value) {?>
							    		<tr class="even pointer">
											<td class="a-center "> <?php echo $i++;?> </td>
											<td ><?php echo $value["TenChuyen"]?></td>
											<td><?php echo $value["TenHang"]?></td>
											<td><?php echo $value["SoLuongThucHien"]?></td>
											<td><?php echo $value["SoLuongKeHoach"]?></td>
											<td><?php echo $value["TenMau"]?></td>
											<td><?php echo $value["TenSize"]?></td>
										    <td><?php echo $value["NgaySX"]?></td>
										    <td data-column="Action">		
										    	<a class="is_ajax" href="<?php echo backend_url('implementations/edit/'.$value["ID"])?>"><i class="fa fa-edit" aria-hidden="true"></i></a> | <a class="is_ajax_delete" href="<?php echo backend_url('implementations/delete/'.$value["ID"])?>"><i class="fa fa-trash" aria-hidden="true"></i></a>	
										    </td>
										</tr>
							    	<?php }
						        }
						    ?>
						</tbody>
					</table>
				</div>
				<?php if(isset($this->pagination)): ?>
					<div class="row">
						<div class="col-sm-12 text-center">
							<?php echo @$this->pagination->create_links();?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
		$('#upload-modal form').submit(function(){
			var current = $(this);
			current.parents('form').find(".message").hide();
			var options = {
                dataType:'json',
                type: 'POST',
	            url: "<?php echo backend_url($folder_view."/import/"); ?>",
                success: function(data){
                    if(data['status'] == 'success'){
                    	alert(data['message']);
                    	location.reload();
                    }
                    else if(data['status'] == 'fail'){
                    	current.find(".alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.ajaxSubmit(options);
            return false;
		});
	});
</script>


<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('click','a.is_ajax',function(){
			$(".box-common-edit-add .message").hide();
			var url = $(this).attr('href');
            $.ajax({
                type: 'POST',
                dataType:'html',
                url: url,
                data:{},
                success: function(html) {
                	if(html != -1){
                    	$(".box-common-edit-add .form-slider").html(html);
                    	$(".box-common-edit-add").slideDown();
                    	$("body,html").animate({scrollTop:0}, 'slow');
                    	$(".box-common-edit-add .form_datetime").each(function(){
							$(this).datetimepicker({
						        format: 'Y/m/d',
						        timepicker: false,
						        autoclose: true,
						        todayBtn: true
						    });
						});
                	}
                    else{
                    	alert('Đơn giá NCC - Vật tư này không tồn tại.');
                    }
                }
            });
			return false;
		});

		$(document).on('click','a.is_ajax_delete',function(){
			if(confirm('Bạn thật sự muốn xóa?')){
				var current = $(this);
				var url = $(this).attr('href');
	            $.ajax({
	                type: 'POST',
	                dataType:'json',
	                url: url,
	                data:{},
	                success: function(data) {
	                	if(data['status'] == 'success'){
	                		current.parents('tr').remove();
	                		$('tr td[data-column="Stt"]').each(function(i){
	                    		$(this).html(i+1);
	                    	});
	                	}
	                }
	            });
            }
			return false;
		});

		$(document).on('submit','.box-common-edit-add form',function(){
			var current = $(this);
			$(".box-common-edit-add .message").hide();
			var options = {
                dataType:'json',
                success: function(data){
                    if(data['status'] == 'success'){
                    	var fields = ["TenChuyen","TenDonHang","SoLuongThucHien","SoLuongKeHoach","NgaySX"];
                        if(data['action'] == 'add'){
                        	var html = '<tr data-id="' + data['responsive']['ID'] + '">';
                        		html += '	<td data-column="Stt"></td>';
                        		fields.forEach(function(element) {
								  	html += '<td data-column="' + element + '">' + data['responsive'][element] + '</td>';
								});
                        		html += '	<td data-column="Action">';
                        		html += '		<a class="is_ajax" href="<?php echo backend_url($folder_view."/edit/"); ?>' + data['responsive']['ID'] + '"><i class="fa fa-edit" aria-hidden="true"></i></a> | ';
								html += '		<a class="is_ajax_delete" href="<?php echo backend_url($folder_view.'/delete/'); ?>' + data['responsive']['ID'] + '"><i class="fa fa-trash" aria-hidden="true"></i></a>';
                        		html += '	</td>';
                        		html += '</tr>';
                        	$('.x_content table').prepend(html);

                        	$('tr td[data-column="Stt"]').each(function(i){
                        		$(this).html(i+1);
                        	});
                        }
                        else{
                        	fields.forEach(function(element) {
							  	$('tr[data-id="' + data['responsive']['ID'] + '"] td[data-column="' + element + '"]').html(data['responsive'][element]);
							});
                        }
                        $(".box-common-edit-add").slideUp();
                    }
                    else if(data['status'] == 'fail'){
                    	$(".box-common-edit-add .alert-danger").html(data['message']).show();
                    }
                }
            }; 
            current.ajaxSubmit(options);
			return false;
		});

		$(document).on('change', '.form-slider select[name="DMVT_ID"]', function() {
			var barcode = $(this).find(":selected").attr('data-barcode');
			if (typeof barcode !== typeof undefined && barcode !== false) {
			    $('.form-slider .barcode-mdvt').val(barcode);
			}
			else{
				$('.form-slider .barcode-mdvt').val('');
			}
		});

		$(document).on('change', '.form-slider .barcode-mdvt', function() {
			var barcode = $(this).val().toString();
			var val = '';
			$('.form-slider select[name="DMVT_ID"] option').each(function(){
			    var data_barcode = $(this).attr('data-barcode');
				if (typeof data_barcode !== typeof undefined && data_barcode !== false && barcode == data_barcode) {
					val = $(this).attr('value');
				}
			});
			$('.form-slider select[name="DMVT_ID"]').val(val).trigger("change");
			console.log($('.form-slider select[name="DMVT_ID"]').val());
		});

		$("#upload-modal .form_datetime").each(function(){
			$(this).datetimepicker({
		        format: 'Y/m/d',
		        timepicker: false,
		        autoclose: true,
		        todayBtn: true
		    });
		});

		$('#upload-modal select').each(function(){
            if(!$(this).hasClass('select2-hidden-accessible')){
                var is_multiple = $(this).prop('multiple');
                $(this).select2();
                if(is_multiple){
                    $(this).on("select2:selecting", function(e) { 
                        $(this).val(null).trigger('change');
                    });
                }
            }
        });


		$('.collapse-link-custom').click(function(){
			$(".box-common-edit-add").slideUp();
			return false;
		});
	});
</script>