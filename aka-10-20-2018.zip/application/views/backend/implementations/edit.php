<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="col-sm-6">
		<div class="form-group"> 
			<label class="control-label" for="Chuyen_ID">Tên chuyên<span class="required">*</span></label>
			<select id="Chuyen_ID" class="form-control" name="Chuyen_ID" required="required">   
		    	<?php if(isset($departments)){
		    		foreach ($departments as $key => $value) {
		    			if(@$post["Chuyen_ID"] == $value["ID"])
		    				echo '<option value="'.$value["ID"].'" selected>'.$value["Name"].'</option>';
		    			else 
		    				echo '<option value="'.$value["ID"].'">'.$value["Name"].'</option>';
		    		}
		    	}?>
			</select>
		</div>
	</div>
	<div class="col-sm-6">
		<div class="form-group"> 
			<label class="control-label" for="ChiTietMaHangID">Tên hàng<span class="required">*</span></label>
			<select id="ChiTietMaHangID" class="form-control" name="ChiTietMaHangID" required="required">   
		    	<?php if(isset($goods)){
		    		foreach ($goods as $key => $value) {
		    			if(@$post["ChiTietMaHangID"] == $value["ID"])
		    				echo '<option value="'.$value["ID"].'" selected>'.$value["TenMahang"].'</option>';
		    			else 
		    				echo '<option value="'.$value["ID"].'">'.$value["TenMahang"].'</option>';
		    		}
		    	}?>
			</select>
		</div>
	</div>
	<div class="col-sm-6">
		<div class="form-group"> 
			<label class="control-label" for="SoLuongThucHien">Số lượng thực hiện<span class="required">*</span></label>
			<input id="SoLuongThucHien" class="form-control" min="0" value="<?php echo @$post["SoLuongThucHien"]?>" name="SoLuongThucHien" placeholder="Nhập Số lượng thực hiện" type="number" required="required">
		</div>
	</div>
	<div class="col-sm-6">
		<div class="form-group"> 
			<label class="control-label" for="SoLuongKeHoach">Số lượng kế hoạch<span class="required">*</span></label>
			<input id="SoLuongKeHoach" class="form-control" min="0" value="<?php echo @$post["SoLuongKeHoach"]?>" name="SoLuongKeHoach" placeholder="Nhập Số lượng kế hoạch" type="number" required="required">
		</div>
	</div>
	<div class="col-sm-12">
		<div class="form-group"> 
			<label class="control-label" for="NgaySX">Ngày sản xuất<span class="required">*</span></label>
			<input id="NgaySX" class="form-control form_datetime" value="<?php echo @$post["NgaySX"];?>" name="NgaySX" placeholder="Nhập ngày sản xuất" type="text" required="required">
		</div>
	</div>
	
	<div class="col-sm-12">
		<div class="ln_solid"></div>
	</div>
	<div class="col-sm-12">
		<div class="form-group text-right">
			<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
			<button id="send" type="submit" class="btn btn-success">Thêm mới</button> 
		</div>
	</div>
</form>