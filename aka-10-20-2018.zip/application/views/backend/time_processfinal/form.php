<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="form-group"> 
		<label class="control-label">Thời gian xử lý sau cùng <span class="required">*</span></label>
		<input type="text" class="form-control" name="TimeProcessFinal" value="<?php echo number_format(@$record['TimeProcessFinal']); ?>" required>
	</div>
	<div class="form-group"> 
		<label class="control-label">Quy trình</label>
		<input type="text" class="form-control" value="<?php echo @$record['ProcessName']; ?>" readonly>
	</div>
	<div class="form-group"> 
		<label class="control-label">Thời gian xử lý nhỏ nhất</label>
		<input type="text" class="form-control" value="<?php echo number_format(@$record['TimProcessMin']); ?>" readonly>
	</div>
	<div class="form-group"> 
		<label class="control-label">Thời gian xử lý lớn nhất</label>
		<input type="text" class="form-control" value="<?php echo number_format(@$record['TimeProcessMax']); ?>" readonly>
	</div>
	<div class="form-group"> 
		<label class="control-label">Thời gian xử lý trung bình</label>
		<input type="text" class="form-control" value="<?php echo number_format(@$record['TimeProcessAverage']); ?>" readonly>
	</div>
	<div class="form-group"> 
		<label class="control-label">Số lượng mẫu trung bình</label>
		<input type="text" class="form-control" value="<?php echo number_format(@$record['NumOfSample']); ?>" readonly>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>