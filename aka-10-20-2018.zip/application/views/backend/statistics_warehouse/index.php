<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-7">
						<h2><?php echo @$title_page; ?> </h2>
					</div>
					<div class="col-sm-5">
						<form method="" method="get">
							<div class="row">
								<div class="col-sm-5">
									<div class="form-group">
										<input type="text" class="form-control" placeholder="Tên vật tư" name="keyword" value="<?php echo $this->input->get('keyword'); ?>">
									</div>
								</div>
								<div class="col-sm-5">
									<div class="form-group"> 
										<input class="form-control" placeholder="Khoảng thời gian"  name="daterange" value="<?php echo $this->input->get('daterange'); ?>" type="text">
									</div>
								</div>
								<div class="col-sm-2">
									<div class="form-group">
										<button type="submit" class="btn btn-primary">Tìm kiếm</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="x_content">
			    <?php $this->load->view($backend_asset."/includes/message");?>
		    	<div class="table-responsive" style="overflow-x: auto !important;min-height: auto;">
			    	<table class="table table-striped jambo_table bulk_action not-datatable">
						<thead>
							<tr class="headings">
								<th>#</th>
								<th>Barcode</th>
								<th>Tên vật tư</th>
								<th>Đơn vị tính</th>
								<th>Tồn kho</th>
								<th>Số lượng nhập</th>
								<th>Số lượng xuất</th>
							</tr>
						</thead>
						<tbody>
							<?php if(isset($results) && $results != null): ?>
								<?php foreach ($results as $key => $item): ?>
									<tr>
										<td><?php echo $key+1; ?></td>
										<td><?php echo $item['Barcode']; ?></th>
										<td><?php echo $item['Name']; ?></th>
										<td><?php echo $item['DVTName']; ?></th>
										<td><?php echo @$item['TotalTon'] != null  ? number_format($item['TotalTon']) : '0'; ?></th>
										<td><?php echo @$item['TotalNhap'] != null ? number_format($item['TotalNhap']) : '0'; ?></th>
										<td><?php echo @$item['TotalXuat'] != null ? number_format($item['TotalXuat']) : '0'; ?></td>
									</tr>
								<?php endforeach; ?>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
				<?php if(isset($this->pagination)): ?>
					<div class="row">
						<div class="col-sm-12 text-center">
							<?php echo @$this->pagination->create_links();?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$('input[name="daterange"]').daterangepicker({
            opens: 'left',
            locale: {
                format: 'YYYY/MM/DD'
            }
        });
	});
</script>
<style type="text/css">
	.calendar-table table tr th {color: #000;}
	.border-error{border:1px solid #ff0000 !important;}
</style>