<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-12">
						<h2><?php echo @$title_page; ?> </h2>
					</div>
				</div>
			</div>
			<div class="x_content">
			    <?php $this->load->view($backend_asset."/includes/message");?>
			    <form action="" method="post">
					<div class="row" id="box-info-goods">
						<div class="col-sm-3">
							<p>Tổng số lượng</p>
							<input class="form-control" type="text" id="number-total" value readonly>
						</div>
						<div class="col-sm-3">
							<p>Ngày bắt đầu</p>
							<input class="form-control" type="text" id="start-day" value readonly>
						</div>
						<div class="col-sm-3">
							<p>Ngày kết thúc</p>
							<input class="form-control" type="text" id="end-day" value readonly>
						</div>
						<div class="col-sm-3">
							<p>Số lượng còn lại</p>
							<input class="form-control" type="text" id="number-total-rest" value readonly>
						</div>
					</div>
			    	<div class="row">
			    		<div class="col-sm-3">
							<div class="form-group"> 
								<select class="form-control" name="MaHang_ID" required="required">
									<option value="">Chọn Mã hàng *</option>
									<?php if(isset($plu_result) && $plu_result != null): ?>
										<?php foreach ($plu_result as $key => $item): ?>
											<option data-index="<?php echo $key;?>" <?php echo $item['ID'] == @$record['MaHang_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
										<?php endforeach; ?>
									<?php endif; ?>
								</select>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="form-group"> 
								<select class="form-control" name="Group_ID" required="required">
									<option value="">Chọn Nhóm kích thước *</option>
									<?php if(isset($size_group_result) && $size_group_result != null): ?>
										<?php foreach ($size_group_result as $key => $item): ?>
											<option value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
										<?php endforeach; ?>
									<?php endif; ?>
								</select>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="form-group"> 
								<select class="form-control" name="color" multiple="">
									<option value="">Chọn màu sắc</option>
									<?php if(isset($color_result) && $color_result != null): ?>
										<?php foreach ($color_result as $key => $item): ?>
											<option value="<?php echo $item['ID']; ?>"><?php echo $item['MaMau']; ?></option>
										<?php endforeach; ?>
									<?php endif; ?>
								</select>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="text-right">
								<a href="<?php echo backend_url($folder_view);?>" class="btn btn-default">Hủy bỏ</a>
								<button type="submit" class="btn btn-primary">Lưu dữ liệu</button>
							</div>
						</div>
			    	</div>
			    	<div class="table-responsive table-add-more" style="overflow-x: auto !important;">
						<?php if(isset($action) && $action != null): ?>
							<?php $this->load->view($backend_asset.'/'.$folder_view.'/table',array('size_result' => @$size_result,'color_result' => @$color_result)); ?>
						<?php else: ?>
							<table class="table table-striped jambo_table bulk_action not-datatable">
								<thead>
									<tr class="headings">
										<th>Kích thước</th>
									</tr>
								</thead>
							</table>
						<?php endif; ?>
					</div>
			    </form>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change','select[name="Group_ID"]',function(){
			load_table();
		});

		$(document).on('change','select[name="color"]',function(){
			load_table();
		});

		function load_table(){
			var val = $('select[name="Group_ID"]').val();
			if(val != null && val != ''){
				var arr = [];
				$('select[name="color"] :selected').each(function(i, selected) {
				    arr.push($(selected).val());
				});
				console.log(arr.join(','));
				var url = '<?php echo backend_url($folder_view."/load_table/"); ?>' + val;
	            $.ajax({
	                type: 'POST',
	                dataType:'html',
	                url: url,
	                data:{color:arr.join(',')},
	                success: function(html) {
	                	$('.table-add-more').html(html);
	                	$('input.daterange').daterangepicker({
				            opens: 'left',
				            autoUpdateInput: false,
				            locale: {
				                format: 'YYYY/MM/DD'
				            }
				        }, function(start, end, label) {
				            console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
				            $($(this)[0].element).val(start.format('YYYY/MM/DD') + ' - ' + end.format('YYYY/MM/DD'));
				            $($(this)[0].element).parent().find('input.StartDate').val(start.format('YYYY/MM/DD'));
				            $($(this)[0].element).parent().find('input.EndDate').val(end.format('YYYY/MM/DD'));
				        });
	                }
	            });
			}
			return false;
		}


		$('form').submit(function(){
			var check = true;
			var check_input = false;
			$(this).find('.daterange').each(function(){
				var current = $(this);
				var date = current.val();
				var current_soluong = current.parents('td').find('.format-number');
				var soluong = current_soluong.val();
				if(soluong != ''){
					if(date == ''){
						current.addClass('border-error');
						check = false;
					}
					else{
						current.removeClass('border-error');
					}
					check_input = true;
				}

				if(date != ''){
					if(soluong == ''){
						current_soluong.addClass('border-error');
						check = false;
					}
					else{
						current_soluong.removeClass('border-error');
					}
					check_input = true;
				}
			});
			if(!check_input){
				alert('Vui lòng nhập đầy đủ dữ liêu.');
				return check_input;
			}
			return check;
		});
		$('input.daterange').daterangepicker({
            opens: 'left',
            autoUpdateInput: false,
            locale: {
                format: 'YYYY/MM/DD'
            }
        }, function(start, end, label) {
            console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
            $($(this)[0].element).val(start.format('YYYY/MM/DD') + ' - ' + end.format('YYYY/MM/DD'));
            $($(this)[0].element).parent().find('input.StartDate').val(start.format('YYYY/MM/DD'));
            $($(this)[0].element).parent().find('input.EndDate').val(end.format('YYYY/MM/DD'));
        });

        $("input.daterange").blur(function() {
		  	var val = $(this).val();
		  	var date = val.split('-');
		  	var check = true;
		  	if (typeof date[0] == 'undefined' || typeof date[1] == 'undefined'){
		  		$(this).val('');
		  		check = false;
		  	}
		  	if(check){
		  		if(!moment($.trim(date[0]), 'YYYY/MM/DD', true).isValid() || !moment($.trim(date[1]), 'YYYY/MM/DD', true).isValid()){         
			        $(this).val('');
			    }
		  	}
		});
	});
</script>
<style type="text/css">
	.calendar-table table tr th {color: #000;}
	.border-error{border:1px solid #ff0000 !important;}
	#box-info-goods{
		display:none;
		margin-bottom:20px;
	}
	html .daterangepicker{
		max-width:495px!important;
	}
    html .daterangepicker .ranges {
    float: right!important;
    width: 100%!important;
    text-align: right!important;
}
</style>

<script>
	var $plu_result = <?php echo json_encode($plu_result);?>;
	$(document).ready(function(){
		$("select[name=MaHang_ID]").change(function(){
			var index = $(this).find('option:selected', this).attr('data-index');
			if(typeof $plu_result[index] != 'null' && typeof $plu_result[index] != 'undefined'){
				var $data = $plu_result[index];
				$("#number-total").val($data["TongSoLuong"]);
				$("#start-day").val($data["StartDate"]);
				$("#end-day").val($data["EndDate"]);
				$("#box-info-goods").show();
			}else{
				$("#box-info-goods").hide();
			}
		})
	})
</script>