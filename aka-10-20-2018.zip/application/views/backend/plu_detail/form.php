<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Mã hàng <span class="required">*</span></label>
				<select class="form-control" name="MaHang_ID" required="required">
					<option value="">Chọn</option>
					<?php if(isset($plu_result) && $plu_result != null): ?>
						<?php foreach ($plu_result as $key => $item): ?>
							<option data-start-date="<?php echo @$item["StartDate"] != null ? date('Y/m/d',strtotime($item["StartDate"])) : ''; ?>" data-end-date="<?php echo @$item["EndDate"] != null ? date('Y/m/d',strtotime($item["EndDate"])) : ''; ?>" <?php echo $item['ID'] == @$record['MaHang_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Màu sắc <span class="required">*</span></label>
				<select class="form-control" name="Color_ID" io>
					<option value="">Chọn</option>
					<?php if(isset($color_result) && $color_result != null): ?>
						<?php foreach ($color_result as $key => $item): ?>
							<option <?php echo $item['ID'] == @$record['Color_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['MaMau']; ?></option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Kích thước <span class="required">*</span></label>
				<select class="form-control" name="Size_ID" required="required">
					<option value="">Chọn</option>
					<?php if(isset($size_result) && $size_result != null): ?>
						<?php foreach ($size_result as $key => $item): ?>
							<option data-group="<?php echo $item['GroupName']; ?>" <?php echo $item['ID'] == @$record['Size_ID'] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Nhóm kích thước</label>
				<input type="text" name="size-group" value="" class="form-control" readonly="">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Số lượng <span class="required">*</span></label>
				<input class="form-control format-number" value="<?php echo @$record["SoLuong"]; ?>" name="SoLuong" type="text" required="required">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group"> 
				<label class="control-label">Ngày bắt đầu - ngày kết thúc <span class="required">*</span></label>
				<input class="form-control" value="<?php echo @$record["StartDate"] != null ? date('Y/m/d',strtotime($record["StartDate"])).' - ' : ''; ?> <?php echo @$record["EndDate"] != null ? date('Y/m/d',strtotime($record["EndDate"])) : ''; ?>" name="daterange" type="text" required="required" disabled="disabled">
				<input class="form-control" value="<?php echo @$record["StartDate"] != null ? date('Y/m/d',strtotime($record["StartDate"])) : ''; ?>" name="StartDate" type="hidden">
				<input class="form-control" value="<?php echo @$record["EndDate"] != null ? date('Y/m/d',strtotime($record["EndDate"])) : ''; ?>" name="EndDate" type="hidden">
			</div>
		</div>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>
<script type="text/javascript">
	$(document).ready(function(){
		var customerName = $('select[name="Size_ID"]').find(":selected").attr('data-group');
		$('select[name="Size_ID"]').parents('form').find('input[name="size-group"]').val(customerName);
		

		$('select[name="Size_ID"]').change(function(){
			var customerName = $(this).find(":selected").attr('data-group');
			$(this).parents('form').find('input[name="size-group"]').val(customerName);
		});
	});
</script>

<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change', 'select[name="MaHang_ID"]', function() {
			var start_date = $(this).find(":selected").attr('data-start-date');
			var end_date = $(this).find(":selected").attr('data-end-date');
			if (typeof start_date !== typeof undefined && start_date !== false && typeof end_date !== typeof undefined && end_date !== false) {
			    $(this).parents('form').find('input[name="daterange"]').val(start_date + ' - ' + end_date);
			    $(this).parents('form').find('input[name="StartDate"]').val(start_date);
			    $(this).parents('form').find('input[name="EndDate"]').val(end_date);
			}
			else{
				$(this).parents('form').find('input[name="daterange"]').val('');
				$(this).parents('form').find('input[name="StartDate"]').val('');
				$(this).parents('form').find('input[name="EndDate"]').val('');
			}
		});
	});
</script>