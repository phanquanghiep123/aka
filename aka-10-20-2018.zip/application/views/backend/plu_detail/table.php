<table class="table table-striped jambo_table bulk_action not-datatable">
	<thead>
		<tr class="headings">
			<th class="text-center">#</th>
			<?php if(isset($size_result) && $size_result != null): ?>
				<?php foreach ($size_result as $key => $item): ?>
					<th class="text-center"><?php echo $item['Name']; ?></th>
				<?php endforeach; ?>
			<?php endif; ?>
		</tr>
	</thead>
	<tbody>
	    <?php if(isset($color_result) && $color_result != null): ?>
	        <?php foreach ($color_result as $key => $item): ?>
	    		<tr style="background-color: #fff;">
					<td style="vertical-align: middle;"><?php echo $item['MaMau']; ?></td>
					<?php if(isset($size_result) && $size_result != null): ?>
						<?php foreach ($size_result as $key1 => $item1): ?>
							<td style="min-width:200px;">
								<div class="form-group">
									<input type="text" class="format-number form-control" placeholder="Số lượng" name="soluong[<?php echo $item['ID']; ?>][<?php echo $item1['ID']; ?>]">
								</div>
								<div class="form-group">
									<input type="text" class="form-control daterange" placeholder="Ngày bắt đầu - Ngày kết thúc" name="date[<?php echo $item['ID']; ?>][<?php echo $item1['ID']; ?>]">
									<input class="form-control StartDate" value="" name="StartDate[<?php echo $item['ID']; ?>][<?php echo $item1['ID']; ?>]" type="hidden">
									<input class="form-control EndDate" value="" name="EndDate[<?php echo $item['ID']; ?>][<?php echo $item1['ID']; ?>]" type="hidden">
								</div>
							</td>
						<?php endforeach; ?>
					<?php endif; ?>
				</tr>
		    <?php endforeach; ?>
	    <?php endif; ?>
	</tbody>
</table>