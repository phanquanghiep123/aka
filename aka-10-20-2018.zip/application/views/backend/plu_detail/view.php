<div class="main-page <?php echo @$main_page;?> row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
				<div class="row">
					<div class="col-sm-12">
						<h2><?php echo @$title_page; ?> </h2>
					</div>
				</div>
			</div>
			<div class="x_content">
			    <?php $this->load->view($backend_asset."/includes/message");?>
			    <form action="<?php echo backend_url($folder_view.'/view/'.$record['ID']); ?>" method="post">
			    	<div class="row">
			    		<div class="col-xs-6">
			    			<h5><?php echo $record['PluName'].' | '.$record['SizeName'].' | '.$record['MaMau']; ?></h5>
			    		</div>
			    		<div class="col-xs-6">
			    			<div class="text-right">
					    		<button type="submit" class="btn btn-primary">Lưu dữ liệu</button>
					    	</div>
			    		</div>
			    	</div>
			    	<div class="table-responsive" style="overflow-x: auto !important;min-height: auto;">
				    	<table class="table table-striped jambo_table bulk_action not-datatable">
							<thead>
								<tr class="headings">
									<th>#</th>
									<?php for($i = 0; $i <= $numberDays; $i++): ?>
										<th class="text-center"><?php echo date('d/m',strtotime("+".$i." day", strtotime($record['StartDate']))); ?></th>
									<?php endfor; ?>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td style="min-width:100px;vertical-align: middle;">SL kế hoạch</td>
									<?php for($i = 0; $i <= $numberDays; $i++): ?>
										<td class="text-center"><?php echo number_format($record['SoLuong']); ?></td>
									<?php endfor; ?>
								</tr>
								<tr>
									<td style="min-width:100px;vertical-align: middle;">SL bố trí</td>
									<?php for($i = 0; $i <= $numberDays; $i++): ?>
										<?php $date = date('Y-m-d',strtotime("+".$i." day", strtotime($record['StartDate']))); ?>
										<?php if($date <= date('Y-m-d')): ?>
											<?php
												$sl = '';
												if(isset($kehoachsx) && $kehoachsx != null){
													foreach ($kehoachsx as $key => $item) {
														if($date == date('Y-m-d',strtotime($item['Date']))){
															$sl = $item['SoLuong'];
															break;
														}
													}
												}
											?>
											<td style="min-width:70px;">
												<div class="form-group">
													<input type="text" class="format-number form-control" value="<?php echo $sl; ?>" placeholder="SL" name="soluong[<?php echo $i; ?>]">
												</div>
											</td>
										<?php else: ?>
											<td></td>
										<?php endif; ?>
									<?php endfor; ?>
								</tr>
							</tbody>
						</table>
					</div>
			    </form>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$('form').submit(function(){
			var check = true;
			$(this).find('input[type="text"]').each(function(){
				var current = $(this);
				var soluong = current.val();
				if(soluong == '' || soluong == null){
					current.addClass('border-error');
					check = false;
				}
				else{
					current.removeClass('border-error');
				}
			});
			return check;
		});
	});
</script>
<style type="text/css">
	.calendar-table table tr th {color: #000;}
	.border-error{border:1px solid #ff0000 !important;}
</style>