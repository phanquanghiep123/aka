<form class="form-horizontal form-label-left" action="<?php echo @$action; ?>" method="post" enctype="multipart/form-data">
	<div class="message alert alert-success" style="display: none;"></div>
    <div class="message alert alert-danger" style="display: none;"></div>
	<div class="form-group"> 
		<label class="control-label">Tên nhóm <span class="required">*</span></label>
		<input class="form-control" value="<?php echo @$record["Name"]; ?>" name="Name" type="text" required="required">
	</div>
	<div class="form-group">
		<label class="control-label">Nhóm kích thước <span class="required">*</span></label>
		<select class="form-control" name="SizeGroup_ID" required="">
			<option value="">Chọn</option>
			<?php if(isset($sizegroup_result) && $sizegroup_result != null): ?>
				<?php foreach ($sizegroup_result as $key => $item): ?>
					<option <?php echo $item['ID'] == @$record["SizeGroup_ID"] ? 'selected' : ''; ?> value="<?php echo $item['ID']; ?>"><?php echo $item['Name']; ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</div>
	<div class="form-group"> 
		<label class="control-label">Mô tả</label>
		<textarea class="form-control" rows="5" name="Description"><?php echo @$record["Description"]; ?></textarea>
	</div>
	<div class="ln_solid"></div>
	<div class="form-group text-right">
		<button type="button" onclick="$('.collapse-link-custom').trigger('click');return false;" class="btn btn-default" data-dismiss="modal">Hủy bỏ</button>
		<button id="send" type="submit" class="btn btn-success"><?php echo @$type == 'add' ? 'Thêm mới' : 'Cập nhật'; ?></button> 
	</div>
</form>